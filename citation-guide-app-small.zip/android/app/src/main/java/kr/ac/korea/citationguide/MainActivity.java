package kr.ac.korea.citationguide;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
