(function(){var d=document,msg=d.getElementById('fmsg');
function say(t,ok){if(!msg)return;msg.textContent=t;msg.className='fmsg '+(ok?'ok':'bad')}
var DL=null,tried=false;
async function getDL(){if(tried)return DL;tried=true;try{if(window.claude&&window.claude.use)DL=await window.claude.use('downloads')}catch(e){DL=null}return DL}
async function getBuf(b){var r=await fetch(b.dataset.src);if(!r.ok)throw new Error('파일을 불러오지 못했습니다('+r.status+')');
 var u8,mime=b.dataset.mime,pdf=mime==='application/pdf';
 if(b.dataset.kind==='b64'){var s=atob((await r.text()).replace(/\s+/g,'')),n=s.length;u8=new Uint8Array(n);for(var i=0;i<n;i++)u8[i]=s.charCodeAt(i)}
 else u8=new Uint8Array(await r.arrayBuffer());
 var h=String.fromCharCode(u8[0],u8[1],u8[2],u8[3]);
 if(pdf?h!=='%PDF':h.slice(0,2)!=='PK')throw new Error('파일 내용이 올바르지 않습니다');
 var want=+b.dataset.bytes||0;if(want&&u8.length!==want)throw new Error('파일이 끝까지 받아지지 않았습니다('+u8.length+'/'+want+' 바이트). 다시 눌러 주세요');
 return u8.buffer}
function errMsg(e){var c=e&&e.code;return c==='declined'?'저장을 취소했습니다.':c==='rate_limited'?'이미 열려 있는 저장 확인창을 먼저 닫거나 허락한 뒤 다시 눌러 주세요.':c==='rejected_extension'?'이 형식은 저장할 수 없습니다.':'저장하지 못했습니다: '+((e&&e.message)||'알 수 없는 오류')}
async function save(name,buf,okmsg){var D=await getDL();if(!D){say('이 화면에서는 저장 기능을 쓸 수 없습니다. 공유 주소를 브라우저에서 직접 열어 다시 시도해 주세요.',false);return false}
 try{await D.save({filename:name,data:buf});say(okmsg||('“'+name+'” 저장을 요청했습니다. 확인창에서 허락하면 저장됩니다.'),true);return true}catch(e){say(errMsg(e),false);return false}}
async function onClick(b){var lab=b.innerHTML;b.disabled=true;b.textContent='준비 중…';say('파일을 준비하고 있습니다…',true);
 try{var bf=await getBuf(b);await save(b.dataset.name,bf)}catch(e){say(errMsg(e),false)}b.disabled=false;b.innerHTML=lab}
d.querySelectorAll('.dlb2:not(.zipall)').forEach(function(b){b.addEventListener('click',function(){onClick(b)})});
getDL().then(function(x){if(!x)say('이 화면에서는 ⬇ 저장이 켜져 있지 않습니다. 파일은 “열기”로 화면 안에서 볼 수 있습니다.',false)});
// ---- 전체 zip (저장 방식, 외부 라이브러리 없음)
var CT=null;function crc(u8){if(!CT){CT=new Uint32Array(256);for(var n=0;n<256;n++){var c=n;for(var k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;CT[n]=c>>>0}}var c=0xFFFFFFFF;for(var i=0;i<u8.length;i++)c=CT[(c^u8[i])&255]^(c>>>8);return(c^0xFFFFFFFF)>>>0}
function zip(files){var enc=new TextEncoder(),parts=[],cen=[],off=0,now=new Date(),dt=((now.getFullYear()-1980)<<9)|((now.getMonth()+1)<<5)|now.getDate(),tm=(now.getHours()<<11)|(now.getMinutes()<<5)|(now.getSeconds()>>1);
 files.forEach(function(f){var nm=enc.encode(f.name),u=new Uint8Array(f.buf),c=crc(u),h=new DataView(new ArrayBuffer(30));
  h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x0800,true);h.setUint16(8,0,true);h.setUint16(10,tm,true);h.setUint16(12,dt,true);h.setUint32(14,c,true);h.setUint32(18,u.length,true);h.setUint32(22,u.length,true);h.setUint16(26,nm.length,true);h.setUint16(28,0,true);
  parts.push(h.buffer,nm,u);
  var ch=new DataView(new ArrayBuffer(46));ch.setUint32(0,0x02014b50,true);ch.setUint16(4,20,true);ch.setUint16(6,20,true);ch.setUint16(8,0x0800,true);ch.setUint16(10,0,true);ch.setUint16(12,tm,true);ch.setUint16(14,dt,true);ch.setUint32(16,c,true);ch.setUint32(20,u.length,true);ch.setUint32(24,u.length,true);ch.setUint16(28,nm.length,true);ch.setUint32(42,off,true);
  cen.push(ch.buffer,nm);off+=30+nm.length+u.length});
 var cs=0;cen.forEach(function(x){cs+=x.byteLength||x.length});
 var e=new DataView(new ArrayBuffer(22));e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,cs,true);e.setUint32(16,off,true);
 return new Blob(parts.concat(cen,[e.buffer]),{type:'application/zip'})}
var zb=d.getElementById('zipall'),zp=d.getElementById('zipprog');
if(zb)zb.addEventListener('click',async function(){var all=[],seen={};d.querySelectorAll('.dlb2:not(.zipall)').forEach(function(b){if(!seen[b.dataset.src]){seen[b.dataset.src]=1;all.push(b)}});
 zb.disabled=true;var files=[],used={};
 try{for(var i=0;i<all.length;i++){var b=all[i];zp.textContent='파일 모으는 중… '+(i+1)+' / '+all.length+' · '+b.dataset.name;var nm=b.dataset.name;if(used[nm])nm=(i+1)+'_'+nm;used[nm]=1;files.push({name:nm,buf:await getBuf(b)})}
  zp.textContent='압축 파일을 만드는 중…';var bl=zip(files);zp.textContent='';
  await save('학술 논문 작성 방법 안내 자료실 전체.zip',bl,'압축 파일 저장을 요청했습니다('+files.length+'개 파일). 확인창에서 허락하면 저장됩니다.')}
 catch(e){zp.textContent='';say(errMsg(e),false)}zb.disabled=false});
// ---- 화면 안에서 열기 (PDF: pdf.js, Word: mammoth)
var V=d.getElementById('fview'),vb=d.getElementById('fvb'),cur=null,pdf=null,pg=1;
function ld(src){return new Promise(function(ok,no){var s=d.createElement('script');s.src=src;s.onload=ok;s.onerror=function(){no(new Error('보기 도구를 불러오지 못했습니다'))};d.head.appendChild(s)})}
async function showPage(){if(!pdf)return;var p=await pdf.getPage(pg),w=Math.min(vb.clientWidth-16,900),v0=p.getViewport({scale:1}),sc=w/v0.width,v=p.getViewport({scale:sc*(window.devicePixelRatio>1?1.5:1.2)}),c=vb.querySelector('canvas')||vb.appendChild(d.createElement('canvas'));
 c.width=v.width;c.height=v.height;c.style.width=w+'px';c.style.height=(v.height/(v.width/w))+'px';await p.render({canvasContext:c.getContext('2d'),viewport:v}).promise;d.getElementById('fvn').textContent=pg+' / '+pdf.numPages;vb.scrollTop=0}
async function openIt(b){cur=b;V.hidden=false;d.getElementById('fvt').textContent=b.dataset.name;vb.innerHTML='<p class="mut">파일을 불러오는 중…</p>';d.getElementById('fvn').textContent='';
 var pn=d.querySelector('.fvnav'),SP=d.getElementById('fsplit');SP&&SP.classList.add('open');try{var r0=SP.getBoundingClientRect();if(r0.top<-40||r0.top>200)SP.scrollIntoView({behavior:'smooth',block:'start'})}catch(e){}
 try{var buf=await getBuf(b);
  if(b.dataset.mime==='application/pdf'){pn.style.display='';if(!window.pdfjsLib)await ld('vendor/pdf.min.js');pdfjsLib.GlobalWorkerOptions.workerSrc='vendor/pdf.worker.min.js';pdf=await pdfjsLib.getDocument({data:new Uint8Array(buf.slice(0))}).promise;pg=1;vb.innerHTML='';await showPage()}
  else{pn.style.display='none';pdf=null;if(!window.mammoth)await ld('vendor/mammoth.browser.min.js');vb.innerHTML='<p class="mut">Word 문서를 화면용으로 바꾸는 중입니다. 큰 파일은 몇 초 걸립니다…</p>';
   var r=await mammoth.convertToHtml({arrayBuffer:buf.slice(0)},{convertImage:mammoth.images.imgElement(function(){return Promise.resolve({src:'data:image/gif;base64,R0lGODlhAQABAAAAACw='})})});
   vb.innerHTML='<div class="fvdoc">'+r.value.replace(/<img[^>]*>/g,'')+'</div><p class="mut">화면용 미리보기입니다. 그림·쪽 나누기·글자 모양은 실제 파일과 다를 수 있으니, 정확한 모양은 저장해서 Word나 한글에서 확인하세요.</p>'}}
 catch(e){vb.innerHTML='<p class="fmsg bad">열지 못했습니다: '+((e&&e.message)||'')+'</p>'}}
d.querySelectorAll('.dlv').forEach(function(b){b.addEventListener('click',function(){openIt(b)})});
if(V){d.getElementById('fvc').onclick=function(){V.hidden=true;vb.innerHTML='';pdf=null;var SP=d.getElementById('fsplit');SP&&SP.classList.remove('open')};d.addEventListener('keydown',function(e){if(e.key==='Escape'&&!V.hidden)d.getElementById('fvc').onclick()});
 d.getElementById('fvp').onclick=function(){if(pdf&&pg>1){pg--;showPage()}};d.getElementById('fvx').onclick=function(){if(pdf&&pg<pdf.numPages){pg++;showPage()}};
 d.getElementById('fvs').onclick=function(){if(cur)onClick(cur)}}
})();
