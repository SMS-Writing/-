(function(){var d=document;
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
// ===== 오른쪽 게임 메뉴 =====
var gp=d.getElementById('gp'),gb=d.getElementById('gpb');
function gpset(o){if(!gp)return;gp.classList.toggle('open',o);d.body.classList.toggle('gpo',o);if(gb)gb.setAttribute('aria-expanded',o?'true':'false')}
if(gp){if(gb)gb.addEventListener('click',function(){gpset(!gp.classList.contains('open'))});
 var gx=d.getElementById('gpx');if(gx)gx.addEventListener('click',function(){gpset(false)});
 d.addEventListener('keydown',function(e){if(e.key==='Escape'&&!e.target.closest('#ffp'))gpset(false)});
 d.querySelectorAll('.gpt').forEach(function(t){t.addEventListener('click',function(){t.parentNode.classList.toggle('shut')})});
 d.querySelectorAll('[data-gpopen]').forEach(function(b){b.addEventListener('click',function(ev){ev.preventDefault();gpset(true)})});
 if(d.querySelector('main .ghead')&&innerWidth>=1400)gpset(true)}
// ===== 이 쪽에서 낱말 찾기 =====
var main=d.getElementById('main');
if(main&&!d.getElementById('ff')){
 var ff=d.createElement('div');ff.id='ff';ff.innerHTML='<span class="ffi" role="button" tabindex="0" aria-label="이 쪽에서 낱말 찾기 열기">🔎<b class="fft"> 이 쪽에서 낱말 찾기</b></span><input id="ffi" type="search" placeholder="이 쪽에서 낱말 찾기" aria-label="이 쪽에서 낱말 찾기" autocomplete="off"><span id="ffc" aria-live="polite"></span><button id="ffu" type="button" title="이전(Shift+Enter)" aria-label="이전">▲</button><button id="ffd" type="button" title="다음(Enter)" aria-label="다음">▼</button><button id="ffx" type="button" title="지우기(Esc)" aria-label="지우기">✕</button>';
 d.body.appendChild(ff);ff.querySelector('.ffi').addEventListener('click',function(){ff.classList.add('open');d.getElementById('ffi').focus()});d.addEventListener('keydown',function(e){if((e.key==='/'||(e.key==='f'&&(e.ctrlKey||e.metaKey)&&e.shiftKey))&&!/INPUT|TEXTAREA|SELECT/.test((e.target||{}).tagName||'')){e.preventDefault();ff.classList.add('open');d.getElementById('ffi').focus()}});
 var inp=d.getElementById('ffi'),cnt=d.getElementById('ffc'),hits=[],cur=-1,tm=0;
 function clear(){main.querySelectorAll('mark.ffm').forEach(function(m){var p=m.parentNode;p.replaceChild(d.createTextNode(m.textContent),m);p.normalize()});hits=[];cur=-1;cnt.textContent='';ff.classList.remove('has')}
 function skip(n){for(var e=n.parentNode;e&&e!==main;e=e.parentNode){var t=e.tagName;if(t==='SCRIPT'||t==='STYLE'||t==='TEXTAREA'||t==='INPUT'||t==='BUTTON'||t==='SELECT'||t==='NOSCRIPT')return true;if(e.classList&&(e.classList.contains('tabs')||e.classList.contains('game')))return true}return false}
 function mark(q){clear();if(!q)return;var ql=q.toLowerCase(),w=d.createTreeWalker(main,NodeFilter.SHOW_TEXT,null),ns=[],n;
  while((n=w.nextNode())){if(n.nodeValue.toLowerCase().indexOf(ql)>=0&&!skip(n))ns.push(n)}
  ns.forEach(function(t){if(hits.length>=600)return;var s=t.nodeValue,l=s.toLowerCase(),i=0,j,frag=d.createDocumentFragment();
   while((j=l.indexOf(ql,i))>=0&&hits.length<600){if(j>i)frag.appendChild(d.createTextNode(s.slice(i,j)));var m=d.createElement('mark');m.className='ffm';m.textContent=s.slice(j,j+q.length);frag.appendChild(m);hits.push(m);i=j+q.length}
   frag.appendChild(d.createTextNode(s.slice(i)));t.parentNode.replaceChild(frag,t)});
  if(!hits.length){cnt.textContent='없음';ff.classList.add('has');return}
  ff.classList.add('has');go(0)}
 function reveal(el){var dt=el.closest('details');while(dt){dt.open=true;dt=dt.parentNode&&dt.parentNode.closest&&dt.parentNode.closest('details')}
  var pane=el.closest('.tabpane');if(pane&&pane.hidden){var ps=Array.prototype.slice.call(main.querySelectorAll('.tabpane')),i=ps.indexOf(pane),tb=main.querySelectorAll('.tabs .tab')[i];if(tb)tb.click()}
  var hp=el.closest('[hidden]');if(hp&&hp.classList.contains('hometab')===false){/* 숨은 구역은 열지 않음 */}}
 function go(i){if(!hits.length)return;if(cur>=0&&hits[cur])hits[cur].classList.remove('cur');cur=(i+hits.length)%hits.length;var m=hits[cur];reveal(m);m.classList.add('cur');
  cnt.textContent=(cur+1)+'/'+hits.length;setTimeout(function(){var tb=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||110)+30,r=m.getBoundingClientRect();scrollTo({top:Math.max(0,scrollY+r.top-Math.max(tb,innerHeight*.3)),behavior:'auto'})},40)}
 inp.addEventListener('input',function(){clearTimeout(tm);tm=setTimeout(function(){mark(inp.value.trim())},180)});
 inp.addEventListener('blur',function(){if(!inp.value)ff.classList.remove('open')});inp.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();if(!hits.length)mark(inp.value.trim());else go(cur+(e.shiftKey?-1:1))}else if(e.key==='Escape'){inp.value='';clear();inp.blur()}});
 d.getElementById('ffd').onclick=function(){if(!hits.length)mark(inp.value.trim());else go(cur+1)};
 d.getElementById('ffu').onclick=function(){if(!hits.length)mark(inp.value.trim());else go(cur-1)};
 d.getElementById('ffx').onclick=function(){inp.value='';clear()}}
// ===== 게임 단추를 누른 뒤 게임 위쪽이 보이게 =====
d.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('.game button,.game .gb,#gwrap button,.gbtn,.nxt,[data-nx]');if(!b)return;var g=b.closest('.game')||d.getElementById('gwrap');if(!g)return;
 setTimeout(function(){var tb=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||110)+8,r=g.getBoundingClientRect();if(r.top<tb-4&&r.bottom>0)scrollTo({top:Math.max(0,scrollY+r.top-tb),behavior:'auto'})},60)},true);
d.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('.sgb,#sglast,#sgrg');if(!b)return;setTimeout(function(){var g=d.getElementById('gwrap');if(!g)return;var tb=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||110)+8;scrollTo({top:Math.max(0,scrollY+g.getBoundingClientRect().top-tb),behavior:'auto'})},450)},true);
// ===== 질문으로 페이지 찾기 =====
var af=d.getElementById('aif');
if(af){var q=d.getElementById('aifq'),go2=d.getElementById('aifgo'),out=d.getElementById('aifout'),busy=false,D=window.SEARCH||[];
 var STOP=/^(어떻게|무엇|뭐|어디|어느|언제|왜|알려|알고|싶|싶어|싶은데|하면|해야|하나요|인가요|있나요|되나요|돼요|해요|좀|그리고|그런데|저는|제가|내가|나는|에서|관련|대해|대한|방법|하는|한다|합니다|써야|쓰나요|어떤)$/;
 function toks(s){return s.toLowerCase().replace(/[^0-9a-z가-힣\s\-]/g,' ').split(/\s+/).map(function(w){return w.replace(/(으로|에서|에게|까지|부터|이란|이라|란|은|는|이|가|을|를|에|의|도|로|와|과|랑|요|나요|인가요|할까요|하나요|해요|하는|하려면|하면)$/,'')}).filter(function(w){return w.length>=2&&!STOP.test(w)})}
 function local(qs){var ks=toks(qs),map={};if(!ks.length)return [];
  D.forEach(function(r){var h=(r.h||'').toLowerCase(),x=(r.x||'').toLowerCase(),p=(r.p||'').toLowerCase(),s=0;ks.forEach(function(k){if(h.indexOf(k)>=0)s+=8;if(p.indexOf(k)>=0)s+=3;if(x.indexOf(k)>=0)s+=2});
   if(s>0){var key=r.u;if(!map[key]||map[key].s<s)map[key]={u:r.u,h:r.h,p:r.p,x:r.x,s:s}}});
  return Object.keys(map).map(function(k){return map[k]}).sort(function(a,b){return b.s-a.s}).slice(0,25)}
 function show(list,note){out.innerHTML=(note?'<p class="mut aifn">'+esc(note)+'</p>':'')+(list.length?'<ol class="aifl">'+list.map(function(r){return '<li><a href="'+esc(r.u)+'"><b>'+esc(r.h||r.p)+'</b><small>'+esc(r.p&&r.p!==r.h?r.p:'')+'</small></a>'+(r.why?'<p>'+esc(r.why)+'</p>':'')+'</li>'}).join('')+'</ol>':'<p class="mut">알맞은 쪽을 찾지 못했습니다. 낱말을 바꾸어 다시 물어보세요.</p>');out.hidden=false}
 async function ask(){var qs=q.value.trim();if(!qs||busy)return;busy=true;go2.disabled=true;go2.textContent='찾는 중…';out.hidden=false;out.innerHTML='<p class="mut">알맞은 쪽을 찾고 있습니다…</p>';
  var cand=local(qs),smp=null;
  try{if(window.claude&&window.claude.use)smp=await window.claude.use('sample')}catch(e){}
  if(!smp){show(cand.slice(0,6),'AI를 쓸 수 없는 환경이라 낱말을 비교해 찾았습니다.');busy=false;go2.disabled=false;go2.textContent='찾기';return}
  if(cand.length<8){var seen={};D.forEach(function(r){if(!seen[r.u]&&cand.length<40){seen[r.u]=1;if(!cand.some(function(c){return c.u===r.u}))cand.push({u:r.u,h:r.h,p:r.p,x:r.x,s:0})}})}
  var lines=cand.map(function(c,i){return (i+1)+'. '+c.u+' | '+(c.p||'')+' | '+(c.h||'')+' | '+(c.x||'').slice(0,70).replace(/\s+/g,' ')}).join('\n');
  var pr='너는 대학 글쓰기 안내서 홈페이지의 안내원이다. 학생의 질문에 가장 알맞은 쪽을 아래 후보에서만 골라라. 후보에 없는 주소를 만들지 마라. 1~3개를 골라 중요한 순서로 쓰고, 각각 이 쪽에서 무엇을 볼 수 있는지 한국어 한 문장(40자 이내)으로 적어라. 알맞은 쪽이 없으면 빈 배열을 돌려줘라.\n출력은 JSON 하나만: {"pages":[{"u":"후보의 주소 그대로","why":"한 문장"}]}\n\n학생 질문: '+qs.slice(0,300)+'\n\n후보(번호. 주소 | 쪽 | 제목 | 내용 앞부분):\n'+lines;
  try{var res=await smp.json(pr,{modelTier:'quick'}),arr=(res&&res.pages)||[],ok=[];arr.forEach(function(a){var c=cand.filter(function(c){return c.u===a.u})[0];if(c&&ok.length<3&&!ok.some(function(o){return o.u===c.u}))ok.push({u:c.u,h:c.h,p:c.p,why:String(a.why||'').slice(0,80)})});
   if(ok.length)show(ok,'');else show(cand.slice(0,5),'AI가 알맞은 쪽을 고르지 못해 낱말이 비슷한 쪽을 보여 드립니다.')}
  catch(e){var c2=e&&e.code;show(cand.slice(0,6),c2==='not_granted'?'AI 사용을 허락하지 않아 낱말을 비교해 찾았습니다.':(c2==='rate_limited'?'잠시 뒤에 다시 시도해 주세요. 우선 낱말이 비슷한 쪽을 보여 드립니다.':'AI 연결에 실패해 낱말을 비교해 찾았습니다.'))}
  busy=false;go2.disabled=false;go2.textContent='찾기'}
 go2.addEventListener('click',ask);q.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();ask()}});
 d.querySelectorAll('.aifex').forEach(function(b){b.addEventListener('click',function(){q.value=b.textContent;ask()})})}
})();
// ---- 틀·예·약어 칸마다 복사 단추
(function(){var d=document;function run(){
 function toast(s){var e=d.createElement('div');e.className='copied';e.textContent=s;d.body.appendChild(e);setTimeout(function(){e.remove()},1300)}
 function copy(t){function fb(){var ta=d.createElement('textarea');ta.value=t;d.body.appendChild(ta);ta.select();try{d.execCommand('copy');toast('복사했습니다: '+t.slice(0,24))}catch(e){toast('복사하지 못했습니다')}ta.remove()}
  if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t).then(function(){toast('복사했습니다: '+t.slice(0,24))},fb);else fb()}
 function btn(label,text){var b=d.createElement('button');b.type='button';b.className='cpbtn';b.textContent=label;b.setAttribute('aria-label','복사: '+text);b.addEventListener('click',function(ev){ev.stopPropagation();copy(text)});return b}
 function clean(el){var c=el.cloneNode(true);c.querySelectorAll('.cpbtn').forEach(function(x){x.remove()});return c.innerText.replace(/\s+\n/g,'\n').trim()}
 function add(cell){if(cell.dataset.cpd||cell.closest('.game,.gbody'))return;cell.dataset.cpd='1';var ps=cell.querySelectorAll(':scope > p');
  if(ps.length>1){ps.forEach(function(p){var t=clean(p);if(t.length>3)p.appendChild(btn('복사',t))})}
  else{var t=clean(cell);if(t.length>3)cell.appendChild(btn('복사',t))}}
 function addAbbr(cell){if(cell.dataset.cpd)return;cell.dataset.cpd='1';var raw=clean(cell),parts=raw.split(/\s*\/\s*/).filter(function(x){return x});var w=d.createElement('span');w.className='cpw';parts.forEach(function(x){w.appendChild(btn('⧉ '+x,x))});cell.appendChild(w)}
 d.querySelectorAll('main td.cp').forEach(add);
 d.querySelectorAll('main table').forEach(function(t){if(t.closest('.game,.gbody'))return;var r0=t.rows[0];if(!r0||r0.cells.length<2)return;if(/판정/.test(r0.textContent)||(/apx02/.test(location.pathname)&&/쓰이는 곳/.test(r0.textContent)))return;var cols=[],ab=[],sym=[];
  Array.prototype.forEach.call(r0.cells,function(c,i){var x=c.textContent.replace(/\*/g,'').trim();if(/^(틀|예|예시|모양|바른 표기|표기|한 문장 예|목록 모양|본문 모양)$/.test(x))cols.push(i);else if(/^약어/.test(x))ab.push(i);else if(x==='기호')sym.push(i)});
  if(sym.length)cols=[];
  for(var i=1;i<t.rows.length;i++){sym.forEach(function(c){var cell=t.rows[i].cells[c];if(cell&&!cell.dataset.cpd){cell.dataset.cpd='1';var tx=clean(cell);if(tx)cell.appendChild(btn('복사',tx))}});cols.forEach(function(c){var cell=t.rows[i].cells[c];if(cell)add(cell)});ab.forEach(function(c){var cell=t.rows[i].cells[c];if(cell)addAbbr(cell)})}});
}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',function(){setTimeout(run,300)});else setTimeout(run,300);
window.__cpRun=run})();
// ---- 게임 아래: 안내서 점검표에서 기억할 것
(function(){var d=document;function run(){var host=d.querySelector('#gwrap,.gbody,.game');if(!host||!d.querySelector('.game'))return;if(d.getElementById('ckcard'))return;
 var s=d.createElement('script');s.src='ckt.js';s.onload=function(){build()};d.head.appendChild(s);
 function sid(){var v=null;try{v=(window.GX&&GX.ls&&GX.ls('mystyle'))||localStorage.getItem('mystyle')}catch(e){}return window.CKT&&CKT[v]?v:'apa'}
 function build(){var anchor=d.querySelector('.grate')||d.querySelector('aside.gsrc');var box=d.createElement('section');box.id='ckcard';box.className='ckcard';
  var nm={apa:'APA',mla:'MLA',cad:'Chicago Author-Date',nb:'Chicago Notes-Bibliography',ieee:'IEEE',van:'Vancouver',acs:'ACS'};
  function draw(){var k=sid(),L=(window.CKT||{})[k]||[],a=[],i;for(i=0;i<3&&L.length;i++){var x=L[Math.floor(Math.random()*L.length)];if(a.indexOf(x)<0)a.push(x)}
   box.innerHTML='<h3>📋 안내서 점검표에서 기억할 것 <small>('+nm[k]+')</small></h3><ul>'+a.map(function(x){return '<li>'+x.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</li>'}).join('')+'</ul><p><button type="button" class="gbtn" id="ckmore">다른 항목 보기</button> <a href="'+window.CKCH[k]+'.html">'+nm[k]+' 장의 제출 전 체크리스트 전체 보기 →</a></p><p class="mut">게임에서 고른 내 인용 스타일의 점검표 항목입니다. 학과·수업의 지침이 있으면 그것이 우선입니다.</p>';
   var b=d.getElementById('ckmore');if(b)b.onclick=draw}
  draw();if(anchor)anchor.parentNode.insertBefore(box,anchor);else (d.querySelector('main')||d.body).appendChild(box)}}
 if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',function(){setTimeout(run,600)});else setTimeout(run,600)})();
/* 게임 "다음" 단추를 오른쪽 빈 곳에 띄워 스크롤 없이 누르게 한다 */
(function(){var d=document;if(!d.querySelector('.game,#gwrap'))return;
 var fab=null,tgt=null,raf=0;
 function ok(b){if(!b||b.disabled||!b.offsetParent)return false;if(/^tn/.test(b.id||''))return false;if(b.closest('#gp,.fview,header,nav'))return false;
  var t=(b.textContent||'').replace(/\s+/g,' ').trim();return t.length<18&&/^(다음|결과 보기|결과보기)/.test(t)}
 function find(){var m=d.querySelector('main')||d.body,bs=m.querySelectorAll('button'),f=null;for(var i=0;i<bs.length;i++)if(ok(bs[i])){f=bs[i]}return f}
 function upd(){raf=0;var b=find();tgt=b;if(!b){if(fab)fab.hidden=true;return}
  if(!fab){fab=d.createElement('button');fab.type='button';fab.id='gnext';fab.setAttribute('aria-label','다음으로');fab.onclick=function(){var t=tgt;if(t&&t.isConnected){fab.hidden=true;t.click()}};d.body.appendChild(fab)}
  var t=(b.textContent||'').replace(/\s+/g,' ').trim();fab.innerHTML='<b>'+(/결과/.test(t)?'결과<br>보기':'다음')+'</b><i>→</i><small>스크롤 없이</small>';fab.hidden=false}
 function sched(){if(!raf)raf=requestAnimationFrame(upd)}
 try{new MutationObserver(sched).observe(d.querySelector('main')||d.body,{childList:true,subtree:true,attributes:true,attributeFilter:['disabled','hidden','class']})}catch(e){}
 d.addEventListener('keydown',function(e){if(e.key!=='ArrowRight'||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey)return;var a=d.activeElement;if(a&&/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName))return;if(fab&&!fab.hidden){e.preventDefault();fab.click()}});
 sched();setTimeout(sched,800);
})();

// ===== 자유게시판 =====
(function(){var d=document,F=d.getElementById('bdf');if(!F)return;
 function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
 var db=null,uid='',owner=false,all=[],cat='전체',q='',msg=d.getElementById('bdm'),box=d.getElementById('bdlist');
 var CATS=['전체','홈페이지 후기','수업·과제 후기','읽은 논문·책 후기','인용·참고문헌 팁','연구 아이디어','기타'];
 var tabs=d.getElementById('bdtabs');
 function tdraw(){tabs.innerHTML=CATS.map(function(c){return '<button type="button" class="gtab'+(c===cat?' on':'')+'" data-c="'+c+'">'+esc(c)+'</button>'}).join('');
  tabs.querySelectorAll('button').forEach(function(b){b.onclick=function(){cat=b.dataset.c;tdraw();draw()}})}
 function draw(){var l=all.filter(function(v){return (cat==='전체'||v.cat===cat)&&(!q||((v.title||'')+' '+(v.text||'')).toLowerCase().indexOf(q)>=0)});
  if(!l.length){box.innerHTML='<p class="mut">'+(all.length?'조건에 맞는 글이 없습니다.':'아직 올라온 글이 없습니다. 첫 글을 남겨 주세요.')+'</p>';return}
  box.innerHTML=l.map(function(v){var mine=(v.doc===uid&&uid)||owner;
   return '<article class="sgi bdi"><b>'+esc(v.title||'')+'</b> <span class="mut">'+esc(v.cat||'')+' · '+esc(v.nick||'익명')+' · '+new Date(v.at||0).toLocaleDateString('ko-KR')+'</span><p>'+esc(v.text||'').replace(/\n/g,'<br>')+'</p>'+(mine?'<button class="gbtn2" data-d="'+esc(v.doc)+'" data-k="'+esc(v.k)+'">지우기</button>':'')+'</article>'}).join('');
  box.querySelectorAll('button').forEach(function(b){b.onclick=async function(){if(b.dataset.s!=='1'){b.dataset.s='1';b.textContent='정말 지울까요?';return}
   try{var rf=db.doc('board/'+b.dataset.d),sn=await rf.get();if(sn.exists){await rf.set({items:(sn.data().items||[]).filter(function(x){return x.k!==b.dataset.k}),upd:Date.now()})}}catch(e){msg.textContent='지울 수 없습니다.'}}})}
 d.getElementById('bdq').oninput=function(){q=this.value.trim().toLowerCase();draw()};
 tdraw();
 (async function(){try{if(!window.claude||!window.claude.use){box.innerHTML='<p class="mut">이 환경에서는 게시판을 쓸 수 없습니다.</p>';return}
  db=await window.claude.use('db');var u=await window.claude.use('user');
  if(u){try{uid=await u.id()}catch(e){}try{owner=!!(u.isOwner&&u.isOwner())}catch(e){}}
  if(!db){box.innerHTML='<p class="mut">로그인하면 게시판을 볼 수 있습니다.</p>';return}
  var to=setTimeout(function(){if(!all.length)draw()},10000);
  db.collection('board').onSnapshot(function(sn){clearTimeout(to);var a=[];sn.docs.forEach(function(x){((x.data()||{}).items||[]).forEach(function(v){v.doc=x.id;a.push(v)})});a.sort(function(x,y){return (y.at||0)-(x.at||0)});all=a;draw()},function(){box.innerHTML='<p class="mut">글을 불러오지 못했습니다.</p>'})}catch(e){box.innerHTML='<p class="mut">글을 불러오지 못했습니다.</p>'}})();
 F.onsubmit=async function(ev){ev.preventDefault();var t=F.text.value.trim(),ti=F.title.value.trim(),nk=F.nick.value.replace(/[<>]/g,'').trim().slice(0,12);if(!t||!ti)return;
  if(window.PF&&PF.bad(ti+' '+t+' '+nk)){msg.textContent=PF.msg||'욕설·비속어가 있어 올릴 수 없습니다.';return}
  if(!db||!uid){msg.textContent='로그인과 참여 권한이 있어야 올릴 수 있습니다.';return}
  try{var rf=db.doc('board/'+uid),sn=await rf.get(),its=sn.exists?(sn.data().items||[]):[];
   its.push({k:Date.now().toString(36)+Math.random().toString(36).slice(2,6),cat:F.cat.value,title:ti,text:t,nick:nk,at:Date.now()});
   await rf.set({items:its.slice(-50),upd:Date.now()});F.reset();msg.textContent='올렸습니다. 감사합니다.'}catch(e){msg.textContent='올리지 못했습니다. 잠시 뒤 다시 해 주세요.'}};
})();
