(function(){
var d=document,GX=window.GX,PF=window.PF;
var secs=d.querySelectorAll('section.toon');if(!secs.length)return;
var NAMES={webtoon:'도토리의 인용 일기',webtoon2:'양식 동물 마을의 헷갈림 일기',webtoon3:'동물 친구들의 주의 한 컷',webtoon4:'시카판다의 보고서 모양 점검',webtoon5:'백일이의 영어 논문 쓰기'};
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}}
function lget(k){try{return JSON.parse(ls(k)||'[]')}catch(e){return []}}
function rid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function ago(t){var s=Math.max(0,(Date.now()-t)/1000);if(s<60)return '방금';if(s<3600)return Math.floor(s/60)+'분 전';if(s<86400)return Math.floor(s/3600)+'시간 전';return Math.floor(s/86400)+'일 전'}
var LK='tcm.local.v1',MK='tcm.mine.v1',RK='grate.mine.v1',last=0;
function sb(){return GX&&GX.sbInit?GX.sbInit().then(function(){return GX.SB}):Promise.resolve(null)}
secs.forEach(function(sec){
 var id=sec.id,g='toon-'+id,box=d.createElement('div');box.className='tcm';box.id='tcm-'+id;sec.parentNode.insertBefore(box,sec.nextSibling);
 var mine=null;try{mine=(JSON.parse(ls(RK)||'{}')[g])||null}catch(e){}
 box.innerHTML='<section class="gc tcmbox"><h2 class="gt">〈'+esc(NAMES[id]||'웹툰')+'〉 응원과 한마디</h2>'
  +'<div class="tcmr"><div class="st5" role="group" aria-label="별점(5점만 줄 수 있습니다)">'+[1,2,3,4,5].map(function(n){return '<button type="button" class="st5b'+(mine?' on':'')+'" data-n="'+n+'" aria-label="별 5점으로 응원하기">★</button>'}).join('')+'</div><span class="tcma mut" aria-live="polite"></span></div>'
  +'<p class="mut">이 웹툰의 별점은 <b>5점만</b> 줄 수 있어요. 별을 누르면 5점으로 응원이 기록됩니다.</p>'
  +'<p class="mut">익명 한마디: 이름·학번 없이 글과 시각만 보입니다. 서로 존중하는 말만 써 주세요.</p>'
  +'<form class="gcf"><textarea maxlength="200" rows="2" required placeholder="예: 3컷이 이해하기 쉬웠어요 / 다음 화가 기다려져요"></textarea><div class="gcb"><small class="cnt">0/200</small><button class="gprimary">익명으로 남기기</button></div><p class="gcm" aria-live="polite"></p></form><div class="gcl"></div></section>';
 var fm=box.querySelector('form'),ta=fm.querySelector('textarea'),cnt=fm.querySelector('.cnt'),msg=fm.querySelector('.gcm'),list=box.querySelector('.gcl'),ra=box.querySelector('.tcma'),shared=[],isOwner=false;
 ta.oninput=function(){cnt.textContent=ta.value.length+'/200'};
 function draw(){var my=lget(MK),loc=lget(LK).filter(function(v){return v.g===g}),all=shared.filter(function(v){return v.g===g});
  loc.forEach(function(v){if(!all.some(function(x){return x.k===v.k}))all.push(v)});all.sort(function(a,b){return (b.at||0)-(a.at||0)});all=all.slice(0,30);
  list.innerHTML=all.length?all.map(function(v){var own=my.indexOf(v.k)>=0;return '<article class="gci"><p>'+esc(v.text)+'</p><span class="mut">익명 · '+ago(v.at||0)+(v.loc?' · 이 기기에서만 보임':'')+'</span>'+((own||isOwner)?' <button class="gdel2" data-k="'+esc(v.k)+'" data-d="'+(v.doc||'')+'">삭제</button>':'')+'</article>'}).join(''):'<p class="mut">아직 한마디가 없습니다. 첫 한마디를 남겨 보세요.</p>';
  list.querySelectorAll('.gdel2').forEach(function(b){b.onclick=async function(){var k=b.dataset.k;ls(LK,JSON.stringify(lget(LK).filter(function(v){return v.k!==k})));
   try{var SB=await sb();var docid=b.dataset.d||(SB&&SB.uid)||'';if(SB&&SB.db&&docid){var rf=SB.db.doc('gcomments/'+docid),sn=await rf.get();if(sn.exists){await rf.set({items:(sn.data().items||[]).filter(function(v){return v.k!==k}),upd:Date.now()})}}}catch(e){}
   shared=shared.filter(function(v){return v.k!==k});draw()}})}
 function status(){sb().then(async function(SB){if(!SB||!SB.db){ra.textContent=mine?'응원해 주셔서 고맙습니다. (이 기기에 기록)':'';return}
   try{var q=await SB.db.collection('ratings').get(),n=0;q.docs.forEach(function(x){var r=((x.data()||{}).r||{})[g];if(r&&r.s)n++});ra.textContent=n?'★ 5.0 / 5 · '+n+'명이 응원했어요':'아직 응원이 없어요'}catch(e){}})}
 box.querySelectorAll('.st5b').forEach(function(b){b.onclick=async function(){box.querySelectorAll('.st5b').forEach(function(x){x.classList.add('on')});
   try{var all=JSON.parse(ls(RK)||'{}');all[g]={s:5,at:Date.now()};ls(RK,JSON.stringify(all))}catch(e){}
   mine={s:5};ra.textContent='5점으로 응원했어요! 고맙습니다.';
   try{var SB=await sb();if(SB&&SB.db&&SB.can&&SB.uid){var rf=SB.db.doc('ratings/'+SB.uid),sn=await rf.get(),r0=sn.exists?(sn.data().r||{}):{};r0[g]={s:5,at:Date.now()};await rf.set({r:r0,upd:Date.now()});status()}}catch(e){}}});
 fm.onsubmit=async function(ev){ev.preventDefault();var t=ta.value.trim();if(!t)return;if(PF&&PF.bad(t)){msg.textContent=PF.msg;return}if(Date.now()-last<20000){msg.textContent='잠시 뒤에 다시 남겨 주세요(20초 간격).';return}
  var item={g:g,text:t,at:Date.now(),k:rid()};last=Date.now();var my=lget(MK);my.push(item.k);ls(MK,JSON.stringify(my.slice(-100)));
  try{var SB=await sb();if(SB&&SB.db&&SB.can&&SB.uid){var rf=SB.db.doc('gcomments/'+SB.uid),sn=await rf.get(),its=sn.exists?(sn.data().items||[]):[];its.push(item);await rf.set({items:its.slice(-50),upd:Date.now()});shared.push({g:g,text:t,at:item.at,k:item.k,doc:SB.uid});ta.value='';cnt.textContent='0/200';msg.textContent='남겼습니다. 고맙습니다.';draw();return}}catch(e){}
  item.loc=1;var l=lget(LK);l.push(item);ls(LK,JSON.stringify(l.slice(-50)));ta.value='';cnt.textContent='0/200';msg.textContent='이 환경에서는 모두에게 공유할 수 없어 이 기기에만 저장했습니다(공유하려면 로그인과 참여 권한이 필요합니다).';draw()};
 draw();status();
 sb().then(async function(SB){if(!SB||!SB.db)return;try{var u=await window.claude.use('user');isOwner=!!(u&&u.isOwner&&u.isOwner())}catch(e){}
  try{SB.db.collection('gcomments').onSnapshot(function(sn){var a=[];sn.docs.forEach(function(x){((x.data()||{}).items||[]).forEach(function(v){a.push({g:v.g,text:v.text,at:v.at,k:v.k,doc:x.id})})});shared=a;draw()},function(){})}catch(e){}});
});
})();
