(function(){
var d=document,$=function(i){return d.getElementById(i)};
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function lsg(k){try{return localStorage.getItem(k)}catch(e){return null}}function lss(k,v){try{localStorage.setItem(k,v)}catch(e){}}
var INK='#3d3128';
// ---- 일곱 양식 동물 (이 홈페이지를 위해 직접 그린 원본 캐릭터) ----
var AN={apa:{n:'아파펭귄',sp:'펭귄',st:'APA',c:'#3a5fb0'},mla:{n:'엠엘여우',sp:'여우',st:'MLA',c:'#7b66b8'},cad:{n:'시카곰',sp:'곰',st:'Chicago A-D',c:'#4fa08f'},nb:{n:'시카판다',sp:'판다',st:'Chicago N-B',c:'#c99a3a'},ieee:{n:'아이트리플냥',sp:'고양이',st:'IEEE',c:'#6f7a8e'},van:{n:'밴쿠개굴',sp:'개구리',st:'Vancouver',c:'#d3777f'},acs:{n:'애쓰구리',sp:'너구리',st:'ACS',c:'#a8764f'}};
function C(x,y,r,f,s,w){return '<circle cx="'+x+'" cy="'+y+'" r="'+r+'" fill="'+f+'"'+(s?' stroke="'+s+'" stroke-width="'+(w||1.5)+'"':'')+'/>'}
function E(x,y,rx,ry,f,rot){return '<ellipse cx="'+x+'" cy="'+y+'" rx="'+rx+'" ry="'+ry+'" fill="'+f+'"'+(rot?' transform="rotate('+rot+' '+x+' '+y+')"':'')+'/>'}
function P(pts,f){return '<polygon points="'+pts+'" fill="'+f+'"/>'}
function eyes(x,y,m,dx,onDark){var s='',L=x-dx,R=x+dx,ink=onDark?'#fff':INK;
 if(m==='happy'){s='<path d="M'+(L-5)+' '+(y+2)+'q5 -8 10 0M'+(R-5)+' '+(y+2)+'q5 -8 10 0" stroke="'+ink+'" stroke-width="2.4" fill="none" stroke-linecap="round"/>'}
 else if(m==='shock'){s=C(L,y,6.5,'#fff',INK,1.6)+C(R,y,6.5,'#fff',INK,1.6)+C(L,y,2,INK)+C(R,y,2,INK)}
 else{s=C(L,y,5.4,'#fff')+C(R,y,5.4,'#fff')+C(L+(m==='think'?1.5:0),y+(m==='think'?-1:0),2.7,INK)+C(R+(m==='think'?1.5:0),y+(m==='think'?-1:0),2.7,INK)}
 if(m==='sweat')s+='<path d="M'+(R+12)+' '+(y-12)+'q4 7 0 10q-4 -3 0 -10z" fill="#8fd0f0" stroke="'+INK+'" stroke-width="1"/>';
 if(m==='think')s+='<text x="'+(R+14)+'" y="'+(y-10)+'" font-size="16" font-weight="800" fill="#c46a5e">?</text>';
 return s}
function mouth(x,y,m){if(m==='happy')return '<path d="M'+(x-6)+' '+y+'q6 8 12 0z" fill="#e57b78" stroke="'+INK+'" stroke-width="1.5"/>';
 if(m==='shock')return E(x,y+3,3.5,5,'#7a3a3a');if(m==='sweat')return '<path d="M'+(x-7)+' '+(y+2)+'q3.5 -4 7 0t7 0" stroke="'+INK+'" stroke-width="2" fill="none" stroke-linecap="round"/>';
 if(m==='think')return '<path d="M'+(x-4)+' '+(y+2)+'h8" stroke="'+INK+'" stroke-width="2" stroke-linecap="round"/>';
 return '<path d="M'+(x-5)+' '+y+'q5 5 10 0" stroke="'+INK+'" stroke-width="2" fill="none" stroke-linecap="round"/>'}
function animal(k,x,y,m,s){s=s||1;var h=y-92,g='<g transform="translate('+x+' '+y+') scale('+s+') translate('+(-x)+' '+(-y)+')">',a=AN[k],hy=h;
 if(k==='apa'){g+=E(x,y-38,36,46,'#34425e')+E(x,y-34,23,36,'#fff')+E(x-38,y-40,9,26,'#2b364f',18)+E(x+38,y-40,9,26,'#2b364f',-18)+E(x-16,y,13,6,'#f0a23a')+E(x+16,y,13,6,'#f0a23a')+C(x,hy,29,'#34425e')+E(x,hy+4,21,19,'#fff')+eyes(x,hy-3,m,11)+P((x-6)+','+(hy+7)+' '+(x+6)+','+(hy+7)+' '+x+','+(hy+14),'#f0a23a')+mouth(x,hy+18,m)}
 else if(k==='mla'){g+='<path d="M'+(x+26)+' '+(y-26)+'q38 -10 30 -46q-8 22 -34 22z" fill="#e8863a"/><path d="M'+(x+51)+' '+(y-66)+'q6 8 5 12q-5 -2 -9 -2z" fill="#fff"/>'+E(x,y-38,34,44,'#e8863a')+E(x,y-34,21,34,'#fff7e6')+E(x-14,y,12,6,'#7a4a24')+E(x+14,y,12,6,'#7a4a24')+P((x-26)+','+(hy-14)+' '+(x-14)+','+(hy-42)+' '+(x-4)+','+(hy-20),'#e8863a')+P((x+26)+','+(hy-14)+' '+(x+14)+','+(hy-42)+' '+(x+4)+','+(hy-20),'#e8863a')+C(x,hy,29,'#e8863a')+P((x-29)+','+(hy+6)+' '+x+','+(hy+30)+' '+(x+29)+','+(hy+6)+' '+x+','+(hy+2),'#fff7e6')+eyes(x,hy-4,m,11)+C(x,hy+16,3.4,INK)+mouth(x,hy+20,m)}
 else if(k==='cad'){g+=E(x,y-38,38,46,'#a0714f')+E(x,y-34,23,34,'#e9c9a8')+E(x-16,y,13,6,'#7b5539')+E(x+16,y,13,6,'#7b5539')+C(x-22,hy-22,10,'#a0714f')+C(x+22,hy-22,10,'#a0714f')+C(x,hy,30,'#a0714f')+E(x,hy+9,15,11,'#e9c9a8')+eyes(x,hy-5,m,12)+C(x,hy+5,4,INK)+mouth(x,hy+11,m)}
 else if(k==='nb'){g+=E(x,y-38,37,46,'#fff','')+E(x-40,y-40,10,28,'#2b2b33',16)+E(x+40,y-40,10,28,'#2b2b33',-16)+E(x-17,y,13,7,'#2b2b33')+E(x+17,y,13,7,'#2b2b33')+C(x-22,hy-24,10,'#2b2b33')+C(x+22,hy-24,10,'#2b2b33')+C(x,hy,30,'#fff')+E(x-12,hy-3,10,12,'#2b2b33',-20)+E(x+12,hy-3,10,12,'#2b2b33',20)+eyes(x,hy-4,m,12,0)+C(x,hy+8,4,'#2b2b33')+mouth(x,hy+14,m)+'<circle cx="'+x+'" cy="'+hy+'" r="30" fill="none" stroke="#d9d9de" stroke-width="1.5"/>'}
 else if(k==='ieee'){g+=E(x,y-38,33,44,'#8d94a3')+E(x,y-32,20,32,'#e5e8ef')+E(x-14,y,12,6,'#6a7080')+E(x+14,y,12,6,'#6a7080')+'<path d="M'+(x+30)+' '+(y-20)+'q36 6 26 -34" stroke="#8d94a3" stroke-width="9" fill="none" stroke-linecap="round"/>'+P((x-26)+','+(hy-12)+' '+(x-18)+','+(hy-40)+' '+(x-4)+','+(hy-20),'#8d94a3')+P((x+26)+','+(hy-12)+' '+(x+18)+','+(hy-40)+' '+(x+4)+','+(hy-20),'#8d94a3')+C(x,hy,29,'#8d94a3')+'<path d="M'+(x-6)+' '+(hy-28)+'v8M'+x+' '+(hy-29)+'v9M'+(x+6)+' '+(hy-28)+'v8" stroke="#6a7080" stroke-width="2.4"/><line x1="'+x+'" y1="'+(hy-29)+'" x2="'+x+'" y2="'+(hy-44)+'" stroke="#6a7080" stroke-width="2"/>'+C(x,hy-46,3.5,'#ffd24a')+eyes(x,hy-3,m,11)+P((x-3)+','+(hy+7)+' '+(x+3)+','+(hy+7)+' '+x+','+(hy+11),'#e57b78')+mouth(x,hy+14,m)+'<path d="M'+(x-30)+' '+(hy+6)+'h-14M'+(x-30)+' '+(hy+12)+'l-13 4M'+(x+30)+' '+(hy+6)+'h14M'+(x+30)+' '+(hy+12)+'l13 4" stroke="#6a7080" stroke-width="1.4"/>'}
 else if(k==='van'){g+=E(x,y-36,36,42,'#5cb85c')+E(x,y-30,22,30,'#d8f3c8')+E(x-18,y,14,6,'#47a047')+E(x+18,y,14,6,'#47a047')+E(x,hy+2,36,26,'#5cb85c')+C(x-19,hy-20,12,'#5cb85c')+C(x+19,hy-20,12,'#5cb85c')+(function(){var mm=m;return eyes(x,hy-20,mm,19)})()+'<path d="M'+(x-20)+' '+(hy+10)+'q20 '+(m==='shock'?4:12)+' 40 0" stroke="'+INK+'" stroke-width="2.2" fill="none" stroke-linecap="round"/>'+C(x-8,hy+2,1.4,INK)+C(x+8,hy+2,1.4,INK)}
 else{g+='<path d="M'+(x+28)+' '+(y-14)+'q40 -4 32 -44" stroke="#8a8f98" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M'+(x+46)+' '+(y-30)+'l12 -3M'+(x+50)+' '+(y-44)+'l12 -3" stroke="#3b3f47" stroke-width="5"/>'+E(x,y-38,34,44,'#8a8f98')+E(x,y-34,20,32,'#d7dae0')+E(x-14,y,12,6,'#4b4f58')+E(x+14,y,12,6,'#4b4f58')+C(x-22,hy-22,9,'#8a8f98')+C(x+22,hy-22,9,'#8a8f98')+C(x,hy,29,'#8a8f98')+E(x,hy+9,15,11,'#e8e9ec')+E(x,hy-4,27,10,'#3b3f47')+eyes(x,hy-4,m,11,1)+C(x,hy+6,4,INK)+mouth(x,hy+14,m)}
 var bx=x-26;g+='<rect x="'+bx+'" y="'+(y-48)+'" width="52" height="16" rx="8" fill="'+a.c+'"/><text x="'+x+'" y="'+(y-37)+'" font-size="'+(a.st.length>9?8:10)+'" font-weight="800" fill="#fff" text-anchor="middle">'+a.st+'</text>';
 return g+'</g>'}
var BGS={campus:['#dff0ff','<circle cx="300" cy="48" r="22" fill="#ffe27a"/><rect y="190" width="360" height="60" fill="#b5dca0"/><rect x="30" y="100" width="110" height="90" fill="#c98b6b"/><polygon points="20,100 85,60 150,100" fill="#8a4b3a"/><rect x="70" y="146" width="30" height="44" fill="#7a4a30"/>'],
 lib:['#f6ecd9','<rect y="196" width="360" height="54" fill="#d9bf92"/>'+[0,1,2].map(function(i){return '<rect x="'+(18+i*118)+'" y="30" width="100" height="164" fill="#a47a52"/>'+[0,1,2,3].map(function(j){return '<rect x="'+(24+i*118)+'" y="'+(38+j*40)+'" width="88" height="6" fill="#7a5530"/><rect x="'+(26+i*118)+'" y="'+(20+j*40+8)+'" width="12" height="16" fill="#c0455a"/><rect x="'+(42+i*118)+'" y="'+(22+j*40+8)+'" width="12" height="14" fill="#4a6bd0"/><rect x="'+(58+i*118)+'" y="'+(20+j*40+8)+'" width="12" height="16" fill="#58a46a"/>'}).join('')}).join('')],
 cafe:['#f9e6d6','<rect y="200" width="360" height="50" fill="#c9a07c"/><rect x="20" y="30" width="90" height="70" rx="6" fill="#bfe3f5" stroke="#8a5a3a" stroke-width="4"/><rect x="240" y="150" width="100" height="14" rx="4" fill="#8a5a3a"/><rect x="280" y="164" width="10" height="36" fill="#8a5a3a"/><rect x="262" y="130" width="22" height="20" rx="4" fill="#fff"/>'],
 night:['#25304f','<circle cx="300" cy="46" r="20" fill="#f6edc0"/>'+[0,1,2,3,4,5,6].map(function(i){return '<circle cx="'+(20+i*52)+'" cy="'+(20+(i*37)%90)+'" r="1.6" fill="#fff"/>'}).join('')+'<rect y="206" width="360" height="44" fill="#1a2238"/>'],
 room:['#fbf0e3','<rect y="204" width="360" height="46" fill="#d8b894"/><rect x="250" y="30" width="80" height="80" rx="4" fill="#cfe9f6" stroke="#a47a52" stroke-width="4"/><path d="M290 30v80M250 70h80" stroke="#a47a52" stroke-width="3"/>'],
 sky:['#d6efff','<ellipse cx="80" cy="50" rx="40" ry="14" fill="#fff"/><ellipse cx="250" cy="80" rx="50" ry="16" fill="#fff"/><rect y="206" width="360" height="44" fill="#a8d99a"/>']};
function panel(p,idx,n){var w=360,h=p.h||240,bg=BGS[p.bg]||BGS.room,s='<svg viewBox="0 0 '+w+' '+h+'" class="tnp" role="img" aria-label="웹툰 컷"><rect width="'+w+'" height="'+h+'" fill="'+bg[0]+'"/>'+(p.h&&p.h>250?'<g transform="translate(0 '+(h-250)+')">'+bg[1]+'</g>':bg[1]);
 (p.c||[]).forEach(function(c){s+=animal(c[0],c[1],c[2]||(h-34),c[3]||'ok',c[4]||1)});
 (p.fx||[]).forEach(function(f){s+=f});return s+'</svg>'}
// 헷갈림 에피소드: lay = strip(2x2) | long(세로 스크롤) | wide(가로 한 장 + 작은 컷) | zig(좌우 번갈아)
var EP=[
 {t:'1화 연도는 어디에 두지?',lay:'long',who:'apa mla',src:'APA는 저자 바로 뒤 괄호 안에 연도, MLA는 쪽수와 함께 끝쪽에 연도를 씁니다(이 안내서 제7장·제8장 “양식별 한눈에 보기”).',
  p:[{bg:'campus',h:250,c:[['apa',110,216,'sweat'],['mla',250,216,'think']],b:[['앗, 내 리포트 참고문헌에 연도가 어디 있더라?',4,4,56],['어느 양식이냐에 따라 달라져. 같이 보자!',46,24,52]],cap:'새 학기, 캠퍼스'},
   {bg:'lib',h:330,c:[['apa',100,300,'happy'],['mla',260,300,'ok']],b:[['나(APA)는 저자 바로 뒤에 (2023). 이렇게 연도를 괄호에 넣어.',4,4,62],['나(MLA)는 연도가 뒤쪽에 있어. …, 2023, pp. 83–114.',36,26,60]],cap:'도서관에서 나란히 비교'},
   {bg:'room',h:260,c:[['apa',110,226,'happy'],['mla',250,226,'happy']],b:[['그래서 “어느 양식?”을 먼저 정하는 거구나!',8,6,70],['맞아. 헷갈리는 건 당연해. 처음엔 다들 그래.',30,30,64]],cap:'정리 끝'}]},
 {t:'2화 이름은 성이 먼저? 이름이 먼저?',lay:'strip',who:'apa ieee',src:'APA는 “성, 이니셜.”, IEEE는 이니셜을 먼저 쓰고 성을 뒤에 둡니다(이 안내서 제7장·제11장, 이 홈페이지 “이름 표기 연습” 게임).',
  p:[{bg:'cafe',c:[['apa',110,206,'think'],['ieee',250,206,'ok']],b:[['Sora Han 이라는 저자, 참고문헌엔 어떻게 쓰지?',4,4,60]],cap:'카페'},
   {bg:'cafe',c:[['apa',110,206,'ok'],['ieee',250,206,'happy']],b:[['나는 Han, S.',6,8,44],['나는 S. Han!',50,34,44]],cap:'같은 사람, 다른 모양'},
   {bg:'room',c:[['apa',110,206,'shock'],['ieee',250,206,'ok']],b:[['어? 순서가 반대네?',6,8,52]],cap:'어라?'},
   {bg:'room',c:[['apa',110,206,'happy'],['ieee',250,206,'happy']],b:[['양식 규칙을 따르면 돼. 이름은 같아도 모양은 달라져.',6,8,86]],cap:'규칙만 따르면 OK'}]},
 {t:'3화 저자가 여러 명이면?',lay:'zig',who:'mla cad',src:'저자가 많을 때 줄이는 기준은 양식마다 다르며 이 안내서의 기준을 따랐습니다(제8·9장, “이름 표기 연습” 게임). 학회·학과 지침이 있으면 그것이 우선입니다.',
  p:[{bg:'lib',h:230,c:[['mla',100,196,'sweat']],b:[['저자가 세 명인데 다 써야 하나…',44,10,50]],cap:''},
   {bg:'room',h:230,c:[['cad',260,196,'ok']],b:[['양식마다 줄이는 기준이 달라요. 이 안내서 기준으로 MLA는 3명 이상이면 첫 저자 뒤에 et al.!',4,6,58]],cap:''},
   {bg:'lib',h:230,c:[['mla',100,196,'think']],b:[['Chicago는 6명까지 쓰고, 이 안내서 기준으로 7명 이상이면 앞 3명 뒤에 et al.이야.',44,6,52]],cap:''},
   {bg:'sky',h:230,c:[['mla',100,196,'happy'],['cad',260,196,'happy']],b:[['헷갈리면 점검표랑 양식 안내를 같이 열어 봐요!',16,0,68]],cap:'끝'}]},
 {t:'4화 번호로 쓰는 양식',lay:'wide',who:'ieee van',src:'IEEE는 본문에 [1] 같은 번호를, Vancouver도 번호를 씁니다(이 안내서 제11장·제12장).',
  p:[{bg:'night',h:250,c:[['ieee',90,216,'sweat'],['van',270,216,'think']],b:[['본문엔 이름이 없고 [1]만 있어서 어디 건지 모르겠어…',4,4,52],['참고문헌 목록에서 1번을 찾으면 돼! 번호가 곧 주소야.',46,40,52]],cap:'밤샘 도서관'},
   {bg:'room',c:[['ieee',110,206,'happy'],['van',250,206,'happy']],b:[['나는 [1] 대괄호',6,8,40],['나는 숫자만 1.',52,30,42]],cap:'모양은 조금 달라요'},
   {bg:'sky',c:[['ieee',110,206,'ok'],['van',250,206,'ok']],b:[['번호는 본문에 나온 차례대로!',6,8,70]],cap:'차례가 중요해요'}]},
 {t:'5화 쪽수 p. 와 pp.',lay:'strip',who:'apa nb',src:'한 쪽은 p., 여러 쪽은 pp.입니다(이 안내서 제7장·제10장, “논문 약어 주관식” 게임).',
  p:[{bg:'lib',c:[['apa',110,206,'think'],['nb',250,206,'ok']],b:[['83쪽 하나만 인용했는데 p.? pp.?',4,6,66]],cap:'쪽수 고민'},
   {bg:'lib',c:[['apa',110,206,'ok'],['nb',250,206,'happy']],b:[['한 쪽이면 p. 83',6,8,50],['여러 쪽이면 pp. 83–114',46,36,50]],cap:'기억 팁'},
   {bg:'room',c:[['apa',110,206,'happy'],['nb',250,206,'happy']],b:[['p는 page 하나, pp는 pages 여러 개!',6,8,80]],cap:'p 하나 = 한 쪽'},
   {bg:'sky',c:[['apa',110,206,'happy'],['nb',250,206,'happy']],b:[['쪽수가 없는 자료는 장·절로, 양식 안내 확인!',6,8,80]],cap:'끝'}]},
 {t:'6화 DOI가 없으면?',lay:'long',who:'van acs',src:'이 안내서는 DOI가 확인되지 않으면 쓰지 않고, 없는 DOI를 만들어 쓰지 않도록 안내합니다(제4장·각 양식 장).',
  p:[{bg:'night',h:250,c:[['van',110,216,'sweat'],['acs',250,216,'think']],b:[['이 논문엔 DOI가 안 보여…',4,6,50],['DOI를 지어서 쓰면 안 돼.',46,26,52]],cap:'DOI 찾기'},
   {bg:'lib',h:320,c:[['van',110,290,'ok'],['acs',250,290,'happy']],b:[['없으면 그냥 안 쓰면 돼. 확인한 정보만!',4,6,70],['논문 첫 쪽이나 출판사 사이트에서 다시 찾아볼 수는 있어.',34,30,62]],cap:'확인한 것만'},
   {bg:'room',h:240,c:[['van',110,206,'happy'],['acs',250,206,'happy']],b:[['못 찾았다고 부끄러워할 일이 아니야!',10,6,72]],cap:'정직이 제일이야'}]},
 {t:'7화 공저자가 이니셜로만 보여요',lay:'zig',who:'cad acs',src:'공저자 이름이 이니셜로만 확인될 때는 확인된 그대로 쓰고 풀어 쓰지 않는다는 원칙은 이 안내서의 안내를 따랐습니다(제4장·각 양식 장). 전체 이름이 확인되면 그 양식 규칙대로 씁니다.',
  p:[{bg:'lib',h:230,c:[['cad',100,196,'think']],b:[['공저자가 J. K.로만 나와요. 이름을 짐작해서 써도 되나?',44,8,52]],cap:''},
   {bg:'room',h:230,c:[['acs',260,196,'ok']],b:[['짐작은 금물! 확인된 그대로 이니셜로 써요.',4,8,58]],cap:''},
   {bg:'cafe',h:230,c:[['cad',100,196,'happy']],b:[['논문 첫 쪽이나 DOI 페이지에서 전체 이름이 나오면, 그때 양식 규칙대로 써요!',44,6,52]],cap:''},
   {bg:'sky',h:230,c:[['cad',100,196,'happy'],['acs',260,196,'happy']],b:[['이니셜 그대로도 틀린 게 아니에요.',14,8,72]],cap:'끝'}]},
 {t:'8화 AI가 준 출처, 믿어도 될까?',lay:'wide',who:'nb ieee',src:'생성형 AI가 알려 준 출처는 직접 열어 확인한 것만 쓴다는 원칙은 이 안내서 부록 11의 안내를 따랐습니다.',
  p:[{bg:'night',h:250,c:[['nb',90,216,'sweat'],['ieee',270,216,'ok']],b:[['AI가 알려 준 논문인데 검색하면 안 나와요…',4,4,52],['AI는 없는 출처를 만들어 낼 때도 있어. 직접 열어 확인하자!',46,40,52]],cap:'새벽 2시'},
   {bg:'room',c:[['nb',110,206,'happy'],['ieee',250,206,'happy']],b:[['열어 보고, 실제로 있으면 그때 인용!',6,8,80]],cap:'직접 확인'},
   {bg:'sky',c:[['nb',110,206,'happy'],['ieee',250,206,'happy']],b:[['확인 못 한 건 “확인하지 못함”으로 두는 용기도 필요해요.',6,8,84]],cap:'끝'}]}];
function layoutClass(l){return 'tn2 tn2-'+l}
function bub(b){return '<div class="tn-b" style="left:'+b[1]+'%;top:'+b[2]+'%;width:'+b[3]+'%">'+esc(b[0])+'</div>'}
function figs(e){return e.p.map(function(p,k){return '<figure class="tn-p tn2p">'+panel(p,k,e.p.length)+(p.cap?'<figcaption class="tn-cap">'+esc(p.cap)+'</figcaption>':'')+(p.b||[]).map(bub).join('')+'<span class="tn-n">'+(k+1)+'</span></figure>'}).join('')}
// ---- 움직이는 에피소드: 같은 서지가 양식마다 어떻게 줄을 서는지 ----
var FIC={apa:['au','yr','ti','jn','vo','pg'],mla:['au','ti','jn','vo','yr','pg'],cad:['au','yr','ti','jn','vo','pg'],nb:['au','ti','jn','vo','yr','pg'],ieee:['nm','au','ti','jn','vo','pg','yr'],van:['nm','au','ti','jn','yr','vo','pg'],acs:['au','ti','jn','yr','vo','pg']};
var TXT={apa:{au:'Han, S.',yr:'(2023).',ti:'Reading figures with scientific eyes.',jn:'<i>Journal of Imaginary Studies</i>,',vo:'<i>29</i>(3),',pg:'83–114.'},
 mla:{au:'Han, Sora.',ti:'“Reading Figures with Scientific Eyes.”',jn:'<i>Journal of Imaginary Studies</i>,',vo:'vol. 29, no. 3,',yr:'2023,',pg:'pp. 83–114.'},
 cad:{au:'Han, Sora.',yr:'2023.',ti:'“Reading Figures with Scientific Eyes.”',jn:'<i>Journal of Imaginary Studies</i>',vo:'29 (3):',pg:'83–114.'},
 nb:{au:'Han, Sora.',ti:'“Reading Figures with Scientific Eyes.”',jn:'<i>Journal of Imaginary Studies</i>',vo:'29, no. 3',yr:'(2023):',pg:'83–114.'},
 ieee:{nm:'[1]',au:'S. Han,',ti:'“Reading figures with scientific eyes,”',jn:'<i>J. Imaginary Stud.</i>,',vo:'vol. 29, no. 3,',pg:'pp. 83–114,',yr:'2023.'},
 van:{nm:'1.',au:'Han S.',ti:'Reading figures with scientific eyes.',jn:'J Imaginary Stud.',yr:'2023;',vo:'29(3):',pg:'83-114.'},
 acs:{au:'Han, S.',ti:'Reading Figures with Scientific Eyes.',jn:'<i>J. Imaginary Stud.</i>',yr:'<b>2023</b>,',vo:'<i>29</i> (3),',pg:'83–114.'}};
var NOTE={apa:'연도가 저자 바로 뒤에 괄호로 와요. 학술지 이름과 권 번호는 기울임이에요.',mla:'제목은 따옴표, 학술지는 기울임. vol.·no.·pp. 라벨이 붙고 연도는 뒤쪽에 있어요.',cad:'저자 다음에 연도(2023.)가 오고, 권 (호): 쪽 모양이에요.',nb:'연도는 권·호 뒤 괄호 (2023): 로 가요. 제목은 따옴표예요.',ieee:'앞에 번호 [1], 이니셜이 먼저, 쪽은 pp., 연도는 맨 끝에 와요.',van:'번호. 성+이니셜(마침표 없음). 연;권(호):쪽 으로 이어 붙여요.',acs:'학술지 약어는 기울임, 연도는 굵게, 권은 기울임이에요.'};
var TPL={apa:{au:'저자.',yr:'(연도).',ti:'논문 제목.',jn:'<i>학술지명</i>,',vo:'<i>권</i>(호),',pg:'쪽.'},
 mla:{au:'저자.',ti:'“논문 제목.”',jn:'<i>학술지명</i>,',vo:'vol. 권, no. 호,',yr:'연도,',pg:'pp. 쪽.'},
 cad:{au:'저자.',yr:'연도.',ti:'“논문 제목.”',jn:'<i>학술지명</i>',vo:'권 (호):',pg:'쪽.'},
 nb:{au:'저자.',ti:'“논문 제목.”',jn:'<i>학술지명</i>',vo:'권, no. 호',yr:'(연도):',pg:'쪽.'},
 ieee:{nm:'[번호]',au:'이니셜 성,',ti:'“논문 제목,”',jn:'<i>약어 학술지명</i>,',vo:'vol. 권, no. 호,',pg:'pp. 쪽,',yr:'연도.'},
 van:{nm:'번호.',au:'성 이니셜.',ti:'논문 제목.',jn:'학술지 약어.',yr:'연도;',vo:'권(호):',pg:'쪽.'},
 acs:{au:'성, 이니셜.',ti:'논문 제목.',jn:'<i>학술지 약어</i>',yr:'<b>연도</b>,',vo:'<i>권</i> (호),',pg:'쪽.'}};
var KC={nm:'#8a8f98',au:'#e57b78',yr:'#e0a100',ti:'#4a8fd0',jn:'#7a62c4',vo:'#4fa08f',pg:'#c47a2c'};
function stage(host){var cur='apa',timer=null,busy=false;
 host.innerHTML='<div class="tn2-stage"><p class="mut">동물 친구를 눌러 보세요. 같은 논문(<b>연습용 가상 자료</b>)의 서지 조각이 양식마다 어떻게 줄을 바꾸는지 움직이며 보여 줍니다.</p><div class="tn2-pick" role="tablist"></div><div class="tn2-who"></div><p class="tn2-lab">틀 서지 <small>(빈칸 모양 · 칸이 줄을 서는 모습)</small></p><div class="tn2-chips tn2-tpl" aria-hidden="true"></div><p class="tn2-lab">예 <small>(연습용 가상 서지)</small></p><div class="tn2-chips" aria-live="polite"></div><p class="tn2-note"></p><div class="gbtns"><button class="gprimary spkl" id="tn2play">▶ 일곱 양식 차례로 보기</button><button class="gbtn" id="tn2stop" hidden>■ 멈추기</button></div></div>';
 var pick=host.querySelector('.tn2-pick'),who=host.querySelector('.tn2-who'),chipsA=host.querySelectorAll('.tn2-chips'),tpl=chipsA[0],chips=chipsA[1],note=host.querySelector('.tn2-note'),els={},els2={},keys=['nm','au','yr','ti','jn','vo','pg'];
 Object.keys(AN).forEach(function(k){var b=d.createElement('button');b.type='button';b.className='tn2-a';b.dataset.k=k;b.style.setProperty('--sc',AN[k].c);b.innerHTML='<svg viewBox="0 0 120 130" width="54" height="58" aria-hidden="true">'+animal(k,60,124,'happy',.8)+'</svg><span>'+AN[k].n+'<small>'+AN[k].st+'</small></span>';b.onclick=function(){stopAuto();go(k)};pick.appendChild(b)});
 keys.forEach(function(k){var c=d.createElement('span');c.className='tn2-c';c.dataset.k=k;c.style.setProperty('--kc',KC[k]);els[k]=c;var c2=c.cloneNode(false);c2.className='tn2-c tn2-t';els2[k]=c2});
 function lay(box,E,T,k){var order=FIC[k],first={};keys.forEach(function(x){var r=E[x].getBoundingClientRect();first[x]=E[x].isConnected?[r.left,r.top]:null});
  box.innerHTML='';order.forEach(function(x){E[x].innerHTML=T[k][x];E[x].style.opacity='';box.appendChild(E[x])});
  keys.forEach(function(x){if(order.indexOf(x)<0)E[x].remove()});
  order.forEach(function(x){var r=E[x].getBoundingClientRect(),f=first[x];if(f){var dx=f[0]-r.left,dy=f[1]-r.top;E[x].style.transition='none';E[x].style.transform='translate('+dx+'px,'+dy+'px)';void E[x].offsetWidth;E[x].style.transition='transform .75s cubic-bezier(.2,.8,.2,1)';E[x].style.transform='none'}else{E[x].style.transform='scale(.4)';E[x].style.opacity='0';void E[x].offsetWidth;E[x].style.transition='all .6s';E[x].style.transform='none';E[x].style.opacity='1'}})}
 function go(k){cur=k;lay(tpl,els2,TPL,k);lay(chips,els,TXT,k);
  pick.querySelectorAll('.tn2-a').forEach(function(b){b.classList.toggle('on',b.dataset.k===k)});
  who.innerHTML='<svg viewBox="0 0 150 150" width="120" height="120" class="tn2-hop" aria-hidden="true">'+animal(k,75,140,'happy',1.05)+'</svg><div class="tn-b tn2-bub"><b>'+AN[k].n+'('+AN[k].sp+') · '+AN[k].st+'</b><br>'+esc(NOTE[k])+'</div>';note.textContent=''}
 function stopAuto(){clearInterval(timer);timer=null;host.querySelector('#tn2play').hidden=false;host.querySelector('#tn2stop').hidden=true}
 host.querySelector('#tn2play').onclick=function(){var ks=Object.keys(AN),i=0;go(ks[0]);this.hidden=true;host.querySelector('#tn2stop').hidden=false;timer=setInterval(function(){i++;if(i>=ks.length){stopAuto();return}go(ks[i])},3800)};
 host.querySelector('#tn2stop').onclick=stopAuto;go('apa')}
function toTop(host){var tb=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||110)+8,r=host.getBoundingClientRect();scrollTo({top:Math.max(0,scrollY+r.top-tb),behavior:'auto'})}
function render(host){var cur=0,read=[];try{read=JSON.parse(lsg('toon2.read')||'[]')}catch(e){}
 var N=EP.length+1;
 var first=true;function show(i){cur=Math.max(0,Math.min(N-1,i));lss('toon2.ep',String(cur));if(read.indexOf(cur)<0){read.push(cur);lss('toon2.read',JSON.stringify(read))}
  var inter=cur===EP.length,e=inter?null:EP[cur];
  host.innerHTML='<div class="tn-head"><h2 class="gt">새 웹툰 〈양식 동물 마을의 헷갈림 일기〉</h2><p class="mut">일곱 양식을 일곱 동물 친구가 맡았어요. 누구나 헷갈리는 순간을 서로 도우며 풀어 갑니다. 가로로 넘기는 컷, 아래로 길게 스크롤하는 컷, 직접 눌러 보는 움직이는 화가 섞여 있습니다.</p></div>'
  +'<div class="tn-tabs" role="tablist">'+EP.map(function(x,k){return '<button class="tn-tab'+(k===cur?' on':'')+(read.indexOf(k)>=0?' read':'')+'" data-k="'+k+'" role="tab" aria-selected="'+(k===cur)+'">'+(k+1)+'화</button>'}).join('')+'<button class="tn-tab spkl'+(cur===EP.length?' on':'')+(read.indexOf(EP.length)>=0?' read':'')+'" data-k="'+EP.length+'">▶ 움직이는 화</button></div>'
  +(inter?'<article class="tn-ep"><h3>9화 (움직이는 화) 서지 조각의 줄서기</h3><div id="tn2host"></div><p class="mut tn2-src"><b>근거</b> 일곱 양식의 서지 모양은 이 안내서 “양식별 한눈에 보기”를 따랐습니다. 논문 정보는 모두 연습용으로 만든 가상 자료이며 실제 논문이 아닙니다. 학술지 이름 약어(J. Imaginary Stud.)도 가상입니다.</p></article>'
   :'<article class="tn-ep"><h3>'+esc(e.t)+'</h3><p class="mut">출연: '+e.who.split(' ').map(function(k){return AN[k].n+'('+AN[k].sp+', '+AN[k].st+')'}).join(', ')+'</p><div class="'+layoutClass(e.lay)+'">'+figs(e)+'</div><p class="mut tn2-src"><b>이 화의 근거</b> '+esc(e.src)+'</p></article>')
  +'<div class="gbtns"><button class="gbtn" id="tn2p"'+(cur===0?' disabled':'')+'>← 이전 화</button><button class="gprimary" id="tn2n"'+(cur===N-1?' disabled':'')+'>다음 화 →</button></div>'
  +'<p class="mut tn-credit">캐릭터(아파펭귄·엠엘여우·시카곰·시카판다·아이트리플냥·밴쿠개굴·애쓰구리)는 이 홈페이지를 위해 직접 그린 원본입니다. 웹툰 속 규칙 설명은 이 안내서(제4장, 제7~13장, 부록 11)와 홈페이지 게임 안내를 바탕으로 했고, 이야기와 인물은 모두 지어낸 것입니다. 학과·수업의 지침이 있으면 그것이 우선입니다.</p>';
  host.querySelectorAll('.tn-tab').forEach(function(b){b.onclick=function(){show(+b.dataset.k)}});
  var pv=$('tn2p'),nx=$('tn2n');if(pv)pv.onclick=function(){show(cur-1)};if(nx)nx.onclick=function(){show(cur+1)};
  if(inter)stage($('tn2host'));if(!first)toTop(host);first=false}
 show(cur)}
window.TOONK={AN:AN,animal:animal,esc:esc,INK:INK,C:C,E:E,P:P};
var H=$('webtoon2');if(H)render(H);
})();
