(function(){var d=document,$=function(i){return d.getElementById(i)};
var NM={apa:['APA','#3a5fb0'],mla:['MLA','#8272b5'],cad:['Chicago Author-Date','#4fa08f'],nb:['Chicago Notes-Bibliography','#cfa04e'],ieee:['IEEE','#8a93a0'],van:['Vancouver','#cf7f88'],acs:['ACS','#a8764f']},CH={apa:'ch07',mla:'ch08',cad:'ch09',nb:'ch10',ieee:'ch11',van:'ch12',acs:'ch13'};
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function lg(k){try{return localStorage.getItem(k)}catch(e){return null}}function ls(k,v){try{localStorage.setItem(k,v)}catch(e){}}
function toast(s){var e=d.createElement('div');e.className='copied';e.textContent=s;d.body.appendChild(e);setTimeout(function(){e.remove()},1500)}
function copy(t){function fb(){var ta=d.createElement('textarea');ta.value=t;d.body.appendChild(ta);ta.select();try{d.execCommand('copy');toast('복사했습니다')}catch(e){toast('복사하지 못했습니다')}ta.remove()}if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t).then(function(){toast('복사했습니다')},fb);else fb()}
var COM=['제출처(수업·학과·학회)가 정한 양식이 있는지 먼저 확인했는가?','본문에 쓴 인용마다 참고문헌에 있고, 참고문헌마다 본문에서 쓰였는가?','출처는 내가 직접 열어 확인한 것만 썼는가? (AI가 알려 준 출처 포함)','DOI·URL은 확인된 것만 썼고, 없는 것을 지어내지 않았는가?','생성형 AI를 썼다면 도구·사용 목적을 밝히고 내용을 직접 검토했는가?'];
function render(){var st=$('chkst'),box=$('chkbox');if(!st||!box||!window.CKT)return;var cur=lg('chk.sty');if(!NM[cur])cur=null;
 st.innerHTML=Object.keys(NM).map(function(k){return '<button type="button" class="sgb'+(k===cur?' on':'')+'" data-k="'+k+'" style="--sc:'+NM[k][1]+'">'+NM[k][0]+'</button>'}).join('');
 st.querySelectorAll('.sgb').forEach(function(b){b.onclick=function(){ls('chk.sty',b.dataset.k);render()}});
 if(!cur){box.innerHTML='<p class="mut">위에서 이번 과제에 쓸 인용 양식을 고르세요. 양식을 모르면 제출처의 안내를 먼저 확인하세요.</p>';return}
 var L=COM.map(function(x){return {t:x,c:1}}).concat((CKT[cur]||[]).map(function(x){return {t:x}})),key='chk.'+cur,S={};try{S=JSON.parse(lg(key)||'{}')}catch(e){}
 function n(){return L.filter(function(x,i){return S[i]}).length}
 box.innerHTML='<div class="chkh" style="--sc:'+NM[cur][1]+'"><b>'+esc(NM[cur][0])+' 제출 전 점검</b> <span id="chkn"></span><div class="ckbar"><i></i></div></div><ul class="chkl">'+L.map(function(x,i){return '<li><label><input type="checkbox" data-i="'+i+'"'+(S[i]?' checked':'')+'> <span>'+esc(x.t)+(x.c?' <em class="chkc">공통</em>':'')+'</span></label></li>'}).join('')+'</ul><div class="gbtns"><button class="gprimary" id="chkcp">아직 안 한 것만 복사</button><button class="gbtn" id="chkall">전체 목록 복사</button><button class="gbtn" id="chkrs">모두 해제</button></div><p class="mut">항목은 이 안내서 “제'+CH[cur].replace('ch0','').replace('ch','')+'장”의 제출 전 체크리스트에서 가져왔고, “공통”은 이 홈페이지가 덧붙인 일반 점검입니다. <a href="'+CH[cur]+'.html">'+NM[cur][0]+' 장에서 전체 보기 →</a> 학과·수업의 지침이 있으면 그것이 우선입니다.</p>';
 function upd(){var c=n(),t=L.length;$('chkn').textContent=c+' / '+t+' 확인';box.querySelector('.ckbar i').style.width=(100*c/t)+'%'}
 box.querySelectorAll('input[type=checkbox]').forEach(function(cb){cb.onchange=function(){S[cb.dataset.i]=cb.checked;ls(key,JSON.stringify(S));upd()}});
 $('chkcp').onclick=function(){var r=L.filter(function(x,i){return !S[i]});copy(NM[cur][0]+' 제출 전 점검 — 아직 확인하지 않은 것\n'+(r.length?r.map(function(x){return '☐ '+x.t}).join('\n'):'(모두 확인했습니다)'))};
 $('chkall').onclick=function(){copy(NM[cur][0]+' 제출 전 점검\n'+L.map(function(x,i){return (S[i]?'☑ ':'☐ ')+x.t}).join('\n'))};
 $('chkrs').onclick=function(){S={};ls(key,'{}');render()};upd()}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',render);else render();window.addEventListener('load',render)})();
