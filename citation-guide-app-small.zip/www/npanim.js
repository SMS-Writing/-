(function(){var d=document,h=d.getElementById('npanim');if(!h)return;
var CAP=20,REF=6,n=14,timer=null,dir=1;
function layout(mode){var it=[],i;for(i=0;i<n;i++)it.push('b');
 if(mode==='enter'){for(i=0;i<4;i++)it.push('e');it.push('h')}
 else{while(it.length%CAP)it.push('x');it.push('h')}
 for(i=0;i<REF;i++)it.push('r');
 var pages=[];for(i=0;i<it.length;i+=CAP)pages.push(it.slice(i,i+CAP));return pages}
function pageHTML(pg,k){var rows=pg.map(function(t){var c={b:'np-b',e:'np-e',h:'np-h',r:'np-r',x:'np-x'}[t];return '<i class="'+c+'">'+(t==='h'?'참고문헌':'')+'</i>'}).join('');return '<div class="np-pg"><div class="np-no">'+(k+1)+'쪽</div>'+rows+'</div>'}
function where(pages){for(var p=0;p<pages.length;p++){var k=pages[p].indexOf('h');if(k>=0)return [p+1,k+1]}return [0,0]}
function draw(){var A=layout('enter'),B=layout('break'),a=where(A),b=where(B);
 h.querySelector('.np-pa').innerHTML=A.map(pageHTML).join('');h.querySelector('.np-pb').innerHTML=B.map(pageHTML).join('');
 var okA=a[1]===1;
 h.querySelector('.np-ca').innerHTML='“참고문헌”이 <b>'+a[0]+'쪽 '+a[1]+'번째 줄</b>에 놓임'+(okA?'':' → 새 쪽에서 시작하지 않음');
 h.querySelector('.np-cb').innerHTML='“참고문헌”이 <b>'+b[0]+'쪽 맨 위</b>에서 시작';
 h.querySelector('.np-n').textContent=n+'줄';h.querySelector('input').value=n}
h.innerHTML='<div class="np-top"><label>앞 내용(본문) 줄 수 <input type="range" min="8" max="34" value="14" aria-label="본문 줄 수"> <b class="np-n"></b></label> <button type="button" class="np-play gbtn">▶ 본문이 늘고 줄 때 보기</button></div>'
 +'<div class="np-cols"><div class="np-col bad"><h4>✕ Enter를 여러 번 눌러 밀기</h4><div class="np-pgs np-pa"></div><p class="np-ca"></p></div>'
 +'<div class="np-col good"><h4>○ 쪽 나누기(Ctrl+Enter)</h4><div class="np-pgs np-pb"></div><p class="np-cb"></p></div></div>'
 +'<p class="mut">막대 한 줄은 본문 한 줄, 빈 막대는 Enter로 만든 빈 줄입니다. 슬라이더를 움직이거나 재생 단추를 눌러 앞 내용이 바뀔 때 “참고문헌”이 어디에 놓이는지 보세요.</p>';
var inp=h.querySelector('input');inp.oninput=function(){n=+inp.value;draw()};
h.querySelector('.np-play').onclick=function(){var b=this;if(timer){clearInterval(timer);timer=null;b.textContent='▶ 본문이 늘고 줄 때 보기';return}b.textContent='■ 멈추기';
 timer=setInterval(function(){n+=dir;if(n>=34){dir=-1}if(n<=8){dir=1}draw()},320)};
draw()})();
