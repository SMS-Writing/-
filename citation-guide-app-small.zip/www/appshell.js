/* 앱 전용: 아래 탭 막대, 머리글 정리, 온라인 전용 기능 안내 */
(function(){
var d=document,WEB='https://claude.ai/artifact/7Ftzm7Eh5NHozMZzYCgCTj';
var page=(location.pathname.split('/').pop()||'index.html').toLowerCase();
function onReady(f){if(d.readyState!=='loading')f();else d.addEventListener('DOMContentLoaded',f)}
onReady(function(){
 /* 검색 단추 */
 var top=d.querySelector('.top'),th=d.getElementById('theme');
 if(top&&th){var sb=d.createElement('button');sb.id='apsrch';sb.type='button';sb.setAttribute('aria-label','검색');sb.textContent='🔍';top.insertBefore(sb,th);
  sb.onclick=function(){d.documentElement.classList.toggle('srch');var q=d.getElementById('q');if(d.documentElement.classList.contains('srch')&&q)setTimeout(function(){q.focus()},50);setTimeout(function(){dispatchEvent(new Event('resize'))},60)}}
 /* 아래 탭 */
 var TABS=[['index.html','🏠','홈'],['#menu','📚','차례'],['webtoon.html','🐿️','웹툰'],['anim.html','🎞️','영상'],['games.html','🎮','게임']];
 var GAMEP=/^(games|match|assemble|traffic|sorter|explore|escape|detective|sports|court|medical|yut|sabang|squid|mole|race|claw|roleplay|lit|bingo|shoot|town|scope|plc|sec|lab|nob|names)\.html$/;
 var bar=d.createElement('div');bar.id='aptab';bar.innerHTML='<nav>'+TABS.map(function(t){var on=t[0]===page||(t[0]==='games.html'&&GAMEP.test(page));return '<a href="'+(t[0]==='#menu'?'#':t[0])+'" data-t="'+t[0]+'"'+(on?' class="on"':'')+'><i>'+t[1]+'</i>'+t[2]+'</a>'}).join('')+'</nav>';
 d.body.appendChild(bar);
 var mb=bar.querySelector('[data-t="#menu"]');mb.onclick=function(e){e.preventDefault();var m=d.getElementById('menu');if(m)m.click();else location.href='index.html'};
 /* 게시판·건의함: 홈페이지로 안내 */
 if(page==='board.html'||page==='suggest.html'){var main=d.getElementById('main')||d.querySelector('main');if(main){var n=d.createElement('div');n.className='apnote';n.innerHTML='<h3>'+(page==='board.html'?'자유게시판':'건의함')+'은 홈페이지에서 써 주세요</h3><p>여러 사람이 함께 보는 글은 인터넷 홈페이지에서만 주고받을 수 있습니다. 아래 단추를 누르면 브라우저에서 홈페이지가 열리고, 메뉴(☰)에서 '+(page==='board.html'?'자유게시판':'건의함')+'을 찾을 수 있습니다.</p><a class="apbtn" href="'+WEB+'" target="_blank" rel="noopener">홈페이지 열기 ↗</a>';main.insertBefore(n,main.firstChild.nextSibling)}}
 /* 앱에 없는 통합본 Word: 홈페이지로 */
 d.querySelectorAll('[data-src="b64/book.txt"],[data-src^="dl/guide-"],[data-src^="dl/manual-"],.zipall').forEach(function(b){var c=b.cloneNode(true);c.disabled=false;c.title='용량이 커서 앱에는 넣지 않았습니다. 누르면 홈페이지 자료실이 열립니다';var sm=c.querySelector('small');if(sm)sm.textContent+=' · 홈페이지';c.addEventListener('click',function(e){e.preventDefault();window.open(WEB,'_blank')});b.parentNode.replaceChild(c,b)});
});
/* 안드로이드 뒤로 가기 */
try{var C=window.Capacitor;if(C&&C.isNativePlatform&&C.isNativePlatform()){var App=C.registerPlugin('App');App.addListener('backButton',function(){if(d.body.classList.contains('open')){d.body.classList.remove('open');return}if(history.length>1&&page!=='index.html')history.back();else App.exitApp()})}}catch(e){}
})();
