// 서지 틀 채우기: 카드를 끌어다(또는 눌러서) 참고문헌·주석 틀의 빈칸에 맞추는 게임
(function(){var d=document,host=d.getElementById('dfill');if(!host)return;
var ST=host.dataset.st||'apa';
var NM={apa:'APA',cad:'Chicago Author-Date',mla:'MLA',nb:'Chicago Notes-Bibliography',ieee:'IEEE',van:'Vancouver',acs:'ACS'};
var COL={apa:'#3a5fb0',cad:'#4f8f84',mla:'#7262a8',nb:'#b98a2e',ieee:'#6f7885',van:'#c0626d',acs:'#98643c'};
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
var DATA={
 two:{A:[{L:'Kwon',F:'Hyeok Yong',I:'H. Y.',V:'HY'},{L:'Chi',F:'Eunju',I:'E.',V:'E'}],Y:'2012',T:'Unequal New Democracies in East Asia: Rising Inequality and Government Responses in South Korea and Taiwan',Ts:'Unequal new democracies in East Asia: Rising inequality and government responses in South Korea and Taiwan',J:'Asian Survey',Ja:'Asian Surv.',V:'52',N:'5',P:'900–923',Pc:'900–923',Pm:'900–23',Pv:'900-23'},
 one:{A:[{L:'Kwon',F:'Boduerae',I:'B.',V:'B'}],Y:'2026',T:'Milan Kundera’s Poetry in North Korea and Socialist World Literature in the 1950s',Ts:'Milan Kundera’s poetry in North Korea and socialist world literature in the 1950s',J:'Journal of Korean Studies',Ja:'J. Korean Stud.',Jv:'J Korean Stud',V:'31',N:'2',P:'367–392',Pc:'367–92',Pm:'367–92',Pv:'367-92'}};
var INI={apa:1,ieee:1,acs:1},VAN={van:1},SENT={apa:1,ieee:1,van:1},ABBR={ieee:1,van:1,acs:1};
var LAB={L1:'첫째 저자 성',F1:'첫째 저자 이름',L2:'둘째 저자 성',F2:'둘째 저자 이름',Y:'연도',T:'논문 제목',J:'학술지',V:'권',N:'호',P:'쪽 범위',NUM:'번호'};
function t(x){return {t:x}}
function S(r,v,lab){return {s:r,v:v,lab:lab||LAB[r]}}
function fnm(st,x){return INI[st]?x.I:VAN[st]?x.V:x.F}
function flab(st,r){return LAB[r]+(INI[st]||VAN[st]?'(이니셜)':'')}
function auth(st,D){var A=D.A,a=A[0],b=A[1],two=!!b,F1=S('F1',fnm(st,a),flab(st,'F1')),F2=two?S('F2',fnm(st,b),flab(st,'F2')):null,L1=S('L1',a.L),L2=two?S('L2',b.L):null;
 if(st==='apa')return two?[L1,t(', '),F1,t(', & '),L2,t(', '),F2]:[L1,t(', '),F1];
 if(st==='cad'||st==='mla'||st==='nb')return two?[L1,t(', '),F1,t(', and '),F2,t(' '),L2]:[L1,t(', '),F1];
 if(st==='ieee')return two?[F1,t(' '),L1,t(' and '),F2,t(' '),L2]:[F1,t(' '),L1];
 if(st==='van')return two?[L1,t(' '),F1,t(', '),L2,t(' '),F2]:[L1,t(' '),F1];
 return two?[L1,t(', '),F1,t('; '),L2,t(', '),F2]:[L1,t(', '),F1]}
function pg(st,D){return st==='mla'?D.Pm:(st==='cad'||st==='nb')?D.Pc:st==='van'?D.Pv:D.P}
function refT(st,D){var T=S('T',SENT[st]?D.Ts:D.T),J=S('J',ABBR[st]?((st==='van'&&D.Jv)?D.Jv:D.Ja):D.J),V=S('V',D.V),N=S('N',D.N),P=S('P',pg(st,D)),Y=S('Y',D.Y),au=auth(st,D);
 if(st==='apa')return au.concat([t(' ('),Y,t('). '),T,t('. '),J,t(', '),V,t('('),N,t('), '),P,t('.')]);
 if(st==='cad')return au.concat([t('. '),Y,t('. “'),T,t('.” '),J,t(' '),V,t(' ('),N,t('): '),P,t('.')]);
 if(st==='mla')return au.concat([t('. “'),T,t('.” '),J,t(', vol. '),V,t(', no. '),N,t(', '),Y,t(', pp. '),P,t('.')]);
 if(st==='nb')return au.concat([t('. “'),T,t('.” '),J,t(' '),V,t(', no. '),N,t(' ('),Y,t('): '),P,t('.')]);
 if(st==='ieee')return [t('[1] ')].concat(au,[t(', “'),T,t(',” '),J,t(', vol. '),V,t(', no. '),N,t(', pp. '),P,t(', '),Y,t('.')]);
 if(st==='van')return [t('1. ')].concat(au,[t('. '),T,t('. '),J,t('. '),Y,t(';'),V,t('('),N,t('):'),P,t('.')]);
 return au.concat([t(' '),T,t('. '),J,t(' '),Y,t(', '),V,t(' ('),N,t('), '),P,t('.')])}
function citeT(st,D){var A=D.A,two=A.length>1,L1=S('L1',A[0].L),L2=two?S('L2',A[1].L):null,Y=S('Y',D.Y);
 var names=two?[L1,t(st==='apa'?' & ':' and '),L2]:[L1];
 if(st==='apa')return [t('(')].concat(names,[t(', '),Y,t(')')]);
 if(st==='cad')return [t('(')].concat(names,[t(' '),Y,t(')')]);
 if(st==='mla')return [t('(')].concat(names,[t(')')]);
 if(st==='acs')return [t('(')].concat(names,[t(', '),Y,t(')')]);
 if(st==='ieee')return [t('['),S('NUM','1'),t(']')];
 if(st==='van')return [t('('),S('NUM','1'),t(')')];
 var F1=S('F1',A[0].F),F2=two?S('F2',A[1].F):null,T=S('T',D.T),J=S('J',D.J);
 return [t('1. '),F1,t(' '),L1].concat(two?[t(' and '),F2,t(' '),L2]:[],[t(', “'),T,t(',” '),J,t(' '),S('V',D.V),t(', no. '),S('N',D.N),t(' ('),Y,t('): ○○.')])}
function distract(st,D,mode){var o=[];
 if(mode==='ref'){
  var a=D.A[0];
  if(INI[st]||VAN[st])o.push({v:a.F,h:'이 양식은 이름을 이니셜로 써요.'});else o.push({v:a.I,h:'이 양식은 이름을 줄이지 않고 풀어 써요.'});
  o.push(SENT[st]?{v:D.T,h:'이 양식은 제목을 문장처럼 쓰고 첫 낱말(과 고유명사)만 대문자로 써요.'}:{v:D.Ts,h:'이 양식은 제목의 주요 낱말을 대문자로 써요.'});
  if(D.J!==D.Ja)o.push(ABBR[st]?{v:D.J,h:'이 양식은 학술지 이름을 약어로 써요.'}:{v:D.Ja,h:'이 양식은 학술지 이름을 줄이지 않고 써요.'});
  else{var pp=pg(st,D),alt=(pp===D.P?D.Pm:D.P);if(alt!==pp)o.push({v:alt,h:'이 양식의 쪽 범위 표기와 달라요.'})}
 }else if(st==='mla')o.push({v:D.Y,h:'MLA는 본문 괄호 안에 연도를 쓰지 않아요.'});
 else if(st==='ieee'||st==='van')o.push({v:D.A[0].L,h:'번호 양식은 본문에 저자 이름이 아니라 번호를 써요.'});
 else if(st==='nb')o.push({v:D.A[0].I,h:'각주에서는 이름을 풀어 쓰고 성을 뒤에 써요.'},{v:D.Ts,h:'각주의 제목은 주요 낱말을 대문자로 써요.'});
 else o.push({v:D.A[0].F,h:'본문 인용에는 이름이 아니라 성만 써요.'});
 return o}
var RO=[['ref','two'],['cite','two'],['ref','one'],['cite','one']];
var ri=0,sel=null,filled={},mistakes=0,total=0,round=null,cards=[];
function modeName(m){return m==='ref'?'참고문헌 목록':(ST==='nb'?'각주(처음 인용)':(ST==='ieee'||ST==='van')?'본문 번호':'본문 인용(괄호 주석)')}
function shuffle(a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),x=a[i];a[i]=a[j];a[j]=x}return a}
function plain(){return round.tok.map(function(k){return k.t!=null?k.t:(filled[k.id]?k.v:'___')}).join('')}
function start(){var r=RO[ri],D=DATA[r[1]],tok=(r[0]==='ref'?refT:citeT)(ST,D),n=0;
 tok.forEach(function(k){if(k.s)k.id='s'+(n++)});
 round={mode:r[0],D:D,tok:tok};filled={};sel=null;
 var cs=tok.filter(function(k){return k.s}).map(function(k){return {id:k.id,v:k.v,role:k.s,used:false}});
 // 같은 값이 둘 이상이면 역할로 구분(예: 성이 같은 두 저자)
 var ds=distract(ST,D,r[0]).filter(function(x){return !cs.some(function(c){return c.v===x.v})}).slice(0,3).map(function(x,i){return {id:'x'+i,v:x.v,role:'x',hint:x.h,used:false}});
 cards=shuffle(cs.concat(ds));total=cs.length;draw()}
function infoP(D){var A=D.A,ord=['첫째','둘째'],rows=[];
 A.forEach(function(a,i){rows.push([ord[i]+' 저자',a.L+' (성) · '+a.F+' (이름)'])});
 rows.push(['연도',D.Y],['논문 제목',D.T],['학술지',D.J+' (약어: '+D.Ja+')'],['권(volume)',D.V],['호(issue)',D.N],['쪽 범위',D.P]);
 return '<div class="dfinfo"><b>먼저 서지 정보를 확인하세요 <small>(아직 완성된 서지가 아니라 정보만 나열한 것이에요)</small></b><dl>'+rows.map(function(x){return '<dt>'+esc(x[0])+'</dt><dd>'+esc(x[1])+'</dd>'}).join('')+'</dl></div>'}
function draw(){var r=round,col=COL[ST];
 var done=Object.keys(filled).length===total;
 var line=r.tok.map(function(k){if(k.t!=null)return '<span class="dft">'+esc(k.t)+'</span>';var f=filled[k.id];return '<span class="dfs'+(f?' ok':'')+'" data-id="'+k.id+'" role="button" tabindex="0" aria-label="'+esc(k.lab)+' 칸">'+(f?esc(k.v):'<i>'+esc(k.lab)+'</i>')+'</span>'}).join('');
 host.innerHTML='<div class="dfh" style="--sc:'+col+'"><b>'+NM[ST]+' · '+modeName(r.mode)+'</b><span class="dfp">'+(ri+1)+' / '+RO.length+'</span></div>'
  +infoP(r.D)
  +'<p class="dfq">카드를 끌어다 알맞은 빈칸에 놓으세요(카드를 누른 뒤 빈칸을 눌러도 됩니다). 빈칸 이름이 힌트예요. 이 양식에 맞지 않는 카드도 섞여 있어요.</p>'
  +'<div class="dfl" id="dfl">'+line+'</div>'
  +'<div class="dfpool" id="dfpool">'+cards.map(function(c,i){return c.used?'':'<button type="button" class="dfc'+(sel===c?' sel':'')+'" data-i="'+i+'">'+esc(c.v)+'</button>'}).join('')+'</div>'
  +'<p class="dffb" id="dffb" aria-live="polite">'+(done?'<b>모두 맞았어요!</b> 실수 '+mistakes+'번':'')+'</p>'
  +(done?'<div class="dfres"><code>'+esc(plain())+'</code><button type="button" class="cpbtn" id="dfcp">완성한 모양 복사</button></div>':'')
  +'<div class="gbtns"><button type="button" class="gprimary" id="dfnext"'+(done?'':' disabled')+'>'+(ri<RO.length-1?'다음 ▶':'다시 하기 ↺')+'</button></div>';
 bind()}
function msg(s,bad){var e=d.getElementById('dffb');if(e){e.textContent=s;e.className='dffb'+(bad?' bad':' good')}}
function place(c,slotId){var k=round.tok.filter(function(x){return x.id===slotId})[0];if(!k||filled[slotId])return;
 if(c.role===k.s&&c.v===k.v&&c.id===slotId){c.used=true;filled[slotId]=1;sel=null;draw();return}
 // 같은 값의 카드가 다른 칸에 맞는 경우는 틀린 칸 안내
 mistakes++;if(c.role==='x')msg(c.hint,true);else if(c.role===k.s)msg('같은 종류지만 이 칸의 값이 아니에요. 순서를 다시 살펴보세요.',true);else msg('이 칸은 “'+k.lab+'” 자리예요. 다른 카드를 찾아보세요.',true)}
function bind(){
 var pool=d.getElementById('dfpool'),line=d.getElementById('dfl');
 pool.querySelectorAll('.dfc').forEach(function(b){var c=cards[+b.dataset.i];
  b.addEventListener('pointerdown',function(ev){if(ev.button>0)return;var sx=ev.clientX,sy=ev.clientY,ghost=null,moved=false;
   function mv(e){if(!moved&&Math.abs(e.clientX-sx)+Math.abs(e.clientY-sy)<6)return;moved=true;if(!ghost){ghost=b.cloneNode(true);ghost.className='dfc dfg';d.body.appendChild(ghost);b.classList.add('drag')}ghost.style.left=e.clientX+'px';ghost.style.top=e.clientY+'px'}
   function up(e){d.removeEventListener('pointermove',mv);d.removeEventListener('pointerup',up);d.removeEventListener('pointercancel',up);
    if(ghost){ghost.remove();b.classList.remove('drag')}
    if(moved){var el=d.elementFromPoint(e.clientX,e.clientY),sl=el&&el.closest&&el.closest('.dfs');if(sl)place(c,sl.dataset.id);else if(el&&el.closest&&!el.closest('#dfpool')){/*빈 곳에 놓음*/}}
    else{sel=(sel===c?null:c);draw()}}
   d.addEventListener('pointermove',mv);d.addEventListener('pointerup',up);d.addEventListener('pointercancel',up)});
  b.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();sel=(sel===c?null:c);draw()}})});
 line.querySelectorAll('.dfs').forEach(function(s){function go(){if(sel)place(sel,s.dataset.id);else msg('먼저 아래 카드를 하나 고르거나 끌어다 놓으세요.',false)}s.addEventListener('click',go);s.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}})});
 var nx=d.getElementById('dfnext');if(nx)nx.addEventListener('click',function(){if(nx.disabled)return;if(ri<RO.length-1)ri++;else{ri=0;mistakes=0}start()});
 var cp=d.getElementById('dfcp');if(cp)cp.addEventListener('click',function(){var t=plain();function ok(){cp.textContent='복사됨';setTimeout(function(){cp.textContent='완성한 모양 복사'},1200)}try{navigator.clipboard.writeText(t).then(ok,ok)}catch(e){ok()}})}
start();
})();
