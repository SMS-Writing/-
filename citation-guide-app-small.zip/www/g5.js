(function(){
var d=document,$=function(i){return d.getElementById(i)};
function boot(){var GX=window.GX;if(!GX||window.__g5done)return;window.__g5done=true;
 var esc=GX.esc,mk=GX.mk,sh=GX.sh,pick=GX.pick,ri=GX.ri,ls=GX.ls,STY=GX.STY,sty=GX.sty,hiRow=GX.hiRow;
 GX.sbInit&&GX.sbInit();
 function sname(id){return sty(id).n}
 var SIDS=STY.map(function(s){return s.id});
 // ---------- 공통: 양식 고르기 막대 (섞기 선택 가능) ----------
 function styBar(host,key,cb){var cur=ls(key)||'mix';var h='<div class="mysel"><span class="mylab">양식</span><button class="mys'+(cur==='mix'?' on':'')+'" data-i="mix" style="--sc:#555">양식 정하지 않고 섞어서</button>'+STY.map(function(s){return '<button class="mys'+(s.id===cur?' on':'')+'" style="--sc:'+s.c+'" data-i="'+s.id+'">'+esc(s.n)+'</button>'}).join('')+'</div>';
  return {html:h,cur:cur,bind:function(){host.querySelectorAll('.mysel .mys').forEach(function(b){b.onclick=function(){ls(key,b.dataset.i);cb()}})}}}
 function pickSid(cur){return cur==='mix'?pick(SIDS):cur}
 // ---------- 공통: 퀴즈 엔진 ----------
 // make() → {q:html, kind:'pick'|'seg', opts:[{t,good,why,hi}], segs:[{t,good}], sid, why, show:html}
 function quiz(host,cfg){var $=function(i){return host.querySelector('#'+i)||d.getElementById(i)};var mode=ls(cfg.gid+'.mode')||'ten',ck=GX.CHK[(cfg.gid.length+cfg.gid.charCodeAt(0))%4];
  function run(){ls(cfg.gid+'.mode',mode);var endless=mode==='endless',i=0,score=0,lv=3,streak=0,ok=0,miss=0,total=cfg.rounds||8,sb=cfg.bar?cfg.bar(run):null;
   function show(){var Q=cfg.make(sb?sb.cur:'mix'),done=false,sn=Q.sid?sty(Q.sid):null;
    host.innerHTML=(sb?sb.html:'')+GX.modeBar([['ten',total+'문제 한 판'],['endless','무한(목숨 3)']],mode)+'<div class="gbar"><span>문제 <b>'+(i+1)+(endless?'':' / '+total)+'</b></span><span>점수 <b>'+score+'</b></span><span>연속 <b>'+streak+'</b></span>'+(endless?'<span>목숨 '+GX.lives(lv,3)+'</span>':'')+'</div>'
     +(sn&&Q.pill!==false?'<div class="qpill"><span class="spill" style="--sc:'+sn.c+'">'+esc(sn.n)+'</span><small>이 문제의 양식</small></div>':'')
     +'<div class="qask"><span class="qav">'+GX.avatar(ck)+'</span><div>'+Q.q+'</div></div>'+(Q.show?'<div class="qshow" id="qshow">'+Q.show+'</div>':'')
     +(Q.kind==='pick'?'<div class="opts">'+Q.opts.map(function(o,k){return '<button type="button" class="opt" data-k="'+k+'"><b>'+['①','②','③','④'][k]+'</b><span>'+o.t+'</span></button>'}).join('')+'</div>':'')
     +'<div class="gfb" id="jfb" aria-live="polite"></div><div class="gbtns"><button id="jhn">힌트</button>'+(endless?'<button id="jstop">그만하고 마치기</button>':'')+'</div>';
    if(sb)sb.bind();host.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){mode=b.dataset.m;run()}});
    $('jhn').onclick=function(){$('jfb').innerHTML='<b>힌트</b> '+(Q.hint||'이 양식의 규칙을 떠올려 보세요.')};
    if(endless)$('jstop').onclick=function(){GX.endGame(host,cfg.gid,score,cfg.label(ok,true),run)};
    function fin(){if(endless)GX.endGame(host,cfg.gid,score,cfg.label(ok,true),run);else{host.innerHTML='';GX.win(host,miss<=1?3:miss<=3?2:1,cfg.doneT,total+'문제 중 '+ok+'개를 맞혔습니다.','한 번 더',run,cfg.gid,score,cfg.label(ok,false))}}
    function ans(right,v,extra){if(done)return;done=true;host.querySelectorAll('.opt,.seg,.cit,.refl .rl').forEach(function(b){b.disabled=true;b.classList&&b.classList.add('locked')});
     if(right){ok++;streak++;score+=10+Math.min(30,streak*2)}else{streak=0;miss++;if(endless)lv--}
     var av=host.querySelector('.qav');if(av){av.innerHTML=GX.avatar(ck,right?'happy':'sad');av.classList.add(right?'cheer':'oops')}
     if(Q.after)Q.after(host,v,right);
     $('jfb').innerHTML=(right?'<b class="okt">'+cfg.goodW+'</b> ':'<b class="not">'+cfg.badW+'</b> ')+(Q.why?'<div class="qwhy">'+Q.why+'</div>':'')+(Q.rule?'<details class="why" open><summary>이 양식의 규칙</summary><div class="wr"><p>'+Q.rule+'</p></div></details>':'')+' <button class="gprimary spkl" id="jn">다음 →</button>';
     var over=endless&&lv<=0,last=!endless&&i+1>=total;if(over||last)$('jn').textContent='결과 보기';$('jn').onclick=function(){i++;if(over||last)fin();else show()};
     try{$('jfb').scrollIntoView({block:'nearest'})}catch(e){}}
    if(Q.kind==='pick'){host.querySelectorAll('.opt').forEach(function(b){b.onclick=function(){var k=+b.dataset.k,o=Q.opts[k];
      host.querySelectorAll('.opt').forEach(function(x,j){var oo=Q.opts[j];x.classList.add(oo.good?'good':(j===k?'pickbad':'dim'));if(oo.note)x.insertAdjacentHTML('beforeend','<em class="owhy'+(oo.good?' ok':'')+'">'+(oo.good?'✔ ':'✖ ')+oo.note+'</em>')});
      ans(!!o.good,k)}})}
    else Q.bind(host,ans)}
   show()}
  run()}

 // ---------- 주관식(직접 입력) 문제 만들기 ----------
 function norm(s,loose){s=String(s||'').replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/\s+/g,' ').trim();if(loose)s=s.toLowerCase().replace(/[\s.,;:'"()\[\]]/g,'');return s}
 function typeQ(o){ // o:{sid,q,show,answers:[정답들],why,rule,hint,exact:true|false}
  return {sid:o.sid,kind:'type',q:o.q,show:(o.show||'')+'<form class="typef" autocomplete="off"><input class="typei" type="text" maxlength="160" placeholder="여기에 직접 쓰세요" aria-label="답 입력"><button class="gprimary" type="submit">확인</button></form><p class="mut typen">'+(o.exact?'마침표·쉼표·대소문자까지 보는 문제입니다.':'대소문자와 마침표는 달라도 맞는 것으로 봅니다. 바른 모양은 정답 설명에서 확인하세요.')+'</p>',why:o.why,rule:o.rule,hint:o.hint,
   bind:function(h,ans){var f=h.querySelector('.typef'),i=h.querySelector('.typei');if(i)setTimeout(function(){try{i.focus({preventScroll:true})}catch(e){}},50);
    f.onsubmit=function(ev){ev.preventDefault();var v=i.value;if(!norm(v))return;var ok=o.answers.some(function(a){return o.exact?norm(a)===norm(v):norm(a,1)===norm(v,1)});
     var shown=o.answers[0],strict=o.answers.some(function(a){return norm(a)===norm(v)});i.disabled=true;f.querySelector('button').disabled=true;
     h.querySelector('.typen').innerHTML=(ok?(strict||o.exact?'':'<b>정답입니다.</b> 다만 바른 모양은 ')+(strict||o.exact?'':'<code>'+esc(shown)+'</code>'+' (마침표·대소문자 확인)'):'내 답 <code>'+esc(v)+'</code> → 바른 답 <code>'+esc(shown)+'</code>');
     ans(ok,v)}}}}
 // =====================================================================
 // 1. 이름 표기 연습
 // =====================================================================
 var NM=[['Hyeok Yong','Kwon'],['Eunju','Chi'],['Elena','Rivera'],['Sora','Han'],['Tunde','Okafor'],['Lucia','Moreno'],['Maja','Lindqvist'],['Jisoo','Park'],['Yuna','Choi'],['Min-ji','Kim'],['Seung Woo','Lee'],['Hana','Cho'],['Doyun','Baek'],['Marco','Reyes'],['Aiko','Tanaka'],['Priya','Nair'],['Omar','Haddad'],['Sofia','Almeida']];
 function ini(f,m){var parts=f.split(' ');if(m==='van')return parts.map(function(p){return p.split('-').map(function(q){return q[0].toUpperCase()}).join('')}).join('');
  return parts.map(function(p){return p.split('-').map(function(q){return q[0].toUpperCase()+'.'}).join('-')}).join(' ')}
 function inv(n){return n[1]+', '+n[0]}
 function nat(n){return n[0]+' '+n[1]}
 function one(sid,n,first){if(sid==='apa'||sid==='acs')return n[1]+', '+ini(n[0]);if(sid==='mla'||sid==='cad'||sid==='nb')return first?inv(n):nat(n);if(sid==='ieee')return ini(n[0])+' '+n[1];return n[1]+' '+ini(n[0],'van')}
 function list(sid,L){var k=L.length,A=L.map(function(n,j){return one(sid,n,j===0)});
  if(sid==='apa'){return k===1?A[0]:A.slice(0,-1).join(', ')+', & '+A[k-1]}
  if(sid==='mla'){return k===1?A[0]:k===2?A[0]+', and '+A[1]:A[0]+', et al.'}
  if(sid==='cad'||sid==='nb'){if(k===1)return A[0];if(k===2)return A[0]+', and '+A[1];if(k<=6)return A.slice(0,-1).join(', ')+', and '+A[k-1];return A.slice(0,3).join(', ')+', et al.'}
  if(sid==='ieee'){if(k===1)return A[0];if(k===2)return A[0]+' and '+A[1];if(k<=6)return A.slice(0,-1).join(', ')+', and '+A[k-1];return A[0]+' et al.'}
  if(sid==='van'){return k<=6?A.join(', '):A.slice(0,6).join(', ')+', et al'}
  return A.join('; ')}
 var NRULE={apa:'APA는 “성, 이니셜.” 순서입니다. 이니셜 사이는 띄어 쓰고(H. Y.), 둘 이상이면 마지막 저자 앞에 “, &”를 씁니다.',
  mla:'MLA는 첫 저자만 “성, 이름”으로 뒤집고 둘째 저자부터는 “이름 성” 순서입니다. 이름은 이니셜이 아니라 풀어 씁니다. 둘이면 “, and”, 셋 이상이면 첫 저자 뒤에 “, et al.”을 씁니다.',
  cad:'Chicago Author-Date는 참고문헌에서 첫 저자만 “성, 이름”으로 뒤집고 나머지는 “이름 성”입니다. 마지막 저자 앞에 “, and”를 씁니다. 이 안내서 기준으로 6명까지 전원, 7명 이상은 앞 3명 뒤에 et al.을 씁니다.',
  nb:'Chicago Notes-Bibliography의 참고문헌(Bibliography)은 첫 저자만 “성, 이름”으로 뒤집고 나머지는 “이름 성”입니다. 마지막 앞에 “, and”. 이 안내서 기준으로 6명까지 전원, 7명 이상은 앞 3명 뒤에 et al.입니다.',
  ieee:'IEEE는 이름 첫 글자(이니셜)를 먼저 쓰고 성을 뒤에 둡니다(H. Y. Kwon). 성을 앞에 두지 않습니다. 둘은 “and”, 셋 이상은 쉼표와 “and”로 잇고, 이 안내서 기준으로 7명 이상은 첫 저자 뒤에 et al.입니다.',
  van:'Vancouver는 성 다음에 이니셜을 붙여 쓰고 마침표와 띄어쓰기가 없습니다(Kwon HY). 저자 사이는 쉼표입니다. 이 안내서 기준으로 7명 이상이면 앞 6명 뒤에 et al.을 씁니다.',
  acs:'ACS는 “성, 이니셜.” 순서이고 저자 사이는 세미콜론(;)입니다(Kwon, H. Y.; Chi, E.). 이 안내서에서는 저자를 모두 씁니다.'};
 function mutate(sid,L){var s=list(sid,L),c=[];
  if(sid==='apa'){c.push([s.replace(/\. /g,'.'),'이니셜 사이를 붙여 썼습니다. APA는 “H. Y.”처럼 띄어 씁니다.']);c.push([s.replace(', & ',' and '),'APA 참고문헌에서는 and가 아니라 &를 씁니다.']);c.push([L.map(function(n){return nat(n)}).join(', '),'성을 먼저 쓰고 쉼표를 붙여야 합니다.'])}
  else if(sid==='van'){c.push([s.replace(/(\b[A-Z])([A-Z]+)\b/g,function(m,a,b){return m}).replace(/ ([A-Z])([A-Z])\b/g,' $1. $2.'),'Vancouver는 이니셜에 마침표를 쓰지 않습니다.']);c.push([s.replace(/, /g,'; '),'Vancouver는 저자 사이에 쉼표를 씁니다(세미콜론은 ACS).'])}
  else if(sid==='ieee'){c.push([L.map(function(n){return n[1]+', '+ini(n[0])}).join(' and '),'IEEE는 이니셜을 앞에, 성을 뒤에 씁니다.']);c.push([s.replace('. ','.'),'이니셜 뒤에 띄어쓰기가 필요합니다.'])}
  else if(sid==='acs'){c.push([s.replace(/; /g,', '),'ACS는 저자 사이에 세미콜론(;)을 씁니다.']);c.push([L.map(function(n){return n[1]+', '+n[0]}).join('; '),'ACS는 이름을 풀어 쓰지 않고 이니셜로 씁니다.'])}
  else{c.push([L.map(function(n){return n[1]+', '+ini(n[0])}).join(', '),'Chicago·MLA는 이름을 이니셜이 아니라 풀어 씁니다.']);if(L.length>1)c.push([L.map(inv).join(', '),'둘째 저자부터는 “이름 성” 순서로 씁니다. 모두 뒤집지 않습니다.']);c.push([s.replace(/, and /,' and '),'마지막 저자 앞 쉼표(“, and”)가 빠졌습니다.'])}
  return c.filter(function(x){return x[0]!==s})}
 function pn(L){return L.map(nat).join(L.length>2?', ':' and ')}
 function nameQ(cur){var sid=pickSid(cur),t=Math.random(),k=t<.55?ri(1,2):(t<.8?3:1),L=sh(NM).slice(0,k),S=sty(sid),good=list(sid,L);
  var ty=pick(['pick','pick','which','family','tf','many','type','type']);
  if(ty==='type'){var K2=sid==='van'||sid==='ieee'?Math.min(k,2):k;L=sh(NM).slice(0,Math.max(1,Math.min(K2,2)));good=list(sid,L);return typeQ({sid:sid,q:'다음 저자를 <b>'+esc(S.n)+'</b> 참고문헌에 쓰는 모양으로 <b>직접 입력</b>해 보세요.',show:'<div class="nameshow">'+esc(pn(L))+'</div><p class="mut">논문 첫 쪽에 쓰인 대로 “이름 성” 순서로 보인 것입니다.</p>',answers:[good],exact:true,why:'바른 표기는 <b>'+esc(good)+'</b> 입니다.',rule:esc(NRULE[sid]),hint:'성이 앞에 오는지, 이니셜인지 이름 전체인지, 저자 사이 기호가 무엇인지 떠올려 보세요.'})}
  if(ty==='many'){var big=sid==='van'||sid==='ieee'||sid==='cad'||sid==='nb';if(big){L=sh(NM).slice(0,7);good=list(sid,L)}else{L=sh(NM).slice(0,3);good=list(sid,L)}}
  if(ty==='pick'||ty==='many'){var pool=[],seen={};seen[good]=1;
   SIDS.filter(function(x){return x!==sid}).forEach(function(x){var s=list(x,L);if(!seen[s]){seen[s]=1;pool.push({t:esc(s),note:'이 모양은 <b>'+esc(sname(x))+'</b> 양식의 표기입니다.'})}});
   mutate(sid,L).forEach(function(m){if(!seen[m[0]]){seen[m[0]]=1;pool.unshift({t:esc(m[0]),note:m[1]})}});
   var o=[{t:esc(good),good:1,note:'바른 표기'}].concat(sh(pool).slice(0,3));if(o.length<4)ty='which';else
   return {sid:sid,kind:'pick',q:'다음 저자를 <b>'+esc(S.n)+'</b> 참고문헌에 쓰면 어떻게 될까요?'+(ty==='many'&&L.length>=3?' (저자가 '+L.length+'명)':''),show:'<div class="nameshow">'+esc(pn(L))+'</div><p class="mut">논문 첫 쪽에 쓰인 대로 “이름 성” 순서로 보인 것입니다.</p>',opts:sh(o),why:'바른 표기는 <b>'+esc(good)+'</b> 입니다.',rule:esc(NRULE[sid]),hint:'성(family name)이 앞에 오는지, 이니셜인지 이름 전체인지, 저자 사이 기호가 무엇인지 보세요.'}}
  if(ty==='which'){var gs=list(sid,L),opts=[sid].concat(sh(SIDS.filter(function(x){return x!==sid&&list(x,L)!==gs})).slice(0,3));
   return {sid:null,kind:'pick',q:'이 저자 표기는 어느 <b>인용 스타일</b>의 모양일까요?',show:'<div class="nameshow">'+esc(gs)+'</div>',opts:sh(opts).map(function(x){return {t:esc(sname(x)),good:x===sid,note:x===sid?'맞습니다.':'<b>'+esc(sname(x))+'</b>는 “'+esc(list(x,L))+'” 모양입니다.'}}),why:'이 모양은 <b>'+esc(S.n)+'</b>입니다.',rule:esc(NRULE[sid]),hint:'이니셜인가요, 이름 전체인가요? 저자 사이 기호는 쉼표·세미콜론·and·& 중 무엇인가요?'}}
  if(ty==='family'){var nn=pick(NM),koFirst=Math.random()<.5,toks=koFirst?[nn[1]].concat(nn[0].split(' ')):nn[0].split(' ').concat([nn[1]]);
   return {sid:null,kind:'seg',q:'이 영문 이름에서 <b>성(family name)</b>을 눌러 보세요.',show:'<div class="nameshow segs">'+toks.map(function(t,j){return '<button type="button" class="seg" data-j="'+j+'">'+esc(t)+'</button>'}).join(' ')+'</div><p class="mut">'+(koFirst?'한국식 순서(성이 앞)로 쓰인 경우입니다.':'서양식 순서(성이 뒤)로 쓰인 경우입니다.')+'</p>',
    why:'성은 <b>'+esc(nn[1])+'</b>입니다. 논문에 쓰인 영문 표기를 그대로 옮기되, 성을 앞에 두는 양식에서는 성 뒤에 쉼표를 붙입니다. 이 문제의 이름은 연습용 가상 이름입니다.',rule:'영문 논문의 저자 이름은 논문 첫 쪽(또는 출판사 쪽)에 쓰인 철자와 하이픈을 그대로 따릅니다. 어느 쪽이 성인지 확실하지 않으면 논문 쪽의 저자 정보나 도서관 목록으로 확인하고, 짐작해서 바꾸지 않습니다.',hint:'한국인 저자는 성이 한 글자(예: Kim, Lee, Park)인 경우가 많지만 확인이 필요합니다.',
    bind:function(h,ans){h.querySelectorAll('.seg').forEach(function(b){b.onclick=function(){var j=+b.dataset.j,ok=toks[j]===nn[1];h.querySelectorAll('.seg').forEach(function(x,q){if(toks[q]===nn[1])x.classList.add('hl');else if(q===j)x.classList.add('pickbad')});h.querySelector('#qshow').classList.add('hlk');ans(ok,j)}})}}}
  // tf
  var m=mutate(sid,L),bad=Math.random()<.5&&m.length,pr=bad?pick(m):[good,''];
  return {sid:sid,kind:'seg',q:'이 저자 표기는 <b>'+esc(S.n)+'</b> 규칙에 맞을까요?',show:'<div class="nameshow" id="nsh">'+esc(pr[0])+'</div><div class="tfrow"><button type="button" class="seg tfb" data-v="0">맞다</button><button type="button" class="seg tfb" data-v="1">틀렸다</button></div>',
   why:bad?'틀린 표기였습니다. '+pr[1]+' 바른 표기: <b>'+esc(good)+'</b>':'규칙에 맞는 표기였습니다.',rule:esc(NRULE[sid]),hint:'이니셜·쉼표·and/&/;·성의 위치를 하나씩 확인하세요.',
   bind:function(h,ans){h.querySelectorAll('.tfb').forEach(function(b){b.onclick=function(){var v=+b.dataset.v;if(bad){var n=h.querySelector('#nsh');n.classList.add('hlk');n.innerHTML='<span class="hl">'+esc(pr[0])+'</span>'}ans(v===(bad?1:0),v)}})}}}
 var NMG=$('nmg');
 if(NMG){(function startN(){quiz(NMG,{gid:'names',rounds:8,doneT:'이름 표기 완주!',goodW:'정답!',badW:'아쉽습니다!',bar:function(re){return styBar(NMG,'names.sty',re)},make:nameQ,label:function(ok,en){return '이름 표기 '+(en?'무한 · ':'· ')+ok+'개 정답'}})})()}

 // =====================================================================
 // 1-2. 이름 표기 단계 도전: 저자·번역자·편집자가 함께 나올 때 (8단계)
 // =====================================================================
 var TITLES=['Reading the Archive','Notes from the Margin','A Field Guide to Sources','The Careful Reader','Maps of Quiet Rooms','Ledger of Small Questions','Paper Boats and Footnotes','The Lantern Method'],
  PUBS=['Harbor Press','Lantern Press','Cedar House','Lakeside Press','Northfield Books'],CHS=['On careful quotation','Seeds of a method','Reading in the dark','Counting the sources','A short history of notes'],
  PLC='Exampleton, NY, USA';
 function pers(sid,n,bad){if(bad){if(sid==='apa'||sid==='mla'||sid==='cad'||sid==='nb')return inv(n);if(sid==='ieee')return n[1]+', '+ini(n[0]);if(sid==='van')return nat(n);return nat(n)}
  if(sid==='apa'||sid==='ieee')return ini(n[0])+' '+n[1];if(sid==='mla'||sid==='cad'||sid==='nb')return nat(n);if(sid==='van')return n[1]+' '+ini(n[0],'van');return n[1]+', '+ini(n[0])}
 function pl(sid,P,bad){var A=P.map(function(n,j){return pers(sid,n,bad&&j===0)}),k=A.length;
  if(sid==='apa')return k===1?A[0]:k===2?A[0]+' & '+A[1]:A.slice(0,-1).join(', ')+', & '+A[k-1];
  if(sid==='van'||sid==='acs')return A.join(', ');
  return k===1?A[0]:k===2?A[0]+' and '+A[1]:A.slice(0,-1).join(', ')+', and '+A[k-1]}
 function rolep(sid,role,P,o){o=o||{};var k=P.length,pls=k>1&&!o.sing,s=pl(sid,P,o.badName),tr=role==='trans';
  if(o.swap)tr=!tr;
  if(sid==='apa')return '('+s+', '+(tr?'Trans.':(pls?'Eds.':'Ed.'))+')';
  if(sid==='mla')return tr?'Translated by '+s:((o.low?'e':'E')+'dited by '+s);
  if(sid==='cad'||sid==='nb')return tr?'Translated by '+s:((o.low?'e':'E')+'dited by '+s);
  if(sid==='ieee')return s+', '+(tr?'Trans.':(pls?'Eds.':'Ed.'));
  if(sid==='van')return s+', '+(tr?'translator':'editor')+(pls?'s':'');
  return s+', '+(pls?'Eds.':'Ed.')}
 var AVAIL={T:['apa','mla','cad','nb','ieee','van'],E:['apa','mla','cad','nb','ieee'],W:['apa','mla','cad','nb','ieee','van','acs'],C:['apa','mla','cad','nb','ieee','van','acs']};
 var TN={T:'번역서(저자 + 번역자)',E:'저자와 편집자가 따로 있는 책',W:'편저서 전체(편집자가 저자 자리)',C:'편저서 속 글(글쓴이 + 책의 편집자)'};
 // 한 서지를 조각(segs: {t, r})으로 만든다. r=author|trans|ed|other
 function dot(s){return /\.$/.test(s)?s:s+'.'}
 function entry(sid,ty,o,f){f=f||{};var A=o.A,Tr=o.Tr,Ed=o.Ed,k=Ed.length,S=[],Y=o.y,au=list(sid,A),sg=function(t,r){S.push({t:t,r:r||'o'})};
  var tr=function(){return rolep(sid,'trans',Tr,f)},ed=function(low){var g={};for(var kk in f)g[kk]=f[kk];if(low===true)g.low=1;return rolep(sid,'ed',Ed,g)},pls=k>1&&!f.sing;
  if(sid==='apa'){
   if(ty==='T'){sg(au,'a');sg('('+Y+').');sg(o.ti);sg(tr()+'.','t');sg(o.pub+'.');sg('(Original work published '+(Y-9)+').')}
   else if(ty==='E'){sg(au,'a');sg('('+Y+').');sg(o.ti);sg(ed()+'.','e');sg(o.pub+'.')}
   else if(ty==='W'){var el=list('apa',Ed);sg(el+' ('+(pls?'Eds.':'Ed.')+').','e');sg('('+Y+').');sg(o.ti+'.');sg(o.pub+'.')}
   else{sg(au,'a');sg('('+Y+').');sg(o.ch+'.');sg('In '+pl('apa',Ed,f.badName)+' ('+(pls?'Eds.':'Ed.')+'),','e');sg(o.bk+' (pp. '+o.pp+').');sg(o.pub+'.')}}
  else if(sid==='mla'){
   if(ty==='T'){sg(dot(au),'a');sg(o.ti+'.');sg(tr()+',','t');sg(o.pub+', '+Y+'.')}
   else if(ty==='E'){sg(dot(au),'a');sg(o.ti+'.');sg(ed()+',','e');sg(o.pub+', '+Y+'.')}
   else if(ty==='W'){var m=list('mla',Ed);sg(m+', '+(pls?'editors':'editor')+'.','e');sg(o.ti+'.');sg(o.pub+', '+Y+'.')}
   else{sg(dot(au),'a');sg('“'+o.ch+'.”');sg(o.bk+',');sg(ed(true)+',','e');sg(o.pub+', '+Y+', pp. '+o.pp+'.')}}
  else if(sid==='cad'||sid==='nb'){var ad=sid==='cad';
   if(ty==='T'){sg(dot(au),'a');if(ad)sg(Y+'.');sg(o.ti+'.');sg(tr()+'.','t');sg(ad?o.pub+'.':o.pub+', '+Y+'.')}
   else if(ty==='E'){sg(dot(au),'a');if(ad)sg(Y+'.');sg(o.ti+'.');sg(ed()+'.','e');sg(ad?o.pub+'.':o.pub+', '+Y+'.')}
   else if(ty==='W'){var c=list(sid,Ed);sg(c+', '+(pls?'eds':'ed')+'.','e');if(ad)sg(Y+'.');sg(o.ti+'.');sg(ad?o.pub+'.':o.pub+', '+Y+'.')}
   else{sg(dot(au),'a');if(ad)sg(Y+'.');sg('“'+o.ch+'.”');sg('In '+o.bk+',');sg(dot(ed(true)),'e');sg(ad?o.pub+'.':o.pub+', '+Y+'.')}}
  else if(sid==='ieee'){
   if(ty==='T'){sg(au+',','a');sg(o.ti+',');sg(dot(tr()),'t');sg(PLC+': '+o.pub+', '+Y+'.')}
   else if(ty==='E'){sg(au+',','a');sg(o.ti+',');sg(dot(ed()),'e');sg(PLC+': '+o.pub+', '+Y+'.')}
   else if(ty==='W'){sg(ed()+',','e');sg(o.ti+'.');sg(PLC+': '+o.pub+', '+Y+'.')}
   else{sg(au+',','a');sg('“'+o.ch+',”');sg('in '+o.bk+',');sg(dot(ed()),'e');sg(PLC+': '+o.pub+', '+Y+', pp. '+o.pp+'.')}}
  else if(sid==='van'){
   if(ty==='T'){sg(dot(au),'a');sg(o.ti+'.');sg(tr()+'.','t');sg(PLC.split(',')[0]+': '+o.pub+'; '+Y+'.')}
   else if(ty==='W'){sg(ed()+'.','e');sg(o.ti+'.');sg('Exampleton: '+o.pub+'; '+Y+'.')}
   else{sg(dot(au),'a');sg(o.ch+'.');sg('In: '+ed()+'.','e');sg(o.bk+'.');sg('Exampleton: '+o.pub+'; '+Y+'.');sg('p. '+o.pp+'.')}}
  else{
   if(ty==='W'){sg(o.ti+';');sg(ed()+';','e');sg(o.pub+': Boston, MA, '+Y+'.')}
   else{sg(dot(au),'a');sg(o.ch+'.');sg('In '+o.bk+';');sg(ed()+';','e');sg(o.pub+': Boston, MA, '+Y+';');sg('pp '+o.pp+'.')}}
  return S}
 function etext(S){return S.map(function(x){return x.t}).join(' ')}
 var RR={apa:'APA는 번역자와 편집자를 제목 뒤 괄호 안에 “(D. Smith, Trans.)”, “(D. Smith, Ed.)”로 씁니다. 이 자리의 이름은 “이니셜 성” 순서이고 성을 뒤집지 않습니다. 편저서 전체는 편집자가 저자 자리에 “(Ed.)”, “(Eds.)”와 함께 오고, 책 속 글은 “In F. Last (Ed.),”로 씁니다. 편집자가 둘 이상이면 Eds.입니다.',
  mla:'MLA는 번역자를 “Translated by 이름 성”, 편집자를 “edited by 이름 성”으로 제목 뒤에 씁니다. 이 자리의 이름은 뒤집지 않고 이니셜이 아니라 풀어 씁니다. 편저서 전체는 편집자가 저자 자리에 “Last, First, editor.”(둘 이상은 editors)로 옵니다.',
  cad:'Chicago Author-Date는 번역자를 “Translated by 이름 성.”, 편집자를 “Edited by 이름 성.”으로 제목 뒤에 씁니다(이름은 뒤집지 않음). 편저서 전체는 “Last, First, ed.”(둘 이상은 eds.)가 저자 자리에 오고, 책 속 글은 “In 책 제목, edited by 이름 성.”입니다.',
  nb:'Chicago Notes-Bibliography의 참고문헌은 번역자를 “Translated by 이름 성.”, 편집자를 “Edited by 이름 성.”으로 제목 뒤에 씁니다(이름은 뒤집지 않음). 편저서 전체는 “Last, First, ed.”(둘 이상은 eds.)가 저자 자리에 오고, 책 속 글은 “In 책 제목, edited by 이름 성.”입니다.',
  ieee:'IEEE는 번역자와 편집자를 “D. Smith, Trans.”, “D. Smith, Ed.”처럼 제목 뒤에 씁니다. 이니셜이 먼저이고 성은 뒤입니다. 편저서 전체는 “E. Hobsbawm and T. Ranger, Eds.,”가 저자 자리에 오고, 책 속 글은 “in 책 제목, 편집자, Eds.” 순서입니다.',
  van:'Vancouver는 번역자를 “Smith D, translator.”, 편집자를 “Park SH, editor.”로 씁니다(둘 이상은 translators·editors). 이니셜에는 마침표를 쓰지 않습니다. 책 속 글은 “In: 편집자, editor. 서명.” 순서입니다.',
  acs:'ACS는 편집자를 “Okafor, T., Lindqvist, M., Eds.”처럼 “성, 이니셜.” 뒤에 Eds.(한 명은 Ed.)를 붙여 씁니다. 편집서 전체는 서명 뒤에, 책 속 글은 “In 서명; 편집자, Eds.; 출판사: 출판지, 연도; pp 쪽.” 순서입니다.'};
 var STG=[['역할 찾기','서지 안에서 번역자·편집자 이름이 들어 있는 곳 찾기'],['번역자 쓰기','저자 + 번역자가 있는 책'],['편집자 쓰기','저자와 편집자가 따로 있는 책'],['편저서 전체','편집자가 저자 자리에 오는 책'],['책 속의 글','글쓴이 + 책의 편집자'],['직접 써 보기','번역자·편집자 표시를 직접 입력'],['틀린 곳 찾기','맞다·틀리다 판정'],['사람이 많을 때','저자 둘, 번역자·편집자 둘 이상']];
 var nq2=0;
 function ppick(n){return sh(NM).slice(0,n)}
 function mkData(many){var P=ppick(many?7:5),k=many?2:1;return {A:P.slice(0,many?2:1),Tr:P.slice(2,2+(many?2:1)),Ed:P.slice(many?4:3,many?4+ri(2,3):3+ri(1,2)),y:ri(2008,2023),ti:pick(TITLES),pub:pick(PUBS),ch:pick(CHS),bk:pick(TITLES),pp:ri(10,60)+'–'+ri(61,99)}}
 function showData(ty,o,sid){var nm=function(P){return P.map(nat).join(', ')},h='<div class="nameshow roles">';
  if(ty==='T')h+='저자: <b>'+esc(nm(o.A))+'</b><br>번역자: <b>'+esc(nm(o.Tr))+'</b><br>책: '+esc(o.ti)+' · '+esc(o.pub)+' · '+o.y+' (원서 '+(o.y-9)+')';
  else if(ty==='E')h+='저자: <b>'+esc(nm(o.A))+'</b><br>편집자: <b>'+esc(nm(o.Ed))+'</b><br>책: '+esc(o.ti)+' · '+esc(o.pub)+' · '+o.y;
  else if(ty==='W')h+='편집자(책 전체를 엮음): <b>'+esc(nm(o.Ed))+'</b><br>책: '+esc(o.ti)+' · '+esc(o.pub)+' · '+o.y;
  else h+='글쓴이: <b>'+esc(nm(o.A))+'</b> · 글: '+esc(o.ch)+'<br>책 편집자: <b>'+esc(nm(o.Ed))+'</b><br>책: '+esc(o.bk)+' · '+esc(o.pub)+' · '+o.y+' · pp. '+o.pp;
  return h+'</div><p class="mut">논문·책 속표지에 쓰인 대로 “이름 성” 순서로 보인 것입니다. 연습용 가상 자료입니다.</p>'}
 function pickTy(sid,ty){return AVAIL[ty].indexOf(sid)>-1?ty:(AVAIL.W.indexOf(sid)>-1?pick(['W','C']):'C')}
 function bad(sid,ty,o){var c=[],E=etext(entry(sid,ty,o)),add=function(f,why){var t=etext(entry(sid,ty,o,f));if(t!==E)c.push([t,why])};
  if(ty==='T'||ty==='E')add({swap:1},ty==='T'?'번역자 표시를 편집자 표시(Ed.·edited by)로 바꿔 썼습니다.':'편집자 표시를 번역자 표시(Trans.·Translated by)로 바꿔 썼습니다.');
  else add({swap:1},'편집자 표시 대신 번역자 표시를 썼습니다.');
  add({badName:1},'번역자·편집자 이름의 모양이 이 양식의 규칙과 다릅니다(성 뒤집기, 이니셜 사용 여부 확인).');
  if(o.Ed.length>1&&(ty==='W'||ty==='C'||ty==='E'))add({sing:1},'편집자가 둘 이상인데 단수형(Ed.·ed.·editor)을 썼습니다.');
  return c}
 function name2Q(cur){var st=Math.floor((nq2++%16)/2),many=st===7,o=mkData(many),ty,want=[['T','E','W','C'],['T'],['E'],['W'],['C'],['T','E','W'],['T','E','W','C'],['T','C','W']][st],w0=pick(want),sid,note='';
  if(cur==='mix'){sid=pick(AVAIL[w0]);ty=w0}else{sid=cur;ty=AVAIL[w0].indexOf(sid)>-1?w0:pick(AVAIL.W.indexOf(sid)>-1?['W','C']:['C']);if(ty!==w0)note='<br><span class="mut">이 양식은 안내서에 '+TN[w0]+' 규칙이 없어 <b>'+TN[ty]+'</b>로 바꿨습니다.</span>'}
  var hd='<b>단계 '+(st+1)+' / 8 · '+STG[st][0]+'</b> <span class="mut">('+STG[st][1]+')</span>'+note+'<br>',S=sty(sid),rule=esc(RR[sid]);
  var trTy=AVAIL.T.indexOf(sid)>-1;
  if(st===0){var seg=entry(sid,ty,o),role=ty==='T'?'t':'e',lab=ty==='T'?'번역자':'편집자';
   return {sid:sid,kind:'seg',q:hd+'다음 서지는 <b>'+esc(S.n)+'</b> 양식입니다. <b>'+lab+'</b> 이름이 들어 있는 부분을 눌러 보세요.',show:'<div class="nameshow segs">'+seg.map(function(x,j){return '<button type="button" class="seg" data-j="'+j+'">'+esc(x.t)+'</button>'}).join(' ')+'</div><p class="mut">연습용 가상 서지입니다.</p>',
    why:'정답은 <b>'+esc(seg.filter(function(x){return x.r===role})[0].t)+'</b> 입니다.',rule:rule,hint:'저자 뒤, 제목 뒤의 괄호나 Trans.·Ed.·edited by 같은 말을 찾아보세요. 책 전체를 엮은 책은 저자 자리에 편집자가 옵니다.',
    bind:function(h,ans){h.querySelectorAll('.seg').forEach(function(b){b.onclick=function(){var j=+b.dataset.j,ok=seg[j].r===role;h.querySelectorAll('.seg').forEach(function(x,q){if(seg[q].r===role)x.classList.add('hl');else if(q===j)x.classList.add('pickbad')});h.querySelector('#qshow').classList.add('hlk');ans(ok,j)}})}}}
  if(st===5){var P=ty==='T'?o.Tr:o.Ed,role2=ty==='T'?'trans':'ed',good=rolep(sid,role2,P);
   return typeQ({sid:sid,q:hd+'<b>'+esc(S.n)+'</b> 양식에서 <b>'+(ty==='T'?'번역자':'편집자')+'</b>를 표시하는 부분을 직접 써 보세요. (표시 말까지 포함, 문장 끝 마침표는 빼고)',show:'<div class="nameshow roles">'+(ty==='T'?'번역자':'편집자')+': <b>'+esc(P.map(nat).join(' · '))+'</b></div><p class="mut">책 속표지에 쓰인 “이름 성” 순서입니다. 연습용 가상 이름입니다.</p>',answers:[good],exact:true,why:'바른 표기는 <b>'+esc(good)+'</b> 입니다.',rule:rule,hint:'이름은 어떤 모양인가요(이니셜? 풀어 쓰기? 성 뒤집기?)? 그 뒤나 앞에 어떤 표시 말이 붙나요?'})}
  if(st===6){var good2=etext(entry(sid,ty,o)),m=bad(sid,ty,o),isBad=Math.random()<.6&&m.length,pr=isBad?pick(m):[good2,''];
   return {sid:sid,kind:'seg',q:hd+'이 서지는 <b>'+esc(S.n)+'</b> 규칙에 맞을까요?',show:showData(ty,o,sid)+'<div class="nameshow" id="nsh">'+esc(pr[0])+'</div><div class="tfrow"><button type="button" class="seg tfb" data-v="0">맞다</button><button type="button" class="seg tfb" data-v="1">틀렸다</button></div>',
    why:isBad?'틀린 서지였습니다. '+pr[1]+' 바른 모양: <b>'+esc(good2)+'</b>':'규칙에 맞는 서지였습니다.',rule:rule,hint:'위의 역할(번역자·편집자)과 서지의 표시 말이 맞는지, 이름 모양과 단수·복수를 하나씩 보세요.',
    bind:function(h,ans){h.querySelectorAll('.tfb').forEach(function(b){b.onclick=function(){var v=+b.dataset.v;if(isBad){var n=h.querySelector('#nsh');n.classList.add('hlk');n.innerHTML='<span class="hl">'+esc(pr[0])+'</span>'}ans(v===(isBad?1:0),v)}})}}}
  // 단계 2,3,4,5,8: 4지선다
  var good3=etext(entry(sid,ty,o)),pool=[],seen={};seen[good3]=1;
  bad(sid,ty,o).forEach(function(m){if(!seen[m[0]]){seen[m[0]]=1;pool.push({t:esc(m[0]),note:m[1]})}});
  SIDS.filter(function(x){return x!==sid&&AVAIL[ty].indexOf(x)>-1}).forEach(function(x){var s=etext(entry(x,ty,o));if(!seen[s]){seen[s]=1;pool.push({t:esc(s),note:'이 모양은 <b>'+esc(sname(x))+'</b> 양식의 서지입니다.'})}});
  var opts=[{t:esc(good3),good:1,note:'바른 표기'}].concat(sh(pool.slice(0,3)));
  return {sid:sid,kind:'pick',q:hd+'다음 자료를 <b>'+esc(S.n)+'</b> 참고문헌에 쓰면 어떻게 될까요? <span class="mut">('+TN[ty]+')</span>',show:showData(ty,o,sid),opts:sh(opts),why:'바른 표기는 <b>'+esc(good3)+'</b> 입니다.',rule:rule,hint:'저자·번역자·편집자 각각의 표시 말과 이름 모양, 쉼표·마침표 위치를 보세요.'}}
 var NMG2=$('nmg2');
 if(NMG2){var nm2n=0;quiz(NMG2,{gid:'names2',rounds:16,doneT:'이름 단계 도전 완주!',goodW:'정답!',badW:'아쉽습니다!',bar:function(re){nq2=0;return styBar(NMG2,'names2.sty',re)},make:name2Q,label:function(ok,en){return '이름 단계 도전 '+(en?'무한 · ':'· ')+ok+'개 정답'}})}

 // =====================================================================
 // 논문 약어 주관식
 // =====================================================================
 var AB=[
  {q:'둘 이상의 쪽(page)을 뜻하는 약어',a:['pp.'],st:'apa',why:'여러 쪽은 “pp.”, 한 쪽은 “p.”입니다. APA·MLA·IEEE의 쪽 표기에 쓰입니다.'},
  {q:'한 쪽(page)을 뜻하는 약어',a:['p.'],st:'mla',why:'한 쪽은 “p.”입니다. 범위가 있으면 “pp.”입니다.'},
  {q:'권(volume)을 뜻하는 약어 (MLA·IEEE 참고문헌에서 학술지 권 앞에 씀)',a:['vol.'],st:'mla',why:'MLA·IEEE는 “vol.”을 씁니다. APA는 권 번호만 이탤릭으로 씁니다.'},
  {q:'호(number/issue)를 뜻하는 약어 (MLA·IEEE에서 호 앞에 씀)',a:['no.'],st:'ieee',why:'“no.”는 호 앞에 씁니다. 숫자만 쓰는 APA·Vancouver와 구별하세요.'},
  {q:'“그리고 다른 사람들”이라는 라틴어에서 온, 저자 수를 줄일 때 쓰는 말',a:['et al.'],st:null,why:'“et al.”은 저자가 많을 때 일부 저자 뒤에 씁니다. 몇 명부터 줄이는지는 양식마다 다릅니다.'},
  {q:'편집자 한 명(editor)을 뜻하는 약어 (APA에서 괄호 안에 씀)',a:['Ed.','(Ed.)'],st:'apa',why:'APA는 “(Ed.)”, 둘 이상이면 “(Eds.)”입니다.'},
  {q:'편집자가 둘 이상일 때(editors)의 약어',a:['Eds.','(Eds.)'],st:'apa',why:'“Eds.”입니다. 한 명이면 “Ed.”입니다.'},
  {q:'판(edition)을 뜻하는 약어 (예: 2nd ___)',a:['ed.'],st:'apa',why:'“2nd ed.”처럼 씁니다.'},
  {q:'번역자(translator)를 뜻하는 약어 (APA에서 괄호 안, 예: (___))',a:['Trans.','(Trans.)'],st:'apa',why:'APA는 “(Trans.)”를 씁니다.'},
  {q:'날짜 없음(no date)을 뜻하는 약어',a:['n.d.'],st:'apa',why:'연도를 알 수 없을 때 APA는 “n.d.”를 씁니다.'},
  {q:'연결된 고유 식별번호 Digital Object Identifier의 약어',a:['DOI'],st:null,why:'DOI는 논문마다 붙는 고유 번호입니다. 이 안내서는 DOI가 없으면 쓰지 않습니다.'},
  {q:'웹 주소 Uniform Resource Locator의 약어',a:['URL'],st:null,why:'URL은 웹 주소입니다. 논문에 DOI가 있으면 DOI를 우선합니다.'},
  {q:'약 ~쯤(circa)을 뜻하는 약어, 대략의 연도 앞에 씀',a:['ca.','c.'],st:'cad',why:'정확한 연도를 모를 때 “ca. 1950”처럼 씁니다.'},
  {q:'Journal of the American Chemical Society의 ACS식 약어',a:['J. Am. Chem. Soc.'],st:'acs',exact:1,why:'ACS는 학술지 이름을 약어로 쓰고 이탤릭으로 씁니다. 약어는 CASSI 목록으로 확인하세요(이 제작 과정에서 CASSI는 열어 보지 못했습니다).'},
  {q:'New England Journal of Medicine의 Vancouver(NLM)식 약어',a:['N Engl J Med'],st:'van',exact:1,why:'Vancouver는 NLM 약어를 마침표 없이 씁니다. 약어는 NLM 목록에서 확인하세요(이 제작 과정에서 열어 보지 못했습니다).'},
  {q:'IEEE Transactions on Pattern Analysis and Machine Intelligence의 IEEE식 약어',a:['IEEE Trans. Pattern Anal. Mach. Intell.'],st:'ieee',exact:1,why:'IEEE는 학술지 단어를 줄여 쓰되 “IEEE”와 마침표 위치를 지킵니다. 약어는 IEEE 약어 목록으로 확인하세요(이 제작 과정에서 열어 보지 못했습니다).'}
 ];
 var ABG=$('abg');
 if(ABG){(function startA(){quiz(ABG,{gid:'abbr',rounds:8,doneT:'약어 주관식 완주!',goodW:'정답!',badW:'아쉽습니다!',bar:null,make:function(){var it=pick(AB),S=it.st?sty(it.st):null;return typeQ({sid:it.st,q:'다음 뜻에 해당하는 <b>약어</b>를 직접 입력하세요.',show:'<div class="nameshow">'+esc(it.q)+'</div>',answers:it.a,exact:!!it.exact,why:'정답: <b>'+esc(it.a[0])+'</b>. '+esc(it.why),rule:S?esc('관련 양식: '+S.n):'',hint:'약어는 보통 마침표로 끝납니다(DOI·URL 제외).'})},label:function(ok,en){return '논문 약어 주관식 '+(en?'무한 · ':'· ')+ok+'개 정답'}})})()}
 // =====================================================================
 // 2. 문서 속 인용 찾기
 // =====================================================================
 var DR=[
 {dp:'간호학',au:[['Harlow','Ines'],['Ono','Daichi']],y:2019,t:'Bedside handover routines and patient-reported safety on medical wards',j:'Harborview Journal of Nursing Practice',ja:'Harborview J. Nurs. Pract.',v:14,i:2,p1:88,p2:101,s:'병동 인계 방식이 환자가 느끼는 안전감에 영향을 준다'},
 {dp:'컴퓨터학',au:[['Brandt','Karl'],['Osei','Nana'],['Vega','Lina']],y:2022,t:'Lightweight anomaly detection for campus network traffic',j:'Proceedings of the Lakeside Systems Society',ja:'Proc. Lakeside Syst. Soc.',v:9,i:1,p1:301,p2:312,s:'가벼운 이상 탐지 모델로도 교내 망의 이상 트래픽을 찾을 수 있다'},
 {dp:'화학',au:[['Mendes','Rafael']],y:2018,t:'Crystal growth kinetics of hydrated salts in aqueous solution',j:'Lakeside Journal of Chemistry',ja:'Lakeside J. Chem.',v:41,i:5,p1:1120,p2:1133,s:'수화염 결정의 성장 속도는 온도에 민감하다'},
 {dp:'경제학',au:[['Ivanova','Dara'],['Mbeki','Thabo']],y:2020,t:'Minimum wage adjustments and part-time hours in small retail firms',j:'Review of Applied Labour Economics',ja:'Rev. Appl. Labour Econ.',v:27,i:3,p1:455,p2:478,s:'최저임금 조정은 소규모 소매업의 시간제 근로 시간을 바꾼다'},
 {dp:'교육학',au:[['Lindgren','Saga']],y:2021,t:'Peer feedback cycles in first-year writing seminars',j:'Journal of Writing Studies',ja:'J. Writ. Stud.',v:12,i:4,p1:67,p2:84,s:'동료 피드백을 되풀이하면 신입생의 글쓰기 수정 습관이 늘어난다'},
 {dp:'건축학',au:[['Sato','Emi'],['Duarte','Paulo']],y:2017,t:'Daylight distribution in narrow urban courtyards',j:'Journal of Building Form and Climate',ja:'J. Build. Form Clim.',v:6,i:2,p1:140,p2:156,s:'좁은 중정은 자연광이 아래층까지 닿는 정도가 낮다'},
 {dp:'정치외교학',au:[['Qureshi','Amina']],y:2016,t:'Summit diplomacy and public attention in regional politics',j:'International Review of Political Communication',ja:'Int. Rev. Polit. Commun.',v:11,i:1,p1:23,p2:41,s:'정상회담은 지역 정치에 대한 대중의 관심을 잠시 높인다'},
 {dp:'생명과학',au:[['Fischer','Jonas'],['Tran','Mai'],['Abara','Chidi']],y:2023,t:'Seasonal variation of soil microbial diversity in alpine meadows',j:'Annals of Mountain Ecology',ja:'Ann. Mt. Ecol.',v:33,i:2,p1:210,p2:229,s:'고산 초원의 토양 미생물 다양성은 계절에 따라 달라진다'},
 {dp:'심리학',au:[['Rivera','Elena'],['Han','Sora']],y:2022,t:'Sleep regularity and exam performance among first-year students',j:'Journal of Student Wellbeing Research',ja:'J. Stud. Wellbeing Res.',v:8,i:3,p1:215,p2:233,s:'수면 시각이 일정한 학생의 시험 성적이 대체로 더 높다'},
 {dp:'미디어학',au:[['Sorensen','Kirsten']],y:2019,t:'Short video platforms and news habits of young adults',j:'Review of Digital Media Studies',ja:'Rev. Digit. Media Stud.',v:5,i:2,p1:99,p2:118,s:'짧은 영상 플랫폼이 청년의 뉴스 이용 습관을 바꾼다'},
 {dp:'식품영양학',au:[['Nair','Priya'],['Almeida','Sofia']],y:2021,t:'Breakfast composition and mid-morning attention in university students',j:'Journal of Applied Nutrition Research',ja:'J. Appl. Nutr. Res.',v:19,i:1,p1:12,p2:27,s:'아침 식사의 구성이 오전 집중력에 영향을 준다'},
 {dp:'기계공학',au:[['Kowalski','Piotr'],['Haddad','Omar']],y:2020,t:'Vibration damping in lightweight robotic arms',j:'Proceedings of the Riverside Mechanics Forum',ja:'Proc. Riverside Mech. Forum',v:3,i:4,p1:540,p2:553,s:'가벼운 로봇 팔은 진동 감쇠 장치가 있어야 정밀도가 유지된다'},
 {dp:'사회학',au:[['Okafor','Tunde'],['Moreno','Lucia']],y:2018,t:'Neighbourhood ties and civic participation in new towns',j:'Journal of Urban Society Studies',ja:'J. Urban Soc. Stud.',v:15,i:3,p1:301,p2:322,s:'이웃과의 유대가 신도시 주민의 시민 참여를 높인다'},
 {dp:'환경공학',au:[['Lindqvist','Maja']],y:2024,t:'Microplastic retention in small urban wetlands',j:'Review of Applied Sciences',ja:'Rev. Appl. Sci.',v:30,i:6,p1:77,p2:95,s:'작은 도시 습지는 미세플라스틱을 상당 부분 붙잡아 둔다'},
 {dp:'철학',au:[['Park','Jisoo']],y:2015,t:'Moral luck and responsibility in everyday judgement',j:'Journal of Practical Philosophy Review',ja:'J. Pract. Philos. Rev.',v:7,i:2,p1:150,p2:171,s:'우연한 결과가 일상의 책임 판단에 영향을 준다'},
 {dp:'음악학',au:[['Choi','Yuna'],['Baek','Doyun']],y:2017,t:'Ensemble tempo coordination without a conductor',j:'Journal of Music Performance Studies',ja:'J. Music Perform. Stud.',v:10,i:1,p1:35,p2:52,s:'지휘자가 없는 합주에서는 연주자들이 서로의 박자를 맞춰 간다'}];
 function cap(s){return s.charAt(0).toUpperCase()+s.slice(1)}
 function LN(r,and){var L=r.au.map(function(a){return a[0]});return L.length===1?L[0]:L.length===2?L[0]+and+L[1]:L[0]+' et al.'}
 function inT(sid,r,k,pg){var dp=pg||r.p1+2;
  if(sid==='apa')return '('+LN(r,' & ')+', '+r.y+')';if(sid==='mla')return '('+LN(r,' and ')+' '+dp+')';if(sid==='cad')return '('+LN(r,' and ')+' '+r.y+', '+dp+')';if(sid==='nb')return '<sup>'+k+'</sup>';if(sid==='ieee')return '['+k+']';return '('+k+')'}
 function badIn(sid,r,k){var dp=r.p1+2;
  if(sid==='apa')return pick([['('+LN(r,' and ')+', '+r.y+')','괄호 안에서는 and가 아니라 &를 씁니다.'],['('+LN(r,' & ')+' '+r.y+')','저자와 연도 사이에 쉼표가 필요합니다.'],['('+LN(r,' & ')+', '+r.y+', '+dp+')','쪽을 쓰려면 p. 표시가 필요합니다(p. '+dp+').']]);
  if(sid==='mla')return pick([['('+LN(r,' and ')+', '+dp+')','MLA는 저자와 쪽 사이에 쉼표를 쓰지 않습니다.'],['('+LN(r,' and ')+' '+r.y+', '+dp+')','MLA는 본문 인용에 연도를 쓰지 않습니다.']]);
  if(sid==='cad')return pick([['('+LN(r,' and ')+', '+r.y+', '+dp+')','저자와 연도 사이에 쉼표를 쓰지 않습니다.'],['('+LN(r,' and ')+' '+dp+')','연도가 빠졌습니다(저자 연도, 쪽).']]);
  if(sid==='ieee')return pick([['('+k+')','IEEE는 대괄호 [ ]를 씁니다.'],['['+LN(r,' and ')+', '+r.y+']','IEEE는 저자–연도가 아니라 번호로 인용합니다.']]);
  if(sid==='van')return pick([['['+k+']','Vancouver는 괄호 번호 ( ) 또는 위 첨자 번호를 씁니다.'],['('+LN(r,' and ')+', '+r.y+')','Vancouver는 저자–연도가 아니라 번호로 인용합니다.']]);
  return pick([['['+k+']','ACS의 번호 인용은 괄호 번호(또는 위 첨자)입니다.'],['('+k+', '+r.y+')','번호 인용에는 연도를 덧붙이지 않습니다.']])}
 var DRULE={apa:'APA 본문 인용은 (저자, 연도)이고 둘 이상이면 &로 잇습니다. 참고문헌은 저자 성 알파벳순입니다.',mla:'MLA 본문 인용은 (저자 쪽)이며 쉼표와 연도가 없습니다. 목록 이름은 Works Cited이고 저자 알파벳순입니다.',cad:'Chicago Author-Date 본문 인용은 (저자 연도, 쪽)입니다. 목록은 References이고 저자 알파벳순입니다.',nb:'Chicago Notes-Bibliography는 본문에 위 첨자 번호를 달고 쪽 아래 각주에 출처를 쓰며, 문서 끝에 Bibliography를 둡니다.',ieee:'IEEE는 본문에 [번호]를 쓰고, 목록은 인용한 순서대로 번호를 붙입니다.',van:'Vancouver는 본문에 (번호) 또는 위 첨자 번호를 쓰고, 목록은 인용한 순서대로 번호를 붙입니다.',acs:'ACS(이 안내서의 번호 방식)는 본문에 (번호)를 쓰고, 목록은 인용한 순서대로 번호를 붙입니다.'};
 function refLine(sid,r,k){return GX.fmt(sid,r,k)}
 function docOf(sid){var rs=sh(DR).slice(0,3),num=(sid==='ieee'||sid==='van'||sid==='acs'),nb=sid==='nb',bad=null,
  sents=rs.map(function(r,j){return {r:r,k:j+1,txt:'<span class="sc">'+esc(r.s)+'</span>는 보고서가 있다.'}});
  var intro=['본문 첫 문단입니다. ','이어서, ','마지막으로 ']; 
  var body=rs.map(function(r,j){var c=inT(sid,r,j+1);return '<span class="sent">'+intro[j]+esc(r.s)+'고 보고되었다 <button type="button" class="cit" data-i="'+j+'">'+c+'</button>.</span>'}).join(' ');
  var order=rs.map(function(r,j){return j});if(!num&&!nb)order.sort(function(a,b){return rs[a].au[0][0]<rs[b].au[0][0]?-1:1});
  if(nb)order.sort(function(a,b){return rs[a].au[0][0]<rs[b].au[0][0]?-1:1});
  var refs=order.map(function(j){return {j:j,pc:refLine(sid,rs[j],j+1)}});
  return {rs:rs,body:body,refs:refs,num:num,nb:nb}}
 function docHTML(sid,D,opt){opt=opt||{};var ttl=sid==='apa'?'References':sid==='mla'?'Works Cited':sid==='nb'?'Bibliography':(sid==='cad'?'References':sid==='acs'?'References':'References');
  var foot=D.nb?'<div class="docf"><h5>각주(쪽 아래)</h5>'+D.rs.map(function(r,j){return '<p><sup>'+(j+1)+'</sup> '+esc(r.au.map(function(a,q){return q===0?a[1]+' '+a[0]:a[1]+' '+a[0]}).join(' and '))+', “'+esc(GX.tcase(r.t))+',” '+(r.p1+2)+'.</p>'}).join('')+'</div>':'';
  return '<div class="docv"><div class="docp"><h5>보고서 본문 <small>(밑줄 단추가 인용 표시)</small></h5><p class="docb">'+D.body+'</p>'+foot+'</div><div class="docr"><h5>참고문헌 <small>(보고서 끝쪽 · '+ttl+')</small></h5><div class="refl">'+D.refs.map(function(x,q){return '<button type="button" class="rl" data-j="'+x.j+'" data-q="'+q+'">'+(D.num?'':'')+(opt.pcs&&opt.pcs[q]?opt.pcs[q]:x.pc.map(mk).join(' '))+'</button>'}).join('')+'</div></div></div>'}
 function docQ(cur){var sid=pickSid(cur),D=docOf(sid),ty=pick(['pair','pair','wrongref','wrongcite','which3']);if(ty==='wrongcite'&&sid==='nb')ty='pair';var S=sty(sid);
  if(ty==='pair'){var j=ri(0,2);
   return {sid:sid,pill:false,kind:'seg',q:'본문에서 <b>깜빡이는 인용 표시</b>는 보고서 끝 참고문헌의 <b>어느 줄</b>과 짝일까요? 그 줄을 눌러 보세요.'+(D.num?'':'(저자와 연도를 맞춰 보세요)'),show:docHTML(sid,D),why:'본문의 '+(D.num?'번호 ['+(j+1)+']':'저자 “'+esc(D.rs[j].au[0][0])+'”')+' 표시는 목록에서 <b>'+(D.num?(j+1)+'번 줄':'저자 이름과 연도가 같은 줄')+'</b>을 가리킵니다. 짝이 되는 줄을 형광펜으로 표시했습니다.',rule:esc(DRULE[sid]),hint:D.num?'번호가 같은 줄을 찾으세요.':'저자 성과 연도가 같은 줄을 찾으세요.',
    bind:function(h,ans){var cs=h.querySelectorAll('.cit');cs[j].classList.add('blink2');h.querySelectorAll('.rl').forEach(function(b){b.onclick=function(){var q=+b.dataset.j,ok=q===j;h.querySelectorAll('.rl').forEach(function(x){if(+x.dataset.j===j)x.classList.add('hl','good2');else if(x===b)x.classList.add('pickbad')});cs[j].classList.add('hl');ans(ok,q)}})}}}
  if(ty==='wrongref'){var wj=ri(0,2),r=D.rs[wj],df=GX.defect(sid,refLine(sid,r,wj+1).slice(),false),pcs=D.refs.map(function(x){return x.j===wj?df.c.map(mk).join(' '):null});
   var D2=D;return {sid:sid,pill:true,kind:'seg',q:'<b>참고문헌</b> 세 줄 가운데 <b>규칙에 어긋난 줄</b>이 하나 있습니다. 그 줄을 눌러 보세요.',show:docHTML(sid,D2,{pcs:pcs}),why:'틀린 줄: '+esc(df.why)+' (노란 형광펜으로 표시)',rule:esc(DRULE[sid]),hint:'구두점·기울임·연도 위치·저자 이름 형식을 보세요.',
    bind:function(h,ans){h.querySelectorAll('.rl').forEach(function(b){b.onclick=function(){var q=+b.dataset.j,ok=q===wj;h.querySelectorAll('.rl').forEach(function(x){if(+x.dataset.j===wj){x.classList.add('hlk');x.innerHTML=hiRow(df.c,df.hi)}else if(x===b)x.classList.add('pickbad')});ans(ok,q)}})}}}
  if(ty==='wrongcite'){var cj=ri(0,2),bc=badIn(sid,D.rs[cj],cj+1);D.body=D.rs.map(function(r,j){var c=j===cj?bc[0]:inT(sid,r,j+1),intro=['본문 첫 문단입니다. ','이어서, ','마지막으로 '][j];return '<span class="sent">'+intro+esc(r.s)+'고 보고되었다 <button type="button" class="cit" data-i="'+j+'">'+esc(c)+'</button>.</span>'}).join(' ');
   return {sid:sid,pill:true,kind:'seg',q:'<b>본문</b>의 인용 표시 세 개 가운데 <b>규칙에 어긋난 것</b>을 눌러 보세요.',show:docHTML(sid,D),why:'틀린 인용: '+esc(bc[1]),rule:esc(DRULE[sid]),hint:'이 양식의 본문 인용 모양(괄호·대괄호·쉼표·연도)을 떠올리세요.',
    bind:function(h,ans){h.querySelectorAll('.cit').forEach(function(b){b.onclick=function(){var q=+b.dataset.i,ok=q===cj;h.querySelectorAll('.cit').forEach(function(x,j){if(j===cj)x.classList.add('hl','blink2');else if(x===b)x.classList.add('pickbad')});h.querySelector('#qshow').classList.add('hlk');ans(ok,q)}})}}}
  // which3
  var op=[sid].concat(sh(SIDS.filter(function(x){return x!==sid})).slice(0,2));
  return {sid:null,kind:'pick',q:'이 보고서는 어느 <b>인용 스타일</b>로 쓰였을까요? 본문의 인용 표시와 끝쪽 참고문헌을 함께 보세요.',show:docHTML(sid,D),opts:sh(op).map(function(x){return {t:esc(sname(x)),good:x===sid,note:x===sid?'맞습니다.':'<b>'+esc(sname(x))+'</b>는 본문 인용이 다른 모양입니다.'}}),why:'이 보고서는 <b>'+esc(S.n)+'</b>입니다. '+esc(DDETAIL(sid)),rule:esc(DRULE[sid]),hint:'본문 인용이 (저자, 연도)인지 [번호]인지, 위 첨자인지 보세요.'}}
 function DDETAIL(sid){return ({apa:'본문이 (저자 & 저자, 연도)입니다.',mla:'본문이 (저자 쪽)이고 목록 이름이 Works Cited입니다.',cad:'본문이 (저자 연도, 쪽)입니다.',nb:'본문에 위 첨자 번호가 있고 쪽 아래 각주가 있습니다.',ieee:'본문이 [번호]입니다.',van:'본문이 (번호)이고 저자 이름에 마침표가 없습니다.',acs:'본문이 (번호)이고 저자 사이에 세미콜론이 있습니다.'})[sid]}
 var DFN=$('dfn');
 if(DFN){(function startD(){quiz(DFN,{gid:'docfind',rounds:8,doneT:'문서 읽기 완주!',goodW:'정답!',badW:'아쉽습니다!',bar:function(re){return styBar(DFN,'docfind.sty',re)},make:docQ,label:function(ok,en){return '문서 속 인용 '+(en?'무한 · ':'· ')+ok+'개 정답'}})})()}
}
if(window.GX)boot();else addEventListener('load',boot);
})();
