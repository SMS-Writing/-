(function(){
var d=document,host=d.getElementById('fmtvideo');if(!host)return;
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
var RED='#d33',GRN='#2f9e5a',INK='#3a2f28',DK='#1c6b3e';
function ease(x){x=Math.max(0,Math.min(1,x));return x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2}
function morph(p){return ease((p-.25)/.5)}
function txt(x,y,t,fs,c,a){return '<text x="'+x+'" y="'+y+'" font-size="'+fs+'" font-weight="800" fill="'+c+'"'+(a?' text-anchor="'+a+'"':'')+'>'+esc(t)+'</text>'}
function badge(p,wrong,right){var e=morph(p),ok=e>.5;return '<g><circle cx="276" cy="20" r="13" fill="'+(ok?GRN:RED)+'"/>'+txt(276,26,ok?'✔':'✘',16,'#fff','middle')+'</g>'+txt(146,22,ok?right:wrong,12,ok?DK:RED,'middle')}
var L=26,PW=248,FS=8.6;
var NW={},MS=null;
function nw(t,fs,b){var k=t+'|'+fs+'|'+(b?1:0);if(NW[k])return NW[k];try{if(!MS){var ns='http://www.w3.org/2000/svg';var sv=d.createElementNS(ns,'svg');sv.setAttribute('width','0');sv.setAttribute('height','0');sv.style.cssText='position:absolute;visibility:hidden';MS=d.createElementNS(ns,'text');sv.appendChild(MS);host.appendChild(sv)}
 MS.setAttribute('font-size',fs);MS.setAttribute('font-weight',b?800:400);MS.textContent=t;NW[k]=MS.getComputedTextLength()||t.length*fs*.85}catch(e){NW[k]=t.length*fs*.85}return NW[k]}
function T(x,y,t,o){o=o||{};var fs=o.fs||FS,n=nw(t,fs,o.b),w=o.w==null?n:o.w;var adj=Math.abs(w-n)>.4?' textLength="'+w.toFixed(1)+'" lengthAdjust="spacing"':'';
 return '<text x="'+x.toFixed(1)+'" y="'+y.toFixed(1)+'" font-size="'+fs+'" font-weight="'+(o.b?800:400)+'" fill="'+(o.c||INK)+'"'+adj+'>'+esc(t)+'</text>'}
function norm(lines){var m=0;lines.forEach(function(l){m=Math.max(m,nw(l,FS))});return m}
function chrome(pg){return '<text x="150" y="350" font-size="7" fill="#9a8c80" text-anchor="middle">'+pg+'</text><text x="274" y="350" font-size="6" fill="#b0a498" text-anchor="end">연습용 가상 자료</text>'}
function note(y,e,bad,good,fs){return txt(L,y,e>.5?good:bad,fs||10,e>.5?DK:RED)}
function key(x,y,w,t,on){return '<g><rect x="'+x+'" y="'+y+'" width="'+w+'" height="20" rx="5" fill="'+(on?'#fff3c4':'#f3efe6')+'" stroke="'+INK+'" stroke-width="1.4"/><text x="'+(x+w/2)+'" y="'+(y+14)+'" font-size="9" font-weight="800" fill="'+INK+'" text-anchor="middle">'+esc(t)+'</text></g>'}
var PARA=['대학 글쓰기 수업에서는 학생이 읽은 자료를 근거로','자기 주장을 세우는 일이 중요하다. 이때 출처를 밝히면','독자가 근거를 직접 확인할 수 있다. 또한 인용 방식을','일관되게 쓴 보고서는 더 믿음직하게 읽힌다. 따라서','이 보고서는 인용 표기의 기본 규칙을 정리하고 한글과','워드에서 각주와 참고문헌을 설정하는 방법을 살핀다.'];
var PARA2=['먼저 본문 문단의 모양을 살핀다. 문단은 첫 줄만 안쪽으로','들이고 줄 끝을 맞추면 한 덩어리로 읽힌다. 다음으로','참고문헌 목록의 모양을 확인한다.'];
var EN=['Citing sources lets readers check the evidence behind','a claim. A consistent style makes a report easier to','read and to trust. This report reviews the basic rules','for notes and reference lists and shows how to set them','up in Word and Hangul so that the layout stays stable.','Check the required style first.'];
var FN='김서연, 『글쓰기와 인용』(가상출판사, 2021), 45.';
var BS={
 apa:{n:'APA',h:'참고문헌',hang:19,lab:0,e:[['김서연. (2021). 대학 글쓰기에서','출처 표기의 효과. 글쓰기연구,','14(2), 45–68.'],['박도윤, 이하늘. (2019). 보고서의','형식과 읽기 경험. 대학교육논총,','8(1), 101–120.']],g:'둘째 줄부터 0.5인치(36pt) 안쪽',cap:'한글: 문단 모양 > 내어쓰기 36pt · 워드: 단락 > 특수 > 내어쓰기 0.5"'},
 mla:{n:'MLA',h:'Works Cited',hang:19,lab:0,e:[['김서연. “대학 글쓰기에서 출처','표기의 효과.” 글쓰기연구, vol. 14,','no. 2, 2021, pp. 45–68.'],['박도윤, 이하늘. “보고서의 형식과','읽기 경험.” 대학교육논총, vol. 8,','no. 1, 2019, pp. 101–20.']],g:'둘째 줄부터 0.5인치(36pt) 안쪽',cap:'한글: 문단 모양 > 내어쓰기 36pt · 워드: 단락 > 특수 > 내어쓰기 0.5"'},
 cad:{n:'Chicago Author-Date',h:'References',hang:19,lab:0,e:[['김서연. 2021. “대학 글쓰기에서','출처 표기의 효과.” 글쓰기연구','14 (2): 45–68.'],['박도윤, 이하늘. 2019. “보고서의','형식과 읽기 경험.” 대학교육논총','8 (1): 101–120.']],g:'둘째 줄부터 0.5인치(36pt) 안쪽',cap:'한글: 문단 모양 > 내어쓰기 36pt · 워드: 단락 > 특수 > 내어쓰기 0.5"'},
 nb:{n:'Chicago Notes-Bibliography',h:'Bibliography',hang:19,lab:0,e:[['김서연. “대학 글쓰기에서 출처','표기의 효과.” 글쓰기연구 14,','no. 2 (2021): 45–68.'],['박도윤, 이하늘. “보고서의 형식과','읽기 경험.” 대학교육논총 8,','no. 1 (2019): 101–120.']],g:'둘째 줄부터 0.5인치(36pt) 안쪽',cap:'한글: 문단 모양 > 내어쓰기 36pt · 워드: 단락 > 특수 > 내어쓰기 0.5"'},
 ieee:{n:'IEEE',h:'References',hang:17,lab:['[1]','[2]'],e:[['김서연, “대학 글쓰기에서 출처 표기의','효과,” 글쓰기연구, vol. 14, no. 2,','pp. 45–68, 2021.'],['박도윤 and 이하늘, “보고서의 형식과','읽기 경험,” 대학교육논총, vol. 8,','no. 1, pp. 101–120, 2019.']],g:'번호는 왼쪽 끝, 둘째 줄부터 번호 다음 글자에 맞춤',cap:'번호 뒤 Tab + 내어쓰기(번호 폭과 같게). 이 안내서의 가상 보고서는 32pt'},
 van:{n:'Vancouver',h:'References',hang:17,lab:['1.','2.'],e:[['김서연. 대학 글쓰기에서 출처 표기의','효과. 글쓰기연구. 2021;14(2):','45-68.'],['박도윤, 이하늘. 보고서의 형식과 읽기','경험. 대학교육논총. 2019;8(1):','101-20.']],g:'번호 다음 글자에 맞추는 형식이 많지만 학술지마다 달라요',cap:'내어쓰기를 쓰는지 번호만 쓰는지 학술지마다 달라요. 투고 규정이 먼저, 없으면 IEEE처럼 번호 뒤 Tab과 내어쓰기'},
 acs:{n:'ACS',h:'References',hang:17,lab:['1.','2.'],e:[['김서연. 대학 글쓰기에서 출처 표기의','효과. 글쓰기연구 2021, 14 (2),','45–68.'],['박도윤; 이하늘. 보고서의 형식과 읽기','경험. 대학교육논총 2019, 8 (1),','101–120.']],g:'이 안내서의 설정: 내어쓰기 32pt, 번호 뒤 Tab',cap:'한글: 문단 모양에서 내어쓰기 32pt, 번호 뒤 Tab · 워드: 단락 > 내어쓰기 32pt (학술지 규정이 먼저)'}};
var BK=['apa','mla','cad','nb','ieee','van','acs'];
function s1(p,m){var S=BS[BK[m]],e=morph(p),o=chrome(14),hang=S.hang*e,y=52,num=!!S.lab;
 o+=T(L,y,S.h,{fs:12,b:1});y+=22;var yTop=y-10;
 S.e.forEach(function(en,k){en.forEach(function(l,i){
   var x=L+(num?(i?hang:S.hang):(i?hang:0));
   if(num&&i===0)o+=T(L,y,S.lab[k],{});
   o+=T(x,y,l,{});y+=13});y+=11});
 if(e>.02)o+='<rect x="'+L+'" y="'+yTop+'" width="'+hang.toFixed(1)+'" height="'+(y-yTop-14).toFixed(0)+'" fill="'+GRN+'" fill-opacity="'+(.13*e).toFixed(2)+'"/>';
 o+=note(y+22,e,'둘째 줄도 왼쪽 끝 → 어디서 항목이 바뀌는지 안 보여요',S.g,9.5);
 o+=T(L,y+40,S.cap,{fs:7.4,c:'#7a6c60'});
 o+=txt(L,334,'양식마다 권장이 달라요. 과목·학술지 규정이 먼저예요.',8.5,'#7a6c60');
 return badge(p,'내어쓰기 없음',S.n+' 내어쓰기')+o}
function s2(p,m){var e=morph(p),o=chrome(7),y=52;
 if(m===0){var pw=norm(PARA);
  o+=T(L,y,'1. 서론',{fs:11,b:1});y+=20;
  PARA.forEach(function(l,i){var n=nw(l,FS),last=i===PARA.length-1;o+=T(L,y,l,{w:last?n:n+(pw-n)*e});y+=14});
  o+='<line x1="'+(L+pw)+'" y1="40" x2="'+(L+pw)+'" y2="'+y+'" stroke="'+(e>.5?GRN:RED)+'" stroke-width="1.6" stroke-dasharray="4 3"/>';
  y+=10;o+=T(L,y+6,'2. 본론',{fs:11,b:1});
  PARA2.forEach(function(l,i){var n=nw(l,FS),last=i===PARA2.length-1;o+=T(L,y+26+i*14,l,{w:last?n:n+(pw-n)*e})});
  o+=note(y+84,e,'줄 끝이 들쭉날쭉해요 (왼쪽 정렬이 되어 있음)','줄 끝이 한 줄로 맞아요 (양쪽 정렬)',10);
  o+=txt(L,y+104,'국내 보고서·논문은 본문을 양쪽 정렬로 쓰는 것이 일반적이에요.',8.5,'#7a6c60');
  return badge(p,'양쪽 정렬 아님','양쪽 정렬')+o}
 var pw2=norm(EN);
 o+=T(L,y,'1. Introduction',{fs:11,b:1});y+=20;
 EN.forEach(function(l,i){var n=nw(l,FS),last=i===EN.length-1;o+=T(L,y,l,{w:last?n:pw2+(n-pw2)*e});y+=14});
 o+='<line x1="'+(L+pw2)+'" y1="40" x2="'+(L+pw2)+'" y2="'+y+'" stroke="'+(e>.5?'#9a8c80':RED)+'" stroke-width="1.4" stroke-dasharray="4 3"/>';
 y+=12;
 o+=note(y+6,e,'왼쪽 정렬이 필요한데 양쪽 정렬이에요','왼쪽 정렬: 오른쪽 끝을 맞추지 않아요',10);
 o+='<rect x="'+L+'" y="'+(y+16)+'" width="'+PW+'" height="96" rx="8" fill="#faf6ea" stroke="#d8cfc2"/>'
  +txt(L+8,y+31,'영어 논문은 양식에 따라 달라요',9.5,INK)
  +T(L+8,y+46,'· APA처럼 왼쪽 정렬을 요구하는 양식이 있어요',{fs:8})
  +T(L+8,y+60,'· IEEE는 본문이 양쪽 정렬이에요',{fs:8})
  +T(L+8,y+74,'· MLA·Chicago는 이 안내서에서 확인하지 못했어요',{fs:8})
  +T(L+8,y+92,'→ 제출 양식과 지도교수 지침을 먼저 확인하세요.',{fs:8,b:1,c:DK});
 return badge(p,'영문 양식 확인 필요','왼쪽 정렬(영문 양식)')+o}
function s3(p){var e=morph(p),W=norm(PARA),ind=10*e,o=chrome(7),y=52;
 o+=T(L,y,'2. 본론',{fs:11,b:1});y+=20;
 [PARA.slice(0,3),PARA.slice(3)].forEach(function(par){par.forEach(function(l,i){var n=nw(l,FS),last=i===par.length-1,x=L+(i===0?ind:0);o+=T(x,y,l,{w:last?n:W-(i===0?ind:0)});y+=14});y+=8});
 if(e>.4)o+='<rect x="'+L+'" y="'+(52+20-9)+'" width="'+ind.toFixed(1)+'" height="11" fill="'+GRN+'" fill-opacity=".3"/>';
 if(e>.5)o+=txt(L+62,50,'← 새 문단의 첫 줄만 10pt',8.5,DK);
 var ty=y+8;o+=T(L,ty+6,'표 1. 인용 양식별 본문 표기 (연습용)',{fs:8,b:1});
 var rows=[['양식','본문 표기','예'],['APA','(저자, 연도)','(김서연, 2021)'],['MLA','(저자 쪽)','(김서연 15)'],['IEEE','[번호]','[1]']],cx=[L,L+56,L+140];
 rows.forEach(function(r,i){var ry=ty+12+i*14;o+='<line x1="'+L+'" y1="'+ry+'" x2="'+(L+PW)+'" y2="'+ry+'" stroke="#8f8a80" stroke-width="'+(i<2?1.1:.5)+'"/>';r.forEach(function(c,j){o+=T(cx[j]+2,ry+10,c,{fs:7.6,b:i===0})})});
 o+='<line x1="'+L+'" y1="'+(ty+12+4*14)+'" x2="'+(L+PW)+'" y2="'+(ty+12+4*14)+'" stroke="#8f8a80" stroke-width="1.1"/>';y=ty+12+4*14+8;
 o+=note(y+10,e,'문단이 시작하는 곳이 한눈에 안 보여요','새 문단의 첫 줄만 안쪽으로 들어가요');
 return badge(p,'첫 줄 들여쓰기 없음','첫 줄 1자 들여쓰기')+o}
function lerp(a,b,t){return a+(b-a)*t}
function cl01(x){return Math.max(0,Math.min(1,x))}
function s4(p,m){var e=morph(p),o=chrome(7),ok=e>.5,e2=cl01((e-.15)/.7),y=48,W=norm(PARA);
 o+=T(L,y,'1. 서론',{fs:11,b:1});y+=18;o+=T(L,y,PARA[0],{w:W})+T(L,y+13,PARA[1],{w:W});y+=34;
 o+='<rect x="'+(L-4)+'" y="'+y+'" width="'+(PW+8)+'" height="116" rx="10" fill="#fffbea" stroke="'+(ok?GRN:RED)+'" stroke-width="2.4"/>'+txt(L+2,y+15,'🔍 확대해서 보기',9,'#7a6c60');
 var F=16,a,q,r,bx=L+4,by=y+66;
 if(m===0){a='…정리하는 일이다';q='”';r='라 했다.'}else{a='…일이라고 보았다';q='.';r=''}
 var xa=bx+nw(a,F),qw=nw(q,F),nwid=14,pre=m===0?'“':'';
 var qx=lerp(xa+nwid,xa,e2),nx=lerp(xa,xa+qw,e2);
 o+=T(bx,by,a,{fs:F,b:1})+T(qx,by,q,{fs:F,b:1});if(r)o+=T(xa+qw+nwid,by,r,{fs:F,b:1});
 var lift=lerp(0,-8,e2);
 o+='<path d="M'+(xa+nwid/2+2)+' '+(by-62)+'Q'+((xa+nx)/2+qw/2+2)+' '+(by-84)+' '+(nx+qw/2+3)+' '+(by-62)+'" fill="none" stroke="#e0a800" stroke-width="3.2" stroke-dasharray="6 4" opacity="'+(e>.04&&e<.96?1:.0)+'"/>';
 o+='<rect x="'+(qx-2).toFixed(1)+'" y="'+(by-17)+'" width="'+(qw+4).toFixed(1)+'" height="22" rx="4" fill="#ffe58a"/>'+T(qx,by,q,{fs:F,b:1,c:'#a05a00'});
 o+='<line x1="'+(nx+qw/2+1).toFixed(1)+'" y1="'+(by-30).toFixed(1)+'" x2="'+(nx+qw/2+1).toFixed(1)+'" y2="'+(by-16)+'" stroke="'+(ok?GRN:RED)+'" stroke-width="2.5"/>';
 o+='<circle cx="'+(nx+qw/2+1).toFixed(1)+'" cy="'+(by-40+lift).toFixed(1)+'" r="13" fill="'+(ok?'#d9f5e2':'#fde3e3')+'" stroke="'+(ok?GRN:RED)+'" stroke-width="3"/>'
  +'<text x="'+(nx+qw/2+1).toFixed(1)+'" y="'+(by-34+lift).toFixed(1)+'" font-size="17" font-weight="900" fill="'+(ok?GRN:RED)+'" text-anchor="middle">1</text>';
 var tx=ok?xa+qw/2:xa+nwid/2;
 o+=txt(L+2,y+104,ok?'✔ 번호가 여기로 옮겨 왔어요!':'✘ 번호가 여기 있어요 (틀림)',11,ok?DK:RED);
 o+=txt(150,by+22,ok?(m===0?'닫는 큰따옴표(”) 다음 →':'마침표(.) 다음 →'):(m===0?'↑ 큰따옴표 안쪽':'↑ 마침표 앞'),9,ok?DK:RED,'middle');
 y+=130;
 o+=key(L,y,118,'한글 Ctrl+N, N',ok)+key(L+128,y,120,'워드 Ctrl+Alt+F',ok);
 o+=txt(L,y+36,ok?'단축키·메뉴로 삽입 → 번호가 자동으로 들어가요':'번호를 손으로 쓰면 안 돼요! 각주와 연결되지 않아요',9.3,ok?DK:RED);
 o+=txt(L,y+52,m===0?'직접 인용(“ ”): 닫는 큰따옴표(”) 바로 다음':'간접 인용: 문장 끝 마침표나 쉼표 다음',9.6,ok?DK:INK);
 var fy=326;
 if(ok)o+='<g opacity="'+Math.min(1,(e-.5)*3).toFixed(2)+'"><line x1="'+L+'" y1="'+(fy-8)+'" x2="'+(L+70)+'" y2="'+(fy-8)+'" stroke="'+INK+'" stroke-width="1"/>'+T(L,fy+2,'1. '+FN,{fs:7.6,c:DK})+'</g>';
 else o+=txt(L,fy,'쪽 아래에 각주가 없어요',8.5,RED);
 return badge(p,'번호 위치가 틀림','번호 위치가 맞음')+o}
function sBody(p,m){
 if(m===1)return sBody2(p);var e=morph(p),o=chrome(7),y=52,W=norm(PARA),sh=lerp(16,0,e),fi=lerp(16,10,e),ok=e>.5,gc=ok?GRN:RED;
 o+=T(L,y,'2. 본론',{fs:11,b:1})+txt(L+64,y-1,'← 소제목은 그대로',8,'#7a6c60');y+=20;var y0=y-10;
 [PARA.slice(0,3),PARA.slice(3)].forEach(function(par){par.forEach(function(l,i){var n=nw(l,FS),last=i===par.length-1,x=L+(i===0?fi:sh),w=last?n:W-(i===0?fi:sh);o+=T(x,y,l,{w:w});y+=14});y+=8});
 o+='<line x1="'+L+'" y1="'+y0+'" x2="'+L+'" y2="'+(y-8)+'" stroke="'+gc+'" stroke-width="1.6" stroke-dasharray="4 3"/>';
 o+='<rect x="'+L+'" y="'+(y0+1)+'" width="'+(sh+.1).toFixed(1)+'" height="'+(y-y0-9)+'" fill="'+RED+'" fill-opacity="'+(.1*(1-e)).toFixed(2)+'"/>';
 o+=note(y+12,e,'본문 줄이 모두 안쪽으로 밀려 있어요','소제목 말고 본문은 왼쪽 끝에 맞춰요',10);
 o+=txt(L,y+30,ok?'첫 줄만 한 글자(10pt) 들이고, 둘째 줄부터는 왼쪽 끝!':'왼쪽 끝 선(점선)에서 멀어졌어요',9.4,ok?DK:RED);
 o+=T(L,y+46,'워드: 눈금자나 단락에서 “왼쪽 들여쓰기”를 0으로, 내어쓰기/Shift+Tab',{fs:7.6,c:'#7a6c60'});
 o+=T(L,y+58,'한글: 문단 모양의 “왼쪽 여백”을 0으로(블록 지정 후 Ctrl+Alt+F5)',{fs:7.6,c:'#7a6c60'});
 return badge(p,'본문이 안쪽으로 밀림','본문 줄이 왼쪽 끝')+o}
function sBody2(p){var e=morph(p),o=chrome(7),y=50,W=norm(PARA),ok=e>.5,u=13,gc=ok?GRN:RED;
 var y0=y-8;
 function H(sym,t,lv){o+=T(L+lv*u,y,sym+' '+t,{fs:FS+.4,b:1});y+=15}
 function B(ls,lv){var ys=y;ls.forEach(function(l,i){var x=L+(i===0?lerp(lv*u,10,e):lv*u*(1-e)),w=i===ls.length-1?nw(l,FS):W-(x-L);o+=T(x,y,l,{w:w});y+=13});o+='<rect x="'+(L-7)+'" y="'+(ys-9)+'" width="3.4" height="'+(y-ys-1)+'" rx="1.7" fill="'+gc+'" opacity="'+(.35+.55*e).toFixed(2)+'"/>';y+=6}
 H('Ⅰ.','서론',0);B([PARA[0],PARA[1]],0);
 H('1.','연구 배경',1);B([PARA[2],PARA[3]],1);
 H('가.','문제 제기',2);B([PARA[4],PARA[5]],2);
 o+='<line x1="'+L+'" y1="'+y0+'" x2="'+L+'" y2="'+(y-4)+'" stroke="'+gc+'" stroke-width="1.8" stroke-dasharray="4 3"/>'+txt(L+PW-70,y0+4,'← 왼쪽 끝 선',8,gc);
 y+=4;o+=note(y+8,e,'항목을 들여썼다고 본문까지 따라 들여썼어요','항목은 들여써도 본문은 왼쪽 끝에 맞춰요',9.4);
 o+=T(L,y+24,'하위 항목이 여러 개 있어도 본문은 모두 같은 자리예요.',{fs:8.2,c:DK,b:1});
 o+=T(L,y+38,'본문 첫 줄만 10pt 들이고, 둘째 줄부터는 왼쪽 끝이에요.',{fs:8,c:'#7a6c60'});
 o+=T(L,y+52,'한글: 항목마다 문단 모양의 왼쪽 여백이 다르게 걸리지 않았는지 확인',{fs:7.2,c:'#7a6c60'});
 o+=T(L,y+63,'워드: 본문 단락의 “왼쪽 들여쓰기”가 0인지 확인',{fs:7.2,c:'#7a6c60'});
  o+=txt(L,y+78,ok?'▮ 초록 막대: 소제목은 계단처럼, 본문은 모두 같은 선':'▮ 빨간 막대: 본문이 소제목 따라 계단처럼 밀려 있어요',7.8,gc);
 return badge(p,'본문이 항목 따라 밀림','본문은 왼쪽 끝')+o}
function sHier(p,m){var e=morph(p),o=chrome(7),y=50,ok=e>.5,W=norm(PARA),u=13;
 function pos(lv){return (m===1?(2-lv):lv)*u*e}
 if(m===0){o+=T(150-nw('차 례',12,1)/2,y,'차 례',{fs:12,b:1});y+=24;
  var it=[['Ⅰ.','서론',0,1],['1.','연구 배경과 필요성',1,3],['2.','AI 시대의 출처 표기',1,5],['가.','문제 제기',2,5],['나.','연구 방법',2,7],['Ⅱ.','본론',0,9],['1.','인용 양식의 비교',1,9],['가.','본문 인용',2,11],['Ⅲ.','결론',0,15]];
  it.forEach(function(r){var x=L+pos(r[2]),tx=r[0]+' '+r[1],w=nw(tx,FS+.4,r[2]===0),pn=String(r[3]);
   o+=T(x,y,tx,{fs:FS+.4,b:r[2]===0});o+='<line x1="'+(x+w+4).toFixed(1)+'" y1="'+(y-1)+'" x2="'+(L+PW-14)+'" y2="'+(y-1)+'" stroke="#9a8c80" stroke-width="1" stroke-dasharray="1 3"/>';o+=T(L+PW-nw(pn,FS),y,pn,{});y+=17});
  y+=6;o+=note(y+6,e,'모두 같은 자리라 위계가 안 보여요','하위 항목일수록 점점 오른쪽으로 들여써요',9.6);
  o+=txt(L,y+24,'목차는 보통 이렇게 계단처럼 들여씁니다.',9,'#7a6c60');y+=34;
 }else{
  function H(sym,t,lv,two){var x=L+pos(lv),sw=nw(sym+' ',FS+.4,1);o+=T(x,y,sym+' '+t[0],{fs:FS+.4,b:1});if(two){o+=T(lerp(x,x+sw,e),y+14,t[1],{fs:FS+.4,b:1});y+=14}y+=15}
  function B(ls){var fi=10*e;ls.forEach(function(l,i){var n=nw(l,FS);o+=T(L+(i===0?fi:0),y,l,{w:i===ls.length-1?n:W-(i===0?fi:0)});y+=13});y+=6}
  H('Ⅰ.',['서론'],0);B([PARA[0],PARA[1]]);
  H('1.',['연구 배경과 필요성'],1);B([PARA[2],PARA[3]]);
  H('2.',['생성형 AI 시대에 대학생이 출처를 밝히지','않는 이유와 해결 방안'],1,true);
  H('가.',['문제 제기'],2);B([PARA[4],PARA[5]]);
  y+=2;o+=note(y+6,e,'위계가 안 보이고 본문 첫 줄도 안 들어가요',m===1?'하위 항목일수록 왼쪽으로 나와요(내어쓰기형)':'하위 항목일수록 오른쪽으로 들어가요(들여쓰기형)',9);
  o+=T(L,y+20,'본문 단락은 항목이 들쭉날쭉해도 왼쪽 끝에 맞추고 첫 줄만 10pt 들여요.',{fs:7.4,c:'#7a6c60'});y+=24}
 y+=6;o+='<rect x="'+L+'" y="'+y+'" width="'+PW+'" height="54" rx="9" fill="#fff6d6" stroke="#e2b93b" stroke-width="2"/>'
  +txt(L+8,y+16,'⭐ 논문·학술지마다 다를 수 있어요',9.4,'#7a5a00')
  +txt(L+8,y+31,m===0?'목차: 하위 항목일수록 들여쓰는 경우가 많아요':'본문: 하위 항목을 내어쓰는 경우가 많지만',9,INK)+txt(L+8,y+45,m===0?'가장 일반적인 기본 모양부터 연습! (제출처 규정이 먼저)':'들여쓰는 논문도 있어요. 기본형부터 연습!',9,INK);
 return badge(p,'위계가 안 보여요',m===0?'목차: 계단식 들여쓰기':m===1?'본문: 내어쓰기형':'본문: 들여쓰기형')+o}
function sOne(p,m){var e=morph(p),o=chrome(7),y=50,W=norm(PARA),u=13,e1=m===0?e:1,e2=m===1?e:1,ok=e>.5;
 function Hd(sym,t,lv,ee){var x=L+lv*u,sw=nw(sym+' ',FS+.4,1);o+='<g opacity="'+ee.toFixed(2)+'">'+T(x,y,sym,{fs:FS+.4,b:1})+'</g>';o+=T(lerp(x,x+sw,ee),y,t,{fs:FS+.4,b:1});y+=15}
 function Bd(l){var n=nw(l,FS);o+=T(L+10,y,l,{w:n>W-10?W-10:n});y+=14}
 o+=T(L,y,'Ⅰ. 연구 배경',{fs:FS+.4,b:1});y+=15;
 if(m===0){o+='<g opacity="'+(1-e1).toFixed(2)+'">'+T(L+u,y,'1. 문제 제기',{fs:FS+.4,b:1})+txt(L+u+nw('1. 문제 제기',FS+.4,1)+6,y,'✘ 하나뿐인데 번호',7.6,RED)+'</g>';y+=15*(1-e1)}
 Bd(PARA[0]);y+=4;
 o+=txt(L,y+2,'↑ 하위 항목이 하나뿐 → 번호 없이 상위 항목에 이어 써요',7.6,(m===0&&!ok)?RED:DK);y+=18;
 o+='<line x1="'+L+'" y1="'+y+'" x2="'+(L+PW)+'" y2="'+y+'" stroke="#d9cfc4" stroke-dasharray="3 3"/>';y+=16;
 o+=T(L,y,'Ⅱ. 연구 방법',{fs:FS+.4,b:1});y+=15;
 Hd('1.','자료 수집',1,e2);Bd(PARA[1]);
 Hd('2.','분석 방법',1,e2);Bd(PARA[2]);
 o+=txt(L,y+4,(m===1&&!ok)?'↑ 하위 항목이 둘인데 번호가 없어요':'↑ 하위 항목이 둘 이상 → 1. 2. 번호를 붙여요',7.6,(m===1&&!ok)?RED:DK);y+=22;
 o+=note(y+6,e,m===0?'하나뿐인 하위 항목에 번호를 붙였어요':'둘 이상인데 번호가 없어서 구분이 안 돼요',m===0?'하나면 번호 없이 본문만 이어 써요':'둘 이상이면 1. 2. 번호로 나누어요',9.4);
 o+=T(L,y+22,'번호는 “나눌 때만” 붙여요. 하위 항목이 하나뿐이면 나눈 것이 아니에요.',{fs:7.6,c:'#7a6c60'});
 return badge(p,m===0?'번호가 하나뿐이에요':'번호가 없어요',m===0?'하나면 번호 없이':'둘 이상이면 번호')+o}
function pg(x,y,w,h,col){return '<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="5" fill="#fff" stroke="'+col+'" stroke-width="2.2"/>'}
var S5={
 apa:{n:'APA',mark:'(김서연, 2021)',kind:'괄호',ref:['김서연. (2021). 글쓰기와','인용. 가상출판사.'],h:'참고문헌',sub:'본문의 괄호 인용'},
 mla:{n:'MLA',mark:'(김서연 45)',kind:'괄호',ref:['김서연. 글쓰기와 인용.','가상출판사, 2021.'],h:'Works Cited',sub:'본문의 괄호 인용'},
 cad:{n:'Chicago Author-Date (내각주)',mark:'(김서연 2021, 45)',kind:'괄호',ref:['김서연. 2021. 글쓰기와','인용. 가상출판사.'],h:'References',sub:'본문의 괄호 인용(내각주)'},
 nb:{n:'Chicago Notes-Bibliography (외각주)',mark:'1',kind:'각주',ref:['김서연. 글쓰기와 인용.','가상출판사, 2021.'],h:'Bibliography',sub:'쪽 아래 각주(외각주)'},
 ieee:{n:'IEEE',mark:'[1]',kind:'번호',ref:['[1] 김서연, 글쓰기와 인용,','가상출판사, 2021.'],h:'References',sub:'본문의 번호 [1]'},
 van:{n:'Vancouver',mark:'[1]',kind:'번호',ref:['1. 김서연. 글쓰기와 인용.','가상출판사; 2021.'],h:'References',sub:'본문의 번호 [1]'},
 acs:{n:'ACS',mark:'1',kind:'각주',ref:['1. 김서연. 글쓰기와 인용;','가상출판사, 2021.'],h:'References',sub:'위 첨자 번호(학술지별로 다름)',sup:1}};
function s5(p,m){var Q=S5[BK[m]],ph=p<.25?0:p<.5?1:2,fl=ease((p-.55)/.2),pulse=p>.75?(.5+.5*Math.sin((p-.75)*40)):0,fs=6.8,o='';
 var haveN=ph!==1,haveB=ph!==0,foot=Q.kind==='각주'&&!Q.sup;
 o+='<rect x="6" y="4" width="288" height="352" rx="6" fill="#fff7e0" stroke="#4a3a30" stroke-width="2.5"/>';
 o+=txt(150,28,'출처는 두 번 적어요!',17,RED,'middle')+txt(150,45,Q.n,10.5,INK,'middle');
 o+=pg(14,54,128,200,haveN?(ph===2?GRN:INK):RED)+txt(78,67,'본문 쪽',8,'#7a6c60','middle');
 o+=T(22,84,'글쓰기에서는 출처를 밝히면',{fs:fs})+T(22,96,'독자가 근거를 확인할 수 있다.',{fs:fs});
 var ex=22+nw('독자가 근거를 확인할 수 있다.',fs)+1;
 if(haveN){if(Q.kind==='괄호'||Q.kind==='번호'){o+=T(22,108,Q.mark+' 이 보고서는 인용',{fs:fs,c:DK,b:1})+'<rect x="20" y="99" width="'+(nw(Q.mark,fs,1)+4)+'" height="12" rx="3" fill="none" stroke="'+GRN+'" stroke-width="1.4"/>'}
  else{o+='<text x="'+ex.toFixed(1)+'" y="93" font-size="6" font-weight="800" fill="'+GRN+'">'+Q.mark+'</text>'+T(22,108,'이 보고서는 인용 표기의',{fs:fs})}}
 else o+=T(22,108,'이 보고서는 인용 표기의',{fs:fs});
 o+=T(22,120,'기본 규칙을 정리한다.',{fs:fs});
 if(foot&&haveN)o+='<line x1="22" y1="224" x2="70" y2="224" stroke="'+INK+'" stroke-width=".9"/>'+T(22,236,'1. 김서연, 『글쓰기와 인용』,',{fs:6.2,c:DK})+T(30,245,'(가상출판사, 2021), 45.',{fs:6.2,c:DK});
 else if(Q.sup&&haveN)o+='<line x1="22" y1="224" x2="70" y2="224" stroke="'+INK+'" stroke-width=".9"/>'+T(22,236,'위 첨자 번호가 참고문헌',{fs:6.2,c:DK})+T(22,245,'번호와 짝이에요.',{fs:6.2,c:DK});
 if(!haveN)o+='<rect x="20" y="200" width="116" height="44" rx="4" fill="none" stroke="'+RED+'" stroke-width="1.4" stroke-dasharray="4 3"/>'+txt(78,218,'본문 표시 없음 ✘',9.2,RED,'middle')+txt(78,232,'('+Q.sub+'가 빠졌어요)',6.8,RED,'middle');
 o+=pg(158,54,128,200,haveB?(ph===2?GRN:INK):RED)+txt(222,67,'참고문헌 쪽',8,'#7a6c60','middle')+T(166,88,Q.h,{fs:8.6,b:1});
 if(haveB)o+=T(166,104,Q.ref[0],{fs:fs})+T(Q.kind==='번호'||Q.ref[0].charAt(0)==='('?176:176,115,Q.ref[1],{fs:fs});
 else o+='<rect x="164" y="96" width="116" height="52" rx="4" fill="none" stroke="'+RED+'" stroke-width="1.4" stroke-dasharray="4 3"/>'+txt(222,118,'목록에 없음 ✘',9.5,RED,'middle')+txt(222,132,'(참고문헌이 빠졌어요)',7.5,RED,'middle');
 var cy=268;o+='<rect x="30" y="'+cy+'" width="240" height="26" rx="7" fill="#fff" stroke="'+INK+'" stroke-width="2"/>'+txt(150,cy+17,'출처: 김서연, 『글쓰기와 인용』(가상출판사, 2021)',8.4,INK,'middle');
 if(ph===2)o+='<path d="M100 '+cy+'C96 258 84 252 78 244" fill="none" stroke="'+GRN+'" stroke-width="2.4" stroke-dasharray="5 4" opacity="'+Math.min(1,fl*2).toFixed(2)+'"/><path d="M200 '+cy+'C212 230 222 190 222 130" fill="none" stroke="'+GRN+'" stroke-width="2.4" stroke-dasharray="5 4" opacity="'+Math.min(1,fl*2).toFixed(2)+'"/>';
 var msg=ph===0?'본문 표시만 있고 참고문헌이 없다 ✘':ph===1?'참고문헌만 있고 본문 표시가 없다 ✘':'본문 표시 + 참고문헌 둘 다 있다 ✔',col=ph===2?DK:RED;
 o+='<rect x="14" y="304" width="272" height="28" rx="8" fill="'+(ph===2?'#e3f5e9':'#fde8e8')+'" stroke="'+col+'" stroke-width="'+(2+pulse*1.5).toFixed(1)+'"/>'+txt(150,323,msg,11,col,'middle');
 o+=txt(150,347,'본문 표시: '+Q.sub+' ↔ 참고문헌 항목',7.6,'#7a6c60','middle');
 return o}
// 장·절·항 사이 한 줄 띄우기
function sGap(p){var e=morph(p),o=chrome(7),y=46,W=norm(PARA),g=lerp(1,15,e),ok=e>.5;
 function H(sym,t,x){o+=T(x,y+9,sym+' '+t,{fs:9.6,b:1});y+=11}
 function G(){if(e>.05)o+='<rect x="'+L+'" y="'+(y+1)+'" width="'+PW+'" height="'+Math.max(0,g-2).toFixed(1)+'" fill="'+GRN+'" fill-opacity="'+(.16*e).toFixed(2)+'"/>'+(e>.5?'<text x="'+(L+PW-4)+'" y="'+(y+g/2+3).toFixed(1)+'" font-size="7" font-weight="800" fill="'+DK+'" text-anchor="end">한 줄</text>':'');y+=g}
 function B(a){a.forEach(function(l,i){o+=T(L+(i===0?10:0),y+8,l,{w:i===a.length-1?nw(l,FS):W-(i===0?10:0)});y+=13})}
 H('Ⅰ.','서론',L);G();B([PARA[0],PARA[1]]);G();
 H('1.','연구 배경과 필요성',L);G();B([PARA[2],PARA[3]]);G();
 H('가.','문제 제기',L);G();B([PARA[4],PARA[5]]);
 y+=14;o+=note(y,e,'장·절·항과 본문이 붙어서 답답해요','장·절·항 사이를 한 줄씩 띄웠어요',10);
 o+=txt(L,y+18,'제목 위·아래를 한 줄 높이로 띄워 줄간격을 만들어요.',8.8,'#7a6c60');
 o+=T(L,y+32,'한글: 문단 모양 > 문단 위/아래 간격  ·  워드: 단락 > 간격(앞·뒤)',{fs:7.4,c:'#7a6c60'});
 return badge(p,'붙어 있어요','한 줄씩 띄움')+o}
// 한 문장마다 엔터 치지 않기
var SEN=['학생은 읽은 자료를 근거로 주장을 세운다.','이때 출처를 밝히면 독자가 근거를 확인한다.','인용 방식을 일관되게 쓰면 믿음직하다.','따라서 기본 규칙을 먼저 익혀야 한다.'];
function wrap(txt,w){var out=[],cur='';txt.split('').forEach(function(ch){if(nw(cur+ch,FS)>w){out.push(cur);cur=ch===' '?'':ch}else cur+=ch});if(cur)out.push(cur);return out}
function sEnter(p){var e=morph(p),o=chrome(7),y=50,W=norm(PARA),ok=e>.5;
 o+=T(L,y,'2. 본론',{fs:11,b:1});y+=22;var y0=y;
 // 틀린 모양: 문장마다 줄바꿈
 SEN.forEach(function(sn,i){o+='<g opacity="'+(1-e).toFixed(2)+'">'+T(L+(i?0:10),y0+i*22,sn,{})+txt(L+(i?0:10)+nw(sn,FS)+3,y0+i*22,'↵',9,RED)+'</g>'});
 // 고친 모양: 한 문단으로 이어짐
 var lines=wrap(SEN.join(' '),W-10),yy=y0;
 lines.forEach(function(l,i){var x=L+(i===0?10:0),n=nw(l,FS);o+='<g opacity="'+e.toFixed(2)+'">'+T(x,yy+i*14,l,{w:i===lines.length-1?n:W-(i===0?10:0)})+'</g>'});
 var ey=y0+Math.max(4*22,lines.length*14)+14;
 o+='<g opacity="'+e.toFixed(2)+'">'+txt(L+nw(lines[lines.length-1],FS)+3,y0+(lines.length-1)*14,'↵',9,GRN)+'</g>';
 o+=note(ey,e,'문장마다 Enter를 쳐서 줄이 들쭉날쭉해요','문장은 이어 쓰고, 문단이 끝날 때만 Enter',10);
 o+=txt(L,ey+20,'↵ = Enter. 한 문단은 Enter 한 번(문단 끝)으로 마쳐요.',8.8,'#7a6c60');
 o+=T(L,ey+34,'줄바꿈은 글 상자 너비에 맡기고, 줄 끝에서 Enter를 치지 않아요.',{fs:7.6,c:'#7a6c60'});
 return badge(p,'문장마다 줄바꿈','문단 끝에만 Enter')+o}
var SC=[
 {t:'참고문헌 내어쓰기',f:s1,modes:['APA','MLA','Chicago A-D','Chicago N-B','IEEE','Vancouver','ACS'],cap:function(m){return ['먼저 틀린 모양: 모든 줄이 왼쪽 끝에 붙어 있어요.','항목 전체를 고르고 내어쓰기를 적용해요. ('+BS[BK[m]].n+')','고친 모양: '+BS[BK[m]].g]},menu:function(m){return BS[BK[m]].cap}},
 {t:'양쪽·왼쪽 정렬',f:s2,modes:['국문 보고서','영문 논문'],cap:function(m){return m===0?['먼저 틀린 모양: 오른쪽 끝이 들쭉날쭉해요.','본문을 고르고 “양쪽 정렬”을 눌러요.','고친 모양: 줄 끝이 한 줄로 맞아요.']:['양식이 왼쪽 정렬을 요구해도 양쪽 정렬로 맞춰 두면 어긋나요.','영문 양식의 요구를 확인하고 정렬을 바꿔요.','왼쪽 정렬: 오른쪽 끝을 맞추지 않는 것이 맞아요(APA처럼).']},menu:function(m){return m===0?'한글: 문단 모양 > 양쪽 정렬(Ctrl+Shift+M) · 워드: 홈 > 양쪽 맞춤(Ctrl+J)':'한글: 왼쪽 정렬 Ctrl+Shift+L · 워드: 왼쪽 맞춤 Ctrl+L. 영문은 양식에 따라 달라요'}},
 {t:'첫 줄 들여쓰기',f:s3,cap:function(){return ['먼저 틀린 모양: 문단이 시작하는 곳을 알아보기 어려워요.','문단 서식의 “첫 줄 들여쓰기”를 써요. 스페이스로 밀지 않아요.','고친 모양: 새 문단의 첫 줄만 1자(10pt) 들어가요.']},menu:function(){return '한글: 문단 모양 > 첫 줄 들여쓰기 10pt · 워드: 단락 > 특수 > 첫 줄 10pt'}},
 {t:'본문 줄 왼쪽 맞추기',f:sBody,modes:['소제목 아래 본문','하위 항목이 여러 개일 때'],cap:function(m){return m===0?['먼저 틀린 모양: 소제목만 왼쪽에 있고 본문 줄이 모두 안쪽으로 밀려 있어요.','본문 블록을 왼쪽으로 옮겨요(내어쓰기 단추·왼쪽 여백 0).','고친 모양: 본문은 첫 줄만 들어가고 나머지는 왼쪽 끝에 붙어요.']:['먼저 틀린 모양: 하위 항목이 들어갈수록 본문도 같이 들여썼어요.','본문 단락만 블록으로 잡아 왼쪽 여백을 0으로 맞춰요.','고친 모양: 하위 항목을 들여써도 본문은 모두 왼쪽 끝! 항목과 본문은 따로 설정해요.']},menu:function(){return '소제목은 그대로 두고 본문만 고쳐요. 워드: 홈 > 내어쓰기(⇤) 단추 또는 눈금자의 □를 왼쪽 끝으로 · 한글: 문단 모양의 왼쪽 여백 0'}},
 {t:'계층 기호 목차·본문',f:sHier,modes:['목차','본문(내어쓰기형)','본문(들여쓰기형)'],cap:function(m){return m===0?['먼저 틀린 모양: 목차의 Ⅰ. 1. 가.가 모두 같은 자리에 있어요.','하위 항목일수록 점점 오른쪽으로 들여써요.','고친 모양: 계단처럼 들어가요. 목차는 보통 이렇게 써요.']:['먼저 틀린 모양: 본문 항목이 모두 같은 자리에 있고 본문 첫 줄도 들어가지 않았어요.',m===1?'본문에서는 하위 항목일수록 왼쪽으로 나오는 내어쓰기형이 많아요.':'본문에서도 하위 항목을 오른쪽으로 들여쓰는 논문이 있어요.','고친 모양: 항목 위계가 보이고 본문 단락은 왼쪽 끝에 맞춰요. 논문마다 달라도 기본형부터 연습해요.']},menu:function(m){return m===0?'목차: 가장 높은 기호(Ⅰ.)는 왼쪽 끝, 하위 항목일수록 한 단계씩 들여써요. 쪽 번호는 오른쪽 끝에 점선으로 이어요.':'본문: 하위 항목을 내어쓰는 경우가 많지만 들여쓰기도 해요(목차와 반대인 점에 주의). 항목 전체에 같은 설정을 적용하고 스페이스·탭을 섞지 않아요. 학술지·학과 규정이 먼저예요.'}},
 {t:'장·절·항 한 줄 띄우기',f:sGap,cap:function(){return ['먼저 틀린 모양: 제목과 본문이 붙어 있어 어디서 바뀌는지 알기 어려워요.','제목 위·아래에 한 줄 높이의 간격을 줘요.','고친 모양: 장·절·항 사이가 한 줄씩 떨어져 한눈에 읽혀요.']},menu:function(){return '보고서의 장·절·항 제목 앞뒤는 한 줄씩 띄워요. 한글: 문단 모양의 문단 위·아래 간격, 워드: 단락의 앞·뒤 간격으로 한 줄 높이를 줘요.'}},
 {t:'문장마다 Enter 금지',f:sEnter,cap:function(){return ['먼저 틀린 모양: 문장이 끝날 때마다 Enter를 쳤어요.','Enter를 지우고 문장을 이어 써요.','고친 모양: 한 문단이 줄 끝까지 자연스럽게 이어지고, 문단이 끝날 때만 Enter를 쳐요.']},menu:function(){return '줄 끝에서 Enter를 치면 문단이 끊겨 양쪽 정렬·들여쓰기가 흐트러져요. 문단을 나눌 때만 Enter를 쳐요.'}},
 {t:'각주 번호 자리',f:s4,modes:['직접 인용 뒤','간접 인용 뒤'],cap:function(m){return ['먼저 틀린 모양: 번호를 손으로 썼어요.','각주 삽입 단축키를 쓰면 번호가 자동으로 들어가요.',m===0?'고친 모양: 닫는 큰따옴표(”) 다음에 위 첨자 번호가 있어요.':'고친 모양: 마침표나 쉼표 다음에 위 첨자 번호가 있어요.']},menu:function(){return '한글: Ctrl+N, N · 워드: Ctrl+Alt+F. 번호는 직접 치지 않고 반드시 이 기능으로 넣어요.'},
  ex:function(m){var u=function(s){return '<sup>'+s+'</sup>'};return m===0?'<div class="fvx no"><b>❌ 틀린 표기</b> 김서연은 “글쓰기는 생각을 정리하는 일이다'+u(1)+'”라고 말했다. <small>번호가 닫는 큰따옴표 안쪽에 들어갔어요.</small></div><div class="fvx yes"><b>✅ 맞는 표기</b> 김서연은 “글쓰기는 생각을 정리하는 일이다”'+u(1)+'라고 말했다. <small>닫는 큰따옴표 바로 다음에 번호를 붙여요.</small></div>':'<div class="fvx no"><b>❌ 틀린 표기</b> 김서연은 글쓰기가 생각을 정리하는 일이라고 보았다'+u(1)+'. <small>번호가 마침표 앞에 들어갔어요.</small></div><div class="fvx yes"><b>✅ 맞는 표기</b> 김서연은 글쓰기가 생각을 정리하는 일이라고 보았다.'+u(1)+' <small>마침표 다음에 번호를 붙여요.</small></div>'}},
 {t:'⭐ 출처는 두 번',f:s5,modes:['APA','MLA','Chicago 내각주','Chicago 외각주','IEEE','Vancouver','ACS'],cap:function(m){return ['본문 표시만 쓰고 참고문헌을 빼면 안 돼요!','참고문헌만 쓰고 본문 표시를 빼도 안 돼요!','같은 출처를 본문에도, 참고문헌에도 꼭 적어요. ('+S5[BK[m]].n+')']},menu:function(m){return '본문 표시('+S5[BK[m]].sub+')는 참고문헌 항목과 짝이 맞아야 해요. 둘 중 하나라도 없으면 출처를 밝혔다고 볼 수 없어요.'}},
 {t:'계층 기호 번호는 둘 이상일 때',f:sOne,modes:['하위 항목이 하나뿐','하위 항목이 둘 이상'],cap:function(m){return m===0?['먼저 틀린 모양: 하위 항목이 하나뿐인데 “1.”을 붙였어요.','하나뿐인 하위 항목은 번호와 소제목을 지우고 본문만 상위 항목에 이어 써요.','고친 모양: 하위 항목이 하나면 번호 없이 상위 항목에 포함해 본문만 써요.']:['먼저 틀린 모양: 하위 항목이 둘인데 번호가 없어서 어디서 나뉘는지 알 수 없어요.','소제목마다 1. 2. 번호를 붙여요.','고친 모양: 하위 항목이 둘 이상이면 번호를 붙여 위계를 보여 줘요.']},menu:function(){return '계층 기호(Ⅰ. 1. 가.)는 하위 항목이 둘 이상일 때만 붙여요. 하나뿐이면 상위 항목 안에 본문으로 쓰고 따로 번호를 주지 않아요. 아래 문장은 층위별로 바로 복사해 쓸 수 있어요(연습용 가상 문장).'},
  ex:function(m){var R=[['장(Ⅰ.)','Ⅰ. 대학생의 생성형 AI 활용 실태'],['절(1.) — 하위 항목이 둘 이상일 때','1. 연구 배경과 필요성\n2. 연구 방법과 범위'],['항(가.) — 하위 항목이 둘 이상일 때','가. 문제 제기\n나. 연구 질문'],['하위 항목이 하나뿐일 때(번호 없이 본문만)','Ⅰ. 연구 배경\n  대학 글쓰기 수업에서는 학생이 읽은 자료를 근거로 자기 주장을 세우는 일이 중요하다.']];return '<div class="fvx cpl"><b>층위별 복사용 문장(연습용 가상)</b><ul>'+R.map(function(r){return '<li><span>'+esc(r[0])+'</span><code>'+esc(r[1]).replace(/\n/g,'<br>')+'</code><button type="button" class="cpbtn" data-cp="'+esc(r[1]).replace(/\n/g,'&#10;')+'">복사</button></li>'}).join('')+'</ul></div>'}}
];
host.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-cp]');if(!b)return;var t=b.getAttribute('data-cp');function ok(){b.textContent='복사됨';setTimeout(function(){b.textContent='복사'},1200)}function fb(){var ta=document.createElement('textarea');ta.value=t;document.body.appendChild(ta);ta.select();try{document.execCommand('copy')}catch(e){}ta.remove();ok()}try{navigator.clipboard.writeText(t).then(ok,fb)}catch(e){fb()}});

var DUR=6200,cur=0,mode=0,t=0,playing=false,last=0,speed=1,raf=0,auto=false;
host.innerHTML='<div class="tn-head"><h2 class="gt">보고서 모양 애니메이션</h2><p class="mut">이 자리에 오면 저절로 재생돼요. 끝나면 ▶ 다시 재생을 눌러 또 볼 수 있고, 아래 막대로 원하는 곳에서 멈춰 볼 수도 있어요. 글은 연습용 가상 문장입니다.</p></div>'
 +'<div class="fv-tabs" id="fvtabs" role="tablist">'+SC.map(function(s,i){return '<button type="button" class="tn-tab" data-i="'+i+'" role="tab">'+(i+1)+'. '+esc(s.t)+'</button>'}).join('')+'</div>'
 +'<div class="fv-tabs fv-modes" id="fvmodes" aria-label="세부 선택"></div>'
 +'<div class="fv-stage"><svg id="fvsvg" viewBox="0 0 300 360" role="img" aria-label="보고서 모양이 고쳐지는 애니메이션"></svg><div class="fv-side"><p id="fvcap" class="fv-cap" aria-live="polite"></p><p id="fvmenu" class="mut fv-menu"></p><div id="fvex" class="fv-ex" hidden></div></div></div>'
 +'<div class="fv-ctl"><button type="button" class="gprimary" id="fvplay">▶ 재생</button><button type="button" class="gbtn" id="fvrep">↺ 처음부터</button><input type="range" id="fvr" min="0" max="1000" value="0" aria-label="재생 위치"><label class="mut">속도 <select id="fvsp"><option value="0.5">느리게</option><option value="1" selected>보통</option><option value="1.6">빠르게</option></select></label></div>'
 +'<p class="mut tn-credit">쪽 그림은 비율을 단순하게 줄인 모형입니다. 값은 이 안내서의 기본값이며 제출처의 규정이 먼저입니다. 영어 논문의 정렬은 양식마다 다릅니다.</p>';
var svg=d.getElementById('fvsvg'),capEl=d.getElementById('fvcap'),menuEl=d.getElementById('fvmenu'),exEl=d.getElementById('fvex'),rng=d.getElementById('fvr'),pb=d.getElementById('fvplay'),mEl=d.getElementById('fvmodes');
function draw(){var s=SC[cur],p=t;
 svg.innerHTML=(SC[cur].f===s5?'':'<rect x="6" y="4" width="288" height="352" rx="6" fill="#fff" stroke="#4a3a30" stroke-width="2.5"/>')+s.f(p,mode);
 var c=s.cap(mode);capEl.textContent=c[p<.25?0:p<.75?1:2];menuEl.textContent=s.menu(mode);var xx=s.ex?s.ex(mode):'';if(exEl._k!==xx){exEl.innerHTML=xx;exEl._k=xx}exEl.hidden=!xx;rng.value=Math.round(p*1000);
 host.querySelectorAll('#fvtabs .tn-tab').forEach(function(b,i){b.classList.toggle('on',i===cur);b.setAttribute('aria-selected',i===cur)})}
function tick(ts){if(!playing)return;if(!last)last=ts;t+=(ts-last)*speed/DUR;last=ts;if(t>=1){t=1;draw();stop(true);return}draw();raf=requestAnimationFrame(tick)}
function play(){if(t>=1)t=0;playing=true;last=0;pb.textContent='■ 멈춤';cancelAnimationFrame(raf);raf=requestAnimationFrame(tick)}
function stop(done){playing=false;cancelAnimationFrame(raf);pb.textContent=done?'▶ 다시 재생':'▶ 재생'}
var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function restart(){stop();if(!reduce)play()}
function buildModes(){var s=SC[cur];if(!s.modes){mEl.innerHTML='';mEl.hidden=true;return}mEl.hidden=false;
 mEl.innerHTML=s.modes.map(function(x,i){return '<button type="button" class="tn-tab sm'+(i===mode?' on':'')+'" data-m="'+i+'">'+esc(x)+'</button>'}).join('');
 mEl.querySelectorAll('button').forEach(function(b){b.onclick=function(){mode=+b.dataset.m;buildModes();t=0;draw();restart()}})}
pb.onclick=function(){playing?stop():play()};
d.getElementById('fvrep').onclick=function(){t=0;draw();play()};
rng.oninput=function(){stop();t=rng.value/1000;draw()};
d.getElementById('fvsp').onchange=function(e){speed=parseFloat(e.target.value)||1};
host.querySelectorAll('#fvtabs .tn-tab').forEach(function(b){b.onclick=function(){cur=+b.dataset.i;mode=0;buildModes();t=0;draw();restart()}});
buildModes();draw();
try{if('IntersectionObserver' in window&&!reduce){var io=new IntersectionObserver(function(es){es.forEach(function(en){if(en.isIntersecting&&!auto){auto=true;t=0;draw();play();io.disconnect()}})},{threshold:.5});io.observe(host.querySelector('.fv-stage'))}}catch(e){}
})();
