(function(){
var d=document,$=function(i){return d.getElementById(i)};
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){}return null}
function sh(a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),t=a[i];a[i]=a[j];a[j]=t}return a}
function pick(a){return a[Math.floor(Math.random()*a.length)]}
function ri(a,b){return a+Math.floor(Math.random()*(b-a+1))}
var STYL=[['apa','APA','#3a5fb0'],['mla','MLA','#8272b5'],['cad','Chicago Author-Date','#6fa89c'],['nb','Chicago Notes-Bibliography','#cfa04e'],['ieee','IEEE','#8a93a0'],['van','Vancouver','#cf7f88'],['acs','ACS','#a8764f']];
function sname(id){for(var i=0;i<STYL.length;i++)if(STYL[i][0]===id)return STYL[i][1];return id}
var GAMENAME={abbr:'논문 약어 주관식 · 약어를 직접 써 보기',names:'이름 표기 연습 · 영문 성·이름 쓰는 법',names2:'이름 단계 도전 · 번역자·편집자',docfind:'문서 속 인용 찾기 · 본문과 참고문헌 짝 맞추기',match:'짝 맞추기 카드 · 약어와 양식 익히기',assemble:'서지 조립 라인 · 서지 순서 익히기',traffic:'인용 신호등 · 출처 밝힐 때 판단하기',sorter:'서지 검수 라인 · 불량 서지 가려내기',explore:'논문 첫 쪽 탐험 · 서지정보 찾기',sports:'인용 올림픽 · 오류 유형 26종목 훈련',court:'법정 게임 · 법률문헌 인용',medical:'병동 회진 · Vancouver 참고문헌',town:'학과 마을 여행 · 여행지마다 빠진 것 찾기',scope:'학과 마을 여행 2 · 이공·보건 골짜기 원정',escape:'참고문헌 방탈출 · 틀린 카드 찾기',detective:'가짜 출처 탐정단 · AI 가짜 서지 가려내기',bingo:'약어 뽑기 빙고 · 논문 약어 익히기',yut:'윷놀이 · 참고문헌 판정',sabang:'사방치기 · 본문 인용 표기',squid:'오징어 놀이 · 서지 검사 통과',mole:'두더지 잡기 · 틀린 표기 잡아내기',race:'카레이싱 · 맞고 틀린 표기 구분',claw:'인형 뽑기 · 맞는 표기 고르기',roleplay:'메타버스 롤플레잉 · 발표·토론 속 출처 밝히기',lit:'문학 인용 연습 · 시·소설 인용하기',site:'홈페이지 전체'};

// ===== 1. 학과 → 추천 양식, 양식 고르고 바로 시작 =====
var REC=[
[/국어국문|국문학|한국어문|문예창작|국어학|한국문학/,'nb','국어국문학은 학회·학과마다 각주식·참고문헌식이 달라 정해진 한 가지가 없습니다. 각주를 쓰는 Chicago Notes-Bibliography가 연습하기 좋습니다.'],
[/영어영문|영문학|독어|독문|불어|불문|중어|중문|노어|일어|일문|서어|언어학|어문|영어교육|외국어/,'mla','영어영문학 등 어문학은 MLA를 널리 씁니다.'],
[/사학|역사|한국사|동양사|서양사|철학|고고|미술사|인류|민속|문헌정보/,'nb','역사·철학 분야는 Chicago 각주 방식(Notes-Bibliography)을 많이 씁니다.'],
[/심리|교육|사범|아동|청소년|사회복지|상담|유아|특수교육|사회학|미디어|언론|신문방송|커뮤니케이션|경영|마케팅|회계|정치|외교|행정|국제|지리|관광|호텔/,'apa','사회과학·교육·경영 분야는 APA를 가장 많이 씁니다(정치·행정은 Chicago Author-Date도 씁니다).'],
[/경제|통계|금융|무역/,'cad','경제학 등은 저자–연도 방식을 학회별로 씁니다. Chicago Author-Date가 가장 가깝습니다.'],
[/의학|의과|의예|간호|보건|약학|치의|한의|수의|생명|바이오|식품|영양|임상|재활|체육/,'van','의학·간호·보건 분야는 Vancouver(번호식)를 많이 씁니다. 생명과학은 학술지마다 다릅니다.'],
[/화학|화공|신소재|재료|환경|에너지|고분자|나노/,'acs','화학·화공·재료 분야는 ACS를 많이 씁니다.'],
[/전기|전자|컴퓨터|컴공|소프트웨어|인공지능|AI|데이터|사이버|정보|기계|건축|토목|산업|반도체|통신|항공|로봇|메카|물리|수학|천문|지구|대기|해양/,'ieee','공학·컴퓨터 분야는 IEEE(번호식)를 많이 씁니다. 물리·수학은 학술지별로 다릅니다.'],
[/디자인|미술|음악|무용|조형|연극|영화|예술|건축디자인/,'nb','디자인·예술 분야는 Chicago 방식을 쓰는 경우가 많습니다.']];
function recommend(t){t=String(t||'').replace(/\s+/g,'');if(!t)return null;
 if(/법학|법과|법대|로스쿨/.test(t))return {law:true,id:'nb',why:'법학은 국내 법학 학술지의 각주 방식을 따릅니다. 법률문헌은 “법정 게임”에서 연습하고, 여기서는 Chicago 각주 방식으로 시작해 볼 수 있습니다.'};
 for(var i=0;i<REC.length;i++)if(REC[i][0].test(t))return {id:REC[i][1],why:REC[i][2]};
 return {id:'apa',why:'학과를 찾지 못했습니다. 가장 널리 쓰이는 APA로 시작해 볼 수 있습니다.',none:true}}
function gateInit(){var G=$('stygate');if(!G)return;var lit=G.dataset.mode==='lit',allow=lit?['apa','mla','cad','nb']:STYL.map(function(s){return s[0]});
 var last=ls('mystyle');if(allow.indexOf(last)<0)last=null;
 G.innerHTML='<section class="sgc"><h2 class="gt">먼저 양식을 정해요</h2><p class="mut">쓸 양식을 모르면 학과(전공)를 입력하세요. 보통 쓰는 양식을 알려 드립니다. 양식을 누르면 바로 게임이 시작됩니다.'+(lit?' 문학 작품(단행본)의 국문 예시는 이 안내서에 있는 네 가지 양식으로 연습합니다.':'')+'</p>'
  +'<form class="sgf2"><label>학과·전공 <input id="sgdept" list="sgdl" autocomplete="off" maxlength="30" placeholder="예: 심리학과, 국어국문학과, 전기전자공학부"></label><datalist id="sgdl">'+['심리학과','교육학과','국어국문학과','영어영문학과','사학과','철학과','정치외교학과','경제학과','경영학과','사회학과','컴퓨터학과','전기전자공학부','화학과','화공생명공학과','의예과','간호학과','법학과','디자인조형학부','생명과학부'].map(function(x){return '<option value="'+x+'">'}).join('')+'</datalist><button class="gprimary" type="submit">추천 받기</button></form>'
  +'<div id="sgrec" class="sgrec" aria-live="polite"></div>'
  +'<div class="sgbtns">'+STYL.filter(function(s){return allow.indexOf(s[0])>=0}).map(function(s){return '<button class="sgb" data-i="'+s[0]+'" style="--sc:'+s[2]+'">'+esc(s[1])+'</button>'}).join('')+(G.dataset.mix==='1'?'<button class="sgb mixb" data-i="mix" style="--sc:#555">양식 정하지 않고 섞어서 시작</button>':'')+'<button class="sgb rndb" data-i="rnd" style="--sc:#e0a100">🎲 바로 시작 (학과·양식 안 정하고 랜덤)</button></div>'
  +(last?'<p><button class="gbtn" id="sglast">지난번에 고른 <b>'+esc(sname(last))+'</b>(으)로 바로 시작</button></p>':'')
  +'<p class="mut sgn">추천은 학문 분야의 일반적인 관행일 뿐입니다. 수업·학과·제출처의 지침이 있으면 그것이 우선입니다. 입력한 학과는 저장하거나 보내지 않습니다.</p></section>';
 function go(id){if(id==='rnd'){id=G.dataset.mix==='1'?'mix':allow[Math.floor(Math.random()*allow.length)]}if(id==='mix'){ls('gmix','1')}else{ls('gmix','0');ls('mystyle',id)}G.remove();var w=$('gwrap');if(w)w.hidden=false;try{window.__g2boot()}catch(e){console.error(e)}try{window.__g3boot()}catch(e){console.error(e)}try{window.__g4boot&&window.__g4boot()}catch(e){console.error(e)}try{window.dispatchEvent(new Event('resize'))}catch(e){}}
 G.querySelectorAll('.sgb').forEach(function(b){b.onclick=function(){go(b.dataset.i)}});
 var lb=$('sglast');if(lb)lb.onclick=function(){go(last)};
 G.querySelector('form').onsubmit=function(ev){ev.preventDefault();var r=recommend($('sgdept').value),box=$('sgrec');if(!r){box.innerHTML='';return}
  var id=allow.indexOf(r.id)>=0?r.id:'apa';
  box.innerHTML='<div class="sgrc" style="--sc:'+STYL.filter(function(s){return s[0]===id})[0][2]+'"><b>추천: '+esc(sname(id))+'</b><p>'+esc(r.why)+'</p>'+(r.law?'<p><a href="court.html">법정 게임(법률문헌) 바로 가기 →</a></p>':'')+'<button class="gprimary" id="sgrg">'+esc(sname(id))+'(으)로 시작</button></div>';
  $('sgrg').onclick=function(){go(id)}}}

// ===== 2. 평가·한마디(비공개) =====
function rnote(){return '<p class="rnote"><b>알림</b> '+esc(window.RN||'')+'</p>'}
function rateInit(){var GX=window.GX;d.querySelectorAll('.grate').forEach(function(host){var g=host.dataset.g,name=GAMENAME[g]||g,site=g==='site',mine=null;
  try{mine=(JSON.parse(ls('grate.mine.v1')||'{}')[g])||null}catch(e){}
  host.innerHTML='<section class="gr2"><h2 class="gt">'+(site?'홈페이지에 대한 평가':'이 게임 평가')+'</h2><div class="gr2r"><div class="st5" role="radiogroup" aria-label="별점">'+[1,2,3,4,5].map(function(n){return '<button type="button" class="st5b'+(mine&&mine.s>=n?' on':'')+'" data-n="'+n+'" role="radio" aria-checked="'+(mine&&mine.s===n)+'" aria-label="'+n+'점">★</button>'}).join('')+'</div><span class="gr2a mut">평균을 불러오는 중…</span></div>'
   +'<form class="gr2f"><label>하고 싶은 말 <small>(선택 · 담당 교수자만 읽습니다)</small><textarea maxlength="400" rows="3" placeholder="'+(site?'홈페이지에서 좋았던 점, 불편했던 점, 바라는 점':'재미·난이도·헷갈린 점·고치면 좋을 점')+'"></textarea></label><div class="gcb"><small class="cnt">0/400</small><button class="gprimary" type="submit">평가 보내기</button></div><p class="gr2m" aria-live="polite"></p></form>'
   +'<p class="mut">별점은 평균만 모두에게 보이고, 쓴 글은 <b>비공개</b>입니다(다른 학생은 볼 수 없습니다).</p>'+rnote()+'</section>';
  var cur=mine?mine.s:0,msg=host.querySelector('.gr2m'),ta=host.querySelector('textarea');
  ta.oninput=function(){host.querySelector('.cnt').textContent=ta.value.length+'/400'};
  host.querySelectorAll('.st5b').forEach(function(b){b.onclick=function(){cur=+b.dataset.n;host.querySelectorAll('.st5b').forEach(function(x){var on=+x.dataset.n<=cur;x.classList.toggle('on',on);x.setAttribute('aria-checked',+x.dataset.n===cur)})}});
  function avg(){if(!GX)return;GX.sbInit().then(async function(){var el=host.querySelector('.gr2a');if(!GX.SB.db){el.textContent='이 환경에서는 평균을 볼 수 없습니다.';return}
   try{var q=await GX.SB.db.collection('ratings').get(),n=0,t=0;q.docs.forEach(function(x){var r=((x.data()||{}).r||{})[g];if(r&&r.s){n++;t+=r.s}});el.textContent=n?'평균 '+(t/n).toFixed(1)+' / 5 ('+n+'명)':'아직 평가가 없습니다.'}catch(e){el.textContent='평균을 불러오지 못했습니다.'}})}
  avg();
  host.querySelector('form').onsubmit=async function(ev){ev.preventDefault();var t=ta.value.trim();if(!cur&&!t){msg.textContent='별점을 누르거나 글을 적어 주세요.';return}
   if(t&&window.PF&&PF.bad(t)){msg.textContent=PF.msg;return}
   try{var all=JSON.parse(ls('grate.mine.v1')||'{}');if(cur){all[g]={s:cur,at:Date.now()};ls('grate.mine.v1',JSON.stringify(all))}}catch(e){}
   var shared=false;
   try{await GX.sbInit();var SB=GX.SB;if(SB.db&&SB.can&&SB.uid){
     if(cur){var rf=SB.db.doc('ratings/'+SB.uid),sn=await rf.get(),r0=sn.exists?(sn.data().r||{}):{};r0[g]={s:cur,at:Date.now()};await rf.set({r:r0,upd:Date.now()})}
     if(t){var sf=SB.db.doc('suggest/'+SB.uid),s2=await sf.get(),its=s2.exists?(s2.data().items||[]):[];var it={k:Date.now().toString(36)+Math.random().toString(36).slice(2,6),kind:'평가: '+name+(cur?' ('+cur+'점)':''),text:t,at:Date.now()};its.push(it);await sf.set({items:its.slice(-50),upd:Date.now()});
      try{var ml=JSON.parse(ls('sg.mine.v1')||'[]');ml.push({k:it.k,kind:it.kind,text:t.slice(0,50),at:it.at});ls('sg.mine.v1',JSON.stringify(ml.slice(-30)))}catch(e){}}
     shared=true}}catch(e){}
   msg.textContent=shared?'보냈습니다. 고맙습니다.':'이 환경에서는 보낼 수 없어 이 기기에만 별점을 기록했습니다(보내려면 로그인과 참여 권한이 필요합니다).';
   if(shared){ta.value='';host.querySelector('.cnt').textContent='0/400';avg()}}})}

// ===== 3. 본문 인용 문제 (사방치기·롤플레잉) =====
function iq(GX){var sid=GX.myId(),r=GX.rec(),S=r.au.map(function(a){return a[0]});if(S.length<2)S.push(pick(GX.AU)[0]);var A=S[0],B=S[1],y=r.y,k=ri(1,9),p=ri(20,480),
 ttl=GX.tcase(r.t.split(' ').slice(0,3).join(' ')),good,bads;
 if(sid==='apa'){good='('+A+' & '+B+', '+y+', p. '+p+')';bads=[['('+A+' and '+B+', '+y+', p. '+p+')','괄호 안에서는 and 대신 &를 씁니다.'],['('+A+' & '+B+' '+y+', p. '+p+')','저자와 연도 사이에 쉼표가 있어야 합니다.'],['('+A+' & '+B+', p. '+p+', '+y+')','연도가 쪽보다 앞에 옵니다.']]}
 else if(sid==='mla'){good='('+A+' and '+B+' '+p+')';bads=[['('+A+' and '+B+', '+p+')','MLA는 저자와 쪽 사이에 쉼표를 쓰지 않습니다.'],['('+A+' and '+B+' '+y+', '+p+')','MLA는 본문 인용에 연도를 쓰지 않습니다.'],['('+A+' & '+B+' '+p+')','MLA는 &가 아니라 and를 씁니다.']]}
 else if(sid==='cad'){good='('+A+' and '+B+' '+y+', '+p+')';bads=[['('+A+' and '+B+', '+y+', '+p+')','저자와 연도 사이에 쉼표를 쓰지 않습니다.'],['('+A+' and '+B+' '+p+')','연도가 빠졌습니다(저자 연도, 쪽).'],['('+A+' & '+B+' '+y+', '+p+')','Chicago는 &가 아니라 and를 씁니다.']]}
 else if(sid==='nb'){good=k+'. '+A+' and '+B+', “'+ttl+',” '+p+'.';bads=[[k+'. '+A+' and '+B+', '+ttl+', '+p+'.','제목은 따옴표 안에 씁니다.'],[k+'. '+A+' and '+B+', “'+ttl+'” '+p+'.','제목 뒤 쉼표는 닫는 따옴표 안에 들어갑니다.'],['('+A+' and '+B+' '+y+', '+p+')','Notes-Bibliography는 괄호 인용이 아니라 번호를 붙인 각주를 씁니다.']]}
 else if(sid==='ieee'){good='['+k+', p. '+p+']';bads=[['('+k+', p. '+p+')','IEEE는 대괄호를 씁니다.'],['['+k+', '+p+']','쪽 앞에 p.를 붙입니다.'],['['+A+', '+y+']','IEEE는 저자–연도가 아니라 번호로 인용합니다.']]}
 else if(sid==='van'){good='('+k+')';bads=[['['+k+']','Vancouver는 괄호 번호(또는 위 첨자 번호)를 씁니다.'],['('+A+', '+y+')','Vancouver는 저자–연도가 아니라 번호로 인용합니다.'],['('+k+', '+y+')','번호만 씁니다. 연도를 덧붙이지 않습니다.']]}
 else {good='('+k+')';bads=[['['+k+']','ACS의 번호 인용은 괄호 번호(또는 위 첨자)입니다.'],['('+k+', '+y+')','번호 인용에는 연도를 덧붙이지 않습니다.'],['(Ref. '+k+')','번호만 괄호 안에 씁니다.']]}
 var bad=Math.random()<.5,b=pick(bads);return {shown:[bad?b[0]:good],bad:bad,why:bad?b[1]:'',fix:[good],sid:sid,opts:[{pc:[good],good:1,why:''}].concat(bads.map(function(x){return {pc:[x[0]],why:x[1]}})),ctx:{A:A,B:B,y:y,p:p,k:k}}}

// ===== 4. 새 게임 =====
function boot3(){var GX=window.GX;if(!GX)return;
 var esc=GX.esc,mk=GX.mk;
 GX.sbInit();rateInit();
 function styleBar(cb){var m=$('mys');if(m)GX.picker(m,cb)}

 // ---- 윷놀이 ----
 var YU=$('yut');if(YU){var st;
  function throwYut(){var f=0,sticks=[];for(var i=0;i<4;i++){var flat=Math.random()<.6;sticks.push(flat);if(flat)f++}var n=f===0?5:f,name=['','도','개','걸','윷','모'][n];if(f===0)name='모';return {n:n,name:name,sticks:sticks,extra:n>=4}}
  function turn(){var t=throwYut(),tot=t.n,txt=t.name,ex=0;while(t.extra&&ex<2){t=throwYut();tot+=t.n;txt+=' + '+t.name;ex++}return {n:tot,txt:txt,sticks:t.sticks}}
  // 진짜 윷판: 바깥 20점 + 대각선 8점 + 중앙. 좌표는 0~100 안의 퍼센트
  var PT={};(function(){var o=[[92,92],[92,74],[92,56],[92,38],[92,20],[92,8],[74,8],[56,8],[38,8],[20,8],[8,8],[8,20],[8,38],[8,56],[8,74],[8,92],[20,92],[38,92],[56,92],[74,92]];
   o.forEach(function(p,i){PT[i]=p});o[0]=[92,92];
   // 모서리: 0=출발(오른쪽 아래) 5=오른쪽 위 10=왼쪽 위 15=왼쪽 아래. 5,10에서 안쪽 대각선
   PT.a1=[76,24];PT.a2=[63,37];PT.C=[50,50];PT.a3=[37,63];PT.a4=[24,76];PT.b1=[24,24];PT.b2=[37,37];PT.b3=[63,63];PT.b4=[76,76]})();
  var DIAG=[[5,'a1','a2','C','a3','a4',15],[10,'b1','b2','C','b3','b4',0]];
  // 말 위치: {n:노드, via:'a'|'b'|''} 
  function nxt(p,first){var n=p.n,v=p.via;
   if(typeof n==='number'){if(first&&n===5)return {n:'a1',via:'a'};if(first&&n===10)return {n:'b1',via:'b'};if(n===19)return {n:'F',via:''};return {n:(n+1)%20===0?'F':n+1,via:''}}
   if(n==='a1')return {n:'a2',via:'a'};if(n==='a2')return {n:'C',via:'a'};if(n==='C')return p.via==='b'?{n:'b3',via:'b'}:{n:'a3',via:'a'};
   if(n==='a3')return {n:'a4',via:'a'};if(n==='a4')return {n:15,via:''};
   if(n==='b1')return {n:'b2',via:'b'};if(n==='b2')return {n:'C',via:'b'};if(n==='b3')return {n:'b4',via:'b'};if(n==='b4')return {n:'F',via:''};
   return {n:'F',via:''}}
  function route(p,k){var out=[],cur=p,first=true;for(var i=0;i<k;i++){if(cur.n==='F')break;cur=nxt(cur,first);first=false;out.push(cur);if(cur.n==='F')break}return out}
  function left(p){var c=0,cur=p,first=true;while(cur.n!=='F'&&c<40){cur=nxt(cur,first);first=false;c++}return c}
  function xy(p){return p.n==='F'?PT[0]:PT[p.n]}
  function board(){var lines='<rect x="8" y="8" width="84" height="84" fill="none" stroke="#7a5128" stroke-width="1.4"/><line x1="92" y1="8" x2="8" y2="92" stroke="#7a5128" stroke-width="1.2"/><line x1="8" y1="8" x2="92" y2="92" stroke="#7a5128" stroke-width="1.2"/>';
   var dots='';Object.keys(PT).forEach(function(k){var p=PT[k],big=(k==='0'||k==='5'||k==='10'||k==='15'||k==='C');dots+='<circle cx="'+p[0]+'" cy="'+p[1]+'" r="'+(big?4.6:3)+'" fill="'+(k==='0'?'#c46a5e':big?'#f6d77a':'#fff8e4')+'" stroke="#7a5128" stroke-width=".9"/>'});
   var hm=PT[0];
   return '<div class="yutbd"><div class="yutwrap"><svg class="yutsvg" viewBox="0 0 100 100" aria-label="윷판">'+'<rect x="0" y="0" width="100" height="100" rx="6" fill="#e8d8b0"/>'+lines+dots+'<text x="92" y="98.5" font-size="3.4" text-anchor="middle" fill="#7a3b2e" font-weight="700">출발·도착</text><text x="50" y="57.5" font-size="3" text-anchor="middle" fill="#7a5128">방</text></svg>'
    +'<span class="yk me" id="ykme" style="left:'+hm[0]+'%;top:'+hm[1]+'%">'+GX.avatar('dot')+'</span><span class="yk cp" id="ykcp" style="left:'+hm[0]+'%;top:'+hm[1]+'%">'+GX.avatar('owl')+'</span></div>'
    +'<div class="yutc2"><div class="yutst" id="yutst">'+'<div class="yutst empty">윷</div>'+'</div><p id="yutmsg">'+esc(st.msg)+'</p></div><div class="yutleg"><span><b class="dotme"></b> 나(도토리) <b id="yml">20</b>걸음 남음</span><span><b class="dotcp"></b> 컴퓨터(올빼미) <b id="ycl">20</b>걸음 남음</span></div></div>'}
  function hop(host,id,p,k,done){var el=host.querySelector('#'+id);if(!el){done&&done();return}var r=route(p.pos,k),i=0;
   (function step(){if(i>=r.length){p.pos=r.length?r[r.length-1]:p.pos;done&&done();return}var q=r[i++],xyp=xy(q);el.style.left=xyp[0]+'%';el.style.top=xyp[1]+'%';el.classList.remove('hopn');void el.offsetWidth;el.classList.add('hopn');setTimeout(step,260)})()}
  function sticksHTML(s){return s.map(function(f){return '<i class="ys'+(f?' flat':'')+'"></i>'}).join('')}
  function start(){st={me:{pos:{n:0,via:''}},cpu:{pos:{n:0,via:''}},msg:'문제를 맞히면 윷을 던질 수 있습니다.'};st.me.pos={n:0,via:''};
   GX.judgeGame(YU,{gid:'yut',skin:'stick',icons:['',''],flip:false,ask:'이 참고문헌은 <b>내 인용 스타일</b> 규칙에 맞을까요? 맞히면 윷을 던집니다.',okL:'맞다',badL:'틀렸다',goodW:'윷을 던집니다!',badW:'아쉽습니다!',unit:'차례',rounds:10,doneT:'윷놀이 종료!',
    top:function(){return board()},
    onMove:function(h,p,right){var c=turn(),msgEl=h.querySelector('#yutmsg'),sk=h.querySelector('#yutst');
     function upd(){var a=h.querySelector('#yml'),b=h.querySelector('#ycl');if(a)a.textContent=left(st.me.pos);if(b)b.textContent=left(st.cpu.pos)}
     function cpuGo(){var k=Math.min(3,Math.max(1,Math.round(c.n/2)));hop(h,'ykcp',st.cpu,k,upd)}
     if(right){var m=turn();if(sk)sk.innerHTML=sticksHTML(m.sticks);if(msgEl)msgEl.textContent='내가 던진 결과: '+m.txt+' → '+m.n+'칸 전진';hop(h,'ykme',st.me,m.n,function(){upd();cpuGo()})}
     else{if(sk)sk.innerHTML='<div class="yutst empty">윷</div>';if(msgEl)msgEl.textContent='윷을 던지지 못하고 컴퓨터가 앞서갑니다';cpuGo()}},
    item:GX.qitem,label:function(ok){var a=left(st.me.pos),b=left(st.cpu.pos);return '윷놀이 · '+(a<b?'승리':a>b?'패배':'무승부')+' · '+ok+'건 정답'}})}
  styleBar(start);start()}

 // ---- 사방치기 ----
 var SB8=$('sab');if(SB8){
  function startS(){var sq=0;
   function top(p){var n=Math.round(p*8);return '<div class="sabbd">'+[8,7,6,5,4,3,2,1].map(function(i){return '<i class="sq'+(i<=n?' done':'')+(i===n+1?' now':'')+'">'+i+'</i>'}).join('')+'</div>'}
   GX.judgeGame(SB8,{gid:'sabang',skin:'stone',icons:['●','○'],ask:'이 <b>본문 인용 표기</b>는 내 인용 스타일 규칙에 맞을까요? 맞히면 돌을 던져 다음 칸으로 뜁니다.',okL:'맞다',badL:'틀렸다',goodW:'다음 칸!',badW:'발이 금을 밟았어요!',unit:'칸',rounds:8,doneT:'사방치기 완주!',
    top:top,onMove:function(h,p){var b=h.querySelector('.sabbd');if(b){b.outerHTML=top(p)}},
    item:function(){return iq(GX)},hint:function(it){return '올바른 모양: '+it.fix.map(mk).join(' ')},label:function(ok,en){return '사방치기 '+(en?'무한 · ':'· ')+ok+'칸 정답'}})}
  styleBar(startS);startS()}

 // ---- 오징어 놀이 ----
 var SQ=$('sqd');if(SQ){
  function mvq(){return '<g class="mv" style="transform:translate(calc(var(--p,0)*460px),calc(var(--p,0)*-6px))"><circle cx="80" cy="95" r="14" fill="#c46a5e" stroke="#2b3558" stroke-width="3"/><path d="M80 109v26M80 118l-14 10M80 118l14 10" stroke="#2b3558" stroke-width="4" stroke-linecap="round"/></g>'}
  function field(p){return '<div class="sport sqf"><svg viewBox="0 0 800 170" role="img" aria-label="오징어 모양 놀이판" style="--p:'+p+'"><rect width="800" height="170" fill="#d9ccaa"/><path d="M40 28H190V162H40Z M190 28L440 78V112L190 162" fill="#eadfc2" stroke="#2b3558" stroke-width="4" stroke-linejoin="round"/><circle cx="560" cy="95" r="62" fill="#eadfc2" stroke="#2b3558" stroke-width="4"/><path d="M440 78Q500 70 520 60M440 112Q500 120 520 130" stroke="#2b3558" stroke-width="4" fill="none"/><text x="560" y="101" text-anchor="middle" font-size="18" font-weight="700" fill="#2b3558" font-family="sans-serif">머리</text><text x="115" y="101" text-anchor="middle" font-size="16" fill="#2b3558" font-family="sans-serif">출발</text><path d="M300 78V112" stroke="#2b3558" stroke-width="3" stroke-dasharray="6 5"/>'+mvq()+'</svg><div class="sptag">오징어 놀이</div></div>'}
  function startQ(){GX.judgeGame(SQ,{gid:'squid',skin:'gate',icons:['▲','▼'],flip:true,ask:'수문장이 묻습니다. 이 참고문헌은 <b>내 인용 스타일</b> 규칙에 맞을까요?',okL:'맞다 (통과)',badL:'틀렸다 (잡았다)',goodW:'한 칸 전진!',badW:'수문장에게 걸렸어요!',unit:'관문',rounds:8,doneT:'오징어 머리에 도착!',
    top:field,onMove:function(h,p){var s=h.querySelector('.sqf svg');if(s)s.style.setProperty('--p',p)},item:GX.qitem,label:function(ok,en){return '오징어 놀이 '+(en?'무한 · ':'· ')+ok+'관문 통과'}})}
  styleBar(startQ);startQ()}

 // ---- 두더지 잡기 ----
 var MO=$('mol');if(MO){var mtimer=null;
  function startM(){clearInterval(mtimer);var lv=3,score=0,streak=0,caught=0,tick=0,gap=3400,dur=9500,holes=[null,null,null,null],over=false;
   MO.innerHTML='<div class="gbar"><span>점수 <b id="msc">0</b></span><span>연속 <b id="mst">0</b></span><span>목숨 <span id="mlv"></span></span></div><p class="mut">두더지가 천천히 올라와 오래 머뭅니다. 카드를 읽고 틀린 표기(불량)가 든 두더지만 눌러 잡으세요. 맞는 표기는 그냥 두세요. 밑의 막대가 다 줄어들면 내려갑니다. 놓친 불량이나 잘못 잡은 두더지는 목숨이 줄어듭니다.</p><div class="molb">'+holes.map(function(_,i){return '<div class="hole" data-i="'+i+'"><div class="moundb"></div></div>'}).join('')+'</div><div class="gfb" id="mfb" aria-live="polite">시작!</div><div class="gbtns"><button id="mstop">그만하고 마치기</button></div>';
   function hud(){$('msc').textContent=score;$('mst').textContent=streak;$('mlv').innerHTML=GX.lives(lv,3)}hud();
   function fb(h){$('mfb').innerHTML=h}
   function loss(msg){lv--;streak=0;hud();fb(msg);if(lv<=0)finish()}
   function finish(){if(over)return;over=true;clearInterval(mtimer);GX.endGame(MO,'mole',score,'두더지 잡기 · '+caught+'마리',startM)}
   function spawn(){var free=[];holes.forEach(function(h,i){if(!h)free.push(i)});if(!free.length)return;var i=pick(free),it=GX.qitem(),el=MO.querySelector('.hole[data-i="'+i+'"]');
    var m=d.createElement('button');m.className='mole';m.type='button';m.innerHTML='<span class="mbody"></span><span class="mface">'+GX.avatar(GX.CHK[(tick+i)%4])+'</span><span class="mcard">'+GX.spill(it)+it.shown.map(mk).join(' ')+'</span><span class="mtm"><i style="animation-duration:'+(dur/1000)+'s"></i></span>';el.appendChild(m);requestAnimationFrame(function(){m.classList.add('up')});
    var h={it:it,el:m,t:Date.now()+dur};holes[i]=h;
    m.onclick=function(){if(!holes[i]||over)return;holes[i]=null;m.classList.add('hit');setTimeout(function(){m.remove()},300);
     if(it.bad){caught++;streak++;score+=10+Math.min(30,streak*3);hud();fb('<b class="okt">잡았다!</b> '+esc(it.why)+'<div class="jfix">바른 표기: '+it.fix.map(mk).join(' ')+'</div>')}
     else loss('<b class="not">맞는 표기였어요.</b> 목숨이 줄었습니다.')}}
   mtimer=setInterval(function(){if(over)return;tick++;var now=Date.now();holes.forEach(function(h,i){if(h&&now>h.t){holes[i]=null;h.el.classList.remove('up');setTimeout(function(){h.el.remove()},300);if(h.it.bad)loss('<b class="not">불량을 놓쳤어요.</b> '+esc(h.it.why));}});
    if(tick%Math.max(6,Math.round(gap/100))===0){spawn();gap=Math.max(2000,gap-60);dur=Math.max(5600,dur-90)}},100);
   $('mstop').onclick=finish}
  styleBar(startM);startM();window.addEventListener('pagehide',function(){clearInterval(mtimer)})}

 // ---- 카레이싱 ----
 var RC=$('rac');if(RC){var rt=null;
  function startR(){clearTimeout(rt);var lv=3,score=0,km=0,streak=0,lane=0,n=0,over=false,it=null,T=7000;
   RC.innerHTML='<div class="gbar"><span>거리 <b id="rkm">0</b> km</span><span>점수 <b id="rsc">0</b></span><span>목숨 <span id="rlv"></span></span></div><p class="mut">서류 카드가 내려옵니다. 맞는 표기면 <b>왼쪽 차선</b>, 틀린 표기면 <b>오른쪽 차선</b>으로 차를 옮겨 카드가 닿기 전에 자리를 잡으세요. (키보드 ← →)</p><div class="road"><div class="lanes"><i>맞는 표기</i><i>틀린 표기</i></div><div class="rcard" id="rcard"></div><div class="rcar" id="rcar"><svg viewBox="-30 -50 60 100" width="46" height="76"><rect x="-22" y="-45" width="44" height="90" rx="14" fill="#c46a5e" stroke="#2b3558" stroke-width="4"/><rect x="-15" y="-22" width="30" height="22" rx="6" fill="#cfe3ee" stroke="#2b3558" stroke-width="3"/><rect x="-29" y="-32" width="8" height="22" rx="3" fill="#2b3558"/><rect x="21" y="-32" width="8" height="22" rx="3" fill="#2b3558"/><rect x="-29" y="14" width="8" height="22" rx="3" fill="#2b3558"/><rect x="21" y="14" width="8" height="22" rx="3" fill="#2b3558"/></svg></div></div><div class="tbtn"><button class="tb g" id="rl">◀ 맞는 표기</button><button class="tb r" id="rr">틀린 표기 ▶</button></div><div class="gfb" id="rfb" aria-live="polite">출발!</div><div class="gbtns"><button id="rstop">그만하고 마치기</button></div>';
   function hud(){$('rkm').textContent=km;$('rsc').textContent=score;$('rlv').innerHTML=GX.lives(lv,3)}hud();
   function setLane(l){lane=l;$('rcar').style.left=l===0?'25%':'75%'}setLane(0);
   $('rl').onclick=function(){setLane(0)};$('rr').onclick=function(){setLane(1)};
   function key(ev){if(!d.body.contains(RC)){d.removeEventListener('keydown',key);return}if(ev.key==='ArrowLeft'){setLane(0);ev.preventDefault()}else if(ev.key==='ArrowRight'){setLane(1);ev.preventDefault()}}
   d.addEventListener('keydown',key);
   function finish(){if(over)return;over=true;clearTimeout(rt);d.removeEventListener('keydown',key);GX.endGame(RC,'race',score,'카레이싱 · '+km+' km',startR)}
   function next(){if(over)return;it=GX.qitem();var c=$('rcard');c.className='rcard';c.innerHTML=GX.spill(it)+it.shown.map(mk).join(' ');c.style.animation='none';void c.offsetWidth;c.style.left=(Math.random()<.5?'25%':'75%');c.style.left='50%';c.style.animation='rfall '+(T/1000)+'s linear forwards';
    rt=setTimeout(function(){resolve()},T)}
   function resolve(){if(over)return;var want=it.bad?1:0,ok=(lane===want);n++;
    if(ok){km+=2;streak++;score+=10+Math.min(30,streak*2);T=Math.max(3200,T-250);$('rfb').innerHTML='<b class="okt">통과!</b> '+(it.bad?esc(it.why):'규칙에 맞는 표기였습니다.')+(it.bad?'<div class="jfix">바른 표기: '+it.fix.map(mk).join(' ')+'</div>':'')}
    else{lv--;streak=0;$('rcar').classList.add('crash');setTimeout(function(){$('rcar').classList.remove('crash')},600);$('rfb').innerHTML='<b class="not">충돌!</b> '+(it.bad?'틀린 표기였습니다. '+esc(it.why):'규칙에 맞는 표기였습니다.')+(it.bad?'<div class="jfix">바른 표기: '+it.fix.map(mk).join(' ')+'</div>':'')}
    hud();if(lv<=0){rt=setTimeout(finish,900);return}rt=setTimeout(next,1300)}
   $('rstop').onclick=finish;next()}
  styleBar(startR);startR();window.addEventListener('pagehide',function(){clearTimeout(rt)})}

 // ---- 인형 뽑기 ----
 var CL=$('clw');if(CL){var raf=0;
  function startC(){cancelAnimationFrame(raf);var coins=10,score=0,good=0,x=0,dir=1,state='move',cards=[],over=false;
   CL.innerHTML='<div class="gbar"><span>동전 <b id="ccn">10</b></span><span>점수 <b id="csc">0</b></span><span>맞는 표기 <b id="cgd">0</b>개</span></div><p class="mut">움직이는 집게를 <b>맞는 표기</b> 위에서 멈추고 뽑으세요. 불량(틀린 표기)을 뽑으면 점수가 깎입니다. 동전 10개로 한 판입니다.</p><div class="clawm"><div class="clawt"><div class="claw" id="claw"><i></i><svg viewBox="0 0 60 50" width="46" height="38"><path d="M30 0V16M30 16Q8 18 10 44M30 16Q52 18 50 44" stroke="#2b3558" stroke-width="5" fill="none" stroke-linecap="round"/></svg></div></div><div class="prizes" id="prz"></div></div><div class="gbtns"><button class="gprimary" id="cgo">뽑기</button><button id="cstop">그만하고 마치기</button></div><div class="gfb" id="cfb" aria-live="polite"></div>';
   function hud(){$('ccn').textContent=coins;$('csc').textContent=score;$('cgd').textContent=good}
   function deal(){cards=[];var nb=ri(1,2);for(var i=0;i<4;i++){var it=null;for(var t=0;t<30;t++){it=GX.qitem();if(i<nb?it.bad:!it.bad)break}cards.push(it)}
    var bi=0;cards=sh(cards);$('prz').innerHTML=cards.map(function(c,i){return '<div class="prz" data-i="'+i+'"><span>'+GX.spill(c)+c.shown.map(mk).join(' ')+'</span></div>'}).join('');state='move'}
   function loop(){if(over)return;if(state==='move'){x+=dir*0.55;if(x>=100){x=100;dir=-1}if(x<=0){x=0;dir=1}$('claw').style.left=(12.5+x*0.75)+'%'}raf=requestAnimationFrame(loop)}
   function finish(){if(over)return;over=true;cancelAnimationFrame(raf);GX.endGame(CL,'claw',Math.max(0,score),'인형 뽑기 · 맞는 표기 '+good+'개',startC)}
   $('cgo').onclick=function(){if(state!=='move'||over)return;state='drop';var pos=12.5+x*0.75,idx=Math.min(3,Math.max(0,Math.floor((pos/100)*4))),c=cards[idx],cl=$('claw');cl.classList.add('drop');coins--;
    setTimeout(function(){var pz=CL.querySelector('.prz[data-i="'+idx+'"]');if(!c.bad){good++;score+=100;pz.classList.add('got');$('cfb').innerHTML='<b class="okt">뽑았다!</b> 규칙에 맞는 표기였습니다.'}else{score-=50;pz.classList.add('bad');$('cfb').innerHTML='<b class="not">불량품!</b> '+esc(c.why)+'<div class="jfix">바른 표기: '+c.fix.map(mk).join(' ')+'</div>'}
     hud();cl.classList.remove('drop');if(coins<=0){setTimeout(finish,1400);return}setTimeout(deal,1500)},700)};
   $('cstop').onclick=finish;hud();deal();loop()}
  styleBar(startC);startC();window.addEventListener('pagehide',function(){cancelAnimationFrame(raf)})}

 roleInit(GX);litInit(GX);escInit(GX)}

// ---- 문학 인용 ----
var WORKS=[
{a:'이광수',t:'무정',p:'신문관·동양서원',y:1918,g:'소설',n:'1917년 매일신보 연재 후 1918년 첫 단행본'},
{a:'염상섭',t:'만세전',p:'수선사',y:1948,g:'소설',n:'1948년 개작 단행본'},
{a:'최인훈',t:'광장',p:'정향사',y:1961,g:'소설',n:'1960년 『새벽』 발표 후 1961년 단행본'},
{a:'김소월',t:'진달래꽃',p:'매문사',y:1925,g:'시집',n:'초판 시집'},
{a:'윤동주',t:'하늘과 바람과 별과 시',p:'정음사',y:1948,g:'시집',n:'초판 시집(1948)'},
{a:'한강',t:'소년이 온다',p:'창비',y:2014,g:'소설',n:''},
{a:'한강',t:'채식주의자',p:'창비',y:2022,g:'소설',n:'읽은 판본 기준(2022년판)'},
{a:'최은영',t:'쇼코의 미소',p:'문학동네',y:2016,g:'소설집',n:'이 안내서의 국문 단행본 예시'},
{a:'김초엽',t:'우리가 빛의 속도로 갈 수 없다면',p:'허블',y:2019,g:'소설집',n:''},
{a:'박준',t:'우리가 함께 장마를 볼 수도 있겠습니다',p:'문학과지성사',y:2018,g:'시집',n:''}];
function litForm(sid,w){var T='__'+w.t+'__';
 if(sid==='apa')return {ref:w.a+'. ('+w.y+'). '+T+'. '+w.p+'.',inn:'('+w.a+', '+w.y+')'};
 if(sid==='mla')return {ref:w.a+'. '+T+'. '+w.p+', '+w.y+'.',inn:'('+w.a+')'};
 if(sid==='cad')return {ref:w.a+'. '+w.y+'. '+T+'. '+w.p+'.',inn:'('+w.a+' '+w.y+')'};
 return {ref:w.a+'. '+T+'. '+w.p+', '+w.y+'.',inn:'1. '+w.a+', '+T+' ('+w.p+', '+w.y+'), ○○.'}}
function litBads(sid,w,other){var T='__'+w.t+'__',F=litForm;var o=[];
 if(sid==='apa'){o=[[w.a+'. '+w.y+'. '+T+'. '+w.p+'.','APA는 연도를 괄호에 넣습니다.'],[w.a+'. ('+w.y+'). '+w.p+'. '+T+'.','제목과 출판사의 순서가 바뀌었습니다(제목 다음 출판사).'],[w.a+'. '+T+'. '+w.p+', '+w.y+'.','연도가 뒤에 있는 것은 MLA·Chicago Notes-Bibliography 모양입니다.']]}
 else if(sid==='mla'){o=[[w.a+'. ('+w.y+'). '+T+'. '+w.p+'.','연도를 괄호로 앞에 둔 것은 APA 모양입니다.'],[w.a+'. '+T+'. '+w.y+', '+w.p+'.','출판사 다음에 연도를 씁니다.'],[w.a+'. “'+w.t+'.” '+w.p+', '+w.y+'.','단행본 제목은 따옴표가 아니라 기울임으로 씁니다.']]}
 else if(sid==='cad'){o=[[w.a+'. ('+w.y+'). '+T+'. '+w.p+'.','Chicago Author-Date는 연도를 괄호 없이 점으로 씁니다.'],[w.a+'. '+T+'. '+w.p+', '+w.y+'.','연도는 저자 바로 뒤에 옵니다.'],[w.a+'. '+w.y+'. '+w.p+'. '+T+'.','제목과 출판사의 순서가 바뀌었습니다.']]}
 else {o=[[w.a+'. '+w.y+'. '+T+'. '+w.p+'.','Notes-Bibliography 참고문헌에서는 연도를 출판사 뒤에 씁니다.'],[w.a+', '+T+' ('+w.p+', '+w.y+').','이것은 각주 모양입니다. 참고문헌에서는 저자 뒤에 점을 찍고 괄호를 쓰지 않습니다.'],[w.a+'. “'+w.t+'.” '+w.p+', '+w.y+'.','단행본 제목은 따옴표가 아니라 기울임으로 씁니다.']]}
 if(other)o.push([w.a+'. '+(sid==='apa'?'('+w.y+'). ':'')+T+'. '+other.p+(sid==='apa'||sid==='cad'?'.':', '+w.y+'.'),'출판사가 이 작품의 것이 아닙니다. 이 작품은 '+w.p+'에서 나왔습니다.']);
 return o}
function litDoc(GX,w,f,inQ,sid){var esc=GX.esc,mk=GX.mk,oth=GX.sh(WORKS.filter(function(x){return x.p!==w.p})).slice(0,2),ents=[{a:w.a,t:f.ref,slot:true}].concat(oth.map(function(x){return {a:x.a,t:litForm(sid,x).ref}}));
 if(sid!=='nb'||true)ents.sort(function(p,q){return String(p.a).localeCompare(String(q.a),'ko')});
 var sup=sid==='nb'?'<sup>1</sup>':'',body=esc(w.a)+'의 『'+esc(w.t)+'』을 읽고, 이 글은 작품 속 인물이 겪는 변화에 주목한다 ',cite=inQ?'<span class="slot" id="litslot1">❓ 본문 인용</span>':'<span class="slot filled">'+(sid==='nb'?'<sup>1</sup>':mk(f.inn))+'</span>';
 return '<div class="docv lit"><div class="docp"><h5>보고서 본문 <small>(밑줄 친 자리가 인용)</small></h5><p class="docb">'+body+cite+'.</p>'+(sid==='nb'?'<div class="docf"><h5>쪽 아래 각주</h5><p>'+(inQ?'<span class="slot" id="litslot1">❓ 각주</span>':'<span class="slot filled">'+mk(f.inn)+'</span>')+'</p></div>':'')+'</div><div class="docr"><h5>보고서 끝쪽 <b>'+(sid==='mla'?'Works Cited':sid==='nb'?'Bibliography':'References')+'</b> <small>(참고문헌)</small></h5><div class="refl">'+ents.map(function(e){return e.slot?(inQ?'<div class="rl dimr slotref">'+mk(e.t)+'</div>':'<div class="rl slotr" id="litslot2">❓ 참고문헌 칸</div>'):'<div class="rl dimr">'+mk(e.t)+'</div>'}).join('')+'</div></div></div>'}
function litInit(GX){var L=$('lit');if(!L)return;var esc=GX.esc,mk=GX.mk;
 function start(){var sid=GX.myId();if(['apa','mla','cad','nb'].indexOf(sid)<0){sid='apa';GX.ls('mystyle','apa')}
  var order=GX.sh(WORKS),i=0,score=0,streak=0,ok=0,total=10;
  function show(){var w=order[i%order.length],f=litForm(sid,w),inQ=Math.random()<.35,others=WORKS.filter(function(x){return x.p!==w.p}),bd=litBads(sid,w,pick(others)),opts,ans,ask;
   if(inQ){var all=['apa','mla','cad','nb'].filter(function(s){return s!==sid}).map(function(s){return litForm(s,w).inn});opts=GX.sh([f.inn].concat(GX.sh(all).slice(0,2)));ask='이 작품을 <b>본문에서 인용</b>할 때 '+esc(sname(sid))+'에 맞는 표기는? (○○는 읽은 판본에서 확인한 쪽)'}
   else{var bb=GX.sh(bd).slice(0,2);opts=GX.sh([[f.ref,'']].concat(bb));ask='이 작품을 <b>참고문헌 목록</b>에 쓸 때 '+esc(sname(sid))+'에 맞는 표기는?'}
   var correct=inQ?f.inn:f.ref;
   L.innerHTML=GX.modeBar([['x','10문제 한 판']],'x')+'<div class="gbar"><span>문제 <b>'+(i+1)+' / '+total+'</b></span><span>점수 <b>'+score+'</b></span><span>연속 <b>'+streak+'</b></span></div>'
    +'<div class="litc"><div class="litt">'+esc(w.g)+'</div><h3>'+esc(w.a)+' 『'+esc(w.t)+'』</h3><p>출판사 <b>'+esc(w.p)+'</b> · 발행 <b>'+w.y+'년</b>'+(w.n?' <small>('+esc(w.n)+')</small>':'')+'</p></div>'+litDoc(GX,w,f,inQ,sid)+'<p>'+ask+'</p>'
    +'<div class="lito">'+opts.map(function(o,k){var txt=inQ?o:o[0];return '<button class="lopt" data-k="'+k+'">'+mk(txt)+'</button>'}).join('')+'</div><div class="gfb" id="lfb" aria-live="polite"></div>';
   L.querySelectorAll('.lopt').forEach(function(b){b.onclick=function(){var k=+b.dataset.k,txt=inQ?opts[k]:opts[k][0],right=txt===correct;var s1=$('litslot1'),s2=$('litslot2');if(s1){s1.innerHTML=mk(correct);s1.classList.add('filled','hl')}if(s2){s2.innerHTML=mk(correct);s2.classList.add('filled','hl')}L.querySelectorAll('.lopt').forEach(function(x,j){x.disabled=true;var t2=inQ?opts[j]:opts[j][0];if(t2===correct)x.classList.add('good')});if(!right)b.classList.add('bad');
     if(right){ok++;streak++;score+=10+Math.min(30,streak*2)}else streak=0;
     var why=right?'정답입니다.':(inQ?'다른 양식의 본문 인용 모양입니다.':esc(opts[k][1]));
     $('lfb').innerHTML=(right?'<b class="okt">정답!</b> ':'<b class="not">아쉬워요.</b> ')+why+' <button class="gprimary" id="lnx">'+(i+1>=total?'결과 보기':'다음 →')+'</button>';
     $('lnx').onclick=function(){i++;if(i>=total){L.innerHTML='';GX.win(L,ok>=9?3:ok>=6?2:1,'연습 끝!',total+'문제 중 '+ok+'개를 맞혔습니다.','한 판 더',start,'lit',score,'문학 인용 · '+sname(sid)+' · '+ok+'/'+total)}else show()}}})}
  show()}
 var m=$('mys');if(m)GX.picker(m,function(){var s=GX.myId();if(['apa','mla','cad','nb'].indexOf(s)<0)GX.ls('mystyle','apa');start()});start()}

// ---- 롤플레잉 ----
var RP=[
{id:'conf',n:'학회 발표',role:'학회 구두 발표자',intro:'오전 세션, 50명 앞에서 12분 발표를 합니다. 첫 슬라이드가 켜졌습니다.',sc:[
 {t:'발표를 시작하며 선행연구를 소개합니다. 어떻게 말할까요?',c:[['“이 분야에서는 이미 다 밝혀진 사실입니다.”',0,'누가 밝혔는지 알 수 없어 청중이 확인할 수 없습니다.'],['“2022년 Rivera와 Han의 연구에 따르면 …입니다.”',2,'저자와 연도를 말로 밝히면 청중이 슬라이드의 출처와 이어서 확인할 수 있습니다.'],['“어디서 읽었는지는 기억이 안 나지만 …입니다.”',0,'출처를 모르는 주장은 발표에 쓰지 않거나 먼저 출처를 찾아야 합니다.']]},
 {t:'engine'},
 {t:'질의응답에서 “그 수치는 어디서 나왔나요?”라는 질문을 받았습니다.',c:[['“발표 자료 마지막 쪽의 참고문헌에 있습니다. 해당 쪽을 보여 드리겠습니다.”',2,'질문에 바로 근거를 보여 줄 수 있어야 합니다.'],['“인터넷에서 봤습니다.”',0,'어느 사이트인지, 누가 낸 자료인지 모르면 신뢰를 얻기 어렵습니다.'],['“그건 제가 직접 조사한 것처럼 보시면 됩니다.”',0,'남의 수치를 내 조사처럼 말하면 안 됩니다.']]},
 {t:'발표 자료에 AI가 만든 요약 문장이 섞여 있습니다. 어떻게 할까요?',c:[['발표 자료에 AI를 쓴 사실과 용도를 밝히고, 내용은 원문과 대조했다고 말한다.',2,'과목·학회 지침에 맞게 활용 사실을 밝히고 확인한 것이 바른 방식입니다.'],['아무 말도 하지 않는다.',0,'지침이 요구하면 밝혀야 하며, 확인하지 않은 내용은 오류가 될 수 있습니다.'],['AI가 쓴 문장은 인용 부호 없이 내 문장처럼 말한다.',0,'AI 산출물도 활용 사실을 밝히고 내용을 책임져야 합니다.']]}]},
{id:'disc',n:'토론자',role:'학회 토론자',intro:'다른 연구자의 발표를 듣고 5분 동안 토론을 맡았습니다.',sc:[
 {t:'발표자의 주장에 반박하고 싶습니다. 근거를 어떻게 소개할까요?',c:[['“제 생각에는 틀렸습니다.”',0,'의견만 있고 근거가 없으면 토론이 되지 않습니다.'],['“○○ 연구(저자, 연도)는 다른 결과를 보고했습니다. 비교해 보면 …”',2,'반론도 출처를 밝힌 근거로 해야 합니다.'],['“다들 그렇게 말하던데요.”',0,'누구의 말인지 알 수 없는 근거는 검증할 수 없습니다.']]},
 {t:'engine'},
 {t:'발표자가 “그 연구는 제 글에도 인용했습니다”라고 말했습니다. 사실을 확인하고 싶습니다.',c:[['발표 논문의 참고문헌 목록에서 해당 서지를 찾아 본다.',2,'참고문헌 목록은 인용 여부를 확인하는 가장 확실한 곳입니다.'],['그냥 믿는다.',1,'믿을 수는 있지만 토론자는 근거를 확인할 책임이 있습니다.'],['청중에게 “아마 안 썼을 것”이라고 말한다.',0,'확인하지 않은 단정은 하지 않습니다.']]},
 {t:'토론을 마무리하며 자료를 청중에게 공유하려 합니다.',c:[['내가 쓴 자료와 인용한 글의 출처를 함께 정리해 공유한다.',2,'공유 자료에도 출처가 따라가야 합니다.'],['발표자의 슬라이드를 허락 없이 그대로 올린다.',0,'타인의 자료를 배포할 때는 허락과 출처가 필요합니다.'],['출처 없이 요약만 공유한다.',1,'요약이라도 어디서 왔는지 밝혀야 다시 확인할 수 있습니다.']]}]},
{id:'panel',n:'패널',role:'패널 토의 참석자',intro:'세 명이 나란히 앉은 패널 토의입니다. 사회자가 첫 질문을 건넸습니다.',sc:[
 {t:'다른 패널이 이미 낸 의견과 비슷한 생각이 떠올랐습니다.',c:[['“앞서 ○○ 패널이 말씀하셨듯이 …에 더해 …”',2,'다른 사람의 생각을 먼저 인정하고 내 기여를 덧붙입니다.'],['못 들은 척하며 내 아이디어처럼 말한다.',0,'남의 아이디어를 내 것처럼 말하면 안 됩니다.'],['아무 말도 하지 않는다.',1,'안전하지만 토론에 기여하지 못합니다.']]},
 {t:'engine'},
 {t:'숫자를 말했는데 청중이 “출처가 뭔가요?”라고 합니다.',c:[['“○○기관의 20XX년 통계입니다. 정확한 표는 나중에 공유하겠습니다.”',2,'기관·연도를 밝히고 자료를 약속합니다.'],['“정확하진 않지만 대략 그렇습니다.”',0,'불확실한 수치는 출처가 있을 때만 말합니다.'],['“언론에서 봤습니다.”',1,'어느 언론의 어떤 기사인지 밝혀야 확인할 수 있습니다.']]},
 {t:'토의 후 자료 정리 담당이 됐습니다.',c:[['발언에 나온 문헌을 정리해 참고문헌 목록으로 만든다.',2,'나온 문헌을 빠짐없이 정리하면 누구든 찾을 수 있습니다.'],['기억나는 대로 대충 적는다.',0,'틀린 서지는 찾을 수 없게 만듭니다.'],['아예 정리하지 않는다.',0,'다음 사람이 근거를 확인할 수 없습니다.']]}]},
{id:'lect',n:'강연자',role:'강단에 선 강연자',intro:'100석 강의실의 강단에 섰습니다. 마이크 테스트가 끝났습니다.',sc:[
 {t:'강연에서 교과서 그림을 쓰려 합니다.',c:[['그림 옆에 출처와 사용 조건을 적는다.',2,'이미지도 만든 이와 출처를 밝히고 사용 조건을 확인합니다.'],['인터넷에서 검색한 그림을 그대로 붙인다.',0,'출처와 사용 조건을 모르면 쓰지 않는 것이 안전합니다.'],['그림을 흐리게 만들어 출처를 숨긴다.',0,'출처를 숨기는 것은 오히려 문제입니다.']]},
 {t:'engine'},
 {t:'청중이 “발표 자료를 받을 수 있나요?”라고 묻습니다.',c:[['참고문헌까지 넣은 파일을 공유한다. 허락받지 않은 자료는 뺀다.',2,'출처와 사용 조건을 지켜 공유합니다.'],['슬라이드 속 남의 그림과 표를 그대로 모두 배포한다.',0,'허락이 없으면 배포하지 않습니다.'],['공유하지 않겠다고 말한다.',1,'가능하지만 공유가 가능한 부분은 나눌 수 있습니다.']]},
 {t:'앞 강연에서 쓴 내 슬라이드를 재활용했습니다.',c:[['“이 부분은 지난 강연에서도 소개했습니다.”라고 밝힌다.',2,'내 이전 자료의 재사용도 밝히는 것이 바릅니다.'],['아무 말도 하지 않는다.',1,'강연에서는 흔하지만 학술 맥락에서는 밝히는 편이 좋습니다.'],['새로운 연구라고 소개한다.',0,'이미 한 내용을 새 연구로 소개하면 안 됩니다.']]}]},
{id:'court',n:'법정',role:'변론 요지서를 낭독하는 사람',intro:'법정에서 변론 요지서를 읽을 차례입니다. 재판장이 고개를 끄덕입니다.',sc:[
 {t:'판례를 언급합니다. 어떻게 말할까요?',c:[['“대법원 20XX. X. X. 선고 20XX다XXXX 판결에 따르면 …”',2,'법원·선고일·사건번호를 밝히면 상대와 재판부가 확인할 수 있습니다(법률문헌 표기는 부록 9 참고).'],['“예전에 비슷한 판결이 있었습니다.”',0,'어느 판결인지 밝히지 않으면 확인할 수 없습니다.'],['“유명한 판결이 있습니다.”',0,'유명하다는 말은 근거가 아닙니다.']]},
 {t:'engine'},
 {t:'외국 문헌을 번역해 증거로 제출하려 합니다.',c:[['원문 출처와 번역한 사람, 번역임을 함께 밝힌다.',2,'번역 인용은 원문 출처와 번역 사실을 밝힙니다.'],['번역자 표시 없이 내 문장처럼 쓴다.',0,'번역도 출처를 밝혀야 합니다.'],['원문 없이 번역문만 낸다.',1,'원문이 없으면 번역을 확인할 수 없습니다.']]},
 {t:'상대 변호인이 “그 법령은 이미 개정됐다”고 지적했습니다.',c:[['시행일과 개정 여부를 다시 확인하고 정확한 조문을 제시한다.',2,'법령은 개정되므로 기준일을 확인해야 합니다.'],['개정 여부와 상관없이 그대로 간다.',0,'현재 유효한 조문인지 확인해야 합니다.'],['“모르겠다”고 하고 넘어간다.',0,'확인하지 않고 넘어가면 신뢰를 잃습니다.']]}]},
{id:'un',n:'유엔 연설',role:'유엔 총회 대표 연설자',intro:'각국 대표 앞에서 5분 연설을 합니다. 통역 헤드폰이 켜졌습니다.',sc:[
 {t:'기후 통계를 연설에 넣으려 합니다.',c:[['“○○기구의 20XX년 보고서에 따르면 …”',2,'기관·연도를 밝히면 통역과 청중이 같은 자료를 찾을 수 있습니다.'],['“전 세계가 알고 있듯이 …”',0,'수치는 “다 안다”로 끝낼 수 없습니다.'],['출처 없이 숫자만 말한다.',0,'숫자는 출처가 있어야 힘이 있습니다.']]},
 {t:'engine'},
 {t:'다른 나라 대표의 말을 인용하려 합니다.',c:[['“○○ 대표께서 △△ 회의에서 …라고 말씀하셨습니다.” 발언 자리를 밝힌다.',2,'누가 언제 어디서 말했는지 밝힙니다.'],['정확하지 않은 기억으로 따옴표를 붙인다.',0,'확인하지 않은 말에 따옴표를 붙이면 안 됩니다.'],['이름 없이 “어떤 나라 대표가”라고 한다.',1,'가능하지만 누구의 말인지 불분명합니다.']]},
 {t:'연설문을 공식 기록으로 제출합니다.',c:[['연설문에 쓴 보고서와 통계의 서지를 정리해 첨부한다.',2,'기록에 출처가 남아야 후속 논의에서 확인할 수 있습니다.'],['초안 그대로 제출한다.',0,'확인하지 않은 초안은 오류가 있을 수 있습니다.'],['출처를 지우고 제출한다.',0,'출처를 지우면 검증이 불가능합니다.']]}]},
{id:'interview',n:'면접',role:'대학원 입학 면접 지원자',intro:'면접실 문을 열었습니다. 교수 세 분이 연구계획서를 펴 놓고 있습니다.',sc:[
 {t:'“연구계획서에서 가장 영향받은 논문이 무엇인가요?”',c:[['논문 저자와 제목, 연도를 정확히 말하고 어떤 점이 영향을 줬는지 설명한다.',2,'영향받은 문헌을 정확히 말할 수 있어야 합니다.'],['“많이 읽었는데 기억나는 건 없습니다.”',0,'읽은 문헌을 모르면 계획서의 근거가 약해 보입니다.'],['읽지 않은 유명한 논문을 말한다.',0,'읽지 않은 것을 읽은 것처럼 말하지 않습니다.']]},
 {t:'engine'},
 {t:'“계획서 작성에 생성형 AI를 쓰셨나요?”',c:[['쓴 부분과 용도, 내용을 직접 확인한 과정을 솔직하게 설명한다.',2,'활용 사실과 확인 과정을 밝히면 신뢰를 얻습니다.'],['“전혀 안 썼습니다.” (실제로는 썼다)',0,'거짓은 가장 위험합니다.'],['대답을 피한다.',1,'피하면 오히려 의심을 부릅니다.']]},
 {t:'“지도 교수님의 논문을 읽어 봤나요?”',c:[['읽은 논문의 제목과 핵심을 말하고 내 연구와 어떻게 이어지는지 설명한다.',2,'정확한 서지와 이해를 보여 줍니다.'],['“유명하시니까요.”',0,'읽은 근거가 없습니다.'],['“아직 안 읽었지만 읽겠습니다.”',1,'솔직하지만 준비가 부족해 보입니다.']]}]},
{id:'company',n:'회사 안',role:'신입 사원',intro:'월요일 회의 시간입니다. 팀장이 시장 현황 보고서를 부탁했습니다.',sc:[
 {t:'보고서에 쓸 시장 규모 수치를 찾았습니다.',c:[['조사기관 이름과 발표 연도를 보고서 각주에 적는다.',2,'회사에서도 수치의 출처와 기준 시점을 밝혀야 합니다.'],['출처 없이 숫자만 적는다.',0,'수치의 출처를 알 수 없으면 판단에 쓸 수 없습니다.'],['블로그에 있는 수치를 확인 없이 쓴다.',0,'원자료를 찾아 확인해야 합니다.']]},
 {t:'engine'},
 {t:'지난 분기의 사내 보고서 문단을 새 보고서에 가져다 쓰려 합니다.',c:[['쓴 사람과 문서 이름을 밝히고 가져온 부분을 표시한다.',2,'사내 문서도 출처를 밝힙니다.'],['말없이 복사해 붙인다.',0,'남이 쓴 문단을 말없이 가져오면 안 됩니다.'],['문장만 바꿔서 쓴다.',1,'바꿔 써도 출처는 밝혀야 합니다.']]},
 {t:'발표 자료에 유료 이미지 사이트의 사진을 쓰려 합니다.',c:[['라이선스를 확인하고 사용 범위와 출처를 표기한다.',2,'이미지는 라이선스를 지켜 씁니다.'],['저작권을 신경 쓰지 않고 쓴다.',0,'라이선스 위반이 될 수 있습니다.'],['워터마크만 가린다.',0,'워터마크를 가리는 것은 해결이 아닙니다.']]}]}];

// ---- 메타버스 광장 (롤플레잉 위쪽) ----
function metaverse(GX,host,sceneName){
 var esc=GX.esc,prof=GX.prof&&GX.prof(),me=(prof&&prof.id)||'손님'+ri(100,999);
 function hash(s){var h=0;for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;return h}
 var CL=['#c46a5e','#3a5fb0','#7fa79c','#d6b36a','#8272b5','#cf7f88','#6fa89c'],EAR=['round','point','long','none'];
 function mini(id,c,sz){var h=hash(String(id)),col=c||CL[h%CL.length],ear=EAR[(h>>3)%4],acc=(h>>5)%4,w=sz||46;
  var e=ear==='round'?'<circle cx="14" cy="14" r="7" fill="'+col+'"/><circle cx="38" cy="14" r="7" fill="'+col+'"/>':ear==='point'?'<path d="M9 22L13 6L22 16ZM43 22L39 6L30 16Z" fill="'+col+'"/>':ear==='long'?'<ellipse cx="17" cy="9" rx="5" ry="10" fill="'+col+'"/><ellipse cx="35" cy="9" rx="5" ry="10" fill="'+col+'"/>':'';
  var a=acc===0?'<path d="M14 16Q26 4 38 16" stroke="#2b3558" stroke-width="3" fill="none"/>':acc===1?'<rect x="18" y="38" width="16" height="6" rx="3" fill="#fff" opacity=".9"/>':acc===2?'<circle cx="26" cy="47" r="4" fill="#d6b36a"/>':'';
  return '<svg class="mmv" viewBox="0 0 52 56" width="'+w+'" height="'+Math.round(w*1.08)+'" aria-hidden="true">'+e+'<ellipse cx="26" cy="32" rx="17" ry="15" fill="'+col+'"/><circle cx="20" cy="30" r="2.4" fill="#2b3558"/><circle cx="32" cy="30" r="2.4" fill="#2b3558"/><path d="M22 37Q26 41 30 37" stroke="#2b3558" stroke-width="2" fill="none" stroke-linecap="round"/><circle cx="16" cy="35" r="2.5" fill="#fff" opacity=".35"/><circle cx="36" cy="35" r="2.5" fill="#fff" opacity=".35"/>'+a+'</svg>'}
 var FL=[['아파핑','APA','#3a5fb0','APA'],['엠엘라떼','MLA','#8272b5','MLA'],['시카고르곤','Chicago Author-Date','#6fa89c','Chicago A-D'],['시카고구마','Chicago Notes-Bibliography','#cfa04e','Chicago N-B'],['아이트리플이잉','IEEE','#8a93a0','IEEE'],['밴쿠버거','Vancouver','#cf7f88','Vancouver'],['애씨드래곤','ACS','#a8764f','ACS']];
 var NPC=FL.map(function(f){return [f[0],f[1]+' 담당 · 연습 친구']});
 var npcLines={'아파핑':['APA는 저자 바로 뒤에 괄호로 연도를 써요. 본문 인용은 (저자, 연도, p. 쪽)이에요.','APA 참고문헌은 “성, 이니셜.” 순서이고 영문 제목은 첫 단어만 대문자로 써요.'],'엠엘라떼':['MLA는 본문 인용에 저자와 쪽수만 써요. 예: (김서연 15)','MLA 목록의 이름은 Works Cited이고, 연도는 출판사 뒤에 와요.'],'시카고르곤':['Chicago Author-Date는 본문에 (저자 연도, 쪽)처럼 쉼표 없이 써요. 예: (김서연 2021, 15)','Chicago 계열은 참고문헌에서 첫 저자만 “성, 이름”으로 뒤집어요.'],'시카고구마':['Chicago Notes-Bibliography는 각주로 인용하고 끝에 Bibliography를 둬요.','각주 번호는 문장 끝 마침표 뒤에 위 첨자로, 내용은 같은 쪽 아래에 써요.'],'아이트리플이잉':['IEEE는 본문에 [1] 같은 번호를 쓰고, 이름은 이니셜을 먼저 써요. 예: S. Han','번호는 인용한 차례대로 붙이고, 목록도 그 번호 순서예요.'],'밴쿠버거':['Vancouver는 번호로 인용하고, 저자는 성 다음에 이니셜을 마침표 없이 써요. 예: Kwon HY','Vancouver 목록은 “번호. 성 이니셜. 제목. 학술지약어. 연;권(호):쪽.” 순서예요.'],'애씨드래곤':['ACS는 저자 사이에 세미콜론을 쓰고, 연도는 굵게, 권은 기울여요.','ACS 번호식 인용은 보고서 안에서 한 가지 모양으로 통일해요.']};
 var TIPS=['본문 문단은 양쪽 정렬이 일반적이에요. 줄 끝이 들쭉날쭉하면 다시 확인!','문단 첫 줄만 글자 한 개 폭(본문 10pt이면 10pt) 들여써요. 스페이스로 밀지 마세요.','참고문헌은 둘째 줄부터 0.5인치 내어쓰기! 스페이스나 Enter로 밀면 모양이 깨져요.','각주는 첫 줄만 들여쓰고, 번호는 같은 쪽 아래 각주와 짝이 맞아야 해요.','본문은 10pt, 줄 간격은 한글 160%예요. 워드는 고정 16pt가 비슷해요.','표지와 목차에는 쪽 번호를 넣지 않고, 본문 첫 쪽을 1쪽으로 세요.','참고문헌은 새 쪽에서 시작해요.','과제는 쓰기 시작한 날 웹하드(클라우드 저장소)에 올려 두세요!','웹하드 동기화가 되는지 꼭 확인! 마감 24시간 전에 최종본을 올리고 다른 기기에서 열어 보세요.','컴퓨터 고장, USB 분실, 마감 직전 파일 손상은 해마다 되풀이돼요. 백업해 두세요!','파일 이름에 버전을 붙여 구분해 두세요. 최종본이 여러 개면 헷갈려요.','용지 A4, 여백 상하좌우 25mm가 이 안내서의 기본값이에요. 학과 지침이 있으면 그것이 먼저예요.','제목·표지는 가운데나 왼쪽, 표 안의 글과 긴 URL은 왼쪽 정렬이 읽기 좋아요.','AI가 알려 준 출처는 직접 열어 확인해요. 없는 출처를 만들어 낼 때도 있어요.','출처를 못 찾겠을 땐 RISS, KCI, 구글 스콜라에서 제목이나 저자로 검색해 보세요.','본문 인용과 참고문헌 목록은 서로 짝이 맞아야 해요.','학과·수업의 지침이 있으면 그 양식이 우선이에요.'];
 FL.forEach(function(f){npcLines[f[0]]=npcLines[f[0]].concat(TIPS)});
 var box=d.createElement('section');box.className='meta';box.setAttribute('aria-label','메타버스 광장');
 box.innerHTML='<div class="mt-top"><div class="mt-me"><span class="mt-av">'+mini(me,null,52)+'</span><div><b>'+esc(me)+'</b><small>내 미니미 · 내 아이디</small></div></div><div class="mt-room"><b>인용 광장</b> · <span id="mtwhere">'+esc(sceneName||'로비')+'</span><small id="mtst">접속자를 확인하는 중…</small></div></div>'
  +'<div class="mt-rule" role="note"><b>꼭 지켜 주세요</b> 상대를 존중하는 말을 씁니다. 비하·욕설·조롱·개인정보(이름·학번·연락처) 공유는 하지 않습니다. 욕설은 자동으로 걸러지지만, 걸러지지 않는 표현도 쓰지 않는 것이 약속입니다. 채팅 내용은 저장되지 않으며 화면을 닫으면 사라집니다.</div>'
  +'<div class="mt-stage" id="mtstage"></div><div class="mt-chat"><div class="mt-log" id="mtlog" aria-live="polite"></div><form class="mt-form" id="mtf"><input id="mti" maxlength="120" autocomplete="off" placeholder="인사를 건네 보세요 (존중하는 말로)"><button class="gprimary">보내기</button></form></div>';
 host.parentNode.insertBefore(box,host);
 var stage=$('mtstage'),log=$('mtlog'),peersNow=[],lastSend=0,roomObj=null,npcOn=true,tm=null;
 function say(who,txt,cls){var p=d.createElement('p');p.className='mt-m '+(cls||'');p.innerHTML='<b>'+esc(who)+'</b> '+esc(txt);log.appendChild(p);while(log.children.length>60)log.removeChild(log.firstChild);log.scrollTop=log.scrollHeight}
 var pos={},raf=0,lastT=0,bub=null,bubT=0,reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 function sz(){var r=stage.getBoundingClientRect();return {w:Math.max(220,r.width),h:stage.clientHeight||300}}
 function pick(arr){return arr[Math.floor(Math.random()*arr.length)]}
 function lineFor(id){var L=npcLines[id];if(!L)return '안녕! 같이 출처 밝히는 법을 익혀 봐요.';return pick(L)}
 function showBub(id,txt){var p=pos[id];if(!p)return;if(bub&&bub.el)bub.el.remove();var e=d.createElement('span');e.className='mt-bub';e.textContent=txt;p.el.appendChild(e);p.el.classList.add('hop');setTimeout(function(){p.el.classList.remove('hop')},500);bub={id:id,el:e};clearTimeout(bubT);bubT=setTimeout(function(){if(bub&&bub.el)bub.el.remove();bub=null},Math.min(9000,3500+txt.length*60))}
 var clickN=0;
 function draw(){var all=[{id:me,me:1}];peersNow.forEach(function(p){all.push({id:p.id})});if(npcOn)FL.forEach(function(f){all.push({id:f[0],npc:1,col:f[2],sty:f[3]})});
  var S=sz(),keep={};
  stage.className='mt-stage fl';
  all.forEach(function(a,i){keep[a.id]=1;if(pos[a.id]&&pos[a.id].el.isConnected)return;
   var sp=a.npc?70+Math.random()*90:45+Math.random()*40,an=Math.random()*6.28,b=d.createElement('button');b.type='button';b.className='mt-p fl'+(a.me?' me':'');b.setAttribute('aria-label',(a.npc?a.id+' ('+a.sty+') 눌러서 말 걸기':a.id));
   b.innerHTML=(a.me?'<i class="mt-tag">나</i>':a.npc?'<i class="mt-tag npc">'+esc(a.sty)+'</i>':'')+mini(a.id,a.col||null,a.npc?54:48)+'<span class="mt-nm">'+esc(a.id)+'</span>';
   stage.appendChild(b);var o={el:b,sv:b.querySelector('svg'),x:Math.random()*(S.w-70),y:30+Math.random()*(S.h-100),vx:Math.cos(an)*sp,vy:Math.sin(an)*sp,ph:Math.random()*6.28,id:a.id,npc:a.npc,me:a.me,tag:a.sty};pos[a.id]=o;
   b.onclick=function(){var t=a.npc?lineFor(a.id):a.me?'나는 '+me+'! 오늘도 출처 잘 밝혀 볼까?':'안녕하세요! 같이 연습해요.';showBub(a.id,t);if(a.npc){say(a.id,t,'npc')}};});
  Object.keys(pos).forEach(function(k){if(!keep[k]){pos[k].el.remove();delete pos[k]}});
  $('mtst').textContent=peersNow.length?('지금 함께 있는 학생 '+peersNow.length+'명'):'지금은 혼자예요. 둥둥 떠다니는 친구들을 눌러 보세요.';
  if(!raf)raf=requestAnimationFrame(frame)}
 function frame(ts){raf=requestAnimationFrame(frame);var dt=Math.min(.05,(ts-(lastT||ts))/1000);lastT=ts;if(!stage.isConnected)return;var S=sz(),k=reduce?.2:1;
  Object.keys(pos).forEach(function(id){var o=pos[id];o.ph+=dt*3;
   if(Math.random()<dt*.35){var a=Math.random()*6.28,sp=(o.npc?60+Math.random()*120:40+Math.random()*50);o.vx=Math.cos(a)*sp;o.vy=Math.sin(a)*sp}
   o.x+=o.vx*dt*k;o.y+=o.vy*dt*k;var W=S.w-60,H=S.h-92;
   if(o.x<0){o.x=0;o.vx=Math.abs(o.vx)}else if(o.x>W){o.x=W;o.vx=-Math.abs(o.vx)}
   if(o.y<18){o.y=18;o.vy=Math.abs(o.vy)}else if(o.y>H){o.y=H;o.vy=-Math.abs(o.vy)}
   var by=Math.sin(o.ph)*6,rot=Math.sin(o.ph*.7)*7;o.el.style.transform='translate('+o.x.toFixed(1)+'px,'+(o.y+by).toFixed(1)+'px)';if(o.sv)o.sv.style.transform='rotate('+rot.toFixed(1)+'deg)';
   if(bub&&bub.id===id){var left=Math.max(-o.x+4,Math.min(S.w-196-o.x,-60));bub.el.style.left=left.toFixed(0)+'px';bub.el.classList.toggle('below',o.y<92)}})}
 draw();
 function npcTalk(){if(!npcOn||!stage.isConnected)return;var f=pick(FL),t=Math.random()<.65?pick(TIPS):lineFor(f[0]);showBub(f[0],t);if(Math.random()<.3)say(f[0],t,'npc');tm=setTimeout(npcTalk,ri(3200,5200))}
 say('안내','광장에 오신 걸 환영해요. 둥둥 떠다니는 친구들을 눌러 보면 말해 줘요. 아래 이야기에서는 출처를 어떻게 밝힐지 고르며 진행됩니다.','sys');tm=setTimeout(npcTalk,1500);
 $('mtf').onsubmit=function(e){e.preventDefault();var inp=$('mti'),t=inp.value.trim();if(!t)return;
  if(window.PF&&PF.bad(t)){say('안내','존중하지 않는 표현이 있어 보내지 않았습니다. 다른 말로 써 주세요.','sys');return}
  if(Date.now()-lastSend<1500){say('안내','조금 천천히 보내 주세요.','sys');return}lastSend=Date.now();inp.value='';say(me,t,'me');
  if(roomObj){try{roomObj.emit('chat',{n:me,t:t.slice(0,120)}).catch(function(){})}catch(er){}}
  else{var KW=[[/못 ?찾|찾을 수|검색|어디서/,['아파핑','출처를 못 찾겠으면 RISS, KCI, 구글 스콜라에서 제목이나 저자로 검색해 보세요. 그래도 확인이 안 되면 “확인하지 못함”으로 두세요.']],[/AI|인공지능|챗/i,['엠엘라떼','AI가 알려 준 출처는 꼭 직접 열어 확인해야 해요. 없는 출처를 만들어 낼 때도 있거든요.']],[/따옴표|복붙|복사|베끼|표절/,['아파핑','그대로 가져온 문장은 따옴표와 출처를 함께 쓰고, 바꿔 쓸 때도 출처는 밝혀야 해요.']],[/출처|인용|참고문헌|각주/,['아파핑','본문 인용과 참고문헌 목록이 서로 짝이 맞는지 확인해 보세요.']],[/발표|슬라이드/,['엠엘라떼','발표 슬라이드에도 출처를 작게 넣고, 말로도 한 번 밝혀 주면 좋아요.']],[/토론|반박|근거/,['시카고르곤','근거를 말할 때는 출처를 함께 말하면 훨씬 믿음이 가요.']]],hit=null;KW.forEach(function(k){if(!hit&&k[0].test(t))hit=k[1]});var n=hit||['아파핑','(연습 친구는 정해 둔 팁만 알려 줘요.) 아래 이야기에서 출처 밝히는 방법을 같이 골라 봐요.'];setTimeout(function(){say(n[0],n[1],'npc')},ri(900,1600))}};
 // 실시간 접속자 (room 능력이 열려 있을 때만)
 (async function(){try{if(!window.claude||!window.claude.use)return;var rm=await window.claude.use('room');if(!rm||!rm.join)return;roomObj=await rm.join('citation-plaza');if(!roomObj)return;
   await roomObj.presence({n:me,s:sceneName||'로비'});
   roomObj.onPeers(function(ch){peersNow=(ch.peers||[]).filter(function(p){return !p.isMe&&p.kind==='viewer'&&p.presence&&typeof p.presence.n==='string'}).map(function(p){var nn=String(p.presence.n).slice(0,12);return {id:(window.PF&&PF.bad(nn))?'익명':nn}});npcOn=peersNow.length<2;draw()});
   roomObj.on('chat',function(m){if(m.isMe)return;var dd=m.data||{};if(typeof dd.t!=='string')return;var t=dd.t.slice(0,120),n=String(dd.n||'익명').slice(0,12);if(window.PF&&(PF.bad(t)||PF.bad(n)))return;say(n,t,'peer')})}catch(er){}})();
 return {where:function(t){var e=$('mtwhere');if(e)e.textContent=t},stop:function(){clearTimeout(tm);clearTimeout(bubT);cancelAnimationFrame(raf);raf=0;npcOn=false}}}
function roleInit(GX){var R=$('rpg');if(!R)return;var esc=GX.esc,mk=GX.mk;
 function menu(){R.innerHTML='<p class="mut">장면을 고르면 그 자리에 선 사람이 되어 말하고 행동하는 이야기가 시작됩니다. 각 장면에서 고른 선택에 따라 <b>신뢰도</b>가 오르내립니다.</p><div class="rpm">'+RP.map(function(s,i){return '<button class="rpb" data-i="'+i+'"><b>'+esc(s.n)+'</b><span>'+esc(s.role)+'</span></button>'}).join('')+'</div>';
  R.querySelectorAll('.rpb').forEach(function(b){b.onclick=function(){play(RP[+b.dataset.i])}})}
 function play(S){var i=0,trust=50,log=[];try{MV.where(S.n+' · '+S.role)}catch(e){}
  function meter(){return '<div class="trust" aria-label="신뢰도 '+trust+'"><span>신뢰도</span><i style="--w:'+trust+'%"></i><b>'+trust+'</b></div>'}
  function stage(){return '<div class="rpstage"><img src="img/art-role.svg" alt="" class="rpimg"><div><h3>'+esc(S.n)+' · '+esc(S.role)+'</h3><p>'+esc(S.intro)+'</p></div></div>'}
  function scene(){if(i>=S.sc.length)return end();var sc=S.sc[i],head=stage()+meter()+'<div class="gbar"><span>장면 <b>'+(i+1)+' / '+S.sc.length+'</b></span><span>양식 <b>'+esc(sname(GX.myId()))+'</b></span></div>';
   if(sc.t==='engine'){var q=iq(GX),opts=[q.fix[0]],pool=[];for(var k=0;k<8&&pool.length<2;k++){var q2=iq(GX);if(q2.bad&&q2.shown[0]!==q.fix[0]&&pool.indexOf(q2.shown[0])<0)pool.push(q2.shown[0])}
    opts=GX.sh(opts.concat(pool.slice(0,2)));var why={};
    R.innerHTML=head+'<div class="rpq"><p>슬라이드(또는 자료) 속 문장 끝에 인용 표기를 달아야 합니다. 저자는 <b>'+esc(q.ctx.A+' · '+q.ctx.B)+'</b>, 연도 <b>'+q.ctx.y+'</b>입니다. 내 양식 <b>'+esc(sname(GX.myId()))+'</b>에 맞는 표기는?</p><div class="lito">'+opts.map(function(o,k2){return '<button class="lopt" data-k="'+k2+'">'+mk(o)+'</button>'}).join('')+'</div></div><div class="gfb" id="rfb2"></div>';
    R.querySelectorAll('.lopt').forEach(function(b){b.onclick=function(){var ok=opts[+b.dataset.k]===q.fix[0];R.querySelectorAll('.lopt').forEach(function(x){x.disabled=true;if(opts[+x.dataset.k]===q.fix[0])x.classList.add('good')});if(!ok)b.classList.add('bad');trust=Math.max(0,Math.min(100,trust+(ok?15:-15)));log.push(ok);
     $('rfb2').innerHTML=(ok?'<b class="okt">정확합니다.</b> 청중이 슬라이드의 출처를 믿고 따라갑니다.':'<b class="not">표기가 어긋났어요.</b> 바른 모양: '+mk(q.fix[0]))+' <button class="gprimary" id="rnx">다음 장면 →</button>';$('rnx').onclick=function(){i++;scene()}}});return}
   R.innerHTML=head+'<div class="rpq"><p>'+esc(sc.t)+'</p><div class="lito">'+sc.c.map(function(c,k){return '<button class="lopt" data-k="'+k+'">'+esc(c[0])+'</button>'}).join('')+'</div></div><div class="gfb" id="rfb2"></div>';
   R.querySelectorAll('.lopt').forEach(function(b){b.onclick=function(){var c=sc.c[+b.dataset.k];R.querySelectorAll('.lopt').forEach(function(x){x.disabled=true;if(sc.c[+x.dataset.k][1]===2)x.classList.add('good')});if(c[1]<2)b.classList.add(c[1]===0?'bad':'mid');
     trust=Math.max(0,Math.min(100,trust+(c[1]===2?15:c[1]===1?0:-15)));log.push(c[1]===2);
     $('rfb2').innerHTML=(c[1]===2?'<b class="okt">좋은 선택!</b> ':c[1]===1?'<b>보통입니다.</b> ':'<b class="not">위험한 선택!</b> ')+esc(c[2])+' <button class="gprimary" id="rnx">다음 장면 →</button>';$('rnx').onclick=function(){i++;scene()}}})}
  function end(){var good=log.filter(Boolean).length,st=trust>=80?3:trust>=55?2:1,msg=trust>=80?'청중이 끝까지 믿고 따라왔습니다.':trust>=55?'대체로 믿을 만했지만 몇 군데에서 근거가 약했습니다.':'근거가 부족해 의심을 샀습니다.';
   R.innerHTML=stage()+meter();GX.win(R,st,'이야기 끝: '+S.n,msg+' (바른 선택 '+good+' / '+log.length+')','다른 장면 고르기',menu,'roleplay',null)}
  scene()}
 var MV=metaverse(GX,R,'로비');menu()}

// ---- 방탈출 (양식을 먼저 고른 뒤 그 양식으로 다섯 방) ----
function escInit(GX){var E=$('esc2');if(!E)return;var esc=GX.esc,mk=GX.mk;
 var THEME=[['서고','먼지 쌓인 서고의 문이 잠겼습니다. 책상 위 서지 카드 가운데 규칙을 어긴 한 장을 찾으면 문이 열립니다.'],['도서관','두 번째 방은 조용한 도서관입니다. 카드 넷 중 하나가 규칙을 어겼습니다.'],['서재','세 번째는 오래된 서재입니다. 한 장만 틀렸습니다.'],['연구실','네 번째는 불이 켜진 연구실입니다. 틀린 카드를 찾아 문을 여세요.'],['의무실','마지막 방입니다. 카드 한 장의 오류를 찾으면 탈출합니다.']];
 var KC=[];try{KC=JSON.parse($('d-kci').textContent)}catch(e){}
 function make(){var sid=GX.myId(),rooms=[],seen={};
  THEME.forEach(function(t){var good=[],bad=null,tries=0;
   while(!bad&&tries++<40){var ko=KC.length&&Math.random()<.5,r=ko?pick(KC):GX.rec();window._lastRec=ko?null:r;var pc=ko?GX.fmtK(sid,r,ri(1,9)):GX.fmt(sid,r,ri(1,9)),df=GX.defect(sid,pc,!!ko);if(!seen[df.why]||tries>25){seen[df.why]=1;bad={pc:df.c,why:df.why}}}
   for(var k=0;k<3;k++){var ko2=KC.length&&Math.random()<.5,r2=ko2?pick(KC):GX.rec();window._lastRec=ko2?null:r2;good.push(ko2?GX.fmtK(sid,r2,ri(1,9)):GX.fmt(sid,r2,ri(1,9)))}
   var items=GX.sh(good.map(function(p){return {t:p.map(mk).join(' '),ok:false}}).concat([{t:bad.pc.map(mk).join(' '),ok:true,why:bad.why}]));
   rooms.push({title:t[0],story:t[1],items:items,hint:'규칙을 어긴 곳은 '+(bad.why.indexOf('순서')>=0?'조각의 순서':bad.why.indexOf('빠졌')>=0?'빠진 조각':bad.why.indexOf('약어')>=0?'학술지 이름 표기':'구두점이나 이름 모양')+'과 관련이 있습니다.'})});
  return rooms}
 function run(){var R=make(),ri2=0,hints=2,wrong=0,t0=Date.now();
  function room(){var r=R[ri2];
   E.innerHTML='<div class="gbar"><span>방 <b>'+(ri2+1)+'</b> / '+R.length+'</span><span>양식 <b>'+esc(sname(GX.myId()))+'</b></span><span>힌트 <b>'+hints+'</b>회</span><span>오답 <b>'+wrong+'</b></span></div><div class="door"><div class="doors">'+R.map(function(x,i){return '<i class="'+(i<ri2?'open':i===ri2?'cur':'')+'"></i>'}).join('')+'</div></div>'
    +'<div class="rmhead"><img id="rmimg" class="rmimg" src="img/art-escape.svg" alt="잠긴 문이 있는 방"><div><h2 class="gt">'+esc(r.title)+'</h2><p>'+esc(r.story)+'</p></div></div><div class="gcards">'+r.items.map(function(it,i){return '<button class="gcard cp0" data-i="'+i+'" style="--sc:#8a1c3a">'+it.t+'</button>'}).join('')+'</div><div class="gfb" id="gfb2" aria-live="polite"></div><div class="gbtns"><button id="ghint2">힌트 쓰기</button></div>';
   E.querySelectorAll('.gcard').forEach(function(b){b.onclick=function(){var it=r.items[+b.dataset.i];
    if(it.ok){b.classList.add('good');var im=$('rmimg');if(im){im.src='img/art-escape-open.svg';im.alt='문이 열린 방';im.classList.add('opened')}$('gfb2').innerHTML='<b>찾았습니다!</b> '+esc(it.why)+' <button id="gnx" class="gprimary">'+(ri2+1<R.length?'다음 방으로 →':'문을 열고 탈출')+'</button>';E.querySelectorAll('.gcard').forEach(function(x){x.disabled=true});$('ghint2').hidden=true;$('gnx').onclick=function(){ri2++;if(ri2>=R.length)fin();else room()}}
    else{wrong++;b.classList.add('bad');b.disabled=true;$('gfb2').textContent='이 카드는 규칙에 맞습니다. 다른 카드를 살펴보세요.';E.querySelector('.gbar span:nth-child(4) b').textContent=wrong}}});
   $('ghint2').onclick=function(){if(hints<1){$('gfb2').textContent='힌트를 모두 썼습니다.';return}hints--;$('gfb2').innerHTML='<b>힌트</b> '+esc(r.hint);E.querySelector('.gbar span:nth-child(3) b').textContent=hints}}
  function fin(){var s=Math.round((Date.now()-t0)/1000),st=wrong<=2&&hints===2?3:wrong<=5?2:1;E.innerHTML='';GX.win(E,st,'탈출 성공!','걸린 시간 '+Math.floor(s/60)+'분 '+(s%60)+'초 · 오답 '+wrong+'회 · 힌트 '+(2-hints)+'회. 내 양식('+esc(sname(GX.myId()))+')의 규칙을 다섯 번 짚었습니다.','다시 도전',run,'escape',null)}
  room()}
 var m=$('mys');if(m)GX.picker(m,run);run()}

// ===== 5. 번역(영어 기본 + 여러 언어) =====
var LANGS=[['en','English','English'],['ja','日本語','Japanese'],['zh-CN','中文(简体)','Simplified Chinese'],['zh-TW','中文(繁體)','Traditional Chinese'],['es','Español','Spanish'],['fr','Français','French'],['de','Deutsch','German'],['ru','Русский','Russian'],['pt','Português','Portuguese'],['it','Italiano','Italian'],['vi','Tiếng Việt','Vietnamese'],['th','ไทย','Thai'],['id','Bahasa Indonesia','Indonesian'],['ms','Bahasa Melayu','Malay'],['tr','Türkçe','Turkish'],['hi','हिन्दी','Hindi'],['ar','العربية','Arabic'],['mn','Монгол','Mongolian'],['uz','Oʻzbekcha','Uzbek']];
var TR={lang:'ko',sample:null,tried:false,orig:new Map(),nodes:[],busy:false,again:false,cache:{},off:false,backoff:0};
function hangul(s){return /[가-힣]/.test(s)}
function trCache(l){try{return JSON.parse(ls('tr.v1.'+l)||'{}')}catch(e){return {}}}
function trSave(l){try{var s=JSON.stringify(TR.cache);if(s.length>1800000){TR.cache={};s='{}'}ls('tr.v1.'+l,s)}catch(e){}}
function status(h,keep){var el=$('trst');if(!el){el=d.createElement('div');el.id='trst';el.className='trst';el.setAttribute('role','status');d.body.appendChild(el)}el.innerHTML=h;el.hidden=!h;if(el._t)clearTimeout(el._t);if(h&&!keep)el._t=setTimeout(function(){el.hidden=true},9000)}
function walk(){var out=[],w=d.createTreeWalker(d.body,NodeFilter.SHOW_TEXT,{acceptNode:function(n){var p=n.parentNode;if(!p||!n.nodeValue||!n.nodeValue.trim())return NodeFilter.FILTER_REJECT;var tg=p.nodeName;if(/^(SCRIPT|STYLE|CODE|PRE|TEXTAREA|NOSCRIPT|OPTION)$/.test(tg))return NodeFilter.FILTER_REJECT;if(p.closest&&p.closest('.notr,[translate="no"],svg,#trst,.lng,#lgl'))return NodeFilter.FILTER_REJECT;return NodeFilter.FILTER_ACCEPT}});
 var n;while((n=w.nextNode()))out.push(n);return out}
function near(n){var p=n.parentElement;if(!p)return false;var r=p.getBoundingClientRect();return r.bottom>-1200&&r.top<innerHeight+2600}
async function getSample(){if(TR.tried)return TR.sample;TR.tried=true;try{if(window.claude&&window.claude.use)TR.sample=await window.claude.use('sample')}catch(e){TR.sample=null}return TR.sample}
async function trRun(){if(TR.lang==='ko'||TR.off)return;if(TR.busy){TR.again=true;return}TR.busy=true;
 try{var info=LANGS.filter(function(x){return x[0]===TR.lang})[0];if(!info)return;
  var all=walk().filter(function(n){return hangul(n.nodeValue)&&near(n)});if(!all.length){return}
  var need=[];all.forEach(function(n){var o=n.nodeValue;if(!TR.orig.has(n)){TR.orig.set(n,o);TR.nodes.push(n)}var key=TR.orig.get(n),c=TR.cache[key.trim()];if(c)n.nodeValue=key.replace(key.trim(),c);else need.push(n)});
  if(!need.length){status('Machine-translated. The Korean text is the original. <button class="trb" id="trko">한국어로</button>',false);bindKo();return}
  var sample=await getSample();if(!sample){TR.off=true;status('이 환경에서는 자동 번역을 쓸 수 없습니다. 브라우저의 번역 기능(예: Chrome 주소창의 번역 아이콘)을 이용해 주세요. / Automatic translation is not available here; please use your browser’s built-in page translation. <button class="trb" id="trko">한국어로</button>',true);bindKo();return}
  status('Translating… ('+need.length+')',true);
  var i=0;while(i<need.length){var batch=[],len=0;while(i<need.length&&batch.length<40&&len<3200){batch.push(need[i]);len+=need[i].nodeValue.length;i++}
   var src=batch.map(function(n){return TR.orig.get(n).trim()});
   var prompt='Translate each Korean string in the JSON array below into '+info[2]+'. This is a Korean university textbook website about academic citation (APA, MLA, Chicago, IEEE, Vancouver, ACS). Rules: keep author names, titles in English, numbers, years, URLs, abbreviations (APA, MLA, DOI, et al., p., pp.), brackets, quotes and punctuation exactly; translate Korean explanatory text naturally and concisely; do not add notes. Return ONLY a JSON array of strings with exactly '+src.length+' items in the same order.\n'+JSON.stringify(src);
   var res=null;try{res=await sample.json(prompt,{modelTier:'quick'})}catch(e){var code=e&&e.code;if(code==='rate_limited'){status('Too many requests. Please wait a moment and scroll again. / 요청이 많아 잠시 쉽니다. 잠시 뒤 다시 스크롤해 주세요.',false);TR.backoff=Date.now()+20000;break}
    if(code==='not_granted'){TR.off=true;status('번역 권한이 허용되지 않았습니다. / Translation permission was not granted. <button class="trb" id="trko">한국어로</button>',true);bindKo();break}
    status('번역 중 오류가 났습니다. / Translation error.',false);break}
   if(Array.isArray(res)&&res.length===src.length){batch.forEach(function(n,k){var t=String(res[k]==null?'':res[k]);if(t){TR.cache[src[k]]=t;var o=TR.orig.get(n);n.nodeValue=o.replace(o.trim(),t)}});trSave(TR.lang)}
   else{status('번역 결과 형식이 맞지 않아 일부를 건너뜁니다. / Some text was skipped.',false)}}
  if(!TR.off&&!TR.backoff){status('Machine-translated; may contain errors. The Korean text is the original. <button class="trb" id="trko">한국어로</button>',false);bindKo()}
 }finally{TR.busy=false;if(TR.again){TR.again=false;setTimeout(trRun,300)}}}
function bindKo(){var b=$('trko');if(b)b.onclick=function(){setLang('ko')}}
function setLang(l){var prev=TR.lang;TR.lang=l;ls('lang.v1',l);TR.off=false;TR.backoff=0;
 if(l==='ko'){TR.nodes.forEach(function(n){var o=TR.orig.get(n);if(o!=null&&n.parentNode)n.nodeValue=o});TR.orig=new Map();TR.nodes=[];d.documentElement.lang='ko';d.documentElement.dir='ltr';status('');markLang();return}
 TR.cache=trCache(l);d.documentElement.lang=l;d.documentElement.dir=(l==='ar')?'rtl':'ltr';
 if(prev!=='ko'&&prev!==l){TR.nodes.forEach(function(n){var o=TR.orig.get(n);if(o!=null&&n.parentNode)n.nodeValue=o});TR.orig=new Map();TR.nodes=[]}
 markLang();trRun()}
function markLang(){var b=$('lgen');if(b)b.classList.toggle('on',TR.lang==='en');var m=$('lgm');if(m){var i=LANGS.filter(function(x){return x[0]===TR.lang})[0];m.firstChild.nodeValue=(i?i[1]:'한국어')+' '}
 d.querySelectorAll('#lgl [data-l]').forEach(function(x){x.classList.toggle('on',x.dataset.l===TR.lang)})}
function langInit(){var m=$('lgm'),l=$('lgl'),en=$('lgen');if(!m||!l)return;
 l.innerHTML='<button data-l="ko" class="lgi">한국어 (원문)</button>'+LANGS.map(function(x){return '<button data-l="'+x[0]+'" class="lgi">'+esc(x[1])+'</button>'}).join('')+'<p class="lgn">자동(기계) 번역입니다. 오류가 있을 수 있으며 한국어 원문이 기준입니다. 서지·약어·숫자는 그대로 둡니다. / Machine translation; the Korean original is authoritative.</p>';
 m.onclick=function(ev){ev.stopPropagation();l.hidden=!l.hidden;m.setAttribute('aria-expanded',String(!l.hidden))};
 d.addEventListener('click',function(ev){if(!ev.target.closest('.lng'))l.hidden=true});
 l.querySelectorAll('.lgi').forEach(function(b){b.onclick=function(){l.hidden=true;setLang(b.dataset.l)}});
 if(en)en.onclick=function(){setLang(TR.lang==='en'?'ko':'en')};
 var saved=ls('lang.v1');if(saved&&saved!=='ko'&&LANGS.some(function(x){return x[0]===saved}))setTimeout(function(){setLang(saved)},400);markLang();
 var deb=null;function sched(){if(TR.lang==='ko'||TR.off)return;clearTimeout(deb);deb=setTimeout(function(){if(Date.now()<TR.backoff)return;TR.backoff=0;trRun()},600)}
 addEventListener('scroll',sched,{passive:true});
 try{new MutationObserver(function(muts){for(var i=0;i<muts.length;i++){var t=muts[i].target;if(t&&t.closest&&t.closest('#trst'))continue;sched();break}}).observe(d.body,{childList:true,subtree:true})}catch(e){}}

window.__g3boot=function(){if(window.__g3done)return;window.__g3done=true;boot3()};
gateInit();
if(!$('stygate'))window.__g3boot();
langInit();
})();
