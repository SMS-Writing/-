/* 앱 전용: claude.ai 기능 대신 기기 안에서 동작하는 대체 기능 */
(function(){
if(window.claude)return;
var KEY='appdb:',BLOCK={board:1,suggest:1,library:1};
function uid(){try{var u=localStorage.getItem('app-uid');if(!u){u='me-'+Math.random().toString(36).slice(2,10);localStorage.setItem('app-uid',u)}return u}catch(e){return 'me'}}
function rd(p){try{var v=localStorage.getItem(KEY+p);return v?JSON.parse(v):null}catch(e){return null}}
function wr(p,v){try{localStorage.setItem(KEY+p,JSON.stringify(v))}catch(e){}}
function snapDoc(p){var v=rd(p);return {id:p.split('/').pop(),exists:v!=null,data:function(){return v}}}
var subs={};
function fire(col){(subs[col]||[]).forEach(function(cb){try{cb(colSnap(col))}catch(e){}})}
function colSnap(col){var docs=[];try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k.indexOf(KEY+col+'/')===0){var p=k.slice(KEY.length);docs.push(snapDoc(p))}}}catch(e){}return {docs:docs,size:docs.length,empty:!docs.length,forEach:function(f){docs.forEach(f)}}}
function blocked(col){return BLOCK[col]}
var db={
 doc:function(p){var col=p.split('/')[0];return {
  get:function(){return blocked(col)?Promise.reject(new Error('offline')):Promise.resolve(snapDoc(p))},
  set:function(v){if(blocked(col))return Promise.reject(new Error('offline'));wr(p,v);setTimeout(function(){fire(col)},0);return Promise.resolve()},
  delete:function(){try{localStorage.removeItem(KEY+p)}catch(e){}setTimeout(function(){fire(col)},0);return Promise.resolve()}}},
 collection:function(col){return {
  get:function(){return blocked(col)?Promise.reject(new Error('offline')):Promise.resolve(colSnap(col))},
  onSnapshot:function(cb,err){if(blocked(col)){setTimeout(function(){err&&err(new Error('offline'))},0);return function(){}}(subs[col]=subs[col]||[]).push(cb);setTimeout(function(){cb(colSnap(col))},0);return function(){subs[col]=(subs[col]||[]).filter(function(x){return x!==cb})}}}}
};
var user={id:function(){return Promise.resolve(uid())},can:function(){return true},canEdit:function(){return false},isOwner:function(){return false}};
function b64(buf){var u=new Uint8Array(buf),s='',CH=0x8000;for(var i=0;i<u.length;i+=CH)s+=String.fromCharCode.apply(null,u.subarray(i,i+CH));return btoa(s)}
var downloads={save:async function(o){
 var C=window.Capacitor;
 if(C&&C.isNativePlatform&&C.isNativePlatform()){
  var FS=C.registerPlugin('Filesystem'),SH=C.registerPlugin('Share');
  var name=String(o.filename||'file').replace(/[\\\/:*?"<>|]/g,'_');
  var r=await FS.writeFile({path:name,data:b64(o.data),directory:'CACHE'});
  try{await SH.share({title:name,files:[r.uri],dialogTitle:'파일 저장·보내기'})}catch(e){if(!/cancel/i.test(String(e&&e.message)))throw e;var x=new Error('declined');x.code='declined';throw x}
  return}
 var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([o.data]));a.download=o.filename||'file';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},2000)}};
window.claude={use:function(name){if(name==='db')return Promise.resolve(db);if(name==='user')return Promise.resolve(user);if(name==='downloads')return Promise.resolve(downloads);return Promise.resolve(null)}};
window.IS_APP=true;document.documentElement.classList.add('in-app');
})();
