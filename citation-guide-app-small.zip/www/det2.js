(function(){
var d=document,$=function(i){return d.getElementById(i)};
function boot(){var GX=window.GX,H=$('det2');if(!GX||!H||window.__d2)return;window.__d2=true;
 var esc=GX.esc,sh=GX.sh;
 // 연습용 가상 논문 8편: 저자(성 last, 이름 first), 연도, 제목, 학술지, 권(호), 쪽, DOI. 실제 논문이 아닙니다.
 var R=[
 {l:'en',a:[['Han','Seoyun','S.'],['Rivera','Elena','E.']],y:2021,t:'Crystal habit of copper sulfate under seeded cooling',j:'Lakeside Journal of Chemistry',v:13,n:2,p:[88,97],doi:'10.9999/ljc.2021.0044',alt:{t:'Crystal growth of copper sulfate under rapid cooling',j:'Lakeside Journal of Physics'}},
 {l:'ko',a:[['한','서윤'],['오','지호']],y:2019,t:'대학생의 출처 표기 습관과 보고서 점수의 관계',j:'글쓰기교육연구',v:12,n:3,p:[45,68],doi:'10.9999/wer.2019.1203',alt:{t:'대학생의 출처 표기 습관과 과제 만족도의 관계',j:'교양교육연구'}},
 {l:'en',a:[['Park','Jimin','J.'],['Moreno','Lucía','L.'],['Okafor','Tunde','T.']],y:2022,t:'Citation practices of undergraduate writers across disciplines',j:'Journal of Writing Studies',v:5,n:1,p:[10,31],doi:'10.9999/jws.2022.0501',alt:{t:'Citation habits of graduate writers across disciplines',j:'Journal of Writing Education'}},
 {l:'ko',a:[['문','도윤'],['백','나래'],['신','하늘']],y:2020,t:'생성형 도구를 쓴 보고서의 출처 확인 과정',j:'정보문화연구',v:8,n:2,p:[101,126],doi:'10.9999/icr.2020.0802',alt:{t:'생성형 도구를 쓴 보고서의 평가 기준',j:'정보교육연구'}},
 {l:'en',a:[['Kim','Haneul','H.']],y:2018,t:'Footnotes and reader trust in student reports',j:'Review of Academic Habits',v:12,n:3,p:[301,320],doi:'10.9999/rah.2018.1203',alt:{t:'Footnotes and reader attention in student reports',j:'Review of Academic Writing'}},
 {l:'ko',a:[['강','민재']],y:2023,t:'인용 표기 규칙이 독자의 신뢰도에 미치는 영향',j:'학술문화연구',v:5,n:3,p:[77,96],doi:'10.9999/acr.2023.0503',alt:{t:'인용 표기 규칙이 독자의 이해도에 미치는 영향',j:'학술소통연구'}},
 {l:'en',a:[['Lindqvist','Maja','M.'],['Choi','Yuna','Y.']],y:2017,t:'Solubility measurements of common laboratory salts',j:'Lakeside Journal of Chemistry',v:9,n:4,p:[212,229],doi:'10.9999/ljc.2017.0904',alt:{t:'Solubility measurements of common household salts',j:'Lakeside Journal of Materials'}},
 {l:'ko',a:[['윤','서아'],['임','태오']],y:2021,t:'학술 논문 서지정보를 직접 확인하는 습관',j:'대학글쓰기연구',v:10,n:1,p:[33,54],doi:'10.9999/uwr.2021.1001',alt:{t:'학술 논문 서지정보를 자동으로 만드는 습관',j:'대학교육연구'}}];
 function digits(s){return s.replace(/\d$/,function(c){return String((+c+3)%10)})}
 // 한 가지 오류를 만든다. 반환: 바뀐 복사본과 설명
 var KINDS=['au','y','t','j','vn','pg','doi'];
 function mut(r,kind){var c=JSON.parse(JSON.stringify(r)),df={};
  if(kind==='au'){if(c.a.length>1&&Math.random()<.5){var rm=c.a.pop();df={f:'au',wrong:'저자 한 명이 빠짐',right:'저자 '+r.a.length+'명',why:'원본 저자는 '+r.a.length+'명인데 한 명을 빼 버렸어요. AI는 공저자를 곧잘 빠뜨려요.'}}
   else{var k=0;if(r.l==='en'){c.a[k][2]=c.a[k][0].charAt(0)+'.';var o=c.a[k][2];c.a[k][2]=(r.a[k][2]==='S.'?'E.':r.a[k][2]==='E.'?'S.':String.fromCharCode(65+((r.a[k][2].charCodeAt(0)-65+3)%26))+'.');df={f:'au',wrong:c.a[k][0]+', '+c.a[k][2],right:r.a[k][0]+', '+r.a[k][2],why:'이름 첫 글자(이니셜)가 원본과 달라요. 성은 같아도 이름이 다르면 다른 사람이에요.'}}
    else{c.a[k][1]=r.a[k][1]==='서윤'?'서연':'지민'===r.a[k][1]?'지호':r.a[k][1].slice(0,-1)+'아';if(c.a[k][1]===r.a[k][1])c.a[k][1]=r.a[k][1].charAt(0)+'우';df={f:'au',wrong:c.a[k][0]+c.a[k][1],right:r.a[k][0]+r.a[k][1],why:'저자의 이름이 원본과 달라요. 비슷한 이름으로 바꿔 쓰는 일이 잦아요.'}}}}
  else if(kind==='y'){c.y=r.y+(Math.random()<.5?-1:1)*(1+Math.floor(Math.random()*2));df={f:'y',wrong:String(c.y),right:String(r.y),why:'발행 연도가 원본은 '+r.y+'년인데 '+c.y+'년으로 썼어요. 연도는 본문 인용에도 쓰여서 틀리면 짝이 어긋나요.'}}
  else if(kind==='t'){c.t=r.alt.t;df={f:'t',wrong:c.t,right:r.t,why:'제목의 낱말이 달라요. 비슷하지만 다른 논문 제목이 될 수 있어요.'}}
  else if(kind==='j'){c.j=r.alt.j;df={f:'j',wrong:c.j,right:r.j,why:'학술지 이름이 달라요. 이름이 비슷한 다른 학술지일 수 있어요.'}}
  else if(kind==='vn'){c.n=r.n===1?3:r.n-1;df={f:'vn',wrong:c.v+'('+c.n+')',right:r.v+'('+r.n+')',why:'호수가 원본은 '+r.n+'호인데 '+c.n+'호로 썼어요. 권호는 AI가 자주 틀리는 부분이에요.'}}
  else if(kind==='pg'){c.p=[r.p[0],r.p[1]+7];df={f:'pg',wrong:c.p[0]+'–'+c.p[1],right:r.p[0]+'–'+r.p[1],why:'끝 쪽이 원본은 '+r.p[1]+'쪽인데 '+c.p[1]+'쪽으로 썼어요. 쪽수는 원본 첫 쪽과 꼭 맞춰 보세요.'}}
  else{c.doi=r.doi.replace(/\d{2}$/,function(x){return ('0'+((+x+17)%100)).slice(-2)});df={f:'doi',wrong:c.doi,right:r.doi,why:'DOI의 끝자리가 달라요. 한 글자만 달라도 다른 논문으로 연결돼요.'}}
  return {r:c,df:df}}
 function nameStr(r){var A=r.a;if(r.l==='ko')return A.map(function(x){return x[0]+x[1]}).join(', ');
  var s=A.map(function(x){return x[0]+', '+x[2]});return s.length===1?s[0]:s.length===2?s[0]+', & '+s[1]:s.slice(0,-1).join(', ')+', & '+s[s.length-1]}
 // 구간별 조각 (필드, 보이는 글)
 function segs(r){var ko=r.l==='ko';return [['au',nameStr(r)],['y','('+r.y+')'],['t',r.t],['j',r.j],['vn',r.v+'('+r.n+')'],['pg',r.p[0]+'–'+r.p[1]],['doi','https://doi.org/'+r.doi]]}
 function strOf(r){return segs(r).map(function(s){return s[1]}).join(' ')}
 function line(r,fn){var S=segs(r),ko=r.l==='ko';return S.map(function(s,i){var inner=s[0]==='j'?'<i>'+esc(s[1])+'</i>':esc(s[1]);var sep=i===0?'. ':s[0]==='y'?'. ':s[0]==='t'?'. ':s[0]==='j'?', ':s[0]==='vn'?', ':s[0]==='pg'?'. ':'';
   return fn(s[0],inner,sep)}).join('')}
 function card(r){return '<div class="dpg"><div class="dpgt">논문 첫 쪽 · 진짜</div><div class="dpgb"><b>'+esc(r.t)+'</b><div>'+esc(r.a.map(function(x){return r.l==='ko'?x[0]+x[1]:x[1]+' '+x[0]}).join(r.l==='ko'?', ':' · '))+'</div><div><i>'+esc(r.j)+'</i> · 제 '+r.v+'권 '+r.n+'호 · '+r.y+'년</div><div>쪽 '+r.p[0]+'–'+r.p[1]+'</div><div class="dd">DOI '+esc(r.doi)+'</div></div></div>'}
 var mode=GX.ls('det2.mode')||'a';
 function tabs(){return '<div class="olyrow"><span class="olyc">놀이</span><button class="gtab'+(mode==='a'?' on':'')+'" data-m="a">🔍 틀린 그림 찾기</button><button class="gtab'+(mode==='b'?' on':'')+'" data-m="b">🖼️ 맞는 그림 찾기</button></div>'}
 function bind(){H.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){mode=b.dataset.m;GX.ls('det2.mode',mode);run()}})}
 var rounds=6;
 function run(){var deck=sh(R).slice(0,rounds),rd=0,score=0,miss=0,solved=0;
  if(mode==='a')A();else Bm();
  // ----- 틀린 그림 찾기: AI가 쓴 서지에서 원본과 다른 곳 누르기
  function A(){var r=deck[rd],n=2+Math.floor(Math.random()*2),kinds=sh(KINDS).slice(0,n),c=JSON.parse(JSON.stringify(r)),diffs={},found=0,mc=0;
   kinds.forEach(function(k){var m=mut(c,k);c=m.r;diffs[m.df.f]=m.df});
   H.innerHTML=tabs()+'<div class="gbar"><span>그림 <b>'+(rd+1)+' / '+rounds+'</b></span><span>찾은 곳 <b id="dfound">0</b> / '+n+'</span><span>헛짚음 <b id="dmiss">0</b></span></div>'
    +'<p class="twq">왼쪽은 <b>논문 첫 쪽(진짜)</b>, 오른쪽은 <b>AI가 써 준 참고문헌</b>입니다. 두 그림을 견주어 <b>틀린 곳 '+n+'군데</b>를 눌러 보세요. (인터넷에서 찾아보지 않아도 됩니다. 가상 자료입니다.)</p>'
    +'<div class="dtp">'+card(r)+'<div class="dpg ai"><div class="dpgt">AI가 쓴 참고문헌 · 의심</div><div class="dpgb dref">'+line(c,function(f,inner,sep){return '<span class="dseg" data-f="'+f+'" tabindex="0" role="button">'+inner+'</span>'+esc(sep)})+'</div></div></div>'
    +'<div id="dnote" aria-live="polite"></div><div class="gbtns"><button id="dgive">모르겠어요 · 정답 보기</button></div>';
   bind();
   function show(f,ok){var s=H.querySelector('.dseg[data-f="'+f+'"]');return s}
   function fin(giveup){H.querySelectorAll('.dseg').forEach(function(s){var f=s.dataset.f;if(diffs[f]&&!s.classList.contains('found'))s.classList.add(giveup?'reveal':'found')});
    var ex=Object.keys(diffs).map(function(f){var x=diffs[f];return '<li><b>'+esc(x.wrong)+'</b> → 진짜는 <b>'+esc(x.right)+'</b>. '+esc(x.why)+'</li>'}).join('');
    var ok=found===n;if(ok)solved++;score+=found*10-Math.min(mc,5)*2;if(score<0)score=0;
    $('dnote').innerHTML='<div class="twfb '+(ok?'ok':'no')+'"><b class="'+(ok?'twok':'twno')+'">'+(ok?'모두 찾았어요!':'놓친 곳이 있어요.')+'</b><ul class="dwhy">'+ex+'</ul></div><div class="gbtns"><button class="gprimary" id="dnx">'+(rd+1>=rounds?'결과 보기':'다음 그림 →')+'</button></div>';
    $('dgive').hidden=true;$('dnx').onclick=function(){rd++;if(rd>=rounds)end();else A()}}
   H.querySelectorAll('.dseg').forEach(function(s){function hit(){var f=s.dataset.f;if(s.classList.contains('found')||s.classList.contains('reveal'))return;
     if(diffs[f]){s.classList.add('found');found++;$('dfound').textContent=found;$('dnote').innerHTML='<div class="twfb ok"><b class="twok">찾았어요!</b> '+esc(diffs[f].why)+'</div>';if(found===n)fin(false)}
     else{mc++;miss++;s.classList.add('bad');$('dmiss').textContent=mc;setTimeout(function(){s.classList.remove('bad')},500);$('dnote').innerHTML='<div class="twfb no">여기는 원본과 같아요. 다시 견주어 보세요.</div>'}}
    s.onclick=hit;s.onkeydown=function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();hit()}}});
   $('dgive').onclick=function(){fin(true)}}
  // ----- 맞는 그림 찾기: 네 개 가운데 원본과 같은 서지 고르기
  function Bm(){var r=deck[rd],ks=sh(KINDS).slice(0,3),cands=[{c:r,ok:true,df:null}];
   ks.forEach(function(k){var m=mut(r,k);cands.push({c:m.r,ok:false,df:m.df})});cands=sh(cands);
   H.innerHTML=tabs()+'<div class="gbar"><span>그림 <b>'+(rd+1)+' / '+rounds+'</b></span><span>맞힌 수 <b>'+solved+'</b></span><span>헛짚음 <b>'+miss+'</b></span></div>'
    +'<p class="twq">왼쪽 <b>논문 첫 쪽(진짜)</b>과 <b>똑같은 참고문헌</b> 하나를 고르세요. 나머지는 한 군데씩 다릅니다.</p>'
    +'<div class="dtp">'+card(r)+'<div class="dcands">'+cands.map(function(x,i){return '<button class="dcand" data-i="'+i+'"><span class="dpgb dref">'+line(x.c,function(f,inner,sep){return '<span data-f="'+f+'">'+inner+'</span>'+esc(sep)})+'</span></button>'}).join('')+'</div></div><div id="dnote" aria-live="polite"></div>';
   bind();
   H.querySelectorAll('.dcand').forEach(function(b){b.onclick=function(){var x=cands[+b.dataset.i];H.querySelectorAll('.dcand').forEach(function(y,i){y.disabled=true;if(cands[i].ok)y.classList.add('ok')});
     if(x.ok){solved++;score+=15}else{miss++;b.classList.add('bad');var s=b.querySelector('[data-f="'+x.df.f+'"]');if(s)s.classList.add('reveal')}
     var why=cands.map(function(y,i){return y.ok?'':'<li>'+esc(y.df.why)+'</li>'}).join('');
     $('dnote').innerHTML='<div class="twfb '+(x.ok?'ok':'no')+'"><b class="'+(x.ok?'twok':'twno')+'">'+(x.ok?'맞아요! 원본과 똑같아요.':'아쉬워요. 이 카드는 틀린 곳이 있어요.')+'</b><ul class="dwhy">'+why+'</ul></div><div class="gbtns"><button class="gprimary" id="dnx">'+(rd+1>=rounds?'결과 보기':'다음 그림 →')+'</button></div>';
     $('dnx').onclick=function(){rd++;if(rd>=rounds)end();else Bm()}}})}
  function end(){H.innerHTML='';var st=miss<=2?3:miss<=6?2:1;GX.win(H,st,'수사 끝!','틀린 곳과 맞는 곳을 가려 냈어요. 실제 과제에서는 AI가 준 서지를 논문 첫 쪽·학술지 목차·DOI와 하나씩 견주어 봅니다.','한 번 더',run,'detective',score,mode==='a'?'틀린 그림 찾기':'맞는 그림 찾기')}
 }
 run()}
if(window.GX)boot();else addEventListener('load',boot);
})();
