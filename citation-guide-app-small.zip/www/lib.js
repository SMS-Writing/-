(function(){var d=document,box=d.getElementById('libl');if(!box)return;
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
var DB=null,AS=null,admin=false,rows=[];
function size(n){return n>1048576?(n/1048576).toFixed(1)+'MB':Math.max(1,Math.round(n/1024))+'KB'}
function draw(){
 if(!rows.length){box.innerHTML='<p class="mut">아직 올라온 자료가 없습니다.'+(admin?' 위 양식으로 첫 자료를 올려 보세요.':'')+'</p>';return}
 var cats={};rows.sort(function(a,b){return (b.at||0)-(a.at||0)}).forEach(function(r){(cats[r.cat||'기타']=cats[r.cat||'기타']||[]).push(r)});
 box.innerHTML=Object.keys(cats).map(function(c){return '<h3 class="gh4">'+esc(c)+'</h3>'+cats[c].map(function(r){return '<div class="libi"><div><b>'+esc(r.name)+'</b>'+(r.desc?'<span class="mut"> · '+esc(r.desc)+'</span>':'')+'<small class="mut"> '+esc(r.type||'')+' '+(r.size?size(r.size):'')+'</small></div><div class="pls"><a class="pl main" href="'+esc(r.url)+'" target="_blank" rel="noopener">열기</a>'+(admin?'<button class="pl libdel" data-i="'+esc(r.id)+'" data-a="'+esc(r.asset||'')+'">삭제</button>':'')+'</div></div>'}).join('')}).join('');
 box.querySelectorAll('.libdel').forEach(function(b){b.onclick=async function(){if(b.dataset.s!=='1'){b.dataset.s='1';b.textContent='한 번 더 누르면 삭제';setTimeout(function(){b.dataset.s='';b.textContent='삭제'},3500);return}
  try{if(AS&&b.dataset.a)await AS.delete(b.dataset.a)}catch(e){}
  try{await DB.doc('library/'+b.dataset.i).delete()}catch(e){}
  rows=rows.filter(function(r){return r.id!==b.dataset.i});draw()}})}
(async function(){
 try{if(window.claude&&window.claude.use){DB=await window.claude.use('db');var u=await window.claude.use('user');admin=!!(u&&u.canEdit&&u.canEdit());if(admin)AS=await window.claude.use('assets')}}catch(e){}
 if(!DB){box.innerHTML='<p class="mut">자료 목록을 불러올 수 없는 환경입니다(로그인이 필요합니다). 아래 기본 제공 PDF는 열 수 있습니다.</p>';return}
 var adm=d.getElementById('libadm');if(admin&&AS&&adm)adm.hidden=false;
 else if(admin&&adm){adm.hidden=false;adm.querySelector('form').innerHTML='<p class="mut">이 환경에서는 파일 올리기를 쓸 수 없습니다(편집 권한이 필요합니다).</p>'}
 try{DB.collection('library').onSnapshot(function(sn){rows=sn.docs.map(function(x){var v=x.data()||{};v.id=x.id;return v});draw()},function(){box.innerHTML='<p class="mut">자료 목록을 불러오지 못했습니다.</p>'})}catch(e){box.innerHTML='<p class="mut">자료 목록을 불러오지 못했습니다.</p>'}
 var f=d.getElementById('libf'),msg=d.getElementById('libmsg');
 if(f&&AS)f.onsubmit=async function(ev){ev.preventDefault();var fl=f.file.files[0],nm=f.name.value.trim();if(!fl){msg.textContent='파일을 고르세요.';return}if(!nm)nm=fl.name;
  msg.textContent='올리는 중…';
  try{var r=await AS.upload(fl);var id='f'+Date.now().toString(36);
   await DB.doc('library/'+id).set({name:nm,desc:f.desc.value.trim(),cat:f.cat.value,url:r.url,asset:r.id,size:r.sizeBytes||fl.size,type:r.contentType||fl.type||'',at:Date.now()});
   f.reset();msg.textContent='올렸습니다.'}catch(e){msg.textContent='올리지 못했습니다: '+((e&&e.message)||'오류')}}
})()})();
// ---- 내려받기 단추 (downloads 능력: 확인창에서 저장)
(function(){var d=document;
function toast(s){var e=d.createElement('div');e.className='copied';e.textContent=s;d.body.appendChild(e);setTimeout(function(){e.remove()},2200)}
var DL=null,tried=false;
async function getDL(){if(tried)return DL;tried=true;try{DL=await window.claude.use('downloads')}catch(e){DL=null}return DL}
var EXT={'application/pdf':'pdf','image/png':'png','image/jpeg':'jpg','image/gif':'gif','image/webp':'webp','image/svg+xml':'svg','text/plain':'txt','text/csv':'csv','application/json':'json','text/markdown':'md','text/html':'html','video/mp4':'mp4','video/webm':'webm'};
function fname(name,type,url){name=String(name||'자료').replace(/[\\/:*?"<>|]/g,'_');if(/\.[A-Za-z0-9]{2,5}$/.test(name))return name;var m=(url||'').match(/\.([A-Za-z0-9]{2,5})(?:$|\?)/);var e=EXT[(type||'').split(';')[0]]||(m&&m[1])||'pdf';return name+'.'+e}
async function save(btn,name,get){var D=await getDL();if(!D){toast('이 화면에서는 내려받기를 쓸 수 없습니다. “열기”로 새 탭에서 열어 저장하세요.');return}
 var o=btn.textContent;btn.disabled=true;btn.textContent='준비 중…';
 try{var data=await get();await D.save({filename:name,data:data});toast('저장 확인창에서 허락하면 내려받아집니다')}catch(e){if(!e||e.code!=='declined')toast('내려받지 못했습니다'+(e&&e.message?': '+e.message:''))}
 btn.disabled=false;btn.textContent=o}
function mk(label,name,get){var b=d.createElement('button');b.type='button';b.className='pl dlb';b.textContent=label;b.onclick=function(){save(b,name,get)};return b}
function fromUrl(u){return function(){return fetch(u).then(function(r){if(!r.ok)throw new Error('파일을 불러오지 못했습니다');return r.blob()})}}
function b64(s){var bin=atob(s),a=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return new Blob([a])}
var MAP={'APA':'apa','MLA':'mla','Chicago Author-Date':'cad','Chicago Notes-Bibliography':'nb','IEEE':'ieee','Vancouver':'van','ACS':'acs'};
function decorate(){
 d.querySelectorAll('#libdef .libi').forEach(function(li){if(li.dataset.dl)return;li.dataset.dl='1';var nm=(li.querySelector('b')||{}).textContent||'',box=li.querySelector('.pls');if(!box)return;
  box.querySelectorAll('a.pl[href^="dl/"]').forEach(function(a){var f=fname(nm+' '+a.textContent,'application/pdf',a.getAttribute('href'));a.insertAdjacentElement('afterend',mk('⬇',f,fromUrl(a.getAttribute('href'))))});
  var k=MAP[nm];if(k&&window.TPLDOCX&&TPLDOCX[k])box.appendChild(mk('⬇ 보고서 양식(Word)',nm+' 보고서 양식.docx',function(){return Promise.resolve(b64(TPLDOCX[k]))}))});
 d.querySelectorAll('#libl .libi').forEach(function(li){if(li.dataset.dl)return;var a=li.querySelector('a.pl.main[href]');if(!a)return;li.dataset.dl='1';var nm=(li.querySelector('b')||{}).textContent||'자료',sm=(li.querySelector('small')||{}).textContent||'';
  a.insertAdjacentElement('afterend',mk('⬇ 내려받기',fname(nm,(sm.match(/(application|image|text|video)\/[\w.+-]+/)||[''])[0],a.getAttribute('href')),fromUrl(a.getAttribute('href'))))})}
new MutationObserver(function(){decorate()}).observe(d.documentElement,{childList:true,subtree:true});
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',decorate);else decorate();
})();
