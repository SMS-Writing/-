(function(){
var d=document,$=function(i){return d.getElementById(i)};
window.__g4boot=function(){if(window.__g4done)return;window.__g4done=true;var GX=window.GX;if(!GX)return;
 var esc=GX.esc,mk=GX.mk,sh=GX.sh,pick=GX.pick,ri=GX.ri,K='#2b3558';
 function sname(id){var s=GX.STY.filter(function(x){return x.id===id})[0];return s?s.n:id}
 function item(ko){var sid=GX.myId(),KC=[];try{KC=JSON.parse($('d-kci').textContent)}catch(e){}ko=KC.length&&Math.random()<(ko==null?.5:ko);var r=ko?pick(KC):GX.rec();window._lastRec=ko?null:r;var pc=ko?GX.fmtK(sid,r,ri(1,9)):GX.fmt(sid,r,ri(1,9));return {sid:sid,ko:ko,pc:pc,r:r}}
 function badOf(b){var df=GX.defect(b.sid,b.pc,!!b.ko);return {shown:df.c,bad:true,why:df.why,fix:b.pc,hi:df.hi,gone:df.gone,rule:df.rule,tip:df.tip,sid:b.sid}}
 function goodOf(b){return {shown:b.pc,bad:false,why:'',fix:b.pc,sid:b.sid}}
 function mkItem(){var b=item();return Math.random()<.5?badOf(b):goodOf(b)}
 // 오답 해설 패널(외부에서도 사용)
 function panelFor(it){var fake={bad:it.bad,shown:it.shown,why:it.why,fix:it.fix,hi:it.hi,gone:it.gone,rule:it.rule,tip:it.tip,sid:it.sid};return GX.whyPanel?GX.whyPanel(fake,false):''}
 // ===== A. 학과별 실험실 =====
 var LABS=[
  {id:'semi',n:'반도체 클린룸',v:'웨이퍼',vi:'wafer',col:'#6c7fd6',lead:'웨이퍼 한 장마다 서지 카드가 붙어 있습니다. 규칙을 어긴 카드가 붙은 웨이퍼는 불량입니다.',like:'ieee'},
  {id:'batt',n:'배터리·에너지 랩',v:'셀',vi:'cell',col:'#3aa27a',lead:'시험 중인 배터리 셀마다 논문 카드가 있습니다. 표기가 틀린 셀을 분리 보관함으로 옮기세요.',like:'acs'},
  {id:'mob',n:'모빌리티 시험장',v:'시험 차량',vi:'car',col:'#d97b3a',lead:'시험 차량 앞 계기판에 참고문헌이 떴습니다. 표기가 틀린 차량만 정비소로 보내세요.',like:'ieee'},
  {id:'ai',n:'인공지능 연구실',v:'학습 데이터',vi:'file',col:'#8a5bd6',lead:'학습 데이터 파일마다 출처 카드가 붙었습니다. 출처 표기가 틀린 파일은 학습에서 뺍니다.',like:'ieee'},
  {id:'cyber',n:'사이버 포렌식 랩',v:'로그',vi:'log',col:'#2f8f6a',lead:'수집한 로그 조각마다 참고문헌 카드가 있습니다. 표기가 틀린 조각에 표시를 하세요.',like:'ieee'},
  {id:'bio',n:'바이오·제약 실험실',v:'시험관',vi:'tube',col:'#c0457a',lead:'시험관마다 문헌 카드가 붙었습니다. 표기가 틀려 “오염”된 시험관을 골라내세요.',like:'van'},
  {id:'def',n:'국방 기술 연구소',v:'장비 상자',vi:'crate',col:'#5f7a4a',lead:'점검할 장비 상자마다 보고서 인용 카드가 있습니다. 표기가 틀린 상자를 찾아 봉인하세요.',like:'ieee'},
  {id:'disp',n:'디스플레이 랩',v:'패널',vi:'panel',col:'#2a8fc4',lead:'검사대 위 패널마다 참고문헌 카드가 있습니다. 표기가 틀린 패널은 불량으로 분류합니다.',like:'ieee'},
  {id:'robot',n:'로봇 제어 랩',v:'부품',vi:'gear',col:'#b08a2c',lead:'조립 중인 로봇 부품마다 문헌 카드가 있습니다. 표기가 틀린 부품은 조립 라인에서 뺍니다.',like:'ieee'}];

 function labScene(id,c){var W='<svg class="labsc" viewBox="0 0 720 150" role="img" aria-label="실험실 풍경">',e='</svg>',s='';
  function r(x,y,w,h,f,rx){return '<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="'+(rx||0)+'" fill="'+f+'"/>'}
  function ci(x,y,rr,f,st){return '<circle cx="'+x+'" cy="'+y+'" r="'+rr+'" fill="'+f+'"'+(st?' stroke="'+st+'" stroke-width="2"':'')+'/>'}
  var i;
  if(id==='semi'){s=r(0,0,720,150,'#eef0ff')+r(0,112,720,38,'#c9cdf0')+r(0,0,720,22,'#ffe36e');for(i=0;i<6;i++)s+=r(20+i*120,0,70,10,'#fff6b8',3);
   for(i=0;i<3;i++){var x=60+i*230;s+=ci(x,64,13,'#fff','#6c7fd6')+r(x-16,76,32,48,'#fff',8)+r(x-16,100,32,6,'#6c7fd6')+r(x-30,84,14,34,'#fff',6)+r(x+16,84,14,34,'#fff',6)}
   s+=r(520,50,180,64,'#9aa4e6',6)+ci(560,82,22,'#e8ebff','#4a56a6')+ci(640,82,22,'#e8ebff','#4a56a6')+r(500,118,220,6,'#6c7fd6')}
  else if(id==='batt'){s=r(0,0,720,150,'#e6f6ee')+r(0,118,720,32,'#b9e3cf');for(i=0;i<8;i++){var x2=24+i*86;s+=r(x2,40,62,70,'#fff',6)+r(x2+22,32,18,8,'#3aa27a')+r(x2+8,50+ (i%3)*8,46,50-(i%3)*8,'#7fd1a8',4)+'<path d="M'+(x2+34)+' 58l-10 18h9l-5 18 14-24h-9z" fill="#fff"/>'}}
  else if(id==='mob'){s=r(0,0,720,150,'#fde9d6')+r(0,70,720,60,'#5b5f68')+'<path d="M0 100H720" stroke="#fff" stroke-width="4" stroke-dasharray="30 22"/>'+ci(640,30,18,'#ffd24a');for(i=0;i<3;i++){var x3=60+i*210;s+='<path d="M'+x3+' 96v-16l14-18h46l16 18v16z" fill="'+['#d97b3a','#3a7bd9','#c0457a'][i]+'"/>'+ci(x3+20,98,9,'#222')+ci(x3+66,98,9,'#222')+r(x3+22,66,18,12,'#fff',2)+r(x3+46,66,18,12,'#fff',2)}}
  else if(id==='ai'){s=r(0,0,720,150,'#efe8fb');for(i=0;i<5;i++){var x4=20+i*70;s+=r(x4,24,54,100,'#4b3a7a',6);for(var j=0;j<5;j++)s+=r(x4+8,32+j*18,38,10,'#6d58a8',2)+ci(x4+42,37+j*18,2.5,j%2?'#7dffb0':'#ffd24a')}
   var P=[[470,40],[470,75],[470,110],[550,30],[550,65],[550,100],[550,130],[640,55],[640,95]];P.forEach(function(p){P.forEach(function(q){if(q[0]-p[0]===80||(q[0]-p[0]===90&&p[0]===550))s+='<line x1="'+p[0]+'" y1="'+p[1]+'" x2="'+q[0]+'" y2="'+q[1]+'" stroke="#8a5bd6" stroke-width="1" opacity=".5"/>'})});P.forEach(function(p){s+=ci(p[0],p[1],9,'#fff','#8a5bd6')})}
  else if(id==='cyber'){s=r(0,0,720,150,'#0f1a2a');for(i=0;i<4;i++){var x5=24+i*110;s+=r(x5,22,96,64,'#13243b',4)+'<path d="M'+(x5+8)+' 36h50M'+(x5+8)+' 48h70M'+(x5+8)+' 60h40M'+(x5+8)+' 72h60" stroke="'+(i===2?'#ff8a73':'#5fe08f')+'" stroke-width="3"/>'+r(x5+36,86,24,10,'#2a3b55')}
   s+=ci(560,60,36,'none','#7fd1ff')+'<path d="M586 86l30 34" stroke="#7fd1ff" stroke-width="8" stroke-linecap="round"/><text x="540" y="66" font-size="20" fill="#ff8a73" font-family="monospace">0xE?</text>'+r(0,124,720,26,'#0b1220')}
  else if(id==='bio'){s=r(0,0,720,150,'#fbe9f2')+r(0,108,720,42,'#e4b9cf');var fl=['#c0457a','#7fd1a8','#ffd24a'];for(i=0;i<3;i++){var x6=40+i*80;s+='<path d="M'+(x6+16)+' 40h20v24l22 44H'+(x6-6)+'l22-44z" fill="#fff" stroke="#7a2e55" stroke-width="2"/><path d="M'+(x6-2)+' 96h56l8 12H'+(x6-10)+'z" fill="'+fl[i]+'"/>'}
   s+='<path d="M360 20c30 20 30 40 0 60s-30 40 0 60M400 20c-30 20-30 40 0 60s30 40 0 60" fill="none" stroke="#c0457a" stroke-width="3"/>';for(i=0;i<5;i++)s+='<line x1="'+(372+Math.abs(Math.sin(i))*0)+'" y1="'+(36+i*24)+'" x2="388" y2="'+(36+i*24)+'" stroke="#7a2e55" stroke-width="2"/>';
   s+=r(520,90,120,18,'#7a2e55',3)+r(560,40,20,52,'#7a2e55',3)+ci(570,38,16,'#fff','#7a2e55')+r(600,66,36,10,'#7a2e55',3)}
  else if(id==='def'){s=r(0,0,720,150,'#e5ecd9')+r(0,100,720,50,'#9fb287')+'<path d="M0 100 120 60 240 100z" fill="#788a63"/>'+r(40,72,150,40,'#5f7a4a',3)+'<path d="M40 72 115 48l75 24z" fill="#4a6038"/>';for(i=0;i<3;i++)s+=r(280+i*58,84+(i%2)*-14,48,36+(i%2)*14,'#8a7a4a',3)+'<path d="M'+(280+i*58)+' '+(98+(i%2)*-14)+'h48" stroke="#5a4e2a" stroke-width="2"/>';
   s+='<path d="M560 110l30-60 30 60z" fill="#6b7a5a"/>'+ci(590,46,26,'#cdd9bd','#4a6038')+'<path d="M590 46l30-24" stroke="#4a6038" stroke-width="5"/>'}
  else if(id==='disp'){s=r(0,0,720,150,'#e1f1fb')+r(0,112,720,38,'#b6d6ea');for(i=0;i<5;i++){var x7=18+i*140,cl=['#ff6b6b','#ffd24a','#5fe08f','#4aa3ff','#c58bff'][i];s+=r(x7,24,122,76,'#222',5)+r(x7+5,29,112,66,cl,3)+'<path d="M'+(x7+5)+' 29l112 66" stroke="#fff" stroke-width="1" opacity=".5"/>'+r(x7+54,100,14,12,'#555')+r(x7+38,110,46,6,'#444',2)}}
  else{s=r(0,0,720,150,'#f7efd6')+r(0,118,720,32,'#dccb94')+r(40,100,200,18,'#8a7230',3)+r(120,70,20,32,'#b08a2c',3)+'<path d="M130 74 190 42 232 66" fill="none" stroke="#b08a2c" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/>'+ci(130,74,12,'#fff6d8','#8a7230')+ci(190,42,10,'#fff6d8','#8a7230')+'<path d="M232 66l12-12M232 66l12 12" stroke="#8a7230" stroke-width="5" stroke-linecap="round"/>'+ci(420,86,34,'#fff6d8','#8a7230')+ci(420,86,12,'#b08a2c')+ci(500,60,22,'#fff6d8','#8a7230')+ci(500,60,8,'#b08a2c')+r(560,50,120,60,'#8a7230',6)+r(572,62,40,12,'#5fe08f',2)+ci(640,92,8,'#ffd24a')}
  return W+s+e}
 function vessel(k,c,on){var f=on?'#f6b3a3':c,s='<svg viewBox="0 0 70 70" width="62" height="62" aria-hidden="true">';
  if(k==='wafer')s+='<circle cx="35" cy="35" r="28" fill="'+f+'" stroke="'+K+'" stroke-width="2"/><path d="M12 28H58M10 38H60M22 14V56M35 8V62M48 14V56" stroke="'+K+'" stroke-width="1" opacity=".5"/><path d="M30 63h10" stroke="'+K+'" stroke-width="3"/>';
  else if(k==='cell')s+='<rect x="14" y="16" width="42" height="44" rx="5" fill="'+f+'" stroke="'+K+'" stroke-width="2"/><rect x="28" y="9" width="14" height="8" fill="'+K+'"/><path d="M28 42h14M35 35v14" stroke="#fff" stroke-width="3"/>';
  else if(k==='car')s+='<path d="M8 46v-8l8-12h30l10 12v8z" fill="'+f+'" stroke="'+K+'" stroke-width="2"/><circle cx="20" cy="48" r="6" fill="'+K+'"/><circle cx="46" cy="48" r="6" fill="'+K+'"/><path d="M20 28h12v10H14zM34 28h10l6 10H34z" fill="#fff" opacity=".7"/>';
  else if(k==='file')s+='<path d="M16 8h28l12 12v42H16z" fill="'+f+'" stroke="'+K+'" stroke-width="2"/><path d="M44 8v12h12" fill="#fff" stroke="'+K+'" stroke-width="2"/><path d="M24 34h24M24 42h24M24 50h16" stroke="'+K+'" stroke-width="2"/>';
  else if(k==='log')s+='<rect x="8" y="12" width="54" height="46" rx="4" fill="#0f1a2a" stroke="'+K+'" stroke-width="2"/><path d="M14 24h22M14 32h34M14 40h18" stroke="'+(on?'#ff8a73':'#5fe08f')+'" stroke-width="3"/>';
  else if(k==='tube')s+='<path d="M24 6h22v8l-4 4v38a7 7 0 0 1-14 0V18l-4-4z" fill="#fff" stroke="'+K+'" stroke-width="2"/><path d="M28 34h14v22a7 7 0 0 1-14 0z" fill="'+f+'"/>';
  else if(k==='crate')s+='<rect x="8" y="16" width="54" height="42" rx="3" fill="'+f+'" stroke="'+K+'" stroke-width="2"/><path d="M8 28H62M8 46H62" stroke="'+K+'" stroke-width="2"/><path d="M26 16V58" stroke="'+K+'" stroke-width="2"/>';
  else if(k==='panel')s+='<rect x="8" y="14" width="54" height="36" rx="3" fill="'+f+'" stroke="'+K+'" stroke-width="2"/><path d="M26 56h18M35 50v6" stroke="'+K+'" stroke-width="3"/><path d="M12 18l20 12-20 12z" fill="#fff" opacity=".4"/>';
  else s+='<circle cx="35" cy="35" r="14" fill="'+f+'" stroke="'+K+'" stroke-width="2"/><circle cx="35" cy="35" r="5" fill="#fff"/><path d="M35 8v10M35 52v10M8 35h10M52 35h10M16 16l7 7M47 47l7 7M54 16l-7 7M23 47l-7 7" stroke="'+K+'" stroke-width="5"/>';
  return s+'</svg>'}
 var L=$('lab');
 if(L){var lab=GX.ls('lab.cur')||'semi';
  function labOf(){return LABS.filter(function(x){return x.id===lab})[0]||LABS[0]}
  function runLab(){var cfg=labOf(),rounds=6,rd=0,score=0,found=0,missed=0,fp=0;
   function tabs(){return '<div class="olyrow"><span class="olyc">실험실</span>'+LABS.map(function(l){return '<button class="gtab'+(l.id===lab?' on':'')+'" data-l="'+l.id+'">'+l.n+'</button>'}).join('')+'</div>'}
   function round(){var nb=ri(1,3),its=[];for(var i=0;i<6;i++){var b=item();its.push(i<nb?badOf(b):goodOf(b))}its=sh(its);var sel={};
    L.innerHTML=tabs()+''+labScene(cfg.id,cfg.col)+'<div class="labhd" style="--lc:'+cfg.col+'"><b>'+esc(cfg.n)+'</b><span>'+esc(cfg.lead)+'</span></div><div class="gbar"><span>실험 <b>'+(rd+1)+' / '+rounds+'</b></span><span>점수 <b>'+score+'</b></span><span>불량 후보 <b id="lcnt">0</b>개 표시</span><span>이 랩에서 흔히 쓰는 양식 <b>'+esc(sname(cfg.like))+'</b></span></div>'
     +'<div class="labgrid">'+its.map(function(it,i){return '<button class="labv" data-i="'+i+'" aria-pressed="false"><span class="lvi">'+vessel(cfg.vi,cfg.col,false)+'</span><span class="lvt">'+it.shown.map(mk).join(' ')+'</span></button>'}).join('')+'</div>'
     +'<p class="mut">이번 실험에는 불량이 <b>1~3개</b> 섞여 있습니다. 불량이라고 생각하는 '+esc(cfg.v)+'을(를) 눌러 표시한 뒤 분석을 시작하세요.</p><div class="gbtns"><button class="gprimary" id="labgo">분석 시작</button></div><div id="labres"></div>';
    L.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){lab=b.dataset.l;GX.ls('lab.cur',lab);runLab()}});
    L.querySelectorAll('.labv').forEach(function(b){b.onclick=function(){var i=+b.dataset.i;sel[i]=!sel[i];b.classList.toggle('on',!!sel[i]);b.setAttribute('aria-pressed',sel[i]?'true':'false');b.querySelector('.lvi').innerHTML=vessel(cfg.vi,cfg.col,!!sel[i]);$('lcnt').textContent=Object.keys(sel).filter(function(k){return sel[k]}).length}});
    $('labgo').onclick=function(){$('labgo').disabled=true;var hit=0,mis=0,fa=0,out='';
     its.forEach(function(it,i){var b=L.querySelectorAll('.labv')[i],on=!!sel[i];b.disabled=true;
      if(it.bad&&on){hit++;b.classList.add('res-ok')}else if(it.bad&&!on){mis++;b.classList.add('res-miss')}else if(!it.bad&&on){fa++;b.classList.add('res-fp')}
      if(it.bad)out+='<div class="labfind '+(on?'ok':'miss')+'"><b>'+(on?'불량을 찾았어요':'놓친 불량')+'</b>'+GX.whyPanel(it,false)+'</div>';
      else if(on)out+='<div class="labfind fp"><b>정상인데 불량으로 표시했어요</b><div class="wrow">'+it.shown.map(mk).join(' ')+'</div><p class="mut">이 표기는 내 양식('+esc(sname(it.sid))+')의 규칙에 맞습니다. 순서: '+esc(GX.ORD[it.sid]||'')+'</p></div>'});
     var gain=hit*25-mis*15-fa*10;score=Math.max(0,score+gain);found+=hit;missed+=mis;fp+=fa;
     $('labres').innerHTML='<div class="labsum">불량 '+(hit+mis)+'개 중 <b>'+hit+'</b>개 발견 · 놓침 '+mis+' · 오표시 '+fa+' → 이번 점수 '+(gain>=0?'+':'')+gain+'</div>'+out+'<div class="gbtns"><button class="gprimary" id="labnx">'+(rd+1>=rounds?'결과 보기':'다음 실험 →')+'</button></div>';
     $('labnx').onclick=function(){rd++;if(rd>=rounds){L.innerHTML='';GX.win(L,missed+fp<=2?3:missed+fp<=6?2:1,'실험 종료!',rounds+'번의 실험에서 불량 '+found+'개를 찾았습니다(놓침 '+missed+', 오표시 '+fp+').','한 번 더',runLab,'lab',score,cfg.n+' · 발견 '+found)}else round()};
     $('labres').scrollIntoView({behavior:'smooth',block:'nearest'})}}
   round()}
  runLab()}
 // ===== B. 노벨상 도전 Nature식 =====
 var NOBP=[
  {f:'물리',id:'nov',a:[['Novoselov','K. S.'],['Geim','A. K.'],['Morozov','S. V.'],['Jiang','D.'],['Zhang','Y.'],['Dubonos','S. V.'],['Grigorieva','I. V.'],['Firsov','A. A.']],t:'Electric field effect in atomically thin carbon films',j:'Science',v:306,p1:666,p2:669,y:2004,note:'그래핀을 분리해 전기적 성질을 보인 논문. 공저자 가임·노보셀로프가 2010년 노벨 물리학상을 받았습니다.'},
  {f:'물리',id:'hin',a:[['Rumelhart','D. E.'],['Hinton','G. E.'],['Williams','R. J.']],t:'Learning representations by back-propagating errors',j:'Nature',v:323,p1:533,p2:536,y:1986,note:'오차 역전파를 알린 논문. 공저자 힌턴이 2024년 노벨 물리학상(홉필드와 공동)을 받았습니다.'},
  {f:'화학',id:'jum',a:[['Jumper','J.'],['Evans','R.'],['Pritzel','A.'],['Green','T.'],['Figurnov','M.'],['Ronneberger','O.']],etal:1,t:'Highly accurate protein structure prediction with AlphaFold',j:'Nature',v:596,p1:583,p2:589,y:2021,note:'단백질 구조를 예측한 논문. 공저자 점퍼가 2024년 노벨 화학상(베이커·허사비스와 공동)을 받았습니다. 실제 저자는 더 많고, 이 게임은 앞 여섯 명만 보였습니다.'},
  {f:'화학',id:'jin',a:[['Jinek','M.'],['Chylinski','K.'],['Fonfara','I.'],['Hauer','M.'],['Doudna','J. A.'],['Charpentier','E.']],t:'A programmable dual-RNA–guided DNA endonuclease in adaptive bacterial immunity',j:'Science',v:337,p1:816,p2:821,y:2012,note:'유전자 가위(CRISPR-Cas9)의 원리를 보인 논문. 공저자 샤르팡티에·다우드나가 2020년 노벨 화학상을 받았습니다.'},
  {f:'생리·의학',id:'wat',a:[['Watson','J. D.'],['Crick','F. H. C.']],t:'Molecular structure of nucleic acids: a structure for deoxyribose nucleic acid',j:'Nature',v:171,p1:737,p2:738,y:1953,note:'DNA 이중나선 구조를 제안한 논문. 두 저자가 1962년 노벨 생리·의학상(윌킨스와 공동)을 받았습니다.'},
  {f:'생리·의학',id:'fir',a:[['Fire','A.'],['Xu','S.'],['Montgomery','M. K.'],['Kostas','S. A.'],['Driver','S. E.'],['Mello','C. C.']],t:'Potent and specific genetic interference by double-stranded RNA in Caenorhabditis elegans',j:'Nature',v:391,p1:806,p2:811,y:1998,note:'RNA 간섭을 발견한 논문. 공저자 파이어·멜로가 2006년 노벨 생리·의학상을 받았습니다.'}];
 var NOBR='Nature식 참고문헌: 저자는 “성, 이니셜 이니셜.”(이니셜 사이 한 칸), 마지막 저자 앞은 “&”, 6명 이상이면 첫 저자 뒤에 et al., 제목은 문장식 대문자, 학술지는 이탤릭, 권은 굵게, 쪽은 “시작–끝”, 연도는 마지막에 괄호로 씁니다.';
 function nobPieces(p){var au=p.a,A;if(au.length>=6)A=au[0][0]+', '+au[0][1]+' et al.';else{var s=au.map(function(x){return x[0]+', '+x[1]});A=s.length>1?s.slice(0,-1).join(', ')+' & '+s[s.length-1]:s[0]}return [A,p.t+'.','__'+p.j+'__','**'+p.v+'**,',p.p1+'–'+p.p2,'('+p.y+').']}
 function nobBad(p,pc){var c=pc.slice(),k=pick(['and','titlecase','nobold','year','hyph','etal','init','noital','dot']),r;
  var A=c[0];
  if(k==='and'&&/ & /.test(A)){c[0]=A.replace(' & ',' and ');return {c:c,hi:[0],why:'마지막 저자 앞에 “and”를 썼습니다.',rule:'Nature식은 마지막 저자 앞에 “&”를 씁니다.',tip:'“&”: Nature · APA. “and”: MLA · Chicago · IEEE.'}}
  if(k==='etal'&&p.a.length>=6){c[0]=p.a.map(function(x){return x[0]+', '+x[1]}).slice(0,-1).join(', ')+' & '+p.a[p.a.length-1][0]+', '+p.a[p.a.length-1][1];return {c:c,hi:[0],why:'저자 여섯 명을 모두 썼습니다.',rule:'Nature식은 저자가 6명 이상이면 첫 저자만 쓰고 “et al.”로 줄입니다.',tip:'6명 이상이면 “첫 저자 et al.”. 5명 이하는 전원.'}}
  if(k==='etal'&&p.a.length<6&&p.a.length>1){c[0]=p.a[0][0]+', '+p.a[0][1]+' et al.';return {c:c,hi:[0],why:'저자가 '+p.a.length+'명뿐인데 “et al.”로 줄였습니다.',rule:'Nature식은 5명 이하면 저자를 모두 씁니다.',tip:'줄이는 기준은 6명부터입니다.'}}
  if(k==='titlecase'){c[1]=GX.tcase(p.t)+'.';if(c[1]!==pc[1])return {c:c,hi:[1],why:'논문 제목의 단어마다 첫 글자를 대문자로 썼습니다(Title Case).',rule:'Nature식은 제목을 문장식 대문자로 씁니다. 첫 단어와 고유명사(예: AlphaFold, Caenorhabditis)만 대문자입니다.',tip:'제목 대문자는 양식마다 다릅니다. Nature·APA·IEEE·Vancouver는 문장식.'}}
  if(k==='nobold'){c[3]=p.v+',';return {c:c,hi:[3],why:'권 번호가 굵게 되어 있지 않습니다.',rule:'Nature식은 권 번호를 굵게 씁니다.',tip:'학술지는 기울임, 권은 굵게. 둘을 짝으로 기억하세요.'}}
  if(k==='noital'){c[2]=p.j;return {c:c,hi:[2],why:'학술지 이름이 기울임 없이 곧게 쓰였습니다.',rule:'Nature식은 학술지 이름을 이탤릭으로 씁니다.',tip:'학술지는 기울임, 권은 굵게.'}}
  if(k==='year'){c.splice(5,1);c.splice(1,0,'('+p.y+').');return {c:c,hi:[1],why:'연도를 저자 바로 뒤로 옮겼습니다.',rule:'Nature식은 연도를 맨 끝에 괄호로 씁니다. 저자–연도(APA) 순서가 아닙니다.',tip:'Nature는 “… 쪽 (연도).” 로 끝납니다.'}}
  if(k==='hyph'){c[4]=p.p1+'-'+p.p2;return {c:c,hi:[4],why:'쪽 범위를 짧은 하이픈(-)으로 이었습니다.',rule:'쪽 범위는 엔 대시(–)로 잇습니다.',tip:'숫자 범위는 엔 대시.'}}
  if(k==='init'&&!(p.a.length>=6)){var x=p.a[0];c[0]=A.replace(x[1],x[1].replace(/\./g,'').replace(/ /g,''));if(c[0]!==A)return {c:c,hi:[0],why:'이니셜의 점과 간격이 빠졌습니다.',rule:'Nature식은 이니셜을 “K. S.”처럼 점과 한 칸으로 씁니다.',tip:'이니셜은 한 글자마다 점과 띄어쓰기.'}}
  c=pc.slice();c[5]=c[5].replace(/\.$/,'');return {c:c,hi:[5],why:'항목 끝의 마침표가 빠졌습니다.',rule:'참고문헌 항목은 마침표로 끝납니다.',tip:'연도 괄호 뒤에도 마침표.'}}

  function nobArt(f){var s='<svg class="nobsc" viewBox="0 0 720 140" role="img" aria-label="분야 그림">',i;
   function ci(x,y,r,fl,st){return '<circle cx="'+x+'" cy="'+y+'" r="'+r+'" fill="'+fl+'"'+(st?' stroke="'+st+'" stroke-width="2"':'')+'/>'}
   if(f==='물리'){s+='<rect width="720" height="140" fill="#10183a"/>';for(i=0;i<40;i++)s+=ci((i*97)%720,(i*53)%140,1.2,'#fff');
    s+='<g transform="translate(150 70)"><ellipse rx="70" ry="24" fill="none" stroke="#7fd1ff" stroke-width="2"/><ellipse rx="70" ry="24" fill="none" stroke="#7fd1ff" stroke-width="2" transform="rotate(60)"/><ellipse rx="70" ry="24" fill="none" stroke="#7fd1ff" stroke-width="2" transform="rotate(-60)"/>'+ci(0,0,9,'#ffd24a')+ci(66,6,5,'#fff')+ci(-33,58,5,'#fff')+ci(-33,-58,5,'#fff')+'</g>';
    s+='<path d="M330 100q40-80 80 0t80 0t80 0" fill="none" stroke="#ff8a73" stroke-width="4"/><path d="M330 100q40-80 80 0t80 0t80 0" fill="none" stroke="#7dffb0" stroke-width="2" opacity=".6" transform="translate(0 6)"/><text x="360" y="130" font-size="14" fill="#cdd6ff">파동 · 입자 · 전자</text>';
    s+='<path d="M600 30l-20 40h16l-12 36 34-48h-18l14-28z" fill="#ffd24a"/>'}
   else if(f==='화학'){s+='<rect width="720" height="140" fill="#e7f6ef"/><rect y="108" width="720" height="32" fill="#b8e0cf"/>';
    s+='<path d="M60 30h26v26l30 52H30l30-52z" fill="#fff" stroke="#238f82" stroke-width="2"/><path d="M36 96h74l6 12H30z" fill="#58c4a8"/><path d="M170 20h20v30l24 58h-68l24-58z" fill="#fff" stroke="#238f82" stroke-width="2"/><path d="M158 90h44l8 18h-60z" fill="#ffd24a"/>';
    var H=[[360,70],[400,48],[440,70],[440,100],[400,122],[360,100]];s+='<polygon points="'+H.map(function(p){return p.join(',')}).join(' ')+'" fill="none" stroke="#238f82" stroke-width="3"/>';H.forEach(function(p,j){s+=ci(p[0],p[1],10,['#e0554f','#4a6bd0','#ffd24a'][j%3],'#fff')});
    s+=ci(520,60,12,'#4a6bd0','#fff')+ci(552,76,9,'#fff','#238f82')+ci(520,92,9,'#fff','#238f82')+'<line x1="520" y1="60" x2="552" y2="76" stroke="#238f82" stroke-width="3"/><line x1="520" y1="60" x2="520" y2="92" stroke="#238f82" stroke-width="3"/><text x="580" y="70" font-size="14" fill="#1b6a60">분자 · 반응</text>'}
   else{s+='<rect width="720" height="140" fill="#fbe9f2"/><rect y="112" width="720" height="28" fill="#e4b9cf"/>';
    s+='<path d="M120 10c60 30 60 50 0 70s-60 40 0 60M200 10c-60 30-60 50 0 70s60 40 0 60" fill="none" stroke="#c0457a" stroke-width="4"/>';for(i=0;i<5;i++)s+='<line x1="140" y1="'+(26+i*26)+'" x2="180" y2="'+(26+i*26)+'" stroke="#7a2e55" stroke-width="2.5"/>';
    s+='<rect x="330" y="96" width="130" height="14" rx="3" fill="#7a2e55"/><rect x="390" y="40" width="20" height="58" rx="3" fill="#7a2e55"/>'+ci(400,36,18,'#fff','#7a2e55')+'<rect x="440" y="62" width="40" height="10" rx="3" fill="#7a2e55"/>';
    s+='<path d="M560 30v40a22 22 0 0 0 44 0V30" fill="none" stroke="#c0457a" stroke-width="5"/>'+ci(582,96,10,'#fff','#c0457a')+'<path d="M650 40h30M665 25v30" stroke="#e0554f" stroke-width="10" stroke-linecap="round"/>'}
   s+='<g transform="translate(666 26)"><circle r="20" fill="#f6d77a" stroke="#a8791a" stroke-width="3"/><circle r="13" fill="none" stroke="#a8791a" stroke-width="1.5"/><text y="5" font-size="13" text-anchor="middle" fill="#7a5410" font-weight="700">N</text></g>';return s+'</svg>'}
  var NOBSRC={'전체':'https://www.nobelprize.org/prizes/','물리':'https://www.nobelprize.org/prizes/physics/','화학':'https://www.nobelprize.org/prizes/chemistry/','생리·의학':'https://www.nobelprize.org/prizes/medicine/'};
 var NB=$('nob');
 if(NB){var fld=GX.ls('nob.f')||'전체';
  function startNob(){GX.judgeGame(NB,{gid:'nob',skin:'lever',icons:['★','✖'],ask:'이 참고문헌은 <b>Nature식</b>에 맞을까요? 맞으면 “수상 논문 인정”, 틀리면 “다시 쓰기”를 누르세요.',okL:'수상 논문 인정',badL:'다시 쓰기',goodW:'인정!',badW:'오답',unit:'논문',rounds:8,doneT:'도전 완료!',
   top:function(pg){var m=Math.min(3,Math.floor(pg*3.2));return '<div class="nobtop"><div class="nobmed">'+[0,1,2].map(function(i){return '<i class="'+(i<m?'on':'')+'">★</i>'}).join('')+'</div><p class="mut">Nature식 규칙: '+esc(NOBR)+'</p>'+nobTabs()+nobArt(fld==='전체'?['물리','화학','생리·의학'][Math.floor(pg*7)%3]:fld)+'<p class="mut nobsrc">노벨상 수상자 소개와 업적은 <a href="'+NOBSRC[fld]+'" target="_blank" rel="noopener">노벨상 공식 사이트(nobelprize.org)</a>에서 볼 수 있습니다(이 제작 과정에서는 접속해 확인하지 못했으니 직접 열어 확인하세요). 수상자 사진은 저작권·초상 문제로 이 홈페이지에 넣지 않고 그림으로 대신했습니다.</p></div>'},
   item:function(){var P=NOBP.filter(function(x){return fld==='전체'||x.f===fld});var p=pick(P),pc=nobPieces(p),bad=Math.random()<.5,b=bad?nobBad(p,pc):null;
     window._nobNote=p.note;
     return {shown:bad?b.c:pc,bad:bad,why:bad?b.why:'',fix:pc,hi:bad?b.hi:null,rule:bad?b.rule:'',tip:bad?b.tip:'',sid:'nature',
      panel:function(right){var note='<div class="wr"><b>이 논문은</b><p>['+esc(p.f)+'] '+esc(p.note)+'</p></div>';if(!bad)return '<details class="why"'+(right?'':' open')+'><summary>왜 맞는 표기일까요?</summary><div class="wr"><b>규칙</b><p>'+esc(NOBR)+'</p></div>'+note+'</details>';
       return '<details class="why"'+(right?'':' open')+'><summary>'+(right?'틀린 이유 자세히 보기':'왜 틀렸을까요?')+'</summary><div class="wr"><b>보인 표기</b><div class="wrow">'+GX.hiRow(b.c,b.hi)+'</div></div><div class="wr"><b>무엇이 틀렸나</b><p>'+esc(b.why)+'</p></div><div class="wr"><b>규칙</b><p>'+esc(b.rule)+'</p></div><div class="wr"><b>바른 표기</b><div class="wrow">'+pc.map(mk).join(' ')+'</div></div><div class="wr tp"><b>기억 팁</b><p>'+esc(b.tip)+'</p></div>'+note+'</details>'}}},
   label:function(ok,en){return 'Nature식 · '+(fld==='전체'?'전 분야':fld)+' · '+ok+'건 정답'}})}
  function nobTabs(){return '<div class="olyrow"><span class="olyc">분야</span>'+['전체','물리','화학','생리·의학'].map(function(f){return '<button class="gtab'+(f===fld?' on':'')+'" data-nf="'+f+'">'+f+'</button>'}).join('')+'</div>'}
  NB.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-nf]');if(b){fld=b.dataset.nf;GX.ls('nob.f',fld);startNob()}});startNob()}
 // ===== C. 사격 훈련 =====
 var SHT=$('shoot');
 if(SHT){function runShoot(){var rounds=10,rd=0,score=0,hits=0,wild=0,mis=0;
   function round(){var good=[item(),item(),item()].map(goodOf),bd=badOf(item()),its=sh(good.concat([bd])),ammo=2,done=false,spd=Math.max(5,11-rd*.5);
    SHT.innerHTML='<div class="gbar"><span>표적 <b>'+(rd+1)+' / '+rounds+'</b></span><span>점수 <b>'+score+'</b></span><span>남은 탄 <b id="amm">'+ammo+'</b></span></div><p class="mut">종이 표적 네 장이 지나갑니다. <b>내 인용 스타일 규칙을 어긴 표적 한 장</b>만 조준해 눌러 주세요. 잘못 맞힌 표적은 “아군”이므로 감점입니다.</p>'
     +'<div class="range"><svg class="rg-bg" viewBox="0 0 800 300" preserveAspectRatio="none" aria-hidden="true"><rect width="800" height="300" fill="#cfe6f3"/><path d="M0 170Q200 120 400 160T800 140V300H0Z" fill="#a9c79a"/><path d="M0 220H800V300H0Z" fill="#c9b48a"/><path d="M0 220H800" stroke="#8c7a52" stroke-width="3"/><path d="M60 224V300M740 224V300" stroke="#8c7a52" stroke-width="2"/></svg>'
     +its.map(function(it,i){return '<button class="tgt" data-i="'+i+'" style="--y:'+(3+i*24.5)+'%;--dur:'+(spd+i*.8)+'s;--dl:'+(-i*1.7)+'s"><span class="tgtc">'+it.shown.map(mk).join(' ')+'</span><i class="tgtr"></i></button>'}).join('')+'<div class="xh" aria-hidden="true"></div></div><div id="shres" aria-live="polite"></div>';
    var R=SHT.querySelector('.range'),xh=R.querySelector('.xh');R.onmousemove=function(e){var b=R.getBoundingClientRect();xh.style.left=(e.clientX-b.left)+'px';xh.style.top=(e.clientY-b.top)+'px'};
    var tmo=setTimeout(function(){end(null)},(spd+4)*1000);
    function end(i){if(done)return;done=true;clearTimeout(tmo);R.classList.add('stop');var t=its[i];SHT.querySelectorAll('.tgt').forEach(function(b,j){b.disabled=true;if(its[j].bad)b.classList.add('isbad')});
     var msg,gain=0;if(i==null){mis++;gain=-10;msg='<b class="not">시간 종료!</b> 틀린 표적을 놓쳤습니다.'}else if(t.bad){hits++;gain=30+(ammo>=2?10:0);msg='<b class="okt">명중!</b> 규칙을 어긴 표적을 맞혔습니다.'}else{wild++;gain=-20;msg='<b class="not">아군 표적입니다!</b> 이 표적은 규칙에 맞는 표기였습니다.'}
     score=Math.max(0,score+gain);$('shres').innerHTML='<div class="gfb">'+msg+' ('+(gain>=0?'+':'')+gain+')</div>'+GX.whyPanel(bd,t&&t.bad)+'<div class="gbtns"><button class="gprimary" id="shn">'+(rd+1>=rounds?'결과 보기':'다음 표적 →')+'</button></div>';
     $('shn').onclick=function(){rd++;if(rd>=rounds){SHT.innerHTML='';GX.win(SHT,hits>=8?3:hits>=5?2:1,'훈련 종료!','10장 중 틀린 표적 '+hits+'장을 맞혔습니다(오사 '+wild+', 놓침 '+mis+').','다시 훈련',runShoot,'shoot',score,'명중 '+hits+' · 오사 '+wild)}else round()}}
    SHT.querySelectorAll('.tgt').forEach(function(b){b.onclick=function(){if(done)return;ammo--;$('amm').textContent=ammo;end(+b.dataset.i)}})}
   round()}
  runShoot()}
 // ===== D. 보안 개발자: 해커 막기 =====
 var SC=$('sec');
 if(SC){var hp=100,miss0=0;
  GX.judgeGame(SC,{gid:'sec',skin:'term',icons:['',''],ask:'들어오는 <b>참고문헌 패킷</b>이 내 양식 규칙에 맞는지 검사하세요. 맞으면 ALLOW, 틀린 것은 해커의 위조 패킷이니 BLOCK!',okL:'[ALLOW] 통과시킨다',badL:'[BLOCK] 차단한다',goodW:'정상 처리',badW:'침투 성공…',unit:'패킷',rounds:12,doneT:'방어 종료!',
   top:function(p){return '<div class="sechd"><div class="secsv">서버 HP <span class="sechp"><i id="sechpi" style="width:'+hp+'%"></i></span> <b id="sechpn">'+hp+'%</b></div><div class="secfeed" id="secfeed">&gt; 방화벽 가동 중… 위조된 서지 패킷은 서버를 감염시킵니다.</div></div>'},
   onMove:function(h,p,r,ok,i){hp=Math.max(0,100-8*(i+1-ok));var a=h.querySelector('#sechpi'),n=h.querySelector('#sechpn'),f=h.querySelector('#secfeed');if(a)a.style.width=hp+'%';if(n)n.textContent=hp+'%';if(f)f.textContent=r?'> 패킷 처리 완료. 서버 상태 양호.':'> 경고! 잘못된 판정으로 서버가 손상되었습니다.'},
   item:function(){return mkItem()},label:function(ok,en){return '방화벽 '+(en?'무한 방어 · ':'· ')+ok+'건 처리'}})}
 // ===== E. 수식·표·그림 위치 맞추기 =====
 var PL=$('plc');
 if(PL){
  var SLOT={top:'위',bottom:'아래',right:'오른쪽 끝',center:'가운데',after:'수식 바로 뒤',left:'왼쪽'};
  var PLQ=[
   {k:'tab',cat:'table',lab:'표 번호·제목',zone:'table',slots:['top','bottom','left'],ans:'top',styles:['apa','mla','cad','nb','ieee','van'],
    why:{apa:'APA: 표 번호는 굵게, 그 아래 제목은 이탤릭으로 표 위에 씁니다(이 안내서 7장).',mla:'MLA: 표 위에 “Table 1”과 제목을 같은 줄에 씁니다(9장).',cad:'Chicago: 표 번호·제목은 표 위에 씁니다(8장).',nb:'Chicago: 표 번호·제목은 표 위에 씁니다(10장).',ieee:'IEEE: 표 위에 “TABLE I”(로마 숫자)와 제목을 가운데 맞춤으로 씁니다(11장).',van:'Vancouver: 표 위에 “Table 1”을 씁니다(12장).'},tip:'표는 위, 그림은 아래 — “표는 머리말, 그림은 발밑 설명”으로 외우세요.'},
   {k:'fig',cat:'figure',lab:'그림 번호·제목',zone:'figure',slots:['top','bottom'],ans:'bottom',ansBy:{apa:'top'},styles:['apa','mla','cad','nb','van'],
    why:{apa:'APA: 그림도 번호·제목을 그림 위에 둡니다(7장).',mla:'MLA: 그림 캡션(Fig. 1.)은 그림 아래에 씁니다(8장).',cad:'Chicago: 그림 번호·제목은 그림 아래에 씁니다(9장).',nb:'Chicago: 그림 번호·제목은 그림 아래에 씁니다(10장).',van:'Vancouver: 그림 아래에 “Figure 1.”과 제목을 씁니다(12장).'},tip:'APA만 그림도 위! 나머지는 표는 위, 그림은 아래.'},
   {k:'graph',cat:'graph',lab:'그래프 번호·제목',zone:'graph',slots:['top','bottom'],ans:'bottom',ansBy:{apa:'top'},styles:['apa','mla','cad','nb','van'],
    why:{apa:'APA: 그래프도 그림(Figure)이라서 번호·제목을 그래프 위에 둡니다(7장).',mla:'MLA: 그래프도 그림이라 캡션(Fig. 2.)을 아래에 씁니다(8장).',cad:'Chicago: 그래프도 그림이라 번호·제목을 아래에 씁니다(9장).',nb:'Chicago: 그래프도 그림이라 번호·제목을 아래에 씁니다(10장).',van:'Vancouver: 그림 아래에 “Figure 2.”와 제목을 씁니다(12장).'},tip:'그래프는 “그림의 한 종류”라서 그림과 같은 자리!'},
   {k:'gsrc',cat:'graph',lab:'그래프 자료 출처',zone:'graph',slots:['top','bottom'],ans:'bottom',styles:['apa','mla','cad','nb'],
    why:{apa:'APA: 출처·주(Note.)는 그림 아래 줄에 씁니다(7장).',mla:'MLA: 출처(Source:)는 그림 아래에 씁니다(8장).',cad:'Chicago: 자료 출처는 그림 아래 줄에 씁니다(9장).',nb:'Chicago: 자료 출처는 그림 아래 줄에 씁니다(10장).'},tip:'번호·제목이 위라도, 출처는 아래 줄!'},
   {k:'tnote',cat:'table',lab:'표의 주·출처',zone:'table',slots:['top','bottom','left'],ans:'bottom',styles:['apa','mla'],
    why:{apa:'APA: 표 번호·제목은 표 위, 주(Note.)는 표 아래에 씁니다(7장).',mla:'MLA: 캡션은 표 위, 출처는 표 아래에 씁니다(9장).'},tip:'제목은 위, 설명·출처는 아래.'},
   {k:'eqn',cat:'eq',lab:'수식 번호 (1)',zone:'eq',slots:['left','center','right'],ans:'right',styles:['apa','mla','cad','nb','ieee','van','acs'],
    why:{_:'수식 번호는 괄호 안에 넣어 오른쪽 끝에 맞추고 보고서 전체에서 연속으로 붙입니다(부록 10, IEEE 논문 틀 기준).'},tip:'수식은 가운데, 번호는 오른쪽 끝!'},
   {k:'eqc',cat:'eq',lab:'별행 수식',zone:'eq2',slots:['left','center','right'],ans:'center',styles:['apa','mla','cad','nb','ieee','van','acs'],
    why:{_:'별행 수식은 가운데에 맞춥니다(부록 10, IEEE 논문 틀 기준).'},tip:'수식은 가운데, 번호는 오른쪽 끝!'},
   {k:'eqsym',cat:'eq',lab:'기호 설명 (“여기서 x는 …”)',zone:'eq3',slots:['top','after','bottom'],ans:'after',styles:['apa','mla','cad','nb','ieee','van','acs'],
    why:{_:'기호는 수식 앞에서 먼저 정의하거나 수식 바로 뒤에서 설명합니다(부록 10). 한참 뒤나 없는 것은 독자를 헤매게 합니다.'},tip:'기호는 “나오기 전”이나 “나온 바로 뒤”에 정의합니다.'}];
  var PREV={tab:'표 1. 학년별 응답자 수',fig:'그림 1. 인용 검증 과정',graph:'그림 2. 학년별 출처 확인 비율',gsrc:'자료: 연습용 가상 자료, 그래프: 필자 작성',tnote:'주. 출처: 연습용 가상 자료',eqn:'(1)',eqc:'E = mc²',eqsym:'여기서 E는 에너지, m은 질량, c는 빛의 속도이다.'};
  var EMO={tab:'📊',fig:'🖼️',graph:'📈',gsrc:'🔖',tnote:'📝',eqn:'🔢',eqc:'🧮',eqsym:'💡'};
  function pzone(q){
   var slot=function(id,txt,cls){return '<button type="button" class="plslot '+(cls||'')+'" data-s="'+id+'"><span class="plg">'+txt+'</span></button>'};
   var ln=function(w){return '<i class="ln" style="width:'+w+'%"></i>'};
   var body='<div class="pgbody">'+ln(96)+ln(88)+ln(92)+ln(60)+'</div>';
   var tbl='<table class="pgt"><tr><th>구분</th><th>응답</th><th>비율</th></tr><tr><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td></tr></table>';
   var dg='<svg class="pgf" viewBox="0 0 160 60"><rect x="4" y="18" width="40" height="24" rx="5" fill="#dfe6f5" stroke="#3a5fb0" stroke-width="2"/><rect x="60" y="18" width="40" height="24" rx="5" fill="#fdebc8" stroke="#c47a2c" stroke-width="2"/><rect x="116" y="18" width="40" height="24" rx="5" fill="#d9f3e0" stroke="#2b8a56" stroke-width="2"/><path d="M46 30h12M102 30h12" stroke="#2b3558" stroke-width="2.5"/><path d="M58 30l-5 -4v8zM114 30l-5 -4v8z" fill="#2b3558"/></svg>',gr='<svg class="pgf" viewBox="0 0 120 70"><path d="M10 62H112M10 6V62" stroke="#2b3558" stroke-width="2"/><rect x="20" y="36" width="16" height="26" fill="#3a5fb0"/><rect x="44" y="24" width="16" height="38" fill="#4fa08f"/><rect x="68" y="14" width="16" height="48" fill="#c47a2c"/><rect x="92" y="30" width="16" height="32" fill="#8272b5"/></svg>';var fg='<svg class="pgf" viewBox="0 0 120 70"><path d="M5 60L35 30L60 45L95 10L115 25" stroke="#3a5fb0" stroke-width="3" fill="none"/><circle cx="35" cy="30" r="3" fill="#3a5fb0"/><circle cx="95" cy="10" r="3" fill="#3a5fb0"/><path d="M5 65H115M5 5V65" stroke="#2b3558" stroke-width="2"/></svg>';
   var h='<div class="pgm" data-z="'+q.zone+'"><div class="pgtag">연습용 가상 쪽</div>';
   if(q.zone==='table')h+='<p class="pgt1">본문: 표 1에 따르면 응답은 학년마다 다르다.</p>'+body+slot('top','▲ 여기? (표 위)')+tbl+slot('bottom','▼ 여기? (표 아래)')+'<div class="pgbody">'+ln(90)+ln(70)+'</div>';
   else if(q.zone==='figure')h+='<p class="pgt1">본문: 그림 1은 인용을 검증하는 과정을 보여 준다.</p>'+body+slot('top','▲ 여기? (그림 위)')+'<div class="pgfw">'+dg+'</div>'+slot('bottom','▼ 여기? (그림 아래)')+'<div class="pgbody">'+ln(90)+ln(70)+'</div>';
   else if(q.zone==='graph')h+='<p class="pgt1">본문: 그림 2는 학년별 출처 확인 비율을 막대그래프로 보여 준다.</p>'+body+slot('top','▲ 여기? (그래프 위)')+'<div class="pgfw">'+gr+'</div>'+slot('bottom','▼ 여기? (그래프 아래)')+'<div class="pgbody">'+ln(90)+ln(70)+'</div>';
   else if(q.zone==='eq3')h+='<p class="pgt1">본문: 에너지와 질량의 관계를 식으로 쓴다.</p>'+slot('top','▲ 여기? (수식 앞)')+'<div class="pgeq"><span class="eqf">E = mc<sup>2</sup></span><small>(1)</small></div>'+slot('after','▼ 여기? (수식 바로 뒤)')+'<div class="pgbody">'+ln(92)+ln(70)+'</div><p class="pgdots">⋮ (몇 쪽 뒤) ⋮</p>'+slot('bottom','▼ 여기? (한참 뒤 · 부록)');
   else if(q.zone==='eq')h+='<p class="pgt1">본문: 에너지와 질량의 관계는 다음과 같다.</p><div class="pgeq3"><div class="c1">'+slot('left','◀ 왼쪽')+'</div><div class="c2"><span class="eqf">E = mc<sup>2</sup></span>'+slot('center','가운데(수식 아래)','sm')+'</div><div class="c3">'+slot('right','오른쪽 끝 ▶')+'</div></div>'+body;
   else h+='<p class="pgt1">본문: 에너지와 질량의 관계는 다음과 같다.</p><div class="pgeq3"><div class="c1">'+slot('left','◀ 왼쪽')+'</div><div class="c2">'+slot('center','가운데')+'</div><div class="c3">'+slot('right','오른쪽 ▶')+'</div></div>'+body;
   return h+'</div>'}
  function runPl(){var sid=GX.myId(),sid2=sid,Q=PLQ.filter(function(q){return q.styles.indexOf(sid)>=0});if(!Q.length){sid2='apa';Q=PLQ.filter(function(q){return q.styles.indexOf('apa')>=0})}
   var ansOf=function(q){return (q.ansBy&&q.ansBy[sid2])||q.ans},cats={};Q.forEach(function(q){(cats[q.cat]=cats[q.cat]||[]).push(q)});var order=sh(Object.keys(cats)),rounds=8,seq=[],used={},ci=0;while(seq.length<rounds){var cl=cats[order[ci%order.length]].filter(function(q){return !used[q.k]});if(!cl.length){cats[order[ci%order.length]].forEach(function(q){used[q.k]=0});cl=cats[order[ci%order.length]]}var pk=sh(cl)[0];used[pk.k]=1;seq.push(pk);ci++}var i=0,score=0,miss=0,combo=0,best=0,done=[];
   function fillHtml(q){var p=PREV[q.k];if(q.k==='eqc')return '<span class="eqf">E = mc<sup>2</sup></span>';if(q.k==='eqn')return '<span class="pnum">(1)</span>';return '<span class="pcap '+q.k+'">'+esc(p)+'</span>'}
   function show(){var q=seq[i];PL.innerHTML=(sid2!==sid?'<p class="mut warn">이 안내서는 '+esc(sname(sid))+'의 표·그림 위치를 따로 정하지 않아 APA로 연습합니다.</p>':'')+'<div class="gbar"><span>문제 <b>'+(i+1)+' / '+rounds+'</b></span><span>점수 <b>'+score+'</b></span><span>연속 <b>'+(combo?'🔥'+combo:'0')+'</b></span><span>양식 <b>'+esc(sname(sid2))+'</b></span></div><div class="plhold"><div class="plhl">✋ 지금 손에 든 조각</div><div class="plgrip"><svg class="plhand" viewBox="0 0 70 60" aria-hidden="true"><rect x="0" y="22" width="24" height="18" rx="4" fill="#5b6b8c"/><path d="M22 20 h20 q10 0 10 10 v6 q0 10 -10 10 h-20z" fill="#f2c9a0" stroke="#c99a6e" stroke-width="2"/><path d="M52 24 q12 -2 14 6 q-2 8 -14 6" fill="#f2c9a0" stroke="#c99a6e" stroke-width="2"/><path d="M34 22 v-8 M42 22 v-10 M50 23 v-8" stroke="#c99a6e" stroke-width="2" stroke-linecap="round"/></svg><div class="plpiece"><small>이 조각을 붙일 자리는?</small><div class="plpv">'+fillHtml(q)+'</div><b>'+EMO[q.k]+' '+esc(q.lab)+'</b></div></div><div class="plarrow">↓ 아래 쪽에서 알맞은 빈자리를 누르세요</div></div>'+pzone(q)+'<div class="gfb" id="plfb" aria-live="polite"></div>';
    PL.querySelectorAll('.plslot').forEach(function(b){b.onclick=function(){var ans=ansOf(q),ok=b.dataset.s===ans;var all=PL.querySelectorAll('.plslot');
     all.forEach(function(x){x.disabled=true});
     b.classList.add('filled',ok?'right':'wrong');b.innerHTML=fillHtml(q);var hd=PL.querySelector('.plhold');if(hd){hd.classList.add('empty');hd.querySelector('.plhl').textContent='🙌 손이 비었어요 — 조각을 붙였습니다'}
     if(!ok){all.forEach(function(x){if(x.dataset.s===ans){x.classList.add('filled','ghost');x.innerHTML=fillHtml(q)}});miss++;combo=0}else{score+=15+Math.min(combo,4)*3;combo++;best=Math.max(best,combo)}
     all.forEach(function(x){if(!x.classList.contains('filled'))x.classList.add('dim')});
     var why=q.why[sid2]||q.why._;$('plfb').innerHTML='<b class="'+(ok?'okt':'not')+'">'+(ok?(combo>1?'🔥 '+combo+'연속! 딱 맞는 자리!':'딱 맞는 자리!'):'자리가 달라요. 초록 점선이 알맞은 자리예요.')+'</b> 정답 위치: <b>'+esc(SLOT[ans]||ans)+'</b><details class="why" open><summary>왜 이 자리일까요?</summary><div class="wr"><b>규칙</b><p>'+esc(why)+'</p></div><div class="wr tp"><b>기억 팁</b><p>'+esc(q.tip)+'</p></div></details> <button class="gprimary" id="plnx">'+(i+1>=rounds?'결과 보기':'다음 →')+'</button>';
     done.push(ok);
     $('plnx').onclick=function(){i++;if(i>=rounds){PL.innerHTML='';GX.win(PL,miss<=1?3:miss<=3?2:1,'쪽 완성!',rounds+'문제 중 '+(rounds-miss)+'개를 제자리에 붙였습니다. 최고 연속 '+best+'번.','한 번 더',runPl,'plc',score,sname(sid2)+' · '+(rounds-miss)+'/'+rounds)}else show()}}})}
   show()}
  runPl()}

 // ===== F. 약어 뽑기 빙고 =====
 var AB=$('abingo');
 if(AB){var AD=JSON.parse($('d-abbr').textContent),zone=GX.ls('abg.z')||'all';
  var stamps=[];try{stamps=JSON.parse(GX.ls('abg.stamps')||'[]')}catch(e){}
  function zoneItems(z){if(z==='all'){var a=[];AD.forEach(function(c){c.items.forEach(function(x){a.push(x)})});var seen={};return a.filter(function(x){if(seen[x[0]])return false;seen[x[0]]=1;return true})}var c=AD.filter(function(x){return x.k===z})[0];return c?c.items:[]}
  function cage(){return '<svg class="abcage" viewBox="0 0 150 130" aria-hidden="true"><circle cx="70" cy="56" r="46" fill="#fffaf0" stroke="'+K+'" stroke-width="3"/><g><circle cx="48" cy="46" r="9" fill="#c46a5e"/><circle cx="70" cy="70" r="9" fill="#3a5fb0"/><circle cx="88" cy="42" r="9" fill="#d6b36a"/><circle cx="58" cy="76" r="8" fill="#7fa79c"/><circle cx="90" cy="68" r="8" fill="#8272b5"/></g><path d="M34 100L22 122M106 100L118 122M18 122H126" stroke="'+K+'" stroke-width="4" stroke-linecap="round"/><path d="M114 56h24l6 8" stroke="'+K+'" stroke-width="3" fill="none"/><circle cx="104" cy="54" r="4" fill="'+K+'"/></svg>'}
  function lines(n,m){var c=0,i,j;for(i=0;i<n;i++){var r=true,cl=true;for(j=0;j<n;j++){if(!m[i*n+j])r=false;if(!m[j*n+i])cl=false}if(r)c++;if(cl)c++}var d1=true,d2=true;for(i=0;i<n;i++){if(!m[i*n+i])d1=false;if(!m[i*n+(n-1-i)])d2=false}if(d1)c++;if(d2)c++;return c}
  function runAb(){var all=zoneItems(zone),n=all.length>=25?5:all.length>=16?4:3,need=n*n,board=sh(all).slice(0,need),balls=sh(board),bi=0,mark=[],score=0,miss=0,got=0,prevL=0,target=n===5?3:2,hinted=false;
   function chips(){return '<div class="olyrow abz"><span class="olyc">모험 지도</span>'+AD.map(function(c){return '<button class="gtab'+(c.k===zone?' on':'')+'" data-z="'+c.k+'">'+(stamps.indexOf(c.k)>=0?'✔ ':'')+esc(c.z)+'</button>'}).join('')+'<button class="gtab'+(zone==='all'?' on':'')+'" data-z="all">'+(stamps.indexOf('all')>=0?'✔ ':'')+'전체 섞기 대모험</button></div>'}
   function draw(){var b=balls[bi];AB.innerHTML=chips()+'<div class="abtop"><div class="abm">'+cage()+'</div><div class="abclue"><span class="abball">?</span><div><small>'+(zone==='all'?'전체 모험':esc((AD.filter(function(c){return c.k===zone})[0]||{}).z||''))+' · 공 '+(bi+1)+' / '+balls.length+'</small><b id="abq">'+esc(b[1])+'</b><span id="abh" class="mut"></span></div></div><div class="abstat"><span>빙고 <b id="abl">'+prevL+'</b> / '+target+'줄</span><span>점수 <b id="abs">'+score+'</b></span><span>헛짚음 <b id="abx">'+miss+'</b></span></div></div>'
    +'<div class="abg" style="--n:'+n+'">'+board.map(function(x,i){return '<button class="abc'+(mark[i]?' done':'')+(x[0].length>9?' long':'')+'" data-i="'+i+'">'+esc(x[0])+'</button>'}).join('')+'</div><div class="gbtns"><button id="abhint">첫 글자 힌트</button></div><p class="mut abnote">뽑힌 공의 설명(뜻·원말)에 맞는 약어를 판에서 누르세요. 가로·세로·대각선 한 줄이 완성되면 빙고입니다. 약어의 쓰임은 양식·학술지에 따라 다를 수 있으니 처음 쓸 때는 규정을 확인하세요.</p><div class="gfb" id="abfb" aria-live="polite"></div>';
    AB.querySelectorAll('.gtab').forEach(function(t){t.onclick=function(){zone=t.dataset.z;GX.ls('abg.z',zone);runAb()}});
    $('abhint').onclick=function(){hinted=true;$('abh').textContent='힌트: 첫 글자는 “'+b[0].charAt(0)+'”';score=Math.max(0,score-3);$('abs').textContent=score};
    AB.querySelectorAll('.abc').forEach(function(c){c.onclick=function(){var i=+c.dataset.i;if(mark[i])return;
     if(board[i]===b){mark[i]=true;c.classList.add('done','pop');got++;score+=hinted?12:20;hinted=false;var L=lines(n,mark);if(L>prevL){score+=50*(L-prevL);prevL=L;$('abfb').innerHTML='<b class="okt">빙고!</b> '+L+'줄 완성 — 보너스 +50'}else $('abfb').innerHTML='<b class="okt">정답!</b> <b>'+esc(b[0])+'</b> = '+esc(b[1]);
      if(prevL>=target||bi+1>=balls.length){setTimeout(function(){if(stamps.indexOf(zone)<0){stamps.push(zone);GX.ls('abg.stamps',JSON.stringify(stamps))}AB.innerHTML='';GX.win(AB,miss<=3?3:miss<=8?2:1,'빙고 완성!',got+'개의 약어를 맞혔고 헛짚음은 '+miss+'번입니다. 지도에 ✔ 도장이 찍혔습니다.','다른 지도로 또 하기',runAb,'abbr',score,(zone==='all'?'전체':AD.filter(function(x){return x.k===zone})[0].z)+' · 빙고 '+prevL+'줄')},900);return}
      bi++;setTimeout(function(){var q=balls[bi];$('abq').textContent=q[1];$('abh').textContent='';$('abl').textContent=prevL;$('abs').textContent=score;var cb=AB.querySelector('.abball');if(cb){cb.classList.remove('roll');void cb.offsetWidth;cb.classList.add('roll')}b=q},700)}
     else{miss++;score=Math.max(0,score-5);c.classList.add('shk');setTimeout(function(){c.classList.remove('shk')},400);$('abx').textContent=miss;$('abs').textContent=score;$('abfb').innerHTML='<b class="not">아니에요.</b> “'+esc(board[i][0])+'”는 <b>'+esc(board[i][1])+'</b>입니다. 이 공의 설명과는 달라요.'}}})}
   draw()}
  runAb()}
};
if(!$('stygate'))window.__g4boot();
})();
