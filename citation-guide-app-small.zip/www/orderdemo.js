(function(){var d=document,h=d.getElementById('orddemo');if(!h)return;
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
var ST=[['apa','APA','#3a5fb0','a'],['mla','MLA','#7b66b8','a'],['cad','Chicago Author-Date','#4fa08f','a'],['nb','Chicago Notes-Bibliography','#c99a3a','a'],['ieee','IEEE','#8a92a5','n'],['van','Vancouver','#d9808a','n'],['acs','ACS','#b0785a','n']];
// 본문에서 인용하는 순서: Oh → Brown → Han
var SRC=[{id:'oh',au:'Oh',t:'대학생의 독서량 변화',y:2020,c:'#d9534f'},{id:'br',au:'Brown',t:'인용 교육의 효과',y:2018,c:'#3a8f5e'},{id:'ha',au:'Han',t:'출처 표기와 신뢰',y:2021,c:'#3a5fb0'}];
var ABC=SRC.slice().sort(function(a,b){return a.au<b.au?-1:1});
var cur='apa',pos={},again=false;
h.innerHTML='<div class="od-tabs" role="tablist"></div><div class="od-text"><b>① 본문에서 인용한 순서</b><div class="od-seq"></div><div class="od-doc"></div><button type="button" class="od-again">④ Brown을 한 번 더 인용해 보기</button><p class="od-re"></p></div><div class="od-arrow" aria-hidden="true">▼ 참고문헌 목록은 이렇게 놓입니다</div><div class="od-list" aria-live="polite"></div><p class="od-cap"></p>';
var tabs=h.querySelector('.od-tabs'),seq=h.querySelector('.od-seq'),list=h.querySelector('.od-list'),cap=h.querySelector('.od-cap'),re=h.querySelector('.od-re');
ST.forEach(function(s){var b=d.createElement('button');b.type='button';b.className='od-t';b.dataset.k=s[0];b.style.setProperty('--c',s[2]);b.innerHTML='<b>'+esc(s[1])+'</b><small>'+(s[3]==='a'?'저자 이름순':'인용 순서')+'</small>';b.onclick=function(){cur=s[0];draw(true)};tabs.appendChild(b)});
seq.innerHTML=SRC.map(function(s,i){return '<span class="od-c" style="--c:'+s.c+'"><i>'+(i+1)+'</i>'+esc(s.au)+'('+s.y+')</span>'}).join('<u>→</u>');
function info(){return ST.filter(function(s){return s[0]===cur})[0]}
function label(s,i,num){var k=cur;
 if(num)return '['+(i+1)+']';return ''}
function rowHTML(s,i,numbered){var k=cur,txt;
 var au=s.au+(k==='apa'||k==='cad'?', X.':'');
 if(k==='apa')txt=esc(s.au)+', X. ('+s.y+'). '+esc(s.t)+'.';
 else if(k==='cad')txt=esc(s.au)+', X. '+s.y+'. “'+esc(s.t)+'.”';
 else if(k==='mla')txt=esc(s.au)+', X. “'+esc(s.t)+'.” '+s.y+'.';
 else if(k==='nb')txt=esc(s.au)+', X. “'+esc(s.t)+'.” '+s.y+'.';
 else if(k==='ieee')txt='X. '+esc(s.au)+', “'+esc(s.t)+',” '+s.y+'.';
 else if(k==='van')txt=esc(s.au)+' X. '+esc(s.t)+'. '+s.y+'.';
 else txt=esc(s.au)+', X. '+esc(s.t)+' '+s.y+'.';
 return '<div class="od-r" data-id="'+s.id+'" style="--c:'+s.c+'"><span class="od-n">'+(numbered?'['+(SRC.indexOf(s)+1)+']':'')+'</span><span class="od-x">'+txt+' ◇</span><span class="od-m">'+(numbered?'인용 '+(SRC.indexOf(s)+1)+'번째':'저자 순')+'</span></div>'}
function draw(anim){var s=info(),numbered=s[3]==='n',arr=numbered?SRC:ABC;
 tabs.querySelectorAll('.od-t').forEach(function(b){b.classList.toggle('on',b.dataset.k===cur)});
 var before={};list.querySelectorAll('.od-r').forEach(function(r){before[r.dataset.id]=r.getBoundingClientRect().top});
 list.innerHTML=arr.map(function(x){return rowHTML(x,0,numbered)}).join('');
 list.className='od-list '+(numbered?'num':'abc');
 if(anim){list.querySelectorAll('.od-r').forEach(function(r){var b=before[r.dataset.id];if(b==null)return;var dy=b-r.getBoundingClientRect().top;if(!dy)return;r.style.transition='none';r.style.transform='translateY('+dy+'px)';requestAnimationFrame(function(){requestAnimationFrame(function(){r.style.transition='transform .7s cubic-bezier(.3,1.2,.4,1)';r.style.transform='none'})})})}
 var nm=s[1];
 cap.innerHTML=numbered?'<b>'+esc(nm)+'</b>: 인용한 순서(Oh → Brown → Han)가 곧 목록 순서입니다. 저자 이름이 ABC순이 아니어도 그대로 둡니다.':'<b>'+esc(nm)+'</b>: 저자 성의 ABC순(Brown → Han → Oh)으로 줄을 세웁니다. 한국어 자료는 가나다순입니다. 본문에서 먼저 인용했는지는 상관없습니다.';
 docDraw(numbered);
 var hit=again;list.querySelectorAll('.od-r').forEach(function(r){r.classList.toggle('hit',hit&&r.dataset.id==='br')});
 if(cur==='nb')cap.innerHTML+=' 각주 번호는 인용 순서이지만, 맨 뒤 참고문헌 목록은 저자 이름순입니다.'}
var btn=h.querySelector('.od-again'),doc=h.querySelector('.od-doc');
btn.onclick=function(){again=!again;btn.textContent=again?'다시 인용 지우기':'④ Brown을 한 번 더 인용해 보기';draw(false)};
function mk(src,n,ev){var k=cur;
 if(k==='apa'||k==='cad')return '('+src.au+', '+src.y+')';
 if(k==='mla')return '('+src.au+')';
 if(k==='ieee'||k==='van')return '['+(SRC.indexOf(src)+1)+']';
 if(k==='acs')return '<sup>'+(SRC.indexOf(src)+1)+'</sup>';
 return '<sup>'+ev+'</sup>'}
function docDraw(numbered){var k=cur,S=[['대학생의 독서량은 줄고 있다',SRC[0]],['인용 교육은 효과가 있다',SRC[1]],['출처 표기는 신뢰를 높인다',SRC[2]]];if(again)S.push(['인용 교육은 학습 동기도 높인다',SRC[1]]);
 doc.innerHTML='<b>본문 예</b><p>'+S.map(function(x,i){var m='<span class="od-mk" style="--c:'+x[1].c+'">'+mk(x[1],0,i+1)+'</span>';return (i===3?'<mark class="od-new">':'')+esc(x[0])+m+'.'+(i===3?'</mark>':'')}).join(' ')+'</p>';
 var t;
 if(!again)t=numbered?'본문에서 처음 인용할 때 Oh는 [1], Brown은 [2], Han은 [3]을 받았습니다. 위 버튼을 눌러 Brown을 또 인용해 보세요.':(k==='nb'?'각주는 인용할 때마다 번호가 새로 붙습니다(¹ ² ³). 위 버튼을 눌러 Brown을 또 인용해 보세요.':'본문에는 (저자, 연도)로 씁니다. 위 버튼을 눌러 Brown을 또 인용해 보세요.');
 else if(numbered)t='<b>네 번째 인용이지만 번호는 [4]가 아니라 [2]입니다.</b> Brown은 이미 처음 인용할 때 [2]를 받았기 때문입니다. 번호는 인용한 횟수가 아니라 <b>자료마다 하나씩</b> 줍니다. 그래서 목록은 계속 3개입니다.';
 else if(k==='nb')t='<b>각주 번호는 ④로 새로 붙지만, 맨 뒤 참고문헌 목록은 3개 그대로입니다.</b> 각주 ④에는 짧게(Brown, “인용 교육,” 12쪽)처럼 쓸 수 있습니다.';
 else t='<b>본문에는 (Brown, 2018)을 다시 쓰고, 참고문헌 목록은 3개 그대로입니다.</b> 번호가 없으니 목록에 줄을 더하지 않습니다.';
 re.innerHTML=t}
draw(false)})();
