(function(){
var d=document,$=function(i){return d.getElementById(i)};
function boot(){var GX=window.GX,H=$('town');if(!GX||!H||window.__tdone)return;window.__tdone=true;
 var esc=GX.esc,sh=GX.sh;
 var DEPT=[
 {id:'hum',n:'고서의 산 · 문과대학(인문계)',em:'⛰️',col:'#9b4a3c',lead:'핵심: 사료·원전의 정확성, 원자료와 내 해석의 구분',
  items:[
  {k:'a',t:'판본·이본·쪽수',w:'같은 작품도 초판·개정판·교감본에 따라 낱말과 쪽수가 다릅니다. 고전문학은 이본·필사본·활자본을 구분합니다. 인용 옆에 판본과 쪽수를 적습니다.'},
  {k:'b',t:'번역 출처·원어 병기',w:'번역본으로 읽었다면 번역 출처를 밝히고, 핵심 개념어는 원어를 함께 씁니다(번역자마다 역어가 다릅니다).'},
  {k:'c',t:'1차 사료와 2차 연구의 구분',w:'당대의 기록(1차 사료)과 후대의 연구(2차 문헌)를 구분하고, 사료는 권·편·장·조까지 씁니다.'},
  {k:'d',t:'원문과 내 해석의 구분',w:'인용한 원문과 내 해석을 따옴표·문단으로 나눠야 어디까지가 자료인지 보입니다.'},
  {k:'e',t:'구술·예문 자료의 조사 정보',w:'구술 자료나 방언 예문은 조사 시기·대상·전사 원칙·익명화 여부를 씁니다.'}],
  cases:[
  {m:[['본문','주인공은 편지에서 “…”(87쪽)라고 쓴다. 이는 화해의 가능성을 보여 준다.'],['자료 메모','문서윤, 『푸른 등불』, 가상출판사. (같은 작품의 초판과 개정판이 모두 나와 있다.)']],x:'a'},
  {m:[['본문','원작의 핵심 개념 ‘자긍’을 논하며 “…”(142쪽)를 인용했다.'],['자료 메모','영어 소설을 한국어 번역본으로 읽었다. 번역본의 서지(번역자·출판 정보)는 메모하지 않았다.']],x:'b'},
  {m:[['본문','가상의 일기 『청루일기』에 “…”라고 적혀 있다. 이는 “…”라고 한 한 연구서의 견해와 같다.'],['자료 메모','일기와 연구서의 내용이 한 문단에 이어져 있다. 어느 쪽이 당대 기록이고 어느 쪽이 후대 연구인지 표시가 없다.']],x:'c'},
  {m:[['본문','사료의 한 대목이 따옴표 없이 내 문장 속에 이어지고, “이는 당시 사람들이 지혜로웠음을 보여 준다”는 평가가 같은 문장에 붙어 있다.'],['자료 메모','출처: 『청루일기』 권2 제3장(표시되어 있다.)']],x:'d'},
  {m:[['본문','마을 어르신들의 말을 예문으로 모아 “ㅇㅇ 방언에서는 어미가 달라진다”고 분석했다.'],['자료 메모','예문 12개. 녹음은 했으나 언제, 누구를 대상으로, 어떤 규칙으로 옮겼는지는 적지 않았다.']],x:'e'},
  {m:[['본문','고전소설 「가상전」의 결말을 인용해 분석했다.'],['자료 메모','「가상전」은 필사본과 활자본이 모두 전한다. 어느 이본을 읽었는지는 적지 않았다.']],x:'a'},
  {m:[['본문','“…”(『푸른 등불』 개정판, 87쪽). 영어 원작은 한국어 번역본(번역자·출판 정보 표시)으로 읽었고 핵심 개념은 원어를 병기했다.'],['구성','사료 인용에는 따옴표와 권·장 표시가 있고, 내 해석은 다음 문단에서 시작한다.']],x:null,ok:'이 보고서에는 판본, 번역 출처, 원문과 해석의 구분이 모두 있습니다.'},
  {m:[['본문','가상의 사료 『청루일기』 권2 제3장은 “…”라고 적었고, 후대의 한 연구는 이를 달리 해석한다. 둘을 문단으로 나누어 썼다.'],['자료 메모','방언 예문 8개는 조사 시기·대상·전사 원칙·익명화 여부를 각주에 밝혔다.']],x:null,ok:'1차 사료와 2차 연구가 구분되어 있고, 구술 자료의 조사 정보도 있습니다.'}]},
 {id:'soc',n:'정책의 도시 · 정경대학(사회계열)',em:'🏙️',col:'#3a5fb0',lead:'핵심: 이론, 자료, 분석 방법의 일치',
  items:[
  {k:'a',t:'표본 수·응답률',w:'설문은 표본 수와 응답률을 씁니다. 비율만 있으면 얼마나 믿을 만한지 가늠할 수 없습니다.'},
  {k:'b',t:'면담 동의·익명화',w:'면담은 연구 참여 동의와 익명화를 씁니다. 학생 등 연구 대상은 보호가 먼저입니다.'},
  {k:'c',t:'자료 출처·발행기관·기준 연도·단위',w:'법령·정부 보고서·통계는 발행기관과 기준 연도를, 경제 자료는 출처·기간·단위를 씁니다.'},
  {k:'d',t:'측정 도구의 출처·신뢰도',w:'척도의 출처와 신뢰도(α 등)를 씁니다. 직접 만든 문항이면 그렇다고 밝힙니다.'},
  {k:'e',t:'인과 주장의 근거와 한계',w:'상관과 인과는 다릅니다. 인과를 말하려면 근거와 한계를 함께 씁니다.'},
  {k:'f',t:'효과 크기·신뢰구간',w:'통계 결과는 p값만이 아니라 효과 크기와 신뢰구간도 함께 씁니다.'}],
  cases:[
  {m:[['본문','대학생 62%가 “글쓰기 수업이 도움이 된다”고 답했다.'],['자료 메모','설문은 지난 학기에 했다. 문항은 기존 척도(출처와 신뢰도 표시)를 썼다.']],x:'a'},
  {m:[['본문','참여자의 실제 이름과 학과·학년을 밝히고 말을 그대로 인용했다.'],['자료 메모','심층 면담 6건. 연구 참여 동의서를 받았는지는 적지 않았다.']],x:'b'},
  {m:[['본문','최근 청년 고용률이 크게 올랐다(○○%).'],['자료 메모','정부 보고서의 숫자를 옮겼다. 어느 기관의 보고서인지, 어느 해 기준인지는 메모에 없다.']],x:'c'},
  {m:[['본문','학업 스트레스를 5문항으로 측정했다(평균 3.4).'],['자료 메모','표본 312명, 응답률 71%. 문항이 기존 척도인지 직접 만든 것인지, 신뢰도는 어떤지 적지 않았다.']],x:'d'},
  {m:[['본문','SNS 이용 시간이 긴 학생일수록 성적이 낮았다(r = −.31). 따라서 SNS 이용이 성적을 떨어뜨린다.'],['자료 메모','표본 312명, 응답률 71%, 척도의 출처와 신뢰도(α)를 밝혔다.']],x:'e'},
  {m:[['본문','두 집단의 평균 차이는 통계적으로 유의했다(p < .05).'],['자료 메모','표본 수, 응답률, 척도의 신뢰도는 밝혔다. 효과 크기와 신뢰구간은 없다.']],x:'f'},
  {m:[['본문','설문 응답자는 312명(응답률 71%)이고, 척도는 기존 척도(α = .86)를 썼다. 상관 결과는 “관련이 있다”까지만 해석하고 인과는 한계로 적었다.'],['자료 메모','정부 통계는 발행기관·기준 연도·단위를 표에 적었다.']],x:null,ok:'표본, 측정 도구, 해석의 한계, 통계 출처가 모두 있습니다.'},
  {m:[['본문','면담 6건은 연구 참여 동의를 받고 가명(참여자 A~F)으로 인용했다. 평균 차이는 효과 크기와 95% 신뢰구간을 함께 적었다.'],['자료 메모','표본 수와 응답률, 척도의 출처와 신뢰도를 표에 정리했다.']],x:null,ok:'동의·익명화와 통계 보고가 갖추어져 있습니다.'}]},
 {id:'med',n:'콘텐츠 바다 · 미디어학부',em:'🌊',col:'#7a62c4',lead:'핵심: 표본(기간·매체·검색어)과 코딩 기준·신뢰도, 온라인 자료의 수집일',
  items:[
  {k:'a',t:'표본: 기간·매체·검색어',w:'어떤 자료를 어떤 기준으로 뽑았는지 표본의 기간·매체·검색어를 밝힙니다.'},
  {k:'b',t:'분류·코딩 기준',w:'자료를 어떻게 나누고 세었는지 코딩 기준을 씁니다.'},
  {k:'c',t:'코딩 신뢰도(코더 간 일치)',w:'여러 사람이 코딩했다면 코더 간 일치도 같은 신뢰도를 씁니다.'},
  {k:'d',t:'온라인 자료의 수집일',w:'온라인 자료는 고쳐지거나 지워질 수 있으므로 수집일을 씁니다.'},
  {k:'e',t:'인용한 온라인 자료의 출처 정보',w:'기사·게시물·영상을 인용하면 작성자·제목·게시일·주소를 씁니다(이 안내서 제7~13장의 웹 자료 표기).'}],
  cases:[
  {m:[['본문','뉴스 기사 200건을 분석했다.'],['자료 메모','프레임 4종의 분류 기준과 두 코더의 일치도, 수집일은 적었다. 기사를 뽑은 기간·매체·검색어는 없다.']],x:'a'},
  {m:[['본문','기사를 “갈등·책임·경제·인간적 관심” 중 하나로 분류해 비율을 냈다.'],['자료 메모','기간(2025년 3~5월), 매체 3곳, 검색어, 수집일은 적었다. 각 분류를 어떤 기준으로 나눴는지는 설명이 없다.']],x:'b'},
  {m:[['본문','두 사람이 영상 150개를 코딩했다.'],['자료 메모','표본의 기간·플랫폼·검색어, 코딩 기준표, 수집일은 있다. 두 코더가 얼마나 일치했는지는 없다.']],x:'c'},
  {m:[['본문','숏폼 영상 댓글 1,000개를 분석했다.'],['자료 메모','기간·플랫폼·검색어, 코딩 기준, 코더 간 일치도는 적었다. 댓글을 언제 모았는지는 적지 않았다.']],x:'d'},
  {m:[['본문','한 기사에 따르면 OTT 이용 시간이 늘었다고 한다.'],['자료 메모','분석 방법은 모두 갖추었다. 이 기사의 작성자·제목·게시일·주소는 어디에도 없다.']],x:'e'},
  {m:[['본문','인기 웹툰의 댓글을 분석했다.'],['자료 메모','코딩 기준과 일치도, 수집일은 있다. “인기”를 어떻게 정했는지, 어느 기간의 댓글인지는 없다.']],x:'a'},
  {m:[['본문','2025년 3~5월 기사 200건(매체 3곳, 검색어 표시)을 분석했다. 두 코더가 프레임 4종으로 분류했고 일치도를 적었다.'],['자료 메모','기사는 2026년 6월 3일에 수집했고, 인용한 기사는 작성자·제목·게시일·주소를 각주에 썼다.']],x:null,ok:'표본, 코딩 기준·신뢰도, 수집일, 인용 출처가 모두 있습니다.'},
  {m:[['본문','숏폼 영상 150개(기간·플랫폼·검색어 표시)를 두 명이 코딩해 일치도를 적었다.'],['자료 메모','수집일을 적었고 코딩 기준표를 부록에 붙였다.']],x:null,ok:'온라인 자료의 표본과 코딩 정보가 갖추어져 있습니다.'}]},
 {id:'art',n:'색채 우주 · 디자인조형학부',em:'🪐',col:'#a8764f',lead:'핵심: 작품·도판의 출처와 저작권, 제작 과정의 기록',
  items:[
  {k:'a',t:'도판·작품의 출처',w:'작품과 도판의 출처(만든 사람·발행 정보·구한 곳)를 씁니다.'},
  {k:'b',t:'이미지 사용 허락(저작권)',w:'이미지 사용 허락을 확인합니다. 출처를 적었다고 허락이 되는 것은 아닙니다.'},
  {k:'c',t:'제작 과정의 기록',w:'스케치·수정 과정·재료 선택처럼 제작 과정을 기록합니다.'},
  {k:'d',t:'도판 목록 표(번호·출처·허락 여부)',w:'도판 목록 표를 만들어 번호, 출처, 허락 여부를 한눈에 점검합니다.'}],
  cases:[
  {m:[['본문','그림 3은 참고한 포스터 디자인이다.'],['자료 메모','이미지 파일만 붙였다. 만든 사람·발행 연도·구한 곳은 적지 않았다. 사용 허락 메일은 받아 두었다.']],x:'a'},
  {m:[['본문','그림 5. 가상의 사진 작가의 작품(작가·제목·누리집 주소 표시)'],['자료 메모','인터넷에서 내려받은 사진을 발표 책자에 넣었다. 사용해도 되는지는 확인하지 않았다.']],x:'b'},
  {m:[['본문','최종 작업물 사진 4장과 의도 설명이 있다.'],['자료 메모','스케치, 수정본, 재료를 고른 이유는 없다. 도판 출처와 허락은 정리되어 있다.']],x:'c'},
  {m:[['본문','도판 12장이 본문 곳곳에 있고 번호와 출처가 각각 적혀 있다.'],['자료 메모','한눈에 보는 목록은 없다. 어느 도판이 허락을 받았는지 찾으려면 12장을 모두 뒤져야 한다.']],x:'d'},
  {m:[['본문','가상의 전시 포스터를 참고해 그렸다. 출처를 적었고 도판 목록도 있다.'],['자료 메모','전시 단체의 로고(가상)를 그대로 가져왔다. 사용해도 되는지는 확인하지 않았다.']],x:'b'},
  {m:[['본문','건축 설계 과제: 최종 도면과 모형 사진을 제출한다. 도판 출처와 목록, 허락 여부는 정리했다.'],['자료 메모','처음 구상에서 최종안까지 어떻게 바뀌었는지는 기록하지 않았다.']],x:'c'},
  {m:[['본문','그림 1~6의 출처·허락 여부를 도판 목록 표(번호·출처·허락)로 정리했다.'],['자료 메모','스케치 3장과 수정본, 재료 선택의 이유를 제작 과정 쪽에 실었다.']],x:null,ok:'출처, 허락, 도판 목록, 제작 과정이 모두 있습니다.'},
  {m:[['본문','참고작 이미지마다 만든 사람·제목·발행 연도·구한 곳을 캡션에 적었다.'],['자료 메모','사용 허락은 받았고 허락 여부를 표에 표시했다. 제작 과정 사진도 있다.']],x:null,ok:'도판의 출처와 허락, 제작 과정이 모두 있습니다.'}]},
 {id:'biz',n:'시장 사막의 오아시스 · 경영대학',em:'🏜️',col:'#c08a2a',lead:'핵심: 가설의 논리, 측정, 실증분석(표본·변수·척도)',
  items:[{k:'a',t:"표본 기간과 기업 선정 기준",w:"어떤 기간의 어떤 기업을 어떤 기준으로 골랐는지 써야 결과를 믿고 다시 확인할 수 있습니다."},{k:'b',t:"변수 정의와 이상치 처리",w:"“수익성” 같은 말은 어떤 값으로 계산했는지, 극단값을 어떻게 다뤘는지 씁니다."},{k:'c',t:"회계기준과 기준 연도",w:"재무제표를 쓰면 회계기준(K-IFRS 등)과 기준 연도를 밝힙니다."},{k:'d',t:"척도의 출처와 신뢰도(α)",w:"설문 문항은 어디서 가져왔는지, 문항 간 신뢰도(α)는 얼마인지 씁니다."},{k:'e',t:"가설을 이끈 이론적 근거",w:"가설은 처음 떠오른 생각이 아니라 이론이나 선행 연구에서 이끌어 냅니다."}],
  cases:[
  {m:[["본문","가상 상장기업의 배당이 높을수록 주가 변동이 작았다."],["자료 메모","기업 300곳을 분석했다. 어떤 기간의 어떤 기준으로 기업을 골랐는지 적지 않았다."]],x:'a'},
  {m:[["본문","수익성이 높은 기업이 투자를 더 늘린다."],["자료 메모","“수익성”을 무엇으로 계산했는지, 극단값을 어떻게 처리했는지 적지 않았다."]],x:'b'},
  {m:[["본문","두 기업의 이익 규모를 비교했다."],["자료 메모","재무제표를 사용했다. 어떤 회계기준으로 쓴 어느 해의 자료인지 적지 않았다."]],x:'c'},
  {m:[["본문","소비자의 브랜드 신뢰를 5점 척도 설문으로 측정했다."],["자료 메모","문항은 직접 만들었다. 다른 연구에서 가져온 것인지, 문항 간 신뢰도(α)를 구했는지 적지 않았다."]],x:'d'},
  {m:[["본문","가설: 광고 횟수가 늘면 구매 의도가 높아진다."],["자료 메모","가설은 처음 떠오른 생각이다. 왜 그렇게 되는지 설명하는 이론이나 선행 연구는 적지 않았다."]],x:'e'},
  {m:[["본문","가상 스타트업 투자 사례를 분석했다."],["자료 메모","사례는 40건이다. 어떤 기준으로 골랐는지, 어느 기간의 사례인지 적지 않았다."]],x:'a'},
  {m:[["본문","가상 비금융 상장기업 300곳(2018~2022년, 거래 정지 기업 제외)을 분석했다. 수익성은 영업이익을 총자산으로 나눈 값이고 상·하위 1%는 조정했다."],["자료 메모","K-IFRS 연결재무제표(각 연도 말 기준). 가설은 선행 이론에서 이끌었고, 설문 척도는 기존 연구에서 가져와 α를 적었다."]],x:null,ok:"표본, 변수 정의, 회계기준, 척도, 가설의 근거가 모두 있는 보고서입니다."}]},
 {id:'edu',n:'배움의 들판 · 사범대학',em:'🌾',col:'#5b9a3c',lead:'핵심: 교육 연구 설계와 윤리(대상 보호·평가 도구)',
  items:[{k:'a',t:"연구 대상과 교육 맥락",w:"어떤 학생(학년·인원)이 어떤 수업·학교 환경에 있었는지 써야 결과를 해석할 수 있습니다."},{k:'b',t:"평가 도구와 타당도",w:"무엇으로 어떻게 재었는지(검사지·루브릭 등)와 그 도구가 알맞은지 씁니다."},{k:'c',t:"동의와 익명화",w:"학생을 대상으로 한 조사는 동의를 받았다는 것과 이름을 가렸다는 것을 씁니다."},{k:'d',t:"교육이론·교육과정의 근거",w:"수업 설계는 이론이나 교육과정에서 근거를 가져와 밝힙니다."},{k:'e',t:"학습 자료·수업 장면의 출처와 개인정보 가리기",w:"학습 자료는 출처를 쓰고, 수업 장면을 옮길 때는 개인정보를 가립니다."}],
  cases:[
  {m:[["본문","토론 수업을 했더니 학생들의 말하기가 나아졌다."],["자료 메모","한 학급에서 했다. 학년과 인원, 수업 시간 같은 맥락은 적지 않았다."]],x:'a'},
  {m:[["본문","수업 뒤 학생들의 이해가 높아졌다고 판단했다."],["자료 메모","교사가 보기에 이해가 높아진 것 같았다. 어떤 검사나 기준으로 쟀는지 적지 않았다."]],x:'b'},
  {m:[["본문","학생 40명에게 학교생활 만족도를 설문했다."],["자료 메모","설문지에 이름을 적게 했다. 학생과 보호자에게 동의를 받았는지, 이름을 어떻게 가렸는지 적지 않았다."]],x:'c'},
  {m:[["본문","모둠 수업이 학습 동기를 높일 것이라고 설계했다."],["자료 메모","모둠 수업이 왜 동기를 높이는지 설명하는 교육이론이나 교육과정 근거를 적지 않았다."]],x:'d'},
  {m:[["본문","수업 장면: 민수(가명이 아닌 실명)가 “선생님, 모르겠어요”라고 했다."],["자료 메모","학습지는 출처 없이 인터넷에서 가져왔다. 실명을 그대로 썼다."]],x:'e'},
  {m:[["본문","국어 수업 단원을 새로 설계했다."],["자료 메모","어느 교육과정의 어느 성취기준에 근거하는지 적지 않았다."]],x:'d'},
  {m:[["본문","가상 중학교 2학년 한 학급 28명, 국어 수업 6차시에서 모둠 토론을 했다. 학생 이름은 가렸고 동의를 받았다."],["자료 메모","평가는 루브릭(타당도 검토 표시)으로 했고, 교육과정 성취기준과 이론을 근거로 밝혔다. 학습 자료의 출처도 적었다."]],x:null,ok:"대상·맥락, 평가 도구, 동의와 익명화, 이론 근거, 자료 출처가 모두 있는 보고서입니다."}]},
 {id:'int',n:'세계 일주의 나라들 · 국제학부',em:'🗺️',col:'#2a8fb0',lead:'핵심: 공식 문서와 영문 문헌의 구분, 비교 기준, 번역 출처',
  items:[{k:'a',t:"공식 문서와 해설 문헌의 구분",w:"나라나 기관이 낸 공식 문서와 그것을 해설한 글을 구분하고 각각의 출처를 씁니다."},{k:'b',t:"제도 비교의 기준",w:"나라를 견줄 때는 무엇을 기준으로 견주는지 먼저 씁니다."},{k:'c',t:"번역 출처",w:"외국어 자료를 번역해 읽었다면 번역한 사람과 출처를 밝힙니다."},{k:'d',t:"문서의 이름·발행기관·날짜",w:"공식 문서는 이름, 발행한 기관, 날짜를 써야 찾을 수 있습니다."},{k:'e',t:"비교할 나라를 고른 까닭",w:"왜 그 나라들을 골랐는지 연구 질문과 이어 설명합니다."}],
  cases:[
  {m:[["본문","가상국 A의 이민 제도가 B보다 엄격하다고 설명했다."],["자료 메모","제도를 견주면서 무엇을 기준으로 엄격하다고 했는지 적지 않았다."]],x:'b'},
  {m:[["본문","가상국 B의 공식 보고서와 한 신문 해설을 함께 인용했다."],["자료 메모","두 자료가 한 문단에 섞여 있다. 어느 것이 공식 문서이고 어느 것이 해설인지 표시가 없다."]],x:'a'},
  {m:[["본문","외국어로 된 연설문의 한 대목을 한국어로 옮겨 인용했다."],["자료 메모","번역본을 읽었다. 누가 번역했는지, 어느 책에서 가져왔는지 적지 않았다."]],x:'c'},
  {m:[["본문","가상국 C의 정부는 지난해 새 정책을 발표했다."],["자료 메모","정부 문서에서 읽었다. 문서 이름과 발행기관, 날짜는 적지 않았다."]],x:'d'},
  {m:[["본문","가상국 A, B, D의 교육 제도를 비교했다."],["자료 메모","왜 이 세 나라를 골랐는지, 연구 질문과 어떻게 이어지는지 적지 않았다."]],x:'e'},
  {m:[["본문","영문 보고서 내용을 요약해 한국어로 옮겼다."],["자료 메모","번역은 직접 했는지 다른 사람의 번역인지 밝히지 않았다."]],x:'c'},
  {m:[["본문","가상국 A와 B의 이민 제도를 입국 허가 요건, 심사 기간, 불복 절차 세 기준으로 견주었다. 두 나라는 같은 지역의 비슷한 규모라서 골랐다."],["자료 메모","공식 문서는 이름·발행기관·날짜를 적었고 해설 문헌과 나누었다. 번역은 직접 했다고 밝혔다."]],x:null,ok:"비교 기준, 나라를 고른 까닭, 공식 문서 정보, 번역 출처가 모두 있는 보고서입니다."}]}
 ];
 function scene(id,c){var s='<svg class="twsc" viewBox="0 0 600 110" role="img" aria-label="'+id+' 여행지">',K='stroke="#2b3558" stroke-width="3"';
  if(id==='hum')s+='<rect width="600" height="110" fill="#e8efe6"/><circle cx="520" cy="26" r="14" fill="#f3d37a"/><path d="M0 100L90 30L150 70L230 18L330 100Z" fill="#8a9f8c" '+K+'/><path d="M180 100L300 40L420 100Z" fill="#6f8a76" '+K+'/><path d="M214 34L230 18L246 34Z" fill="#fff"/><rect x="440" y="62" width="58" height="38" fill="#e8d5b5" '+K+'/><path d="M432 64L469 40L506 64Z" fill="#9b4a3c" '+K+'/><rect y="100" width="600" height="10" fill="#6a8a62"/>';
  else if(id==='soc')s+='<rect width="600" height="110" fill="#e6ecf8"/><g '+K+'><rect x="40" y="50" width="46" height="50" fill="#e4b04a"/><rect x="96" y="22" width="40" height="78" fill="#3a5fb0"/><rect x="146" y="44" width="50" height="56" fill="#d0554f"/><rect x="206" y="16" width="38" height="84" fill="#6fa89c"/><rect x="254" y="38" width="48" height="62" fill="#8272b5"/><path d="M340 100V58l40-30 40 30v42Z" fill="#fff"/><path d="M360 100V70h40v30" fill="#cfa04e"/><rect x="440" y="30" width="44" height="70" fill="#2f9a64"/><rect x="494" y="52" width="52" height="48" fill="#e4b04a"/></g><rect y="100" width="600" height="10" fill="#b3bdd0"/>';
  else if(id==='med')s+='<rect width="600" height="110" fill="#dcebf7"/><circle cx="90" cy="26" r="14" fill="#f3d37a"/><path d="M0 76q30-14 60 0t60 0 60 0 60 0 60 0 60 0 60 0 60 0 60 0 60 0V110H0Z" fill="#5a9ed0" '+K+'/><path d="M300 70h60l-10 18h-40Z" fill="#fff" '+K+'/><path d="M330 70V28l34 24Z" fill="#fbe3d3" '+K+'/><rect x="480" y="30" width="12" height="46" fill="#7a62c4" '+K+'/><circle cx="486" cy="26" r="6" fill="#d0554f"/><path d="M470 14q16-12 32 0M462 4q24-18 48 0" fill="none" '+K+'/>';
  else if(id==='art')s+='<rect width="600" height="110" fill="#242a52"/><g fill="#fff"><circle cx="40" cy="20" r="2"/><circle cx="170" cy="14" r="2"/><circle cx="260" cy="40" r="2"/><circle cx="400" cy="18" r="2"/><circle cx="560" cy="44" r="2"/><circle cx="330" cy="86" r="2"/></g><circle cx="120" cy="60" r="30" fill="#e4a14e" '+K+'/><ellipse cx="120" cy="60" rx="48" ry="9" fill="none" '+K+'/><circle cx="300" cy="50" r="18" fill="#c46a5e" '+K+'/><circle cx="460" cy="64" r="26" fill="#6fa89c" '+K+'/><path d="M520 30l8 18 18 2-14 12 4 18-16-10-16 10 4-18-14-12 18-2Z" fill="#f3d37a" '+K+'/>';
  else if(id==='edu')s+='<rect width="600" height="110" fill="#eaf3dd"/><circle cx="520" cy="24" r="14" fill="#f3d37a"/><path d="M0 84q80-40 160 0t160 0 160 0 160 0V110H0Z" fill="#8fbf6a" '+K+'/><rect x="200" y="46" width="110" height="42" fill="#fbe3d3" '+K+'/><path d="M190 48L255 18L320 48Z" fill="#d0554f" '+K+'/><rect x="240" y="62" width="26" height="26" fill="#7a5a3a" '+K+'/><path d="M420 90V50M410 56l10-12 10 12" fill="none" '+K+'/><path d="M80 90V60" stroke="#2b3558" stroke-width="3"/><circle cx="80" cy="54" r="10" fill="#6fa86a" '+K+'/>';
  else if(id==='int')s+='<rect width="600" height="110" fill="#e3f1f6"/><circle cx="130" cy="56" r="40" fill="#7fc0d8" '+K+'/><path d="M100 40q14-10 24 0t-4 20-22 0M142 68q16-4 22 8" fill="#8fbf6a" '+K+'/><path d="M330 36l70 14-70 14 8-14Z" fill="#fff" '+K+'/><path d="M290 50h30" '+K+'/><path d="M470 100V40" '+K+'/><path d="M470 40h50v22h-50Z" fill="#d0554f" '+K+'/><path d="M540 100V52" '+K+'/><path d="M540 52h40v18h-40Z" fill="#3a5fb0" '+K+'/><rect y="100" width="600" height="10" fill="#b8d2dc"/>';
  else s+='<rect width="600" height="110" fill="#f6ecd0"/><circle cx="70" cy="26" r="16" fill="#f3d37a"/><path d="M0 92q100-40 200-8t200-6 200 8V110H0Z" fill="#e6c786" '+K+'/><path d="M440 90V44" '+K+'/><path d="M440 44q-22-6-30 8M440 44q22-6 30 8M440 44q-6-18-24-14M440 44q8-18 26-12" fill="none" stroke="#2f9a64" stroke-width="5"/><path d="M230 90l40-34 40 34Z" fill="#fff" '+K+'/><circle cx="130" cy="82" r="9" fill="#e4b04a" '+K+'/><circle cx="160" cy="84" r="7" fill="#e4b04a" '+K+'/>';
  return s+deco(id)+'<g id="tvn" class="tvn"></g><g id="tvw" class="tvw"></g></svg>'}
 var KK='stroke="#2b3558" stroke-width="1.8" stroke-linejoin="round"';
 function animal(col,ear,acc,fl){var o='<g'+(fl?' transform="scale(-1,1)"':'')+'><g class="tvb">';
  if(acc==='pack')o+='<rect x="-16" y="-24" width="9" height="14" rx="3" fill="#e4a14e" '+KK+'/>';
  o+='<rect class="lga" x="-6" y="-7" width="5" height="7" rx="2" fill="'+col+'" '+KK+'/><rect class="lgb" x="2" y="-7" width="5" height="7" rx="2" fill="'+col+'" '+KK+'/>';
  o+='<ellipse cx="0" cy="-15" rx="9.5" ry="10" fill="'+col+'" '+KK+'/><ellipse cx="2" cy="-13" rx="5" ry="6" fill="#fff" opacity=".7"/>';
  if(acc==='tie')o+='<path d="M0 -22L-3 -17L0 -9L3 -17Z" fill="#d0554f" '+KK+'/>';
  if(ear==='round')o+='<circle cx="-5" cy="-37" r="3.6" fill="'+col+'" '+KK+'/><circle cx="8" cy="-37" r="3.6" fill="'+col+'" '+KK+'/>';
  else if(ear==='pointy')o+='<path d="M-8 -32L-6 -42L-1 -34Z" fill="'+col+'" '+KK+'/><path d="M5 -34L10 -42L12 -31Z" fill="'+col+'" '+KK+'/>';
  else if(ear==='long')o+='<ellipse cx="-3" cy="-43" rx="2.8" ry="7" fill="'+col+'" '+KK+'/><ellipse cx="7" cy="-43" rx="2.8" ry="7" fill="'+col+'" '+KK+'/>';
  o+='<circle cx="2" cy="-29" r="9.5" fill="'+col+'" '+KK+'/><circle cx="5" cy="-30" r="1.7" fill="#2b3558"/><circle cx="-1" cy="-30" r="1.7" fill="#2b3558"/><path d="M1 -26q2 2 4 0" fill="none" stroke="#2b3558" stroke-width="1.4"/><circle cx="8" cy="-26" r="1.8" fill="#f2a0a0" opacity=".8"/>';
  if(acc==='hat')o+='<ellipse cx="2" cy="-37" rx="12" ry="3" fill="#e4c46a" '+KK+'/><path d="M-5 -37q7-10 14 0Z" fill="#e4c46a" '+KK+'/>';
  if(acc==='cap')o+='<path d="M-7 -36q9-9 18 0Z" fill="#3a5fb0" '+KK+'/><rect x="8" y="-37" width="9" height="3" rx="1.5" fill="#3a5fb0" '+KK+'/>';
  return o+'</g></g>'}
 var TR={hum:['#a97455','round','pack',96],soc:['#8fb0e0','pointy','tie',98],med:['#9a7a5e','round','',84],art:['#f4d9e6','long','',88],biz:['#e08a4a','pointy','hat',98],edu:['#f4d85a','round','cap',98],int:['#e9edf3','round','',84]};
 function vehicle(id){var f='<g class="tvfl">';
  if(id==='med')return f+'<path d="M-30 -2H30L22 10H-22Z" fill="#fff" '+KK+'/><path d="M2 -3V-46L26 -8Z" fill="#fbe3d3" '+KK+'/></g>';
  if(id==='art')return f+'<path d="M-6 8q-6 12 6 22q12-10 6-22Z" class="tvfi" fill="#f08a3a"/><path d="M-14 4V-14q14-26 28 0V4Z" fill="#fff" '+KK+'/><path d="M-14 -2L-24 10L-14 6ZM14 -2L24 10L14 6Z" fill="#d0554f" '+KK+'/></g>';
  if(id==='int')return f+'<ellipse cx="0" cy="4" rx="34" ry="8" fill="#fff" '+KK+'/><path d="M-6 2L-22 20L-4 8ZM26 0l10-12l4 14Z" fill="#7fb0d8" '+KK+'/></g>';
  return ''}
 function walker(id){var t=TR[id]||TR.hum,v=vehicle(id),sc=(id==='med'||id==='art'||id==='int')?.8:1,dy=id==='med'?-8:id==='art'?-4:id==='int'?-4:0;
  return v+'<g transform="translate(0,'+dy+') scale('+sc+')">'+animal(t[0],t[1],t[2])+'</g><g id="tvbub" class="tvbub"><rect id="tvbr" x="-60" y="-78" width="120" height="22" rx="9" fill="#fff" stroke="#2b3558" stroke-width="1.6"/><path d="M-4 -56L0 -49L4 -56Z" fill="#fff" stroke="#2b3558" stroke-width="1.6"/><path d="M-3 -56.8H3" stroke="#fff" stroke-width="2.4"/><text id="tvbt" x="0" y="-63" text-anchor="middle" font-size="11" font-weight="800" fill="#2b3558"></text></g>'}
 function deco(id){var c='';
  function cl(x,y,k,d){return '<g class="tvcl" style="animation-delay:'+d+'s"><g transform="translate('+x+','+y+') scale('+k+')"><ellipse cx="0" cy="0" rx="16" ry="6" fill="#fff" opacity=".9"/><ellipse cx="-8" cy="-4" rx="8" ry="6" fill="#fff" opacity=".9"/><ellipse cx="7" cy="-5" rx="9" ry="7" fill="#fff" opacity=".9"/></g></g>'}
  if(id==='hum'||id==='soc'||id==='edu'||id==='biz')c+=cl(60,18,1,-6)+cl(260,12,.8,-20)+cl(420,24,1.1,-30);
  if(id==='int')c+=cl(60,14,1,-6)+cl(300,22,.9,-22)+cl(430,10,1.1,-30);
  if(id==='hum'||id==='edu')c+='<g class="tvbird"><path d="M0 0q5-6 10 0q5-6 10 0" fill="none" stroke="#2b3558" stroke-width="2" transform="translate(320,20)"/></g>';
  if(id==='med')c+='<g class="tvwv"><path d="M-60 90q15-8 30 0t30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0 30 0V110H-60Z" fill="#7fb6df" opacity=".75"/></g><g class="tvjp"><path d="M-8 4q8-16 16 0q-8 5-16 0Z" fill="#f08a3a" stroke="#2b3558" stroke-width="1.6" transform="translate(200,70)"/></g>';
  if(id==='art')c+='<g class="tvtw"><circle cx="70" cy="30" r="2.5" fill="#fff"/><circle cx="230" cy="22" r="2.5" fill="#f3d37a"/><circle cx="380" cy="70" r="2.5" fill="#fff"/><circle cx="560" cy="16" r="2.5" fill="#f3d37a"/></g><g class="tvfl"><circle cx="330" cy="90" r="6" fill="#6fa89c" stroke="#fff" stroke-width="1.5"/></g>';
  if(id==='biz')c+='<g class="tvsun"><circle cx="70" cy="26" r="22" fill="#f3d37a" opacity=".35"/></g>';
  return c}
 var LINES=['출발~! 첫 마을이에요','가방을 열어 볼게요','다음 마을이 보여요','한 걸음 더!','거의 다 왔어요','마지막 마을이 가까워요','마지막 마을이에요!'];
 var lastX=-50,walkT=0;
 function travel(rd,rounds,first){var w=$('tvw'),n=$('tvn');if(!w)return;var id=dept().id,t=TR[id]||TR.hum,y=t[3],x=70+rd*(400/(rounds-1));
  w.innerHTML=walker(id);n.innerHTML='<g transform="translate(556,'+(id==='art'?98:id==='int'?98:id==='med'?96:100)+')"><g class="tvwave">'+animal(id==='hum'?'#d98c8c':id==='soc'?'#d8c27a':id==='med'?'#8ccfc6':id==='art'?'#c9b5e8':id==='biz'?'#e6a15f':id==='edu'?'#a6d58a':'#9ccbe0','round',id==='soc'?'tie':'',1)+'</g></g><g transform="translate(556,'+(id==='art'?98:id==='int'?98:id==='med'?96:100)+')"><text x="0" y="-56" text-anchor="middle" font-size="10" font-weight="800" fill="#2b3558" class="tvhi">마을 사람</text></g>';
  w.style.transform='translate('+(first?-50:lastX)+'px,'+y+'px)';w.getBoundingClientRect();
  var sv=w.ownerSVGElement;sv.classList.add('mv');
  requestAnimationFrame(function(){w.style.transform='translate('+x+'px,'+y+'px)'});
  lastX=x;clearTimeout(walkT);say(LINES[Math.min(rd,LINES.length-1)]);
  walkT=setTimeout(function(){sv.classList.remove('mv')},1900)}
 function say(txt){var b=$('tvbt'),r=$('tvbr');if(!b)return;b.textContent=txt;var wd=Math.max(60,txt.length*11+22);r.setAttribute('width',wd);r.setAttribute('x',-wd/2)}
 function hop(ok){var w=$('tvw');if(!w)return;var b=w.querySelector('.tvb');if(b){b.classList.remove('hop','shk');void b.getBoundingClientRect();b.classList.add(ok?'hop':'shk')}say(ok?'좋아요! 정답~':'아이쿠, 다시 살펴봐요')}
 var cur=GX.ls('town.cur')||'hum';
 function dept(){return DEPT.filter(function(x){return x.id===cur})[0]||DEPT[0]}
 function run(){var D=dept(),rounds=7,rd=0,score=0,right=0,deck=sh(D.cases.slice()).slice(0,rounds);
  function tabs(){return '<div class="olyrow"><span class="olyc">여행지</span>'+DEPT.map(function(x){return '<button class="gtab'+(x.id===cur?' on':'')+'" data-l="'+x.id+'">'+x.em+' '+esc(x.n)+'</button>'}).join('')+'</div>'}
  function legend(){return '<details class="twlg"><summary>이 여행지에서 알아 둘 것(안내서 부록 3)</summary><ul>'+D.items.map(function(it){return '<li><b>'+esc(it.t)+'</b> — '+esc(it.w)+'</li>'}).join('')+'</ul></details>'}
  function round(){var c=deck[rd];
   H.innerHTML=tabs()+scene(D.id,D.col)+'<div class="labhd" style="--lc:'+D.col+'"><b>'+D.em+' '+esc(D.n)+' 여행</b><span>'+esc(D.lead)+'</span></div>'+legend()
    +'<div class="gbar"><span>여행 <b>'+(rd+1)+' / '+rounds+'</b></span><span>점수 <b>'+score+'</b></span></div>'
    +'<div class="twpaper"><div class="twtag">여행 가방 속 연습용 가상 보고서 · 학생 보고서의 한 대목</div>'+c.m.map(function(r){return '<p><b>'+esc(r[0])+'</b> '+esc(r[1])+'</p>'}).join('')+'</div>'
    +'<p class="twq">마을 사람이 여행 가방에서 꺼낸 보고서입니다. 이 보고서에서 <b>빠진 것</b>은 무엇일까요? 하나를 고르세요. 빠진 것이 없다면 맨 아래를 누르세요.</p>'
    +'<div class="twchips">'+D.items.map(function(it){return '<button class="twchip" data-k="'+it.k+'">'+esc(it.t)+'</button>'}).join('')+'<button class="twchip pass" data-k="">빠진 것 없음 · 통과</button></div><div id="twres" aria-live="polite"></div>';
   travel(rd,rounds,rd===0);
   H.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){cur=b.dataset.l;GX.ls('town.cur',cur);D=dept();lastX=-50;run()}});
   H.querySelectorAll('.twchip').forEach(function(b){b.onclick=function(){answer(c,b.dataset.k,b)}})}
  function answer(c,k,btn){H.querySelectorAll('.twchip').forEach(function(b){b.disabled=true;if((b.dataset.k||null)===c.x)b.classList.add('ok');});
   var ok=(k||null)===c.x;hop(ok);if(!ok)btn.classList.add('bad');if(ok){score+=15;right++}
   var it=D.items.filter(function(i){return i.k===c.x})[0];
   var msg=ok?'<b class="twok">맞아요!</b> ':'<b class="twno">아쉬워요.</b> ';
   msg+=c.x?('빠진 것은 <b>'+esc(it.t)+'</b>입니다. '+esc(it.w)):esc(c.ok||'빠진 것이 없는 보고서입니다.');
   if(!ok&&k){var pk=D.items.filter(function(i){return i.k===k})[0];msg+='<br><span class="mut">고른 “'+esc(pk.t)+'”은(는) 이 보고서에 이미 있거나 이번 보고서의 핵심이 아닙니다.</span>'}
   if(!ok&&!k)msg+='<br><span class="mut">빠진 것이 있는 보고서였어요.</span>';
   $('twres').innerHTML='<div class="twfb '+(ok?'ok':'no')+'">'+msg+'</div><div class="gbtns"><button class="gprimary" id="twnx">'+(rd+1>=rounds?'결과 보기':'다음 마을 사람 →')+'</button></div>';
   $('twnx').onclick=function(){rd++;if(rd>=rounds){H.innerHTML='';GX.win(H,right>=6?3:right>=4?2:1,'여행 끝!',rounds+'번 가운데 '+right+'번 빠진 것을 알맞게 찾았습니다.','한 번 더',run,'town',null,'')}else round()};
   $('twres').scrollIntoView({behavior:'smooth',block:'nearest'})}
  round()}
 run()}
if(window.GX)boot();else addEventListener('load',boot);
})();
