(function(){
var d=document,$=function(i){return d.getElementById(i)};
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function sh(a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t}return a}
function cp(txt,btn){function ok(){var o=btn.textContent;btn.textContent='복사됨';setTimeout(function(){btn.textContent=o},1200)}
 function fb(){var t=d.createElement('textarea');t.value=txt;d.body.appendChild(t);t.select();try{d.execCommand('copy');ok()}catch(e){}t.remove()}
 try{navigator.clipboard.writeText(txt).then(ok,fb)}catch(e){fb()}}
// ===== 양식별 한눈에 보기 =====
d.querySelectorAll('.qs').forEach(function(b){b.addEventListener('click',function(){
 d.querySelectorAll('.qs').forEach(function(x){x.classList.toggle('on',x===b)});
 d.querySelectorAll('.qp').forEach(function(p){p.hidden=p.dataset.s!==b.dataset.s});
 try{history.replaceState(null,'','#'+b.dataset.s)}catch(e){}})});
d.querySelectorAll('.qp').forEach(function(p){p.querySelectorAll('.qss').forEach(function(b){b.addEventListener('click',function(){
 p.querySelectorAll('.qss').forEach(function(x){x.classList.toggle('on',x===b)});
 p.querySelector('.qa1').hidden=b.dataset.t!=='a';p.querySelector('.qb1').hidden=b.dataset.t!=='b'})})});
(function(){var h=(location.hash||'').slice(1),b=h&&d.querySelector('.qs[data-s="'+h+'"]');if(b)b.click()})();
// ===== FAQ 검색 =====
var fs=$('fqs');if(fs)fs.addEventListener('input',function(){var k=fs.value.trim().toLowerCase(),n=0;
 d.querySelectorAll('.qa').forEach(function(q){var on=d.querySelector('.fqt.on'),c=on?on.dataset.c:'all',ok=(c==='all'||q.dataset.c===c)&&(!k||q.textContent.toLowerCase().indexOf(k)>=0);q.hidden=!ok;if(ok)n++});
 var m=$('fqn');if(m)m.hidden=n>0});
// ===== 방탈출 =====
var E=$('esc');
if(E){var D=JSON.parse($('escdata').textContent),R=D.rooms,ri=0,hints=2,wrong=0,t0=Date.now(),done=false;
 function room(){var r=R[ri];
  E.innerHTML='<div class="gbar"><span>방 <b>'+(ri+1)+'</b> / '+R.length+'</span><span>힌트 <b>'+hints+'</b>회 남음</span><span>오답 <b>'+wrong+'</b></span></div>'
  +'<div class="door"><div class="doors">'+R.map(function(x,i){return '<i class="'+(i<ri?'open':i===ri?'cur':'')+'"></i>'}).join('')+'</div></div>'
  +'<div class="rmhead"><img id="rmimg" class="rmimg" src="img/art-escape.svg" alt="잠긴 문이 있는 방"><div><h2 class="gt">'+esc(r.title)+'</h2><p>'+esc(r.story)+'</p></div></div><div class="gcards">'+r.items.map(function(it,i){return '<button class="gcard cp0" data-i="'+i+'" style="--sc:#8a1c3a">'+it.t+'</button>'}).join('')+'</div>'
  +'<div class="gfb" id="gfb" aria-live="polite"></div><div class="gbtns"><button id="ghint">힌트 쓰기</button></div>';
  E.querySelectorAll('.gcard').forEach(function(b){b.addEventListener('click',function(){var it=r.items[+b.dataset.i];
   if(it.ok){b.classList.add('good');var im=$('rmimg');if(im){im.src='img/art-escape-open.svg';im.alt='문이 열린 방';im.classList.add('opened')}$('gfb').innerHTML='<b>찾았습니다!</b> '+esc(it.why)+' <button id="gnext" class="gprimary">'+(ri+1<R.length?'다음 방으로 →':'문을 열고 탈출')+'</button>';
    E.querySelectorAll('.gcard').forEach(function(x){x.disabled=true});$('ghint').hidden=true;
    $('gnext').onclick=function(){ri++;if(ri>=R.length)fin();else room()}}
   else{wrong++;b.classList.add('bad');b.disabled=true;$('gfb').innerHTML='이 카드는 규칙에 맞습니다. 다른 카드를 살펴보세요.';E.querySelector('.gbar b:last-child').textContent=wrong}})});
  $('ghint').onclick=function(){if(hints<1){$('gfb').textContent='힌트를 모두 썼습니다.';return}hints--;$('gfb').innerHTML='<b>힌트</b> '+esc(r.hint);E.querySelector('.gbar span:nth-child(2) b').textContent=hints}}
 function fin(){var s=Math.round((Date.now()-t0)/1000),st=wrong<=2&&hints===2?3:wrong<=5?2:1;
  E.innerHTML='<div class="gwin"><img class="rmimg big" src="img/art-escape-open.svg" alt="문이 열린 방"><div class="stars">'+'★'.repeat(st)+'☆'.repeat(3-st)+'</div><h2>탈출 성공!</h2><p>걸린 시간 '+Math.floor(s/60)+'분 '+(s%60)+'초 · 오답 '+wrong+'회 · 힌트 '+(2-hints)+'회</p><p>다섯 양식의 규칙을 모두 짚었습니다. 아래 가이드에서 틀렸던 부분을 다시 확인해 보세요.</p><div class="gbtns"><button id="gre" class="gprimary">다시 도전</button><a class="gbtn" href="quick.html">양식별 한눈에 보기</a></div></div>';
  $('gre').onclick=function(){ri=0;hints=2;wrong=0;t0=Date.now();room()}}
 room()}
// ===== 약어 빙고 =====
var B=$('bingo');
if(B){var P=JSON.parse($('bingodata').textContent),N=5,cells,marked,order,oi,miss,lines;
 function start(){var pool=sh(P).slice(0,24);cells=sh(pool);cells.splice(12,0,null);marked=cells.map(function(c){return c===null});order=sh(pool);oi=0;miss=0;lines=0;draw()}
 function count(){var L=[],i,j;for(i=0;i<5;i++){L.push([0,1,2,3,4].map(function(j){return i*5+j}));L.push([0,1,2,3,4].map(function(j){return j*5+i}))}
  L.push([0,6,12,18,24]);L.push([4,8,12,16,20]);return L.filter(function(l){return l.every(function(k){return marked[k]})}).length}
 function draw(){var cur=order[oi],ln=count(),win=ln>=3||oi>=order.length;
  B.innerHTML='<div class="gbar"><span>빙고 <b>'+ln+'</b>줄 <small>(3줄이면 승리)</small></span><span>남은 낱말 <b>'+(order.length-oi)+'</b></span><span>오답 <b>'+miss+'</b></span></div>'
  +(win?'<div class="gwin"><div class="stars">'+(ln>=3?'🎉':'🙂')+'</div><h2>'+(ln>=3?'빙고 '+ln+'줄 완성!':'낱말을 모두 썼습니다')+'</h2><p>오답 '+miss+'회. 학술지 이름의 약어는 실제로는 해당 학술지와 양식이 정한 약어표를 따릅니다.</p><div class="gbtns"><button id="bre" class="gprimary">다시 하기</button><a class="gbtn" href="apx07.html">영문 논문 약어표(부록 7)</a></div></div>'
   :'<div class="bcall"><span>이 낱말의 약어를 찾으세요</span><b>'+esc(cur[0])+'</b></div>')
  +'<div class="bgrid">'+cells.map(function(c,i){return c===null?'<div class="bc free on">FREE</div>':'<button class="bc'+(marked[i]?' on':'')+'" data-i="'+i+'"'+(win||marked[i]?' disabled':'')+'>'+esc(c[1])+'</button>'}).join('')+'</div>'
  +(win?'':'<div class="gbtns"><button id="bskip">건너뛰기</button></div>');
  if(win){$('bre').onclick=start;return}
  B.querySelectorAll('.bc[data-i]').forEach(function(b){b.addEventListener('click',function(){var i=+b.dataset.i;
   if(cells[i][0]===cur[0]){marked[i]=true;oi++;draw()}else{miss++;b.classList.add('bad');setTimeout(function(){b.classList.remove('bad')},500);B.querySelector('.gbar span:nth-child(3) b').textContent=miss}})});
  $('bskip').onclick=function(){oi++;draw()}}
 start()}
// ===== 가짜 출처 탐정단 =====
var T=$('det');
if(T){var C=JSON.parse($('detdata').textContent),ci=0,sc=0,total=0;
 function cs(){var c=C[ci];T.innerHTML='<div class="dhead"><img src="img/art-detective.svg" alt="탐정"><b>'+esc(c.t)+'</b></div><div class="gbar"><span>'+esc(c.t)+'</span><span>누적 점수 <b>'+sc+'</b></span></div><p>'+esc(c.story)+'</p><div class="dcards">'+sh(c.src.map(function(s,i){return i})).map(function(i){var s=c.src[i];return '<article class="dcard" data-i="'+i+'"><div class="dtxt">'+s.c+'</div><div class="dtools"><button data-k="doi">DOI 조회</button><button data-k="aut">저자 조회</button><button data-k="jrn">학술지 조회</button><button data-k="pg">쪽·권호 확인</button></div><div class="dres" hidden></div><label class="dflag"><input type="checkbox"> 의심스럽다</label></article>'}).join('')+'</div><div class="gbtns"><button id="dsub" class="gprimary">조사 결과 제출</button></div><div id="drep"></div>';
  T.querySelectorAll('.dcard').forEach(function(card){var s=c.src[+card.dataset.i];card.querySelectorAll('.dtools button').forEach(function(b){b.addEventListener('click',function(){var r=card.querySelector('.dres');r.hidden=false;var k=b.dataset.k;r.innerHTML='<b>'+b.textContent+'</b> '+esc(s[k]);b.classList.add('used')})})});
  $('dsub').onclick=function(){var ok=0,tot=c.src.length,rep=[];T.querySelectorAll('.dcard').forEach(function(card){var s=c.src[+card.dataset.i],f=card.querySelector('input').checked,good=f===s.fake;if(good)ok++;card.classList.add(good?'right':'wrong');
    rep.push('<li class="'+(good?'ok':'no')+'">'+(good?'✔ ':'✘ ')+(s.fake?'가짜 또는 오류: ':'정상: ')+esc(s.doi)+' '+esc(s.pg)+'</li>')});
   sc+=ok;total+=tot;$('dsub').hidden=true;$('drep').innerHTML='<h3>수사 결과 '+ok+' / '+tot+'</h3><ul class="dlist">'+rep.join('')+'</ul><div class="gbtns">'+(ci+1<C.length?'<button id="dn" class="gprimary">다음 사건 →</button>':'<button id="dre" class="gprimary">처음부터 다시</button>')+'</div>'+(ci+1>=C.length?'<p>전체 '+sc+' / '+total+'. 실제 과제에서는 DOI와 학술지 사이트에서 직접 확인하고, 확인하지 못한 서지는 쓰지 않습니다.</p>':'');
   if($('dn'))$('dn').onclick=function(){ci++;cs()};if($('dre'))$('dre').onclick=function(){ci=0;sc=0;total=0;cs()}}}
 cs()}
// ===== 생성형 AI 일지 =====
var A=$('aij');
if(A){var KEY='aijournal.v1',mem=[],store=true;
 function load(){try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){store=false;return mem}}
 function save(a){mem=a;try{localStorage.setItem(KEY,JSON.stringify(a))}catch(e){store=false}}
 var P=['자료 조사(검색 대신)','아이디어·주제 정하기','개요 짜기','문장 다듬기·번역','요약','코드·수식 확인','서지 형식 확인','기타'];
 function today(){var t=new Date();return t.getFullYear()+'-'+('0'+(t.getMonth()+1)).slice(-2)+'-'+('0'+t.getDate()).slice(-2)}
 function sentence(e){return '생성형 AI('+(e.tool||'도구명')+(e.ver?', '+e.ver:'')+')를 '+(e.use.length?e.use.join(', '):'○○')+' 목적으로 '+e.date+'에 사용했다. 입력한 내용: '+(e.prompt||'○○')+'. AI의 응답 중 '+(e.adopted||'○○')+'을(를) '+(e.how||'직접 확인하고 고쳐')+' 반영했다. 사실과 출처는 '+(e.verify||'직접 확인한 자료')+'(으)로 점검했다.'}
 function view(){var L=load();
  A.innerHTML='<div class="jform"><h2 class="gt">새 기록</h2><div class="gr"><label>날짜<input id="jd" type="date" value="'+today()+'"></label><label>과목·과제<input id="jc" placeholder="예: 글쓰기 보고서 2차"></label></div>'
  +'<div class="gr"><label>도구 이름<input id="jt" placeholder="사용한 도구"></label><label>버전·모델 <small>선택</small><input id="jv"></label></div>'
  +'<fieldset class="jus"><legend>어디에 썼나요(여러 개 선택)</legend>'+P.map(function(p,i){return '<label class="chk"><input type="checkbox" value="'+esc(p)+'"> '+esc(p)+'</label>'}).join('')+'</fieldset>'
  +'<label>입력한 요청(프롬프트) 요약<textarea id="jp" rows="2"></textarea></label><label>AI의 응답 중 반영한 부분<textarea id="ja" rows="2"></textarea></label><label>내가 고치거나 직접 쓴 부분<textarea id="jh" rows="2"></textarea></label><label>사실·출처를 확인한 방법<textarea id="jvf" rows="2" placeholder="예: 논문 쪽에서 DOI 확인, 안내서 해당 쪽과 대조"></textarea></label>'
  +'<label class="chk"><input type="checkbox" id="jck"> AI가 준 서지·인용은 모두 직접 열어 확인했다</label><div class="gbtns"><button id="jadd" class="gprimary">기록 저장</button></div></div>'
  +'<div class="jsum"><b>'+L.length+'</b>건 기록 · 출처 확인 완료 <b>'+L.filter(function(x){return x.chk}).length+'</b>건'+(store?'':' · <span class="warnt">이 환경에서는 브라우저 저장이 되지 않아 이 쪽을 닫으면 사라집니다. 전체 복사로 보관하세요.</span>')+'</div>'
  +'<div class="jlist">'+(L.length?L.slice().reverse().map(function(e,ri){var i=L.length-1-ri;return '<article class="jitem"><div class="jh"><b>'+esc(e.date)+'</b> · '+esc(e.course||'과목 미입력')+' · '+esc(e.tool||'도구 미입력')+(e.chk?' <span class="okb">출처 확인</span>':' <span class="nob">출처 확인 전</span>')+'</div><p>'+esc(e.use.join(', '))+'</p><details><summary>표기 문장 만들기</summary><div class="jsen cp">'+esc(sentence(e))+'</div><button class="gb" data-c="'+i+'">문장 복사</button></details><button class="gdel" data-d="'+i+'">삭제</button></article>'}).join(''):'<p class="mut">아직 기록이 없습니다.</p>')+'</div>'
  +'<div class="gbtns">'+(L.length?'<button id="jall">전체 복사</button><button id="jclr">전체 삭제</button>':'')+'</div><p class="mut">표기 문장은 이 안내서의 제안 형식입니다. 제출처의 지침이 있으면 그에 맞게 고치세요.</p>';
  $('jadd').onclick=function(){var use=[].map.call(A.querySelectorAll('.jus input:checked'),function(x){return x.value});
   var e={date:$('jd').value,course:$('jc').value.trim(),tool:$('jt').value.trim(),ver:$('jv').value.trim(),use:use,prompt:$('jp').value.trim(),adopted:$('ja').value.trim(),how:$('jh').value.trim(),verify:$('jvf').value.trim(),chk:$('jck').checked};
   var a=load();a.push(e);save(a);view()};
  A.querySelectorAll('.gb[data-c]').forEach(function(b){b.addEventListener('click',function(){cp(sentence(load()[+b.dataset.c]),b)})});
  A.querySelectorAll('.gdel').forEach(function(b){b.addEventListener('click',function(){var a=load();a.splice(+b.dataset.d,1);save(a);view()})});
  var al=$('jall');if(al)al.onclick=function(){cp(load().map(function(e,i){return (i+1)+'. '+e.date+' | '+e.course+' | '+e.tool+' '+e.ver+' | '+e.use.join(', ')+'\n   요청: '+e.prompt+'\n   반영: '+e.adopted+'\n   직접 고친 부분: '+e.how+'\n   확인: '+e.verify+' | 서지 확인 '+(e.chk?'예':'아니오')}).join('\n'),al)};
  var cl=$('jclr');if(cl)cl.onclick=function(){if(cl.dataset.s==='1'){save([]);view()}else{cl.dataset.s='1';cl.textContent='정말 삭제할까요? 한 번 더 누르세요'}}}
 view()}
})();
