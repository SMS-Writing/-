(function(){var d=document,host=d.getElementById('toontiger');if(!host)return;
function go(){if(!window.TOONK)return setTimeout(go,100);init(window.TOONK)}go();
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function init(K){var E=K.E,C=K.C,P=K.P,INK=K.INK||'#2b2118';
/* ---------- 어흥이: 새로 그린 원본 호랑이 (기분 4가지) ---------- */
function tiger(m){var O='#f2962b',D='#3a2410',CR='#fbe6bf',g='',x=75;
 var up=(m==='joy');
 // 꼬리
 g+='<path d="M108 150 C140 148 144 118 128 108" fill="none" stroke="'+O+'" stroke-width="11" stroke-linecap="round"/><path d="M131 136 l8 -3 M137 124 l8 -1 M131 112 l7 4" stroke="'+D+'" stroke-width="3" stroke-linecap="round"/>';
 // 몸
 g+=E(x,141,34,36,O)+E(x,146,21,27,CR);
 g+='<path d="M43 124 q9 3 13 11 M42 138 q9 1 13 8 M107 124 q-9 3 -13 11 M108 138 q-9 1 -13 8" fill="none" stroke="'+D+'" stroke-width="3.4" stroke-linecap="round"/>';
 g+=E(58,173,14,7,O)+E(92,173,14,7,O)+'<path d="M52 174 v-3 M58 174 v-3 M64 174 v-3 M86 174 v-3 M92 174 v-3 M98 174 v-3" stroke="'+D+'" stroke-width="1.6" stroke-linecap="round"/>';
 // 팔
 if(up){g+=E(34,112,8,19,O,-34)+E(116,112,8,19,O,34)}
 else if(m==='angry'){g+=E(44,140,8,18,O,-14)+E(106,140,8,18,O,14)}
 else{g+=E(40,138,8,19,O,18)+E(110,138,8,19,O,-18)}
 // 이름표
 g+='<rect x="52" y="140" width="46" height="15" rx="7.5" fill="#c0392b"/><text x="75" y="151" font-size="9.5" font-weight="800" fill="#fff" text-anchor="middle">어흥이</text>';
 // 귀
 g+=C(51,57,12,O)+C(99,57,12,O)+C(51,58,6,'#f4b3a6')+C(99,58,6,'#f4b3a6');
 // 얼굴
 g+=E(x,84,39,33,O);
 g+=P('37,86 28,95 41,98',O)+P('113,86 122,95 109,98',O);
 g+='<path d="M75 52 v12 M63 54 l3 10 M87 54 l-3 10 M38 82 h9 M40 91 h8 M112 82 h-9 M110 91 h-8" fill="none" stroke="'+D+'" stroke-width="3.4" stroke-linecap="round"/>';
 g+=E(x,97,17,12,CR)+P('70,90 80,90 75,96','#d9645a')+'<path d="M75 96 v4" stroke="'+D+'" stroke-width="1.6"/>';
 // 눈·입
 if(m==='ok'){g+=C(60,79,4.6,INK)+C(90,79,4.6,INK)+C(61.6,77.4,1.6,'#fff')+C(91.6,77.4,1.6,'#fff')+'<path d="M75 100 q-5 5 -9 1 M75 100 q5 5 9 1" fill="none" stroke="'+INK+'" stroke-width="2.2" stroke-linecap="round"/>'}
 else if(m==='confused'){g+=C(60,80,4.6,INK)+C(90,79,5.6,INK)+C(61.6,78.4,1.6,'#fff')+C(91.8,77.4,1.8,'#fff')+'<path d="M50 69 q9 -7 17 -1" fill="none" stroke="'+D+'" stroke-width="3" stroke-linecap="round"/><path d="M82 69 l16 6" fill="none" stroke="'+D+'" stroke-width="3" stroke-linecap="round"/><path d="M66 104 q4 -5 8 0 t8 0" fill="none" stroke="'+INK+'" stroke-width="2.2" stroke-linecap="round"/><text x="118" y="46" font-size="30" font-weight="900" fill="#f2c94c" stroke="'+D+'" stroke-width="1" text-anchor="middle">?</text><text x="28" y="40" font-size="19" font-weight="900" fill="#f2c94c" stroke="'+D+'" stroke-width=".8" text-anchor="middle">?</text><path d="M104 66 q3 6 0 9 q-3 -3 0 -9z" fill="#8fd3f4"/>'}
 else if(m==='angry'){g+=E(60,80,6,4.4,'#fff')+E(90,80,6,4.4,'#fff')+C(62,81,3.2,INK)+C(88,81,3.2,INK)+P('47,63 71,75 70,81 46,70',D)+P('103,63 79,75 80,81 104,70',D)+'<path d="M64 102 Q75 117 86 102 Z" fill="#7a1f1a"/><path d="M67 102 l2.4 6 l2.4 -6 M79.2 102 l2.4 6 l2.4 -6" fill="#fff" stroke="#fff" stroke-width="1"/><circle cx="34" cy="50" r="7" fill="#fff" opacity=".6"/><circle cx="26" cy="40" r="5" fill="#fff" opacity=".45"/><circle cx="116" cy="50" r="7" fill="#fff" opacity=".6"/><circle cx="124" cy="40" r="5" fill="#fff" opacity=".45"/><path d="M104 48 l6 3 M104 48 l3 -6 M104 48 l-6 0 M104 48 l3 6" stroke="#e03131" stroke-width="3" stroke-linecap="round"/>'}
 else{g+='<path d="M53 82 q7 -9 14 0 M83 82 q7 -9 14 0" fill="none" stroke="'+INK+'" stroke-width="3.2" stroke-linecap="round"/><path d="M62 100 Q75 120 88 100 Z" fill="#7a1f1a"/><ellipse cx="75" cy="111" rx="6" ry="4" fill="#e57373"/><circle cx="49" cy="95" r="5.5" fill="#ff8f8f" opacity=".55"/><circle cx="101" cy="95" r="5.5" fill="#ff8f8f" opacity=".55"/><text x="24" y="40" font-size="20" fill="#ffd84a">✦</text><text x="118" y="34" font-size="24" fill="#ffd84a">✦</text><text x="10" y="86" font-size="14" fill="#ffd84a">✦</text>'}
 return g}
function tigerSvg(m){return '<svg viewBox="0 0 150 190" class="vp-bearsvg" aria-hidden="true">'+tiger(m||'ok')+'</svg>'}

/* ---------- 자료: 연습용 가상 저자 (영어 Seoyun Han·Elena Rivera, 국문 한서윤·이도윤) ---------- */
var ST=function(o,t,lab){return {order:o,txt:t,lab:lab}};
var EP=[
{k:'apa',t:'1화 APA 편',c:'#3a5fb0',topic:'본문은 성만, 목록은 성 + 이니셜',
 hook:['본문 괄호에는 성만 쓴다 — 이름·이니셜은 쓰지 않는다','저자 둘은 &, 셋 이상은 첫 저자 + et al.(첫 인용부터)','목록에서만 성, 이니셜 — 모든 저자를 이렇게 쓴다'],
 steps:[
  {lab:'이름 그대로 (평소 순서)',cap:'Seoyun Han and Elena Rivera — 이름 먼저, 성 나중',order:['a1','a2','x','b1','b2'],txt:{a1:'Seoyun',a2:'Han',x:'and',b1:'Elena',b2:'Rivera'}},
  {lab:'① 본문 괄호',cap:'이름이 사라지고 성만 남는다. and 대신 &, 뒤에 연도',order:['a2','x','b2','y'],txt:{a2:'(Han',x:'&',b2:'Rivera,',y:'2021)'},tag:{y:'연도'}},
  {lab:'② 참고문헌 목록',cap:'성이 맨 앞, 이름은 이니셜 + 마침표. 둘째 저자도 성이 먼저',order:['a2','a1','x','b2','b1','y'],txt:{a2:'Han,',a1:'S.,',x:'&',b2:'Rivera,',b1:'E.',y:'(2021).'},tag:{y:'연도'}}],
 rows:[['1명','(Han, 2021)','(한서윤, 2021)'],['2명','(Han & Rivera, 2021)','(한서윤 & 이도윤, 2021)'],['3명 이상','(Han et al., 2021)','(한서윤 외, 2021)'],['문장 안에서','Han and Rivera (2021)','한서윤과 이도윤(2021)은 …']],
 rowSay:['저자가 한 명이면 성과 연도만. 쉼표가 들어가는 게 APA의 특징이야.','두 명이면 & 로 잇고, 한국어는 같은 모양으로 쓰되 이름 전체를 쓴다.','세 명 이상이면 첫 저자만 쓰고 et al., 한국어는 외. 첫 번째 인용부터 이렇게 줄여.','문장 안에서는 and를 풀어 쓰고, 연도만 괄호에 넣어.'],
 colHead:['구분','영어 저자','한국어 저자 (◇ 가상)'],
 mis:[['(Seoyun Han, 2021)','(Han, 2021)','본문 괄호에 이름을 쓰면 안 돼요. 성만!'],['(Han S., 2021)','(Han, 2021)','이니셜은 성이 같은 저자가 따로 있을 때만 본문에 붙입니다.'],['(Han, Rivera, 2021)','(Han & Rivera, 2021)','저자 둘 사이에는 쉼표가 아니라 &.']],
 quiz:{q:'APA 본문 괄호에서 Seoyun Han의 2021년 글을 맞게 쓴 것은?',opts:['(Han, 2021)','(Seoyun Han, 2021)','(Han S., 2021)'],a:0,exp:'본문은 성만 쓴다. 이니셜은 목록에서만.'},
 pass:'참고문헌 오류 0건'},
{k:'cad',t:'2화 Chicago Author-Date 편',c:'#4fa08f',topic:'본문은 성만·쉼표 없이, 목록은 첫 저자만 뒤집기',
 hook:['본문 괄호는 성만, 저자와 연도 사이에 쉼표가 없다 (Han 2021)','저자 둘은 and, 3명 이상은 첫 저자 et al.','목록은 첫 번째 저자만 성, 이름 — 둘째부터는 이름 성 그대로'],
 steps:[
  {lab:'이름 그대로 (평소 순서)',cap:'Seoyun Han and Elena Rivera',order:['a1','a2','x','b1','b2'],txt:{a1:'Seoyun',a2:'Han',x:'and',b1:'Elena',b2:'Rivera'}},
  {lab:'① 본문 괄호',cap:'이름이 사라지고 성만. 연도 앞에 쉼표가 없다',order:['a2','x','b2','y'],txt:{a2:'(Han',x:'and',b2:'Rivera',y:'2021)'},tag:{y:'연도'}},
  {lab:'② 참고문헌 목록',cap:'첫 저자 Han만 뒤집힌다. Elena Rivera는 그대로',order:['a2','a1','x','b1','b2','y'],txt:{a2:'Han,',a1:'Seoyun,',x:'and',b1:'Elena',b2:'Rivera.',y:'2021.'},tag:{y:'연도'}}],
 rows:[['1명','(Han 2021)','(한서윤 2021)'],['2명','(Han and Rivera 2021)','(한서윤·이도윤 2021)'],['3명 이상 (국문은 4명 이상)','(Han et al. 2021)','(한서윤 외 2021)'],['쪽수까지','(Han 2021, 15)','(한서윤 2021, 15)']],
 rowSay:['한 명이면 (Han 2021). APA와 달리 쉼표가 없어.','두 명이면 and로 잇고, 한국어는 가운뎃점으로 이어.','영어는 세 명부터 et al., 국문은 네 명 이상부터 외로 줄여.','쪽수가 필요하면 연도 뒤에 쉼표를 찍고 붙여.'],
 colHead:['구분','영어 저자','한국어 저자 (◇ 가상)'],
 mis:[['(Han, 2021)','(Han 2021)','쉼표는 APA식이에요. Chicago는 저자 뒤에 쉼표가 없어요.'],['(Han & Rivera 2021)','(Han and Rivera 2021)','& 대신 and를 씁니다.'],['Seoyun Han and Elena Rivera. 2021.','Han, Seoyun, and Elena Rivera. 2021.','목록에서는 첫 저자만 성, 이름 순서로 뒤집어요.']],
 quiz:{q:'Chicago A-D 목록에서 두 저자를 맞게 쓴 것은?',opts:['Han, Seoyun, and Elena Rivera.','Seoyun Han and Elena Rivera.','Han, Seoyun, and Rivera, Elena.'],a:0,exp:'첫 번째 저자만 성, 이름. 둘째 저자는 이름 성 그대로.'},
 pass:'저자 표기 오류 0건'},
{k:'mla',t:'3화 MLA 편',c:'#7a62c4',topic:'본문엔 연도 없이 성 + 쪽수',
 hook:['본문 괄호는 성 + 쪽수, 연도는 쓰지 않는다 (Han 15)','저자 둘은 and, 3명 이상은 첫 저자 et al.','Works Cited는 첫 저자만 성, 이름 — 둘째부터 이름 성'],
 steps:[
  {lab:'이름 그대로 (평소 순서)',cap:'Seoyun Han and Elena Rivera',order:['a1','a2','x','b1','b2'],txt:{a1:'Seoyun',a2:'Han',x:'and',b1:'Elena',b2:'Rivera'}},
  {lab:'① 본문 괄호',cap:'이름이 사라지고 성만 + 쪽수. 연도도 쉼표도 없다',order:['a2','x','b2','y'],txt:{a2:'(Han',x:'and',b2:'Rivera',y:'15)'},tag:{y:'쪽수'}},
  {lab:'② Works Cited',cap:'첫 저자 Han만 뒤집힌다. Elena Rivera는 그대로',order:['a2','a1','x','b1','b2'],txt:{a2:'Han,',a1:'Seoyun,',x:'and',b1:'Elena',b2:'Rivera.'}}],
 rows:[['1명','(Han 15)','(한서윤 15)'],['2명','(Han and Rivera 15)','(한서윤·이도윤 15)'],['3명 이상','(Han et al. 15)','(한서윤 외 15)'],['문장에 저자를 썼다면','According to Han, … (15).','한서윤에 따르면 … (15).']],
 rowSay:['한 명이면 성과 쪽수. 연도가 없다는 게 MLA의 얼굴이야.','두 명이면 and. 한국어는 가운뎃점으로 이어.','세 명 이상이면 et al., 한국어는 외로 줄여.','문장에서 저자를 이미 밝혔다면 괄호에는 쪽수만 써.'],
 colHead:['구분','영어 저자','한국어 저자 (◇ 가상)'],
 mis:[['(Han 2021, 15)','(Han 15)','MLA 본문 괄호에는 연도를 쓰지 않아요.'],['(Han, 15)','(Han 15)','저자와 쪽수 사이에 쉼표를 찍지 않아요.'],['Han, Seoyun, and Rivera, Elena.','Han, Seoyun, and Elena Rivera.','둘째 저자는 뒤집지 않아요.']],
 quiz:{q:'MLA 본문에서 Han의 15쪽을 인용할 때 맞는 것은?',opts:['(Han 15)','(Han 2021, 15)','(Han, 15)'],a:0,exp:'성 + 쪽수. 연도와 쉼표는 쓰지 않는다.'},
 pass:'인용 표기 오류 0건'},
{k:'nb',t:'4화 Chicago Notes-Bibliography 편',c:'#c97a2c',topic:'각주는 이름 성, 약식은 성만, 참고문헌은 첫 저자만 뒤집기',
 hook:['첫 각주는 이름을 다 쓰고 이름 성 순서 (Seoyun Han)','다시 인용하는 약식 각주는 성만 + 짧은 제목 + 쪽','참고문헌은 첫 저자만 성, 이름 — 여기만 뒤집힌다'],
 steps:[
  {lab:'① 첫 번째 각주',cap:'이름을 다 쓰고, 이름 성 순서 그대로. 쉼표로 이어 간다',order:['a1','a2','x','b1','b2'],txt:{a1:'Seoyun',a2:'Han',x:'and',b1:'Elena',b2:'Rivera,'}},
  {lab:'② 약식 각주 (다시 인용)',cap:'이름이 사라지고 성만 남는다. 뒤에 짧은 제목과 쪽',order:['a2','x','b2','y'],txt:{a2:'Han',x:'and',b2:'Rivera,',y:'Short Title, 18.'},tag:{y:'짧은 제목 · 쪽'}},
  {lab:'③ 참고문헌',cap:'첫 저자 Han만 뒤집힌다. 마침표로 끝난다',order:['a2','a1','x','b1','b2'],txt:{a2:'Han,',a1:'Seoyun,',x:'and',b1:'Elena',b2:'Rivera.'}}],
 rows:[['1명 (첫 각주)','Seoyun Han, Title (…), 15.','한서윤, 『제목』 (출판사, 2021), 15.'],['2명 (첫 각주)','Seoyun Han and Elena Rivera, Title …','한서윤·이도윤, 『제목』 …'],['3명 이상','Seoyun Han et al., Title …','한서윤 외, 『제목』 …'],['약식 각주','Han and Rivera, Short Title, 18.','한서윤·이도윤, 『짧은 제목』, 18.']],
 rowSay:['첫 각주는 이름 성 순서로 다 쓰고 쪽까지. 한국어는 성과 이름 그대로.','저자가 둘이면 and, 한국어는 가운뎃점.','세 명 이상이면 첫 저자 뒤에 et al., 한국어는 외.','다시 인용할 때는 성만, 짧은 제목, 쪽수. 영어는 Ibid. 대신 이 약식을 권한다(18판).'],
 colHead:['구분','영어 저자','한국어 저자 (◇ 가상)'],
 again:{head:'같은 책을 다시 인용할 때',rows:[['바로 앞 각주와 같은 문헌','위의 글, 18.','국내 관행'],['앞에서 인용했지만 바로 앞은 아님','한서윤, 앞의 글, 20.','국내 관행'],['영어 (Chicago 18판)','Han and Rivera, Short Title, 18.','Ibid.·op. cit.은 쓰지 않는다']],say:['한국어 각주에서는 바로 앞 각주와 같은 글이면 위의 글, 쪽수를 써.','바로 앞은 아니지만 앞에서 인용한 글이면 저자 이름, 앞의 글, 쪽수.','영어는 Ibid. 대신 성만 쓴 약식 각주를 쓴다. op. cit.은 쓰지 않아.']},
 mis:[['Han, Seoyun and Elena Rivera, Title …','Seoyun Han and Elena Rivera, Title …','각주는 뒤집지 않아요. 이름 성 순서!'],['Seoyun Han and Elena Rivera, Short Title, 18.','Han and Rivera, Short Title, 18.','약식 각주에는 이름을 다시 쓰지 않고 성만.'],['Seoyun Han and Elena Rivera. Title …','Han, Seoyun, and Elena Rivera. Title …','참고문헌은 첫 저자만 성, 이름 순서로 뒤집어요.']],
 quiz:{q:'Chicago N-B에서 첫 번째 각주에 두 저자를 맞게 쓴 것은?',opts:['Seoyun Han and Elena Rivera,','Han, Seoyun, and Elena Rivera,','Han and Rivera,'],a:0,exp:'각주는 이름 성 순서. 뒤집는 곳은 참고문헌.'},
 pass:'각주·서지 오류 0건'},
{k:'ieee',t:'5화 IEEE 편',c:'#2d7fa8',topic:'이니셜이 앞, 성이 뒤 — 본문은 번호',
 hook:['본문에는 이름 대신 번호 [1]을 쓴다','목록은 이니셜 먼저, 성 나중 — S. Han (성이 앞이 아니다)','저자 둘은 and, 같은 문헌은 같은 번호를 다시 쓴다'],
 steps:[
  {lab:'이름 그대로 (평소 순서)',cap:'Seoyun Han and Elena Rivera',order:['a1','a2','x','b1','b2'],txt:{a1:'Seoyun',a2:'Han',x:'and',b1:'Elena',b2:'Rivera'}},
  {lab:'① 본문 (저자를 언급할 때)',cap:'이름이 사라지고 성만, 뒤에 번호. 저자를 안 쓰면 번호만 [1]',order:['a2','x','b2','y'],txt:{a2:'Han',x:'and',b2:'Rivera',y:'[1]'},tag:{y:'번호'}},
  {lab:'② 참고문헌 목록',cap:'앞에 번호, 이니셜이 먼저 오고 성이 나중에. 순서를 뒤집지 않는다',order:['y','a1','a2','x','b1','b2'],txt:{y:'[1]',a1:'S.',a2:'Han',x:'and',b1:'E.',b2:'Rivera,'},tag:{y:'번호'}}],
 rows:[['번호만','… 보고했다 [1].','… 보고했다 [1].'],['저자를 언급할 때 (2명)','Han and Rivera [1]','학회 규정 확인'],['3명 이상','Han et al. [2]','한서윤 외 [2]'],['같은 문헌 다시','… [1].','… [1].']],
 rowSay:['IEEE는 대부분 번호만 써. 저자 이름이 본문에 안 나와도 돼.','저자를 문장에 넣고 싶을 때는 성만 쓰고 번호를 붙여.','세 명 이상이면 첫 저자 et al., 한국어는 외.','같은 문헌을 다시 인용해도 새 번호가 아니라 처음 번호 [1] 그대로야.'],
 colHead:['구분','영어 저자','한국어 저자 (◇ 가상)'],
 mis:[['[Han, 2021]','[1]','본문에는 성과 연도 대신 번호를 써요.'],['[1] Han, S. and Rivera, E.','[1] S. Han and E. Rivera','IEEE는 이니셜이 앞, 성이 뒤예요.'],['[4] S. Han and E. Rivera (같은 문헌 두 번째)','[1] S. Han and E. Rivera','다시 인용해도 처음 번호를 그대로 써요. 목록에도 다시 올리지 않아요.']],
 quiz:{q:'IEEE 목록에서 두 저자를 맞게 쓴 것은?',opts:['[1] S. Han and E. Rivera','[1] Han, S. and Rivera, E.','[1] Seoyun Han and Elena Rivera'],a:0,exp:'이니셜 먼저, 성 나중. 성을 앞에 두지 않는다.'},
 pass:'번호·저자 오류 0건'},
{k:'van',t:'6화 Vancouver 편',c:'#d0453b',topic:'성 먼저, 이니셜은 붙여서 점 없이',
 hook:['본문에는 이름 없이 번호 (1)만 쓴다','목록은 성 먼저, 이니셜은 붙이고 마침표를 찍지 않는다 — Han S','저자 사이는 쉼표, 끝에만 마침표. 6명 넘으면 et al.(투고 규정 확인)'],
 steps:[
  {lab:'이름 그대로 (평소 순서)',cap:'Seoyun Han and Elena Rivera',order:['a1','a2','x','b1','b2'],txt:{a1:'Seoyun',a2:'Han',x:'and',b1:'Elena',b2:'Rivera'}},
  {lab:'① 본문',cap:'이름이 모두 사라지고 번호만 남는다 (같은 문헌은 같은 번호)',order:['y'],txt:{y:'(1)'},tag:{y:'번호'}},
  {lab:'② 참고문헌 목록',cap:'성 먼저, 이니셜은 마침표 없이 붙인다. 저자 사이는 쉼표, 끝은 마침표',order:['y','a2','a1','b2','b1'],txt:{y:'1.',a2:'Han',a1:'S,',b2:'Rivera',b1:'E.'},tag:{y:'번호'}}],
 rows:[['1명','Han S.','Lee JH. (한국 이름은 두 글자 머리글자)'],['2명','Han S, Rivera E.','Lee JH, Seo HS.'],['6명까지','Han S, Rivera E, Okafor M, Lin J, Park D, Silva C.','—'],['7명 이상','Han S, Rivera E, Okafor M, Lin J, Park D, Silva C, et al.','—']],
 rowSay:['한 명이면 성, 이니셜, 마침표. 이니셜 사이에 점이 없어.','두 명이면 쉼표로 잇고 맨 끝에만 마침표.','여섯 명까지는 모두 써.','일곱 명 이상이면 여섯 명 뒤에 et al.. 다만 학술지마다 달라서 투고 규정을 먼저 봐.'],
 colHead:['구분','영어 저자 (◇ 가상)','한국 저자 예'],
 mis:[['Han, S., Rivera, E.','Han S, Rivera E.','점과 쉼표를 이니셜에 붙이지 않아요.'],['S. Han, E. Rivera','Han S, Rivera E.','IEEE식이에요. Vancouver는 성이 먼저!'],['Han S; Rivera E.','Han S, Rivera E.','세미콜론은 ACS식이에요. 저자 사이는 쉼표.']],
 quiz:{q:'Vancouver 목록에서 두 저자를 맞게 쓴 것은?',opts:['Han S, Rivera E.','Han, S., Rivera, E.','S. Han, E. Rivera'],a:0,exp:'성 먼저, 이니셜은 점 없이 붙인다. 쉼표로 잇는다.'},
 pass:'저자 표기 오류 0건'},
{k:'acs',t:'7화 ACS 편',c:'#2f9d6a',topic:'성, 이니셜 — 저자 사이는 세미콜론',
 hook:['목록은 성, 이니셜 순서 — Han, S.','저자 사이는 쉼표가 아니라 세미콜론(;)','본문은 번호(위첨자·괄호)나 저자–연도 중 학술지 규정대로'],
 steps:[
  {lab:'이름 그대로 (평소 순서)',cap:'Seoyun Han and Elena Rivera',order:['a1','a2','x','b1','b2'],txt:{a1:'Seoyun',a2:'Han',x:'and',b1:'Elena',b2:'Rivera'}},
  {lab:'① 본문 (번호 방식)',cap:'이름이 사라지고 번호만. 위첨자나 이탤릭 괄호 번호',order:['y'],txt:{y:'¹'},tag:{y:'번호'}},
  {lab:'② 참고문헌 목록',cap:'모든 저자가 성, 이니셜. 저자 사이는 세미콜론',order:['a2','a1','b2','b1'],txt:{a2:'Han,',a1:'S.;',b2:'Rivera,',b1:'E.'}}],
 rows:[['1명','Han, S.','—'],['2명','Han, S.; Rivera, E.','—'],['3명','Han, S.; Rivera, E.; Okafor, M.','—'],['저자–연도 방식의 본문','Rivera and Han (2022) / (Han et al., 2022)','3명 이상은 첫 저자 et al.']],
 rowSay:['한 명이면 성, 이니셜. 마침표를 꼭 붙여.','두 명이면 세미콜론으로 이어. 쉼표가 아니야.','세 명도 전부 세미콜론으로 이어 쓴다.','저자–연도 방식을 쓰는 학술지라면 본문에는 이렇게 써. 이때 둘은 and, 셋 이상은 et al.'],
 colHead:['구분','영어 저자 (◇ 가상)','비고'],
 mis:[['Han, S., Rivera, E.','Han, S.; Rivera, E.','저자 사이는 세미콜론!'],['S. Han; E. Rivera','Han, S.; Rivera, E.','ACS는 성이 먼저, 이니셜이 나중이에요.'],['Han, S., & Rivera, E.','Han, S.; Rivera, E.','&와 쉼표는 APA식이에요.']],
 quiz:{q:'ACS 목록에서 두 저자를 맞게 쓴 것은?',opts:['Han, S.; Rivera, E.','Han, S., & Rivera, E.','S. Han; E. Rivera'],a:0,exp:'성, 이니셜 순서에 세미콜론으로 잇는다.'},
 pass:'저자 표기 오류 0건'}
];
var NMK={apa:'APA',cad:'Chicago A-D',mla:'MLA',nb:'Chicago N-B',ieee:'IEEE',van:'Vancouver',acs:'ACS'};
var TK=[['a1','g'],['a2','s'],['x','o'],['b1','g'],['b2','s'],['y','o']];
host.innerHTML='<div class="vp vt"><div class="vp-stage" tabindex="0" aria-label="어흥이의 이름 표기 영상"><div class="vp-mascot"><div class="vp-bubble"></div><div class="vp-bear"></div></div><div class="vp-main"><div class="vp-chip"></div><div class="vp-scene"></div><div class="vp-sub" aria-live="off"></div></div><button type="button" class="vp-big" aria-label="재생">▶</button><div class="vp-ctl"><div class="vp-bar" role="slider" aria-label="재생 위치"></div><div class="vp-row"><button type="button" data-a="prev" title="이전 장면">⏮</button><button type="button" data-a="pp" title="재생·멈춤 (스페이스)">▶</button><button type="button" data-a="next" title="다음 장면">⏭</button><span class="vp-time">0:00</span><span class="vp-sp"></span><button type="button" data-a="cc" class="on" title="자막">자막</button><button type="button" data-a="voice" title="브라우저 음성으로 읽어 주기">소리</button><button type="button" data-a="spd" title="재생 속도">1×</button><button type="button" data-a="auto" class="on" title="끝나면 다음 화 자동 재생">자동</button><button type="button" data-a="fs" title="전체 화면">⛶</button></div></div></div><div class="vp-list" role="list"></div><p class="mut vp-note">호랑이 어흥이가 본문 괄호와 각주에서 저자 이름을 어떻게 쓰는지 양식별로 보여 줍니다. 참고문헌 목록은 앞의 애니메이션에도 있지만, 여기서는 <b>본문·각주에서의 이름</b>을 중심으로 목록과 비교합니다. 영어 저자 Seoyun Han·Elena Rivera와 한국어 저자 한서윤·이도윤은 연습용 가상 자료(◇)이고, 어흥이는 새로 그린 원본 캐릭터입니다. 학술지·학과 규정이 있으면 그것이 먼저입니다.</p></div>';
var ei=0,bi=0,si=-1,playing=false,el=0,speed=1,cc=true,voice=false,auto=true,raf=0,last=0,scenes=[],beats=[],total=0,typed='',endTimer=0,curMood='';
var $=function(q){return host.querySelector(q)},stage=$('.vp-stage'),scene=$('.vp-scene'),sub=$('.vp-sub'),chip=$('.vp-chip'),bar=$('.vp-bar'),big=$('.vp-big'),list=$('.vp-list'),bubble=$('.vp-bubble'),bearEl=$('.vp-bear');
function setMood(m){if(m===curMood)return;curMood=m;bearEl.innerHTML=tigerSvg(m);bearEl.className='vp-bear mood-'+m}
function tokHtml(){return TK.map(function(t){return '<span class="t-chip '+t[1]+'" data-id="'+t[0]+'"><b></b><small></small></span>'}).join('')}
function legend(){return '<div class="t-leg"><span class="t-chip s"><b>Han</b><small>성</small></span> 성(가족 이름) <span class="t-chip g"><b>Seoyun</b><small>이름</small></span> 이름(본인 이름)</div>'}
function make(e,k){var n=NMK[e.k],S=[];
 // 1 오프닝: 헷갈림
 var mess=['(Han, 2021)?','Seoyun Han?','Han, S.?','S. Han?','Han S?','(한서윤 2021)?'];
 S.push({k:'오프닝',m:'confused',html:'<div class="v-title" style="--c:'+e.c+'"><small>어흥이의 이름 표기 교실</small><b>'+esc(e.t)+'</b><span>'+esc(e.topic)+'</span></div><div class="t-mess" data-r="1">'+mess.map(function(w,i){return '<i style="--i:'+i+'">'+esc(w)+'</i>'}).join('')+'</div>',
  b:[{say:e.t+'. '+e.topic+'.',bub:'안녕, 어흥이야!',r:0,dur:4200},{say:'성만 쓰나? 이름까지 쓰나? 성이 먼저야, 이름이 먼저야? 으아, 헷갈린다!',bub:'으아, 헷갈려!',r:1,dur:5200,m:'confused'}]});
 // 2 두 저자
 S.push({k:'성과 이름',m:'ok',html:'<h4 class="v-h">먼저, 성과 이름부터 구분하자</h4>'+legend()+'<div class="t-people"><div class="t-p" data-r="1"><em>🌏 영어 저자 (◇ 가상)</em><div class="t-row"><span class="t-chip g"><b>Seoyun</b><small>이름</small></span><span class="t-chip s"><b>Han</b><small>성</small></span><span class="t-chip o"><b>and</b></span><span class="t-chip g"><b>Elena</b><small>이름</small></span><span class="t-chip s"><b>Rivera</b><small>성</small></span></div><p>영어 이름은 보통 이름이 앞, 성이 뒤</p></div><div class="t-p" data-r="2"><em>🇰🇷 한국어 저자 (◇ 가상)</em><div class="t-row"><span class="t-chip s"><b>한</b><small>성</small></span><span class="t-chip g"><b>서윤</b><small>이름</small></span><span class="t-chip o"><b>·</b></span><span class="t-chip s"><b>이</b><small>성</small></span><span class="t-chip g"><b>도윤</b><small>이름</small></span></div><p>한국어 이름은 성이 앞, 이름이 뒤</p></div></div><p class="t-keep" data-r="3">'+esc(n)+'는 이 두 가지를 <b>줄이거나, 뒤집거나, 이니셜로 바꿔서</b> 쓴다</p>',
  b:[{say:'이 편의 연습용 가상 저자는 Seoyun Han과 Elena Rivera야. 빨간 칩이 성, 파란 칩이 이름이야.',bub:'빨강=성, 파랑=이름',r:1,dur:0},{say:'한국어는 반대야. 한서윤은 성이 한, 이름이 서윤. 성이 앞에 와.',bub:'한국어는 성이 먼저',r:2,dur:0},{say:n+'는 이 이름들을 줄이거나, 순서를 뒤집거나, 이니셜로 바꿔서 써. 그 규칙을 끝까지 보여 줄게.',bub:'규칙은 딱 몇 개!',r:3,dur:0}]});
 // 3 모양 변신
 var sb=e.steps.map(function(s,i){return {say:(i===0?'먼저 평소처럼 쓴 이름이야. ':'')+s.lab.replace(/^[①②③] /,'')+(i>0?'. ':'. ')+s.cap+'.',bub:s.lab.replace(/^[①②③] /,''),r:i+1,dur:0}});
 sb.push({say:'칩이 움직이는 걸 다시 떠올려 봐. 줄이고, 뒤집고, 이니셜로. '+n+'는 이 순서로 바뀌어.',bub:'칩의 움직임 기억!',r:e.steps.length+1,dur:0});
 S.push({k:'이름이 바뀌는 과정',m:'ok',html:'<h4 class="v-h">같은 두 사람, '+esc(n)+'에서는?</h4>'+legend()+'<div class="t-morph" data-morph=\''+JSON.stringify(e.steps)+'\'><div class="t-pill"></div><div class="t-row">'+tokHtml()+'</div><p class="t-cap"></p></div>',b:sb});
 // 4 저자 수·한국어
 var two=e.rows.some(function(r){return r[2]&&r[2]!=='—'});
 var tb='<h4 class="v-h">저자 수에 따라, 그리고 한국어라면</h4><table class="t-tab"><thead><tr>'+e.colHead.map(function(h){return '<th>'+esc(h)+'</th>'}).join('')+'</tr></thead><tbody>'+e.rows.map(function(r,i){return '<tr data-r="'+(i+1)+'" data-cur="'+(i+1)+'"><th>'+esc(r[0])+'</th><td>'+esc(r[1])+'</td><td>'+esc(r[2])+'</td></tr>'}).join('')+'</tbody></table>';
 var rb=e.rowSay.map(function(t,i){return {say:t,bub:e.rows[i][0],r:i+1,dur:0}});
 S.push({k:'저자 수·한국어',m:'ok',html:tb,b:rb});
 // 4b 다시 인용 (NB만)
 if(e.again){S.push({k:'다시 인용',m:'ok',html:'<h4 class="v-h">'+esc(e.again.head)+'</h4><table class="t-tab"><thead><tr><th>상황</th><th>쓰는 모양</th><th>비고</th></tr></thead><tbody>'+e.again.rows.map(function(r,i){return '<tr data-r="'+(i+1)+'" data-cur="'+(i+1)+'"><th>'+esc(r[0])+'</th><td>'+esc(r[1])+'</td><td>'+esc(r[2])+'</td></tr>'}).join('')+'</tbody></table>',
   b:e.again.say.map(function(t,i){return {say:t,bub:['위의 글','앞의 글','영어는 약식'][i],r:i+1,dur:0}})})}
 // 5 어흥 실수
 var mb=[{say:'헷갈린다… 화가 난다… 어흥~! 자주 하는 실수 세 개만 모아 봤어.',bub:'어흥~!!',r:0,dur:0,m:'angry'}];
 e.mis.forEach(function(x,i){mb.push({say:(i+1)+'번째 실수! '+x[0]+' 는 틀렸어. 맞는 건 '+x[1]+'.',bub:['어흥! 틀렸어!','으르렁!','이건 안 돼!'][i%3],r:i+1,dur:0,m:'angry'})});
 mb.push({say:'이 세 가지만 안 틀려도 인용 표기는 반 이상 끝난 거야.',bub:'후우, 진정…',r:e.mis.length+1,dur:0,m:'ok'});
 S.push({k:'어흥! 자주 하는 실수',m:'angry',html:'<h4 class="v-h">어흥~! 이렇게 쓰면 안 돼요</h4><div class="t-mis">'+e.mis.map(function(x,i){return '<div class="t-m" data-r="'+(i+1)+'"><div class="bad"><i>✗</i><s>'+esc(x[0])+'</s></div><div class="good"><i>✓</i><b>'+esc(x[1])+'</b></div><p>'+esc(x[2])+'</p></div>'}).join('')+'</div>',b:mb});
 // 6 줄무늬 3줄
 S.push({k:'호랑이 줄무늬 3줄',m:'ok',html:'<h4 class="v-h">줄무늬 세 줄만 기억해!</h4><ul class="t-str">'+e.hook.map(function(t,i){return '<li data-r="'+(i+1)+'"><i></i><span>'+esc(t)+'</span></li>'}).join('')+'</ul>',
  b:e.hook.map(function(t,i){return {say:['첫 번째 줄무늬. ','두 번째 줄무늬. ','세 번째 줄무늬. '][i]+t+'.',bub:['첫째 줄','둘째 줄','셋째 줄'][i],r:i+1,dur:0}})});
 // 7 퀴즈
 var q=e.quiz,opts=q.opts.slice(),good=opts[q.a],rot=k%3;opts=opts.slice(rot).concat(opts.slice(0,rot));var ai=opts.indexOf(good);
 S.push({k:'퀴즈',m:'ok',html:'<h4 class="v-h">퀴즈</h4><p class="v-q" data-r="1">'+esc(q.q)+'</p><ul class="v-opt" data-r="1">'+opts.map(function(o,i){return '<li data-ans="'+(i===ai?1:0)+'"><i>'+'①②③'[i]+'</i>'+esc(o)+'</li>'}).join('')+'</ul><p class="v-exp" data-r="2">정답은 '+'①②③'[ai]+' '+esc(good)+'. '+esc(q.exp)+'</p>',
  b:[{say:'퀴즈 시간! '+q.q+' 잠깐 생각해 봐.',bub:'퀴즈 시간!',r:1,dur:8200},{say:'정답은 '+(ai+1)+'번, '+good+'. '+q.exp,bub:'정답은 '+(ai+1)+'번!',r:2,dur:0,m:'happy'}]});
 // 8 정리
 var rows=['본문·각주: '+e.hook[0],e.hook[1],e.hook[2],'마지막으로, 학술지·학과 규정이 언제나 먼저다'];
 S.push({k:'정리',m:'ok',html:'<h4 class="v-h">어흥이의 제출 전 점검</h4><ul class="v-check">'+rows.map(function(t,i){return '<li data-r="'+(i+1)+'"><i>✓</i><span>'+esc(t)+'</span></li>'}).join('')+'</ul>',
  b:rows.map(function(t,i){return {say:['점검 하나. ','점검 둘. ','점검 셋. ','마지막 점검. '][i]+t+'.',bub:['하나!','둘!','셋!','마지막!'][i],r:i+1,dur:0}})});
 // 9 논문 통과
 var nx=EP[k+1],cf='';for(var c=0;c<26;c++)cf+='<u style="left:'+((c*37)%100)+'%;animation-delay:'+((c*0.23)%2.4).toFixed(2)+'s;background:'+['#f2c94c','#e57373','#64b5f6','#81c784','#ba68c8'][c%5]+'"></u>';
 S.push({k:'논문 통과!',m:'ok',html:'<div class="t-pass"><div class="t-cf">'+cf+'</div><div class="t-mail" data-r="1"><small>◇ 연습용 가상 화면</small><b>투고 논문 심사 결과 안내</b><p data-r="1">인용·참고문헌 점검: <em>'+esc(e.pass)+'</em></p></div><div class="t-stamp" data-r="2">게재 확정!</div></div>',
  b:[{say:'그리고 몇 주 뒤… 심사 결과가 도착했어. 인용 표기 지적은 하나도 없어!',bub:'결과가 왔다!',r:1,dur:0,m:'ok'},{say:'논문 통과! 어흥~ 아니, 야호! 헷갈려서 화났던 시간이 전부 기쁨으로 바뀌었어!',bub:'야호~ 통과!!',r:2,dur:6200,m:'joy'},{say:nx?'다음 화는 '+nx.t+'야. 거기서 또 만나자, 어흥!':'마지막 화였어. 이름 표기, 이제 안 헷갈리지? 어흥~!',bub:nx?'다음 화에서 봐!':'다 기억났지?',r:2,dur:4600,m:'joy'}]});
 return S}
function build(){scenes=make(EP[ei],ei);beats=[];var a=0;
 scenes.forEach(function(s,i){s.start=a;s.b.forEach(function(b){b.dur=b.dur||Math.min(11000,Math.max(3400,2300+b.say.length*80));b.start=a;b.si=i;beats.push(b);a+=b.dur});s.dur=a-s.start});total=a}
function fmt(ms){var s=Math.round(ms/1000);return Math.floor(s/60)+':'+('0'+s%60).slice(-2)}
function drawBar(){bar.innerHTML=scenes.map(function(s,i){return '<i style="flex:'+s.dur+'" data-i="'+i+'" title="'+esc(s.k)+'"><u></u></i>'}).join('');bar.querySelectorAll('i').forEach(function(x){x.onclick=function(ev){ev.stopPropagation();seek(scenes[+x.dataset.i].start+1)}})}
function applyStep(box,idx){if(box.dataset.step===String(idx))return;var steps=JSON.parse(box.dataset.morph),s=steps[idx],row=box.querySelector('.t-row'),ch={},before={};
 row.querySelectorAll('.t-chip').forEach(function(c){ch[c.dataset.id]=c;if(!c.classList.contains('gone'))before[c.dataset.id]=c.getBoundingClientRect().left});
 var had=box.dataset.step!==undefined&&box.dataset.step!=='';
 Object.keys(ch).forEach(function(id){var c=ch[id],on=s.order.indexOf(id)>=0;c.classList.toggle('gone',!on);if(on){c.querySelector('b').textContent=s.txt[id];var tg=(s.tag&&s.tag[id])||(c.classList.contains('s')?'성':c.classList.contains('g')?'이름':'');c.querySelector('small').textContent=(id==='y'||id==='x')?(tg||''):tg;
   if(c.classList.contains('s')&&/^[A-Z]\.?[,;]?$/.test(s.txt[id]))c.querySelector('small').textContent='성'}});
 // 이름 칩은 이니셜이면 '이니셜' 표시
 Object.keys(ch).forEach(function(id){var c=ch[id];if(c.classList.contains('g')&&!c.classList.contains('gone')){var t=s.txt[id];c.querySelector('small').textContent=/^[A-Z]\.?[,;.]?$|^[A-Z],?$/.test(t)?'이니셜':'이름'}});
 s.order.forEach(function(id){row.appendChild(ch[id])});
 Object.keys(ch).forEach(function(id){if(s.order.indexOf(id)<0)row.appendChild(ch[id])});
 if(had)s.order.forEach(function(id){if(before[id]===undefined)return;var dx=before[id]-ch[id].getBoundingClientRect().left;if(!dx)return;var c=ch[id];c.style.transition='none';c.style.transform='translateX('+dx+'px)';requestAnimationFrame(function(){requestAnimationFrame(function(){c.style.transition='transform .9s cubic-bezier(.3,1.2,.4,1)';c.style.transform='none'})})});
 box.querySelector('.t-pill').textContent=s.lab;box.querySelector('.t-cap').textContent=s.cap;box.dataset.step=String(idx);box.classList.remove('t-pop');void box.offsetWidth;box.classList.add('t-pop')}
function setBeat(i,fromSeek){var b=beats[i],s=scenes[b.si];
 if(b.si!==si||fromSeek==='scene'){si=b.si;scene.innerHTML='<div class="vp-in">'+s.html+'</div>';chip.textContent=EP[ei].t+' · '+s.k+' ('+(si+1)+'/'+scenes.length+')';bar.querySelectorAll('i').forEach(function(x,k){x.classList.toggle('done',k<si)});curMood='';var mm=host.querySelector('.t-morph');if(mm)delete mm.dataset.step}
 bi=i;var r=b.r;setMood(b.m||s.m);
 scene.querySelectorAll('[data-r]').forEach(function(x){x.classList.toggle('on',+x.dataset.r<=r)});
 scene.querySelectorAll('[data-cur]').forEach(function(x){x.classList.toggle('cur',+x.dataset.cur===r);x.classList.toggle('past',+x.dataset.cur<r)});
 var mo=scene.querySelector('.t-morph');if(mo)applyStep(mo,Math.max(0,Math.min(JSON.parse(mo.dataset.morph).length-1,r-1)));
 if(s.k==='퀴즈'&&r>=2)scene.querySelectorAll('.v-opt li').forEach(function(x){x.classList.toggle('ok',x.dataset.ans==='1');x.classList.toggle('no',x.dataset.ans!=='1')});
 bubble.textContent=b.bub;bubble.classList.remove('pop');void bubble.offsetWidth;bubble.classList.add('pop');
 typed=b.say;sub.textContent='';if(voice&&playing)say(b.say)}
var VP={name:'어흥이',rate:1.08,pitch:1.25,pref:['Minsu','InJoon','Hyunsu','Jinho','GookMin','Bongjin','Google','Yuna','민수','인준']},spk=0,talking=false,holdT=0,vcache=null;
function pickVoice(){if(vcache)return vcache;try{var vs=speechSynthesis.getVoices().filter(function(v){return /^ko/i.test(v.lang)});if(!vs.length)return null;function sc(v){var s=0,n=v.name;VP.pref.forEach(function(p,i){if(n.indexOf(p)>-1)s=Math.max(s,40-i*3)});if(/Natural|Neural|Online|Premium|Enhanced|향상/i.test(n))s+=30;if(v.localService===false)s+=5;return s}vs.sort(function(a,b){return sc(b)-sc(a)});vcache=vs[0];return vcache}catch(e){return null}}
try{speechSynthesis.addEventListener('voiceschanged',function(){vcache=null})}catch(e){}
var LN={A:'에이',B:'비',C:'씨',D:'디',E:'이',F:'에프',G:'지',H:'에이치',I:'아이',J:'제이',K:'케이',L:'엘',M:'엠',N:'엔',O:'오',P:'피',Q:'큐',R:'아르',S:'에스',T:'티',U:'유',V:'브이',W:'더블유',X:'엑스',Y:'와이',Z:'지'},ENP=['Alex','Guy','Daniel','David','Google UK English Male','Fred','Male','Google US English'],ecache=null;
var TR=[[/\bop\. ?cit\./gi,'옵 싯'],[/\bIbid\./gi,'이비드'],[/\bet al\./gi,'엣 알'],[/\bWorks Cited/g,'웍스 사이티드'],[/\bCited\b/g,'사이티드'],[/\bSeoyun\b/g,'서윤'],[/\bElena\b/g,'엘레나'],[/\bN-?B\b/g,'엔 비'],[/\bChicago\b/g,'시카고'],[/\bVancouver\b/g,'밴쿠버'],[/\bRivera\b/g,'리베라'],[/\bHan\b/g,'핸'],[/\band\b/g,'앤드'],[/\bAuthor-Date\b/g,'오서 데이트']];
function spellKo(s){return s.replace(/[A-Za-z][A-Za-z.\- ]*(?=[가-힣])/g,function(w){TR.forEach(function(r){w=w.replace(r[0],r[1])});return w}).replace(/\b(apa|mla|acs|ieee)\b/gi,function(m){return m.toUpperCase()}).replace(/\b[A-Z]{2,5}\b/g,function(w){return w.split('').map(function(c){return LN[c]}).join(' ')})}
function enVoice(){if(ecache!==null)return ecache;try{var vs=speechSynthesis.getVoices().filter(function(v){return /^en/i.test(v.lang)});if(!vs.length)return null;function sc(v){var s=0,n=v.name;ENP.forEach(function(p,i){if(n.indexOf(p)>-1)s=Math.max(s,40-i*3)});if(/Natural|Neural|Online|Premium|Enhanced/i.test(n))s+=30;if(/en-US/i.test(v.lang))s+=4;return s}vs.sort(function(a,b){return sc(b)-sc(a)});ecache=vs[0];return ecache}catch(e){return null}}
try{speechSynthesis.addEventListener('voiceschanged',function(){ecache=null})}catch(e){}
function seg(s){var out=[],re=/[A-Za-z][A-Za-z0-9'’&\/\-]*(?:[ ,.:;]+[A-Za-z][A-Za-z0-9'’&\/\-]*)*\.?/g,m,last=0,H=/[가-힣]/,en=!!enVoice();while((m=re.exec(s))){var w=m[0],a=s.charAt(m.index-1),b=s.charAt(m.index+w.length),ln=w.replace(/[^A-Za-z]/g,'').length;var sp=w.search(/[ ,]+[^ ,]+$/);if(en&&!H.test(a)&&H.test(b)&&sp>0&&w.slice(0,sp).split(/[ ,]+/).length>=2){out.push(['ko',s.slice(last,m.index)]);out.push(['en',w.slice(0,sp)]);out.push(['ko',' '+w.slice(sp).replace(/^[ ,]+/,'')])}else if(!en||H.test(a)||H.test(b)||/^[A-Z]{2,5}\.?$/.test(w)||ln<3){out.push(['ko',s.slice(last,m.index+w.length)])}else{out.push(['ko',s.slice(last,m.index)]);out.push(['en',w.replace(/\b([A-Z]{2,5})\b/g,function(x){return x.split('').join('. ')+'.'})])}last=m.index+w.length}out.push(['ko',s.slice(last)]);var r=[];out.forEach(function(x){var tx=x[1];if(r.length&&r[r.length-1][0]===x[0])r[r.length-1][1]+=tx;else r.push([x[0],tx])});return r.map(function(x){return [x[0],(x[0]==='ko'?spellKo(x[1]):x[1]).replace(/^[\s,.:;]+/,'').trim()]}).filter(function(x){return /[가-힣A-Za-z0-9]/.test(x[1])})}
function clean(t){return String(t).replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\uFE0F]/gu,'').replace(/[◇◆※★☆✓✔✗✘▶●○■□▲△▼▽]/g,' ').replace(/\s*[→⇒]\s*/g,', ').replace(/·/g,', ').replace(/[“”"『』「」《》〈〉<>]/g,'').replace(/\s*\(([^)]*)\)\s*/g,', $1, ').replace(/\s*…+\s*/g,', ').replace(/\s*[—–]\s*/g,', ').replace(/,\s*,/g,',').replace(/\s+/g,' ').replace(/^[,\s]+|[,\s]+$/g,'').trim()}
function hush(){spk++;talking=false;try{speechSynthesis.cancel()}catch(e){}}
function say(t){try{var S=speechSynthesis;hush();var id=spk,c=clean(t);if(!c)return;var parts,q=[],i=0;try{parts=c.split(new RegExp('(?<=[가-힣)][.~]|[!?])\\s+'))}catch(e){parts=[c]}parts.forEach(function(p,k){seg(p).forEach(function(x,j,arr){q.push([x[0],x[1],j===arr.length-1?110:40])})});var v=pickVoice(),ev=enVoice();talking=true;holdT=0;function next(){if(id!==spk)return;if(i>=q.length){talking=false;return}var it=q[i++],u=new SpeechSynthesisUtterance(it[1]);if(it[0]==='en'&&ev){u.lang=ev.lang||'en-US';u.voice=ev;u.rate=Math.min(1.5,VP.rate*0.95*speed)}else{u.lang='ko-KR';if(v)u.voice=v;u.rate=Math.min(1.6,VP.rate*speed)}u.pitch=VP.pitch;u.volume=1;u.onend=function(){setTimeout(next,it[2])};u.onerror=function(){if(id===spk)talking=false};S.speak(u)}next()}catch(e){talking=false}}
function frame(ts){if(!playing)return;var dt=Math.min(100,ts-last);last=ts;el+=dt*speed;if(voice&&talking){var hb=beats[bi];if(hb&&el>=hb.start+hb.dur-40){if(!holdT)holdT=ts;if(ts-holdT<12000)el=hb.start+hb.dur-40}}else holdT=0;if(el>=total){end();return}
 var i=0;for(var k=0;k<beats.length;k++){if(el>=beats[k].start)i=k}
 if(i!==bi)setBeat(i);var b=beats[i],p=(el-b.start)/b.dur;
 var n=Math.min(typed.length,Math.floor(typed.length*Math.min(1,p/0.8)));sub.textContent=cc?typed.slice(0,n):'';
 var s=scenes[si],sp=(el-s.start)/s.dur,fills=bar.querySelectorAll('i');if(fills[si])fills[si].firstChild.style.width=Math.min(100,sp*100)+'%';
 $('.vp-time').textContent=fmt(el)+' / '+fmt(total);raf=requestAnimationFrame(frame)}
function end(){playing=false;sync();if(auto&&ei+1<EP.length){endTimer=setTimeout(function(){load(ei+1,true)},600)}}
function sync(){stage.classList.toggle('playing',playing);big.hidden=playing;$('[data-a=pp]').textContent=playing?'⏸':'▶';if(!playing){hush()}}
function play(){clearTimeout(endTimer);if(el>=total-50){el=0;setBeat(0,'scene')}playing=true;last=performance.now();sync();if(voice)say(beats[bi].say);cancelAnimationFrame(raf);raf=requestAnimationFrame(frame)}
function pause(){playing=false;cancelAnimationFrame(raf);sync()}
function seek(ms){el=Math.max(0,Math.min(total-10,ms));var i=0;for(var k=0;k<beats.length;k++){if(el>=beats[k].start)i=k}
 var s=beats[i].si;setBeat(i,s!==si?null:'scene');var fills=bar.querySelectorAll('i');fills.forEach(function(x,k){x.firstChild.style.width=k<si?'100%':'0'});var sc=scenes[si];fills[si].firstChild.style.width=((el-sc.start)/sc.dur*100)+'%';$('.vp-time').textContent=fmt(el)+' / '+fmt(total);sub.textContent=cc?typed.slice(0,Math.floor(typed.length*Math.min(1,((el-beats[i].start)/beats[i].dur)/0.8))):''}
function load(i,gop){clearTimeout(endTimer);ei=i;el=0;si=-1;bi=0;curMood='';build();drawBar();setBeat(0,'scene');$('.vp-time').textContent='0:00 / '+fmt(total);list.querySelectorAll('.vp-it').forEach(function(x,k){x.classList.toggle('on',k===i)});stage.style.setProperty('--c',EP[i].c);if(gop)play();else pause()}
list.innerHTML=EP.map(function(e,i){return '<button type="button" class="vp-it" role="listitem" style="--c:'+e.c+'" data-i="'+i+'"><b>'+esc(e.t.replace(/ 편$/,''))+'</b><span>'+esc(e.topic)+'</span><em>▶ 재생 중</em></button>'}).join('');
list.querySelectorAll('.vp-it').forEach(function(b){b.onclick=function(){load(+b.dataset.i,true);stage.scrollIntoView({block:'nearest',behavior:'smooth'})}});
big.onclick=function(ev){ev.stopPropagation();play()};
stage.addEventListener('click',function(ev){if(ev.target.closest('.vp-ctl'))return;playing?pause():play()});
host.querySelectorAll('[data-a]').forEach(function(b){b.onclick=function(ev){ev.stopPropagation();var a=b.dataset.a;
 if(a==='pp')playing?pause():play();
 else if(a==='prev'){var c=scenes[si];seek(el-c.start>1500?c.start+1:(scenes[si-1]||c).start+1)}
 else if(a==='next'){if(si<scenes.length-1)seek(scenes[si+1].start+1);else if(ei+1<EP.length)load(ei+1,true)}
 else if(a==='cc'){cc=!cc;b.classList.toggle('on',cc);if(!cc)sub.textContent=''}
 else if(a==='voice'){if(!('speechSynthesis' in window)){b.textContent='음성 없음';return}voice=!voice;b.classList.toggle('on',voice);if(voice&&playing)say(beats[bi].say);else hush()}
 else if(a==='spd'){speed=speed===1?1.5:speed===1.5?2:speed===2?.75:1;b.textContent=speed+'×'}
 else if(a==='auto'){auto=!auto;b.classList.toggle('on',auto)}
 else if(a==='fs'){try{if(d.fullscreenElement)d.exitFullscreen();else stage.requestFullscreen()}catch(e){}}}});
stage.addEventListener('keydown',function(ev){if(ev.key===' '){ev.preventDefault();playing?pause():play()}else if(ev.key==='ArrowRight'){ev.preventDefault();host.querySelector('[data-a=next]').click()}else if(ev.key==='ArrowLeft'){ev.preventDefault();host.querySelector('[data-a=prev]').click()}});
d.addEventListener('visibilitychange',function(){if(d.hidden&&playing)pause()});
window.TOONTIGER={EP:EP,tiger:tigerSvg,seek:function(ms){seek(ms)},info:function(){return {scenes:scenes.map(function(s){return {k:s.k,start:s.start,dur:s.dur,n:s.b.length}}),beats:beats.map(function(b){return {start:b.start,dur:b.dur,si:b.si}}),total:total}},load:function(i){load(i,false)}};
load(0,false)}
})();
