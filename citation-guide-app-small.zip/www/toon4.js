(function(){
var d=document,$=function(i){return d.getElementById(i)},K=window.TOONK;
if(!K||!$('webtoon4'))return;
var AN=K.AN,esc=K.esc,INK=K.INK;
var RED='#d33',GRN='#2f9e5a',PG='#b9b2a6';
function svg(h,inner){return '<svg viewBox="0 0 360 '+h+'" class="tnp" role="img" aria-label="웹툰 컷"><defs><marker id="ah4" markerWidth="8" markerHeight="8" refX="4" refY="6" orient="auto"><path d="M0 0L4 8L8 0z" fill="#4a3a30"/></marker></defs>'+inner+'</svg>'}
function tw(t,fs){var w=0;for(var i=0;i<t.length;i++){var c=t.charCodeAt(i);w+=(c>=0x2E80||c===0x2192)?fs:(c>=65&&c<=90?fs*0.7:fs*0.58)}return w}
function lines(arr,x,y,fs,anchor,col,maxW){maxW=maxW||(anchor?0:(346-x));return arr.map(function(t,i){var fit=(maxW&&tw(t,fs)>maxW)?' textLength="'+maxW.toFixed(1)+'" lengthAdjust="spacingAndGlyphs"':'';return '<text x="'+x+'" y="'+(y+i*(fs+4))+'" font-size="'+fs+'" font-weight="700" fill="'+(col||INK)+'"'+(anchor?' text-anchor="'+anchor+'"':'')+fit+'>'+esc(t)+'</text>'}).join('')}
function bubble(x,y,w,arr,fs){var h=arr.length*(fs+4)+10;return '<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="12" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+lines(arr,x+10,y+fs+5,fs,null,null,w-20)}
function band(t,c){return '<rect width="360" height="30" fill="'+c+'"/><text x="12" y="20" font-size="14" font-weight="800" fill="#fff">'+esc(t)+'</text>'}
// ---- 쪽 모형: 글줄을 회색 막대로 그린다 ----
var RAG=[0,16,5,24,9,19,2,13,22,7,17,3];
function bars(x,y,w,n,o){o=o||{};var s='',gapY=o.gy||8.5;for(var i=0;i<n;i++){var ind=i===0?(o.first||0):(o.hang||0),r=o.rag?RAG[(i+(o.seed||0))%RAG.length]:0,last=(i===n-1&&o.last)?w*o.last:0;
  var xx=x+ind,ww=w-ind-r-last;s+='<rect x="'+xx+'" y="'+(y+i*gapY)+'" width="'+Math.max(10,ww)+'" height="4.5" rx="2" fill="'+(o.col||PG)+'"/>'}return s}
function pageFrame(x,y,inner,w,h){return '<g transform="translate('+x+','+y+')"><rect width="'+(w||150)+'" height="'+(h||190)+'" rx="4" fill="#fff" stroke="#4a3a30" stroke-width="2.5"/>'+inner+'</g>'}
function tag(x,y,t,c){return '<g><circle cx="'+x+'" cy="'+y+'" r="11" fill="'+c+'"/><text x="'+x+'" y="'+(y+5)+'" font-size="14" font-weight="900" fill="#fff" text-anchor="middle">'+t+'</text></g>'}
function mark(x,y,w,h,c){return '<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="5" fill="none" stroke="'+c+'" stroke-width="2.4" stroke-dasharray="5 3"/>'}
function sup(x,y,t,c){return '<text x="'+x+'" y="'+y+'" font-size="9" font-weight="800" fill="'+(c||RED)+'">'+t+'</text>'}
// ---- 컷 종류 ----
function pIntro(k,line,topic){var a=AN[k];return svg(250,'<rect width="360" height="250" fill="'+a.c+'22"/>'+band(topic,a.c)+'<rect y="214" width="360" height="36" fill="'+a.c+'" fill-opacity=".25"/>'+K.animal(k,100,222,'happy',1.25)+bubble(168,52,184,line,13))}
function pCompare(topic,wrongInner,rightInner,wl,rl,wnote,rnote){
 return svg(300,'<rect width="360" height="300" fill="#faf6ea"/>'+band(topic,'#6b5a4a')
  +pageFrame(14,42,wrongInner)+pageFrame(196,42,rightInner)
  +tag(26,52,'✘',RED)+tag(208,52,'✔',GRN)
  +lines(wl,18,252,11,null,RED,160)+lines(rl,200,252,11,null,'#1c6b3e',150)
  +(wnote?'':'')+'')}
function pTip(k,say,menu,topic){var a=AN[k];return svg(280,'<rect width="360" height="280" fill="'+a.c+'22"/>'+band(topic,a.c)
 +'<rect x="14" y="42" width="332" height="100" rx="10" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+lines(menu,26,62,12,null,null,308)
 +'<rect y="156" width="360" height="124" fill="'+a.c+'" fill-opacity=".22"/>'+K.animal(k,62,268,'ok',0.72)+bubble(112,166,236,say,12))}
// ---- 1화: 각주는 어디에? ----
function ep1(){
 var wrong=bars(14,16,122,7)+sup(120,19+8.5*2-2,'¹',RED)+mark(8,10,134,76,RED)+'<text x="75" y="130" font-size="10" font-weight="800" fill="'+RED+'" text-anchor="middle">같은 쪽 아래에</text><text x="75" y="144" font-size="10" font-weight="800" fill="'+RED+'" text-anchor="middle">각주가 없어요!</text><text x="75" y="166" font-size="9" fill="#6a5a50" text-anchor="middle">(문서 끝에 모으면 미주)</text>';
 var right=bars(14,16,122,5)+sup(124,19+8.5*2-2,'¹',GRN)+'<line x1="14" y1="136" x2="64" y2="136" stroke="#4a3a30" stroke-width="1.5"/>'+'<text x="14" y="150" font-size="8.5" font-weight="800" fill="'+GRN+'">1.</text>'+bars(25,146,111,2,{gy:7.5,col:'#8f8a80'})+mark(8,128,134,40,GRN);
 var p3=svg(256,'<rect width="360" height="256" fill="#faf6ea"/>'+band('번호는 마침표·쉼표 뒤에!','#6b5a4a')
  +'<rect x="14" y="44" width="160" height="78" rx="10" fill="#fff" stroke="'+RED+'" stroke-width="2.5"/><circle cx="26" cy="44" r="11" fill="'+RED+'"/><text x="26" y="49" font-size="14" font-weight="900" fill="#fff" text-anchor="middle">✘</text>'
  +'<text x="26" y="86" font-size="14" font-weight="700" fill="'+INK+'">…라고 했다<tspan dy="-6" font-size="10" fill="'+RED+'">1</tspan><tspan dy="6">.</tspan></text><text x="26" y="108" font-size="10" fill="'+RED+'" font-weight="800">번호가 마침표 앞에 있어요</text>'
  +'<rect x="186" y="44" width="160" height="78" rx="10" fill="#fff" stroke="'+GRN+'" stroke-width="2.5"/><circle cx="198" cy="44" r="11" fill="'+GRN+'"/><text x="198" y="49" font-size="14" font-weight="900" fill="#fff" text-anchor="middle">✔</text>'
  +'<text x="198" y="86" font-size="14" font-weight="700" fill="'+INK+'">…라고 했다.<tspan dy="-6" font-size="10" fill="'+GRN+'">1</tspan></text><text x="198" y="108" font-size="10" fill="#1c6b3e" font-weight="800">마침표 뒤, 위 첨자</text>'
  +'<rect x="14" y="140" width="332" height="86" rx="10" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+lines(['번호는 1, 2, 3… 순서대로 이어 가요.','각주는 번호가 있는 쪽 맨 아래에 같은 번호로 써요.','손으로 치지 말고 각주 삽입 기능을 써요.'],26,162,12));
 return [pIntro('nb',['각주는 어디에','넣어야 할까?','번호는 문장 끝,','내용은 쪽 아래!'],'1화 · 각주의 자리'),
  pCompare('같은 문서, 다른 자리',wrong,right,['각주가 이 쪽에 없고','문서 끝에 몰려 있다'],['번호가 있는 쪽 아래에','짧은 선과 각주가 있다']),p3,
  pTip('nb',['한글·워드 모두','각주 삽입 기능으로!','번호를 손으로 치면','순서가 깨져요.'],['한글: 입력 > 주석 > 각주 (Ctrl+N, N)','워드: 참조 > 각주 삽입 (Ctrl+Alt+F)','각주 글자는 본문보다 작게(예: 본문 10pt, 각주 9pt)'],'설정은 이렇게')];
}
// ---- 2화: 들여쓰기는 얼마나? ----
function ep2(){
 var wrong=bars(14,16,122,4)+bars(14,56,122,1)+'<line x1="14" y1="96" x2="64" y2="96" stroke="#4a3a30" stroke-width="1.5"/>'+'<text x="14" y="110" font-size="8.5" font-weight="800" fill="'+RED+'">1.</text>'+bars(25,106,111,1,{col:'#8f8a80'})+bars(36,113.5,100,1,{col:'#8f8a80'})+bars(14,16,0,0)
  +mark(8,10,134,34,RED)+mark(8,98,134,28,RED)+'<text x="75" y="150" font-size="9.5" font-weight="800" fill="'+RED+'" text-anchor="middle">① 본문 첫 줄 들여쓰기 없음</text><text x="75" y="164" font-size="9.5" font-weight="800" fill="'+RED+'" text-anchor="middle">② 각주 둘째 줄이 들어감</text>';
 var right=bars(14,16,122,4,{first:7})+'<line x1="14" y1="96" x2="64" y2="96" stroke="#4a3a30" stroke-width="1.5"/>'+'<text x="22" y="110" font-size="8.5" font-weight="800" fill="'+GRN+'">1.</text>'+bars(33,106,103,1,{col:'#8f8a80'})+bars(14,113.5,122,1,{col:'#8f8a80'})
  +mark(8,10,134,34,GRN)+mark(8,98,134,28,GRN)+'<text x="75" y="150" font-size="9.5" font-weight="800" fill="#1c6b3e" text-anchor="middle">① 본문: 첫 줄만 1자(10pt)</text><text x="75" y="164" font-size="9.5" font-weight="800" fill="#1c6b3e" text-anchor="middle">② 각주: 첫 줄만 0.5인치</text>';
 var ruler='<rect x="20" y="60" width="320" height="34" rx="6" fill="#fff" stroke="#4a3a30" stroke-width="2"/>';for(var i=0;i<=10;i++){ruler+='<line x1="'+(30+i*28)+'" y1="60" x2="'+(30+i*28)+'" y2="'+(i%5===0?80:72)+'" stroke="#4a3a30" stroke-width="1.5"/>'}
 ruler+='<rect x="30" y="100" width="'+(36)+'" height="10" fill="'+GRN+'" fill-opacity=".5"/><text x="30" y="128" font-size="11" font-weight="800" fill="#1c6b3e">0.5인치 = 36pt ≈ 1.27cm</text><path d="M30 118H66" stroke="#2f9e5a" stroke-width="2.5" marker-end="url(#ah4)"/>';
 var p3=svg(260,'<rect width="360" height="260" fill="#faf6ea"/>'+band('들여쓰기 자로 재 보기','#6b5a4a')+ruler
  +'<rect x="14" y="146" width="332" height="100" rx="10" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+lines(['본문 새 문단: 첫 줄만 글자 1개 폭(10pt)','각주: 첫 줄만 0.5인치, 둘째 줄부터는 왼쪽 끝','참고문헌: 첫 줄은 왼쪽 끝, 둘째 줄부터 0.5인치(내어쓰기)','스페이스·Enter로 밀지 말고 문단 서식의 값으로!'],26,168,11.5));
 return [pIntro('nb',['들여쓰기는','얼마나 해야 해?','본문·각주·참고문헌이','모두 달라!'],'2화 · 들여쓰기의 양'),
  pCompare('본문과 각주의 들여쓰기',wrong,right,['첫 줄을 안 들였고','각주는 둘째 줄을 들였다'],['본문·각주 모두','첫 줄만 들였다']),p3,
  pTip('nb',['한글: 문단 모양에서','각주 첫 줄 36pt.','워드: 특수 > 첫 줄','0.5인치!'],['한글: 각주 문단의 “첫 줄”을 들여쓰기 36pt','워드: 단락 > 특수 > 첫 줄 0.5"','각주 전체는 각주 스타일(한글)·각주 텍스트 스타일(워드)에서 한 번에'],'설정은 이렇게')];
}
// ---- 3화: 양쪽 정렬 ----
function ep3(){
 var wrong=bars(14,16,122,12,{rag:true,gy:10,last:0.35})+'<line x1="136" y1="12" x2="136" y2="132" stroke="'+RED+'" stroke-width="2" stroke-dasharray="4 3"/>'+mark(8,10,134,126,RED)+'<text x="75" y="156" font-size="9.5" font-weight="800" fill="'+RED+'" text-anchor="middle">오른쪽 끝이 들쭉날쭉!</text><text x="75" y="170" font-size="9.5" font-weight="800" fill="'+RED+'" text-anchor="middle">(왼쪽 정렬로 되어 있음)</text>';
 var right=bars(14,16,122,12,{gy:10,last:0.35})+'<line x1="136" y1="12" x2="136" y2="132" stroke="'+GRN+'" stroke-width="2" stroke-dasharray="4 3"/>'+mark(8,10,134,126,GRN)+'<text x="75" y="156" font-size="9.5" font-weight="800" fill="#1c6b3e" text-anchor="middle">오른쪽 끝이 반듯!</text><text x="75" y="170" font-size="9.5" font-weight="800" fill="#1c6b3e" text-anchor="middle">(양쪽 정렬)</text>';
 var zoomW='<rect x="14" y="44" width="160" height="96" rx="10" fill="#fff" stroke="'+RED+'" stroke-width="2.5"/>'+bars(26,62,130,5,{rag:true,gy:12,col:'#cfc7ba'})+'<text x="26" y="132" font-size="10" font-weight="800" fill="'+RED+'">줄마다 끝이 다르다</text>';
 var zoomR='<rect x="186" y="44" width="160" height="96" rx="10" fill="#fff" stroke="'+GRN+'" stroke-width="2.5"/>'+bars(198,62,130,5,{gy:12,col:'#cfc7ba'})+'<text x="198" y="132" font-size="10" font-weight="800" fill="#1c6b3e">줄 끝이 한 줄로 맞는다</text>';
 var p3=svg(250,'<rect width="360" height="250" fill="#faf6ea"/>'+band('줄 끝을 눈으로 확인!','#6b5a4a')+zoomW+zoomR
  +'<rect x="14" y="152" width="332" height="86" rx="10" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+lines(['본문 문단은 양쪽 정렬이 일반적이에요.','제목·표지 항목은 가운데나 왼쪽, 표 안의 글과 긴 URL은','왼쪽 정렬이 읽기 좋아요. 영문 양식은 왼쪽 정렬을 요구하기도 해요.'],26,174,11.5));
 return [pIntro('nb',['어? 글줄 오른쪽이','들쭉날쭉하네?','양쪽 정렬이','안 된 것 같아!'],'3화 · 양쪽 정렬'),
  pCompare('오른쪽 끝을 보세요',wrong,right,['양쪽 정렬이 아니라','왼쪽 정렬로 되어 있다'],['양쪽 정렬로','줄 끝이 맞는다']),p3,
  pTip('nb',['정렬은 문단 서식으로!','스페이스로 줄 끝을','맞추지 마세요.'],['한글: 문단 모양 > 정렬 > 양쪽 정렬','워드: 홈 > 양쪽 맞춤','본문 문단·각주를 블록으로 지정해 한 번에 적용'],'설정은 이렇게')];
}
// ---- 4화: 참고문헌 내어쓰기 ----
function bib(x,hang,col,c2){var s='',y=14;for(var i=0;i<3;i++){s+=bars(x,y,122,3,{hang:hang,col:c2||PG,gy:8,last:0.45});y+=34}return s}
function ep4(){
 var wrong=bib(14,0)+mark(8,8,134,98,RED)+'<text x="75" y="128" font-size="9.5" font-weight="800" fill="'+RED+'" text-anchor="middle">둘째 줄부터 들어가지 않아</text><text x="75" y="142" font-size="9.5" font-weight="800" fill="'+RED+'" text-anchor="middle">항목이 어디서 끝나는지 몰라요</text>';
 var right=bib(14,9)+'<rect x="14" y="14" width="9" height="95" fill="'+GRN+'" fill-opacity=".18"/>'+mark(8,8,134,98,GRN)+'<text x="75" y="128" font-size="9.5" font-weight="800" fill="#1c6b3e" text-anchor="middle">첫 줄은 왼쪽 끝,</text><text x="75" y="142" font-size="9.5" font-weight="800" fill="#1c6b3e" text-anchor="middle">둘째 줄부터 0.5인치 안쪽</text>';
 var entry=function(x,y,hang,col){return bars(x,y,150,3,{hang:hang,col:col,gy:10,last:0.4})};
 var p3=svg(250,'<rect width="360" height="250" fill="#faf6ea"/>'+band('내어쓰기 = 둘째 줄부터 안쪽','#6b5a4a')
  +'<rect x="14" y="44" width="332" height="92" rx="10" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+entry(30,60,0,'#cfc7ba').replace(/<rect /g,'<rect ')+entry(30,96,0,'#cfc7ba').slice(0,0)
  +'<rect x="30" y="58" width="150" height="4.5" rx="2" fill="'+PG+'"/><rect x="66" y="68" width="150" height="4.5" rx="2" fill="'+PG+'"/><rect x="66" y="78" width="60" height="4.5" rx="2" fill="'+PG+'"/><path d="M30 92H66" stroke="'+GRN+'" stroke-width="2.5" marker-end="url(#ah4)"/><text x="72" y="112" font-size="11" font-weight="800" fill="#1c6b3e">0.5인치(36pt, 약 1.27cm)</text>'
  +'<rect x="14" y="148" width="332" height="90" rx="10" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+lines(['항목 안은 한 줄 간격, 항목 사이는 한 줄 띄움.','가나다순 → ABC순으로 한 목록에 정렬해요.','스페이스·Enter로 밀면 글꼴이 바뀔 때 모양이 깨져요.'],26,170,11.5));
 return [pIntro('nb',['참고문헌이 한 덩어리로','보이지 않아?','내어쓰기를','안 한 거야!'],'4화 · 참고문헌 내어쓰기'),
  pCompare('참고문헌의 왼쪽 끝을 보세요',wrong,right,['내어쓰기 없음','(모든 줄이 왼쪽 끝)'],['내어쓰기 적용','(둘째 줄부터 안쪽)']),p3,
  pTip('nb',['항목 전체를 블록으로','지정해서 한 번에!','한글 36pt, 워드 0.5"','내어쓰기예요.'],['한글: 문단 모양 > 내어쓰기 36pt','워드: 단락 > 들여쓰기 > 특수 > 내어쓰기 0.5"','Chicago 서지·APA·MLA 참고문헌 모두 같은 방식이에요(번호식은 번호 폭에 맞춤)'],'설정은 이렇게')];
}
// ---- 5화: 한 쪽 통째 점검 ----
function ep5(){
 var messy=bars(14,16,122,7,{rag:true,gy:9.5,last:0.3,seed:3})+sup(122,34,'¹',RED)+'<line x1="14" y1="96" x2="64" y2="96" stroke="#4a3a30" stroke-width="1.5" opacity=".0"/>'+bars(14,108,122,2,{col:'#8f8a80',gy:8})+'<text x="14" y="104" font-size="8" font-weight="800" fill="#8f8a80">참고문헌</text>'+bars(14,126,122,3,{gy:8,last:0.4,col:PG})+bars(14,155,122,3,{gy:8,last:0.4,col:PG})
  +tag(144,22,'①',RED)+tag(144,60,'②',RED)+tag(144,138,'③',RED);
 var fixed=bars(14,16,122,6,{gy:9.5,last:0.3,first:7})+sup(122,34,'¹',GRN)+'<line x1="14" y1="76" x2="64" y2="76" stroke="#4a3a30" stroke-width="1.5"/><text x="22" y="87" font-size="8" font-weight="800" fill="'+GRN+'">1.</text>'+bars(33,83,103,1,{col:'#8f8a80'})+bars(14,91,122,1,{col:'#8f8a80'})
  +'<text x="14" y="112" font-size="8" font-weight="800" fill="#8f8a80">참고문헌</text>'+bars(14,118,122,3,{hang:9,gy:8,last:0.4,col:PG})+bars(14,148,122,3,{hang:9,gy:8,last:0.4,col:PG})
  +tag(144,22,'✔',GRN)+tag(144,60,'✔',GRN)+tag(144,138,'✔',GRN);
 var c3=svg(260,'<rect width="360" height="260" fill="#faf6ea"/>'+band('틀린 곳 세 군데','#6b5a4a')
  +'<rect x="14" y="42" width="332" height="206" rx="10" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'
  +tag(32,66,'①',RED)+lines(['본문 오른쪽 끝이 들쭉날쭉 → 양쪽 정렬','본문 첫 줄이 들어가 있지 않다 → 첫 줄 1자'],50,70,12)
  +tag(32,126,'②',RED)+lines(['번호가 있는데 같은 쪽 아래에 각주가 없다','→ 각주 삽입으로 쪽 아래에 쓰기'],50,130,12)
  +tag(32,186,'③',RED)+lines(['참고문헌 둘째 줄이 안쪽으로 들어가지 않았다','→ 내어쓰기 0.5인치'],50,190,12));
 var intro=svg(250,'<rect width="360" height="250" fill="#4fa08f22"/>'+band('5화 · 한 쪽을 통째로 점검','#4fa08f')+'<rect y="214" width="360" height="36" fill="#4fa08f" fill-opacity=".25"/>'+K.animal('cad',100,222,'sweat',1.25)+bubble(168,52,184,['선배! 제가 쓴 쪽','어디가 이상한지','모르겠어요…'],13)+'<text x="262" y="196" font-size="26" text-anchor="middle">📄❓</text>');
 var cmp=svg(300,'<rect width="360" height="300" fill="#faf6ea"/>'+band('처음 쪽과 고친 쪽','#6b5a4a')+pageFrame(14,42,messy)+pageFrame(196,42,fixed)+tag(26,52,'✘',RED)+tag(208,52,'✔',GRN)+lines(['번호 ①②③이','고칠 곳이에요'],18,252,11,null,RED)+lines(['고친 쪽: 모두 ✔'],200,252,11,null,'#1c6b3e'));
 var end=svg(250,'<rect width="360" height="250" fill="#c99a3a22"/>'+band('한 줄 정리','#c99a3a')+'<rect x="14" y="42" width="332" height="100" rx="10" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+lines(['✔ 각주는 같은 쪽 아래, 번호는 마침표 뒤','✔ 본문 첫 줄 1자 · 각주 첫 줄 0.5인치','✔ 본문은 양쪽 정렬 · 참고문헌은 내어쓰기 0.5인치'],26,66,12)+'<rect y="160" width="360" height="90" fill="#c99a3a" fill-opacity=".22"/>'+K.animal('nb',62,242,'happy',0.72)+bubble(112,168,236,['제출 전에 한 쪽씩','눈으로 점검하면','대부분 잡혀요!'],12));
 return [intro,cmp,c3,end];
}
var EPS=[{t:'1화 각주는 어디에?',f:ep1,src:'이 안내서 제10장(Chicago 외각주의 각주 번호 위치, 각주·미주의 구분)과 제3장·부록 2(각주 삽입 메뉴).'},
 {t:'2화 들여쓰기는 얼마나?',f:ep2,src:'이 안내서 제2장 2절·제3장·제10장(본문 첫 줄 10pt, 각주 첫 줄만 0.5인치, 참고문헌 둘째 줄부터 0.5인치). 값은 이 안내서의 기본값이며 제출처의 규정이 먼저입니다.'},
 {t:'3화 양쪽 정렬',f:ep3,src:'이 안내서 제2장 6절(본문 양쪽 정렬, 표·URL은 왼쪽 정렬이 읽기 좋음)과 제3장. 영문 양식은 왼쪽 정렬을 요구하기도 합니다.'},
 {t:'4화 참고문헌 내어쓰기',f:ep4,src:'이 안내서 제10장·제4장(Bibliography 둘째 줄부터 0.5인치 내어쓰기, 항목 사이 한 줄 띄움)과 제3장.'},
 {t:'5화 한 쪽 통째 점검',f:ep5,src:'1~4화의 내용을 한 쪽에 모아 점검했습니다. 쪽 그림은 비율을 단순하게 줄인 모형입니다.'}];
function render(host){var cur=0;
 function show(i,noscroll){cur=i;var e=EPS[i],ps=e.f();
  host.innerHTML='<div class="tn-head"><h2 class="gt">웹툰 시리즈 〈시카판다의 보고서 모양 점검〉</h2><p class="mut">각주의 자리, 들여쓰기, 양쪽 정렬, 참고문헌 내어쓰기를 “쪽 그림”으로 보며 틀린 곳을 찾아요. ✘는 틀린 모양, ✔는 맞는 모양입니다. 쪽 그림은 글을 회색 막대로 줄여 그린 모형이에요.</p></div>'
   +'<div class="tn-tabs" role="tablist">'+EPS.map(function(x,k){return '<button class="tn-tab'+(k===i?' on':'')+'" data-k="'+k+'" role="tab" aria-selected="'+(k===i)+'">'+esc(x.t)+'</button>'}).join('')+'</div>'
   +'<article class="tn-ep"><h3>'+esc(e.t)+'</h3><div class="tn2 tn2-zig">'+ps.map(function(p,n){return '<figure class="tn-p tn2p">'+p+'<figcaption class="tn-cap">'+(n+1)+'</figcaption></figure>'}).join('')+'</div>'
   +'<p class="mut tn2-src"><b>이 화의 근거</b> '+esc(e.src)+' 한글·워드 메뉴 이름은 버전에 따라 다를 수 있습니다.</p></article>'
   +'<div class="gbtns"><button class="gbtn" id="tn4p"'+(i===0?' disabled':'')+'>← 이전 화</button><button class="gprimary" id="tn4n"'+(i===EPS.length-1?' disabled':'')+'>다음 화 →</button></div>'
   +'<p class="mut tn-credit">캐릭터는 이 홈페이지를 위해 직접 그린 원본입니다. 쪽 그림의 글은 실제 문장이 아니라 회색 막대로 그린 모형입니다.</p>';
  host.querySelectorAll('.tn-tab').forEach(function(b){b.onclick=function(){show(+b.dataset.k)}});
  var pv=$('tn4p'),nx=$('tn4n');if(pv)pv.onclick=function(){show(cur-1)};if(nx)nx.onclick=function(){show(cur+1)};
  if(!noscroll){var tb=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||110)+8,r=host.getBoundingClientRect();window.scrollTo(0,Math.max(0,r.top+window.pageYOffset-tb))}}
 show(0,true)}
render($('webtoon4'));
})();
