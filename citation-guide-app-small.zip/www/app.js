(function(){
var d=document,root=d.documentElement;
try{var t=localStorage.getItem('theme');if(t)root.setAttribute('data-theme',t)}catch(e){}
d.getElementById('theme').onclick=function(){var cur=root.getAttribute('data-theme')||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light');var n=cur==='dark'?'light':'dark';root.setAttribute('data-theme',n);try{localStorage.setItem('theme',n)}catch(e){}};
var m=d.getElementById('menu');if(m)m.onclick=function(){d.body.classList.toggle('open')};
var on=d.querySelector('#nav a.on'),nv=d.getElementById('nav');if(on&&nv)nv.scrollTop=Math.max(0,on.offsetTop-nv.clientHeight/2);
var main=d.getElementById('main');var sh=d.querySelector('.shero');if(sh&&main)main.style.setProperty('--sc',sh.style.getPropertyValue('--sc'));
// 상자·표 처리
d.querySelectorAll('main table').forEach(function(t){var r=t.rows;
 if(r.length===1&&r[0].cells.length===1){t.classList.add('box1');var td=r[0].cells[0],tx=td.textContent.trim(),lab='';
  if(/^(주의|경고)/.test(tx)){t.classList.add('warn');lab='주의'}else if(/^(이 장의 학습 목표|학습 목표)/.test(tx)){t.classList.add('ok');lab='학습 목표'}else if(/체크리스트|점검표/.test(tx.slice(0,40))){t.classList.add('gold');lab='체크리스트'}else if(/^(TIP|팁|참고)/i.test(tx)){lab='TIP'}
  if(lab)td.setAttribute('data-label',lab);
  // 체크박스
  var ps=td.querySelectorAll('p'),n=0,k=0,key='ck:'+location.pathname+':'+(td.textContent.trim().slice(0,24));
  var st={};try{st=JSON.parse(localStorage.getItem(key)||'{}')}catch(e){}
  ps.forEach(function(p){var s=p.textContent.trim();if(/^[☐□]/.test(s)){var id=k++;var lb=d.createElement('label');lb.className='ck';var cb=d.createElement('input');cb.type='checkbox';cb.checked=!!st[id];var sp=d.createElement('span');sp.textContent=s.replace(/^[☐□]\s*/,'');lb.appendChild(cb);lb.appendChild(sp);p.replaceWith(lb);cb.addEventListener('change',function(){st[id]=cb.checked;try{localStorage.setItem(key,JSON.stringify(st))}catch(e){}upd()})}});
  var bar;function upd(){if(!bar)return;var a=td.querySelectorAll('.ck input'),c=0;a.forEach(function(x){if(x.checked)c++});bar.firstChild.style.width=(a.length?100*c/a.length:0)+'%'}
  if(k>0){bar=d.createElement('div');bar.className='ckbar';bar.innerHTML='<i></i>';td.appendChild(bar);upd()}
  return}
 var h=r[0]?Array.prototype.map.call(r[0].cells,function(c){return c.textContent}):[],cols=[];
 h.forEach(function(x,i){if(/예|틀|모양|표기|목록|바른/.test(x)&&r.length>1)cols.push(i)});
 if(r.length>1&&r[0].cells.length>1)for(var i=1;i<r.length;i++)cols.forEach(function(c){var td=r[i].cells[c];if(td&&td.textContent.trim().length>3)td.classList.add('cpc')});
});
function toast(s){var e=d.createElement('div');e.className='copied';e.textContent=s;d.body.appendChild(e);setTimeout(function(){e.remove()},1300)}
d.addEventListener('click',function(ev){var el=ev.target.closest&&ev.target.closest('td.cpc,.cp');if(!el)return;if(window.getSelection&&String(getSelection()).length>0)return;var s=el.innerText.trim();
 function fb(){var ta=d.createElement('textarea');ta.value=s;d.body.appendChild(ta);ta.select();try{d.execCommand('copy');toast('복사했습니다')}catch(e){toast('복사하지 못했습니다')}ta.remove()}
 if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(s).then(function(){toast('복사했습니다')},fb);else fb()});
// 그림 확대
d.addEventListener('click',function(ev){var im=ev.target;if(im.tagName==='IMG'&&im.closest('main')){var lb=d.createElement('div');lb.id='lb';lb.innerHTML='<img src="'+im.src+'" alt="">';lb.onclick=function(){lb.remove()};d.body.appendChild(lb)}});
d.addEventListener('keydown',function(e){if(e.key==='Escape'){var l=d.getElementById('lb');if(l)l.remove()}});
// 진행 막대·맨 위로
var pg=d.getElementById('prog'),tt=d.getElementById('totop');
function sc(){var h=d.documentElement.scrollHeight-innerHeight,y=window.scrollY;if(pg)pg.style.width=(h>0?100*y/h:0)+'%';if(tt)tt.classList.toggle('on',y>600)}
addEventListener('scroll',sc,{passive:true});sc();if(tt)tt.onclick=function(){scrollTo({top:0})};
// 탭 나누기(긴 쪽)
var tabAct=null;
(function(){
 if(!main||(d.body.classList.contains('home')||!!d.querySelector('div.home')))return;
 var kids=Array.prototype.slice.call(main.children);
 var h3s=kids.filter(function(e){return e.tagName==='H3'});
 if(h3s.length<6)return;
 var pn=main.querySelector('.pn'),end=pn?kids.indexOf(pn):kids.length,first=kids.indexOf(h3s[0]);
 var secs=[],cur=null;
 for(var i=first;i<end;i++){var e=kids[i];if(e.tagName==='H3'){cur={h:e,n:[e],len:0};secs.push(cur)}else if(cur)cur.n.push(e);if(cur)cur.len+=e.textContent.length}
 var total=secs.reduce(function(a,s){return a+s.len},0),nt=Math.min(6,Math.max(2,Math.round(total/8000))),target=total/nt;
 var groups=[],g=null,acc=0;
 secs.forEach(function(s,i){if(!g){g={s:[],len:0};groups.push(g)}g.s.push(s);g.len+=s.len;var left=secs.length-i-1,gl=nt-groups.length;if(g.len>=target&&groups.length<nt&&left>=gl){g=null}});
 if(groups.length<2)return;
 var bar=d.createElement('div');bar.className='tabs';bar.setAttribute('role','tablist');
 var panes=groups.map(function(gr,gi){
  var p=d.createElement('div');p.className='tabpane';p.hidden=gi>0;
  var a=gr.s[0].h.textContent.trim().replace(/^(\d+)\.[\s\S]*$/,'$1'),b=gr.s[gr.s.length-1].h.textContent.trim().replace(/^(\d+)\.[\s\S]*$/,'$1');
  var t0=gr.s[0].h.textContent.trim().replace(/^\d+\.\s*/,'');
  var rg=(/^\d+$/.test(a)&&/^\d+$/.test(b)?(a===b?a+'절':a+'–'+b+'절'):'');var num='탭 '+(gi+1)+'/'+groups.length+(rg?' · '+rg:'');
  var btn=d.createElement('button');btn.type='button';btn.setAttribute('role','tab');btn.className='tab'+(gi===0?' on':'');btn.innerHTML='<b>'+num+'</b><span>'+t0.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</span>';
  btn.onclick=function(){show(gi,true)};bar.appendChild(btn);
  gr.s.forEach(function(s){s.n.forEach(function(x){p.appendChild(x)})});
  var nav=d.createElement('div');nav.className='tabnav';
  if(gi>0){var pv=d.createElement('button');pv.type='button';pv.className='tabprev tabnext';pv.textContent='← 이전 탭 ('+gi+'/'+groups.length+')';pv.onclick=function(){show(gi-1,true)};nav.appendChild(pv)}
  if(gi<groups.length-1){var nt0=groups[gi+1].s[0].h.textContent.trim().replace(/^\d+\.\s*/,'');var nx=d.createElement('button');nx.type='button';nx.className='tabnext tabgo';nx.innerHTML='<small>다음 탭 ('+(gi+2)+'/'+groups.length+')</small><b></b>';nx.querySelector('b').textContent=nt0+' →';nx.onclick=function(){show(gi+1,true)};nav.appendChild(nx)}
  else{var en=d.createElement('p');en.className='tabend';en.textContent='마지막 탭입니다.';nav.appendChild(en)}
  p.appendChild(nav);
  return p});
 var anchor=kids[first]; // 이미 옮겨졌으므로 pn 앞에 삽입
 var ref=pn||null;panes.forEach(function(p){main.insertBefore(p,ref)});main.insertBefore(bar,panes[0]);var tn=d.createElement('p');tn.className='tabnote';tn.innerHTML='<b>이 쪽은 '+groups.length+'개의 탭으로 나뉘어 있습니다.</b> 위의 탭을 누르거나, 각 탭 맨 아래의 <b>다음 탭</b> 단추로 이어서 읽으세요.';main.insertBefore(tn,bar);
 function show(i,scroll){panes.forEach(function(p,k){p.hidden=k!==i});Array.prototype.forEach.call(bar.children,function(b,k){b.classList.toggle('on',k===i)});tabAct=i;if(scroll){var y=bar.getBoundingClientRect().top+scrollY-64;scrollTo({top:Math.max(0,y)})}if(window.__spy)window.__spy()}
 function goHash(){var id=decodeURIComponent((location.hash||'').slice(1));if(!id)return;var el=d.getElementById(id);if(!el)return;var pi=panes.findIndex(function(p){return p.contains(el)});if(pi>=0){show(pi,false);setTimeout(function(){el.scrollIntoView()},30)}}
 addEventListener('hashchange',goHash);d.addEventListener('click',function(ev){var a=ev.target.closest&&ev.target.closest('a[href^="#"]');if(!a)return;var id=decodeURIComponent(a.getAttribute('href').slice(1));var el=d.getElementById(id);if(!el)return;var pi=panes.findIndex(function(p){return p.contains(el)});if(pi>=0&&panes[pi].hidden){ev.preventDefault();show(pi,false);history.replaceState(null,'','#'+id);setTimeout(function(){el.scrollIntoView()},30)}});
 goHash();
})();
// FAQ 탭
d.querySelectorAll('.fqt').forEach(function(b){b.addEventListener('click',function(){d.querySelectorAll('.fqt').forEach(function(x){x.classList.toggle('on',x===b)});var c=b.dataset.c;d.querySelectorAll('.qa').forEach(function(q){q.hidden=!(c==='all'||q.dataset.c===c)})})});
// 오른쪽 차례
var rail=d.getElementById('rail');
if(rail&&main){var hs=main.querySelectorAll('h3[id]');if(hs.length>2){rail.innerHTML='<b>이 쪽의 차례</b>'+Array.prototype.map.call(hs,function(h){return '<a href="#'+h.id+'">'+h.textContent.replace(/^\d+\.\s*/,'')+'</a>'}).join('');
 var links=rail.querySelectorAll('a');function spy(){var cur=-1,fv=-1;hs.forEach(function(h,i){if(!h.offsetParent)return;if(fv<0)fv=i;if(h.getBoundingClientRect().top<120)cur=i});if(cur<0)cur=Math.max(0,fv);links.forEach(function(a,i){a.classList.toggle('on',i===cur)})}window.__spy=spy;addEventListener('scroll',spy,{passive:true});spy()}}
// 검색
var q=d.getElementById('q'),res=d.getElementById('res'),D=window.SEARCH||[];
function esc(s){return s.replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function rx(k){return new RegExp('('+esc(k).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','ig')}
function run(v){v=v.trim();if(!v){res.hidden=true;return}var AL={'벤쿠버':'vancouver','밴쿠버':'vancouver','뱅쿠버':'vancouver','밴쿠버식':'vancouver','벤쿠버식':'vancouver','시카고':'chicago','시카고식':'chicago','에이피에이':'apa','엠엘에이':'mla','아이트리플이':'ieee','외각주':'notes-bibliography','내각주':'author-date'};var ks=v.toLowerCase().split(/\s+/).filter(Boolean).map(function(k){return AL[k]||k}),out=[];
 D.forEach(function(r){var h=r.h.toLowerCase(),x=r.x.toLowerCase(),s=0;for(var i=0;i<ks.length;i++){var k=ks[i],a=h.indexOf(k)>=0,b=x.indexOf(k)>=0,c=r.p.toLowerCase().indexOf(k)>=0;if(!a&&!b&&!c){s=-1;break}s+=(a?10:0)+(c?3:0)+(b?1:0)}if(s>=0)out.push([s,r])});
 out.sort(function(a,b){return b[0]-a[0]});out=out.slice(0,30);
 if(!out.length){res.innerHTML='<div class="none">찾은 내용이 없습니다. 다른 낱말로 검색해 보세요.</div>';res.hidden=false;return}
 res.innerHTML=out.map(function(o){var r=o[1],k=ks[0],i=r.x.toLowerCase().indexOf(k),sn=r.x?r.x.substr(Math.max(0,i-30),110):'';return '<a href="'+r.u+'"><b>'+esc(r.h).replace(rx(k),'<mark>$1</mark>')+'</b><small>'+esc(r.p)+(sn?' · …'+esc(sn).replace(rx(k),'<mark>$1</mark>')+'…':'')+'</small></a>'}).join('');res.hidden=false}
if(q){q.addEventListener('input',function(){run(q.value)});q.addEventListener('keydown',function(e){if(e.key==='Escape'){res.hidden=true;q.blur()}});d.addEventListener('click',function(e){if(!e.target.closest('.sbox'))res.hidden=true});d.addEventListener('keydown',function(e){if(e.key==='/'&&d.activeElement!==q&&!/INPUT|TEXTAREA/.test(d.activeElement.tagName)){e.preventDefault();q.focus()}})}
d.querySelectorAll('.chip').forEach(function(c){c.addEventListener('click',function(e){e.preventDefault();q.value=c.dataset.q;run(q.value);q.focus();scrollTo(0,0)})});
// 홈: 양식 찾기
var fr=d.getElementById('fres');
d.querySelectorAll('.fb').forEach(function(b){b.addEventListener('click',function(){d.querySelectorAll('.fb').forEach(function(x){x.classList.remove('on')});b.classList.add('on');var s=(window.SINFO||{})[b.dataset.s];if(!s||!fr)return;fr.style.setProperty('--sc',s.c);fr.hidden=false;fr.innerHTML='<div><small>추천 양식</small><br><b>'+s.name+'</b></div><div>본문 인용과 목록 모양은 아래 비교표, 자세한 규칙은 <a href="ch'+(s.ch<10?'0':'')+s.ch+'.html">제'+s.ch+'장 '+s.name+'</a>. 목록: <code>'+s.list+'</code></div>';
 d.querySelectorAll('.ar,.feat li').forEach(function(x){x.style.opacity=x.dataset.s===b.dataset.s?1:.35})})});
// 홈: 요소 강조
var ars=d.getElementById('ars');
d.querySelectorAll('.lg').forEach(function(b){b.addEventListener('click',function(){var k=b.dataset.k;d.querySelectorAll('.lg').forEach(function(x){x.classList.remove('on')});d.querySelectorAll('.ar,.feat li').forEach(function(x){x.style.opacity=1});d.querySelectorAll('.fb').forEach(function(x){x.classList.remove('on')});if(fr)fr.hidden=true;
 d.querySelectorAll('.sg').forEach(function(s){s.classList.toggle('hl',!!k&&s.dataset.k===k)});
 if(!k){ars.classList.remove('f')}else{ars.classList.add('f');b.classList.add('on')}})});
})();

// ===== 2026-11 추가: 쪽 이동 시 맨 위, 홈 탭 =====
(function(){
 var d=document;
 try{history.scrollRestoration='manual'}catch(e){}
 if(!location.hash)window.scrollTo(0,0);
 addEventListener('pageshow',function(e){if(!location.hash)window.scrollTo(0,0)});
 d.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('.tabnext');if(b)setTimeout(function(){window.scrollTo({top:0,behavior:'auto'})},30)});
 if(!(d.body.classList.contains('home')||!!d.querySelector('div.home')))return;
 var main=d.getElementById('main');if(!main)return;
 var secs=Array.prototype.slice.call(main.children).filter(function(e){return e.tagName==='SECTION'&&!e.classList.contains('hero')&&!e.classList.contains('motiv')});
 var MAP=[['어떤 양식',0],['일곱 양식',0],['양식별 자료',1],['도구',2],['게임',3],['안내서 전체',4],['외부',5],['이 홈페이지',5]],L=['양식 고르기','양식별 자료','도구','게임','안내서 차례','참고 사이트'];
 var grp=secs.map(function(s){var h=(s.querySelector('h2')||{}).textContent||'';for(var i=0;i<MAP.length;i++)if(h.indexOf(MAP[i][0])>=0)return MAP[i][1];return 0});
 var bar=d.createElement('div');bar.className='hometabs';bar.setAttribute('role','tablist');
 L.forEach(function(t,i){var b=d.createElement('button');b.type='button';b.className='hometab';b.textContent=t;b.dataset.i=i;b.setAttribute('role','tab');bar.appendChild(b)});
 var anchor=secs[0];main.insertBefore(bar,anchor);
 function show(i,noscroll){secs.forEach(function(s,k){s.hidden=grp[k]!==i});bar.querySelectorAll('.hometab').forEach(function(b){b.classList.toggle('on',+b.dataset.i===i)});try{history.replaceState(null,'','#t'+(i+1))}catch(e){}if(!noscroll){var y=bar.getBoundingClientRect().top+scrollY-52;if(scrollY>y)window.scrollTo({top:Math.max(0,y)})}}
 bar.addEventListener('click',function(e){var b=e.target.closest('.hometab');if(b)show(+b.dataset.i)});
 var m=(location.hash||'').match(/^#t([1-5])$/);show(m?+m[1]-1:0,true);
 d.querySelectorAll('a[data-tab]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();show(+a.dataset.tab-1)})});
})();

// ===== 절 진행 바: 지금 보는 절과 읽은/안 읽은 절 표시 =====
(function(){
 var d=document,main=d.getElementById('main');
 if(!main||d.body.classList.contains('home')||d.querySelector('div.home'))return;
 var hs=Array.prototype.slice.call(main.querySelectorAll('h3[id]'));
 if(hs.length<3)return;
 var key='secread.v1.'+location.pathname.split('/').pop(),read={};
 try{(JSON.parse(localStorage.getItem(key)||'[]')).forEach(function(i){read[i]=1})}catch(e){}
 function save(){try{localStorage.setItem(key,JSON.stringify(Object.keys(read)))}catch(e){}}
 var bar=d.createElement('nav');bar.className='secbar';bar.setAttribute('aria-label','절 진행 표시');
 var chips=hs.map(function(h,i){var t=h.textContent.trim(),n=(t.match(/^(\d+)\./)||[])[1]||String(i+1),ti=t.replace(/^\d+\.\s*/,'');
  var a=d.createElement('button');a.type='button';a.className='sbc';a.title=t;a.innerHTML='<i class="sbm"></i><b>'+n+'</b><span></span>';a.querySelector('span').textContent=ti;
  a.onclick=function(){go(h)};return a});
 var top=d.createElement('div');top.className='sbt';top.innerHTML='<span class="sbs"></span><span class="sbp"><i></i></span><button type="button" class="sbn">안 읽은 절로 →</button><button type="button" class="sbr" title="읽음 표시 지우기">초기화</button>';
 var row=d.createElement('div');row.className='sbrow';chips.forEach(function(c){row.appendChild(c)});
 bar.appendChild(top);bar.appendChild(row);main.insertBefore(bar,main.firstChild);
 function go(h){var id=h.id;var el=d.getElementById(id);
  if(location.hash==='#'+id){history.replaceState(null,'',location.pathname+location.search)}
  location.hash='#'+id;
  setTimeout(function(){var y=h.getBoundingClientRect().top+scrollY-(bar.getBoundingClientRect().height+(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||104)+8);window.scrollTo(0,Math.max(0,y))},80)}
 var ends=hs.map(function(h){var last=h,n=h.nextElementSibling;while(n&&n.tagName!=='H3'&&!n.classList.contains('tabnav')&&!n.classList.contains('pn')&&!n.classList.contains('tabpane')){last=n;n=n.nextElementSibling}return last});
 var raf=0;
 function upd(){raf=0;var tb=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||104)+bar.getBoundingClientRect().height+16,cur=-1,fv=-1,ch=false;
  hs.forEach(function(h,i){if(!h.offsetParent)return;if(fv<0)fv=i;var r=h.getBoundingClientRect();if(r.top<tb+40)cur=i;
   var er=ends[i].getBoundingClientRect();if(!read[h.id]&&er.bottom>0&&er.bottom<innerHeight-30&&r.top<innerHeight){read[h.id]=1;ch=true}});
  if(cur<0)cur=Math.max(0,fv);if(ch)save();
  var nr=0;chips.forEach(function(c,i){var rd=!!read[hs[i].id];c.classList.toggle('done',rd);c.classList.toggle('cur',i===cur);if(!rd)nr++;c.querySelector('.sbm').textContent=rd?'✓':(i===cur?'▶':'○')});
  var dn=hs.length-nr;top.querySelector('.sbs').innerHTML='지금 <b>'+(hs[cur].textContent.trim().replace(/^(\d+)\..*/,'$1')||cur+1)+'</b>절 · 읽음 <b>'+dn+'/'+hs.length+'</b>'+(nr?' · 남은 절 '+nr+'개':' · 모두 읽었습니다');
  top.querySelector('.sbp i').style.width=Math.round(dn/hs.length*100)+'%';
  top.querySelector('.sbn').hidden=!nr;
  var cc=chips[cur];if(cc){var l=cc.offsetLeft-row.clientWidth/2+cc.offsetWidth/2;row.scrollLeft=l}}
 function sched(){if(!raf)raf=requestAnimationFrame(upd)}
 addEventListener('scroll',sched,{passive:true});addEventListener('resize',sched);d.addEventListener('click',function(){setTimeout(sched,120)});
 top.querySelector('.sbn').onclick=function(){for(var i=0;i<hs.length;i++){if(!read[hs[i].id]){go(hs[i]);return}}};
 top.querySelector('.sbr').onclick=function(){read={};save();upd()};
 setTimeout(upd,150);setTimeout(upd,900);
})();

/* 휴대폰: 아래로 내리면 머리글을 숨기고, 위로 올리면 다시 보이기 */
(function(){
var d=document,root=d.documentElement,mq=matchMedia('(max-width:760px)'),last=scrollY,hid=false,tick=false;
function top(){return d.querySelector('.top')}
function setTb(){var t=top();if(!mq.matches||!t)return;root.style.setProperty('--tb',(hid?0:t.offsetHeight)+'px')}
function busy(){var r=d.getElementById('res'),l=d.getElementById('lgl'),a=d.activeElement;return d.body.classList.contains('open')||(r&&!r.hidden)||(l&&!l.hidden)||(a&&top()&&top().contains(a)&&/INPUT|TEXTAREA/.test(a.tagName))}
function show(v){if(hid===!v)return;hid=!v;root.classList.toggle('hdh',hid);setTb()}
function onScroll(){tick=false;if(!mq.matches){if(hid)show(true);return}var y=scrollY,dy=y-last;if(Math.abs(dy)<6)return;last=y;if(y<120||dy<0||busy())show(true);else show(false)}
addEventListener('scroll',function(){if(!tick){tick=true;requestAnimationFrame(onScroll)}},{passive:true});
addEventListener('resize',function(){if(!mq.matches){root.classList.remove('hdh');hid=false}setTimeout(setTb,0)});
addEventListener('load',function(){setTimeout(setTb,0)});
setTb();
})();
