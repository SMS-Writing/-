(function(){var d=document,host=d.getElementById('toonvid5');if(!host)return;
function go(){var T=window.TOON5;if(!T)return setTimeout(go,100);init(T)}go();
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function init(T){var EP=T.EP,NM=T.NM,ei=0,bi=0,si=0,playing=false,el=0,speed=1,cc=true,voice=false,auto=true,raf=0,last=0,scenes=[],beats=[],total=0,typed='',endTimer=0;
 function bearSvg(m){return '<svg viewBox="0 0 150 190" class="vp-bearsvg" aria-hidden="true">'+T.bear(75,172,m||'happy',1.15)+'</svg>'}
 host.innerHTML='<div class="vp"><div class="vp-stage" tabindex="0" aria-label="백일이의 영어 논문 쓰기 영상"><div class="vp-mascot"><div class="vp-bubble"></div><div class="vp-bear"></div></div><div class="vp-main"><div class="vp-chip"></div><div class="vp-scene"></div><div class="vp-sub" aria-live="off"></div></div><button type="button" class="vp-big" aria-label="재생">▶</button><div class="vp-ctl"><div class="vp-bar" role="slider" aria-label="재생 위치"></div><div class="vp-row"><button type="button" data-a="prev" title="이전 장면">⏮</button><button type="button" data-a="pp" title="재생·멈춤 (스페이스)">▶</button><button type="button" data-a="next" title="다음 장면">⏭</button><span class="vp-time">0:00</span><span class="vp-sp"></span><button type="button" data-a="cc" class="on" title="자막">자막</button><button type="button" data-a="voice" title="브라우저 음성으로 읽어 주기">소리</button><button type="button" data-a="spd" title="재생 속도">1×</button><button type="button" data-a="auto" class="on" title="끝나면 다음 화 자동 재생">자동</button><button type="button" data-a="fs" title="전체 화면">⛶</button></div></div></div><div class="vp-list" role="list"></div><p class="mut vp-note">컷 만화가 아니라 설명 영상처럼 만든 애니메이션입니다. 한 화는 서지 비교, 차이점, 날짜 순서, 헷갈리는 규칙, 퀴즈, 정리 순서로 진행됩니다. 스페이스바로 재생·멈춤, 좌우 화살표로 장면 이동을 할 수 있습니다. 국내 쪽 논문·저자는 연습용 가상 자료(◇)이고 주인공 백일이는 새로 그린 원본 캐릭터입니다.</p></div>';
 var $=function(q){return host.querySelector(q)},stage=$('.vp-stage'),scene=$('.vp-scene'),sub=$('.vp-sub'),chip=$('.vp-chip'),bar=$('.vp-bar'),big=$('.vp-big'),list=$('.vp-list'),bubble=$('.vp-bubble'),bearEl=$('.vp-bear');
 var PERM=[['연','월','일'],['연','일','월'],['월','일','연'],['월','연','일'],['일','월','연'],['일','연','월']];
 function make(e,k){var n=NM[e.k],r=e.rule,nov=/Nov|^11$/.test(e.order[1][1]+e.order[0][1]),mo=nov?'11':'3',dy=nov?'4':'3',dn=nov?'접속일(2026. 11. 4.)':'발행일(2026. 3. 3.)';
  var ko={연:'2026',월:mo,일:dy},ord=e.order.map(function(o){return o[0]}),lab=ord.join(' → ');
  var S=[];
  // 1 오프닝
  S.push({k:'오프닝',m:'happy',html:'<div class="v-title" style="--c:'+e.c+'"><small>백일이의 영어 논문 쓰기</small><b>'+esc(e.t)+'</b><span>'+esc(e.topic)+'</span></div>',b:[{say:e.t+'. '+e.topic+'.',bub:'안녕, 백일이야!',r:9,dur:3800}]});
  // 2 소개
  var plan=['서지 모양 비교','다른 점 하나씩','날짜 순서 ('+dn.replace(/\(.*\)/,'')+')','헷갈리는 규칙','퀴즈','정리'];
  S.push({k:'오늘 할 일',m:'happy',html:'<h4 class="v-h">오늘 살펴볼 것</h4><ol class="v-plan">'+plan.map(function(p,i){return '<li data-r="'+(i+1)+'"><i>'+(i+1)+'</i>'+esc(p)+'</li>'}).join('')+'</ol>',
   b:[{say:'안녕, 나는 마늘 먹는 곰 백일이야! 국내 학회에서는 낫표를 쓰지만, 해외 학술지에 낼 때는 어떻게 달라질까? 오늘은 '+n+' 편이야.',bub:'오늘은 '+n+' 편!',r:0,dur:0},{say:'오늘은 이 여섯 가지를 차례로 볼 거야.',bub:'여섯 가지만 보자',r:6,dur:0}]});
  // 3 비교
  S.push({k:'서지 비교',m:'ok',html:'<h4 class="v-h">같은 종류의 논문, 두 가지 모양</h4><div class="v-cmp"><div class="v-card ko" data-r="1"><em>🇰🇷 국내 관행 (◇ 가상 논문)</em><p>'+esc(e.ko)+'</p></div><div class="v-card en" data-r="2"><em>🌏 해외 · '+esc(n)+'</em><p>'+esc(e.en)+'</p></div></div>',
   b:[{say:'먼저 국내 학회의 서지야. 논문 제목은 낫표 「 」, 학술지 이름은 겹낫표 『 』로 묶었어.',bub:'국내는 낫표!',r:1,dur:0},{say:'같은 종류의 논문을 '+n+'로 쓰면 이렇게 완전히 다른 모양이 돼.',bub:n+'는 이렇게!',r:2,dur:0},{say:'어디가 어떻게 다른지, 하나씩 짚어 볼게.',bub:'하나씩 볼게',r:2,dur:0}]});
  // 4 차이점
  var DB=e.diffs.map(function(t,i){return {say:(i+1)+'번째. '+t.replace(/[“”]/g,'')+'.',bub:(i+1)+'번째 차이',r:i+1,dur:0}});
  DB.push({say:'이 '+e.diffs.length+'가지만 기억해도 절반은 끝난 거야!',bub:'절반 끝!',r:e.diffs.length+1,dur:0});
  S.push({k:'다른 점',m:'ok',html:'<h4 class="v-h">다른 점 하나씩</h4><ol class="v-diff">'+e.diffs.map(function(t,i){return '<li data-r="'+(i+1)+'" data-cur="'+(i+1)+'"><i>'+(i+1)+'</i><span>'+esc(t)+'</span></li>'}).join('')+'</ol>',b:DB});
  // 5 날짜
  var chipsKo=['연','월','일'].map(function(x){return '<div class="v-chip" data-k="'+x+'"><small>'+x+'</small><b>'+ko[x]+'</b></div>'}).join('');
  var fv={};e.order.forEach(function(o){fv[o[0]]=o[1]});
  S.push({k:'날짜 순서',m:'happy',html:'<h4 class="v-h">'+esc(dn.replace(/\(.*\)/,''))+' 순서: 국내 vs '+esc(n)+'</h4><div class="v-date"><div class="v-lbl ko" data-r="1">🇰🇷 국내: 연 → 월 → 일</div><div class="v-chips" data-flip="2" data-ko=\''+JSON.stringify(ko)+'\' data-fv=\''+JSON.stringify(fv)+'\' data-ord=\''+JSON.stringify(ord)+'\'>'+chipsKo+'</div><div class="v-lbl en" data-r="2">🌏 '+esc(n)+': '+lab+'</div></div><div class="v-ex" data-r="3"><b>예</b> '+esc(e.ed)+'</div><ul class="v-note" data-r="3">'+e.edn.map(function(t){return '<li>'+esc(t)+'</li>'}).join('')+'</ul>',
   b:[{say:'날짜 순서도 달라. 국내는 연, 월, 일. 큰 단위에서 작은 단위로 가는 숫자 순서야.',bub:'국내는 연·월·일',r:1,dur:0},{say:n+'는 '+ord.join(', ')+' 순서로 써. 칸이 이렇게 자리를 바꾸는 거야.',bub:'칸이 움직여!',r:2,dur:0},{say:'실제로는 이렇게 써. '+e.edn.join('. ')+'.',bub:'이렇게 쓰자',r:3,dur:0}]});
  // 6 규칙
  S.push({k:'헷갈리는 규칙',m:'ok',html:'<h4 class="v-h">'+esc(r.head)+'</h4><div class="v-cmp"><div class="v-card en" data-r="1"><em>🌏 해외</em><p>'+esc(r.a)+'</p></div><div class="v-card ko" data-r="2"><em>🇰🇷 국내</em><p>'+esc(r.b)+'</p></div></div><ul class="v-note" data-r="3">'+r.notes.map(function(t){return '<li>'+esc(t)+'</li>'}).join('')+'</ul>',
   b:[{say:'이번엔 자주 헷갈리는 규칙이야. '+r.head+'.',bub:'헷갈리는 규칙!',r:0,dur:0},{say:'해외 양식은 위처럼 쓰고, 국내 관행은 아래처럼 써.',bub:'두 모양 비교',r:2,dur:0},{say:r.notes.join('. ')+'.',bub:'이것만 기억!',r:3,dur:0}]});
  // 7 퀴즈
  var good=ord.join(' → '),opts=[good];PERM.forEach(function(p){var s=p.join(' → ');if(opts.length<3&&opts.indexOf(s)<0&&s!==['연','월','일'].join(' → '))opts.push(s)});
  if(opts.length<3)opts.push(['연','월','일'].join(' → '));
  var rot=(k%3);opts=opts.slice(rot).concat(opts.slice(0,rot));
  var ansI=opts.indexOf(good);
  S.push({k:'퀴즈',m:'happy',html:'<h4 class="v-h">퀴즈</h4><p class="v-q" data-r="1">'+esc(n)+'에서 '+esc(dn.replace(/\(.*\)/,''))+'을 쓰는 순서는?</p><ul class="v-opt" data-r="1">'+opts.map(function(o,i){return '<li data-ans="'+(i===ansI?1:0)+'"><i>'+'①②③'[i]+'</i>'+esc(o)+'</li>'}).join('')+'</ul><p class="v-exp" data-r="2">정답은 '+'①②③'[ansI]+' '+esc(good)+'. '+(good==='연 → 월 → 일'?'이 양식은 국내와 같은 순서로 쓴다.':'국내(연 → 월 → 일)와 순서가 다르다.')+'</p>',
   b:[{say:'퀴즈 시간! '+n+'에서 '+dn.replace(/\(.*\)/,'')+'을 쓰는 순서는? 3초 동안 생각해 봐.',bub:'퀴즈 시간!',r:1,dur:7500},{say:'정답은 '+(ansI+1)+'번, '+ord.join(', ')+' 순서야.',bub:'정답은 '+(ansI+1)+'번!',r:2,dur:0}]});
  // 8 정리
  var rows=['제목·학술지: 낫표(「 」 『 』)는 국내용 → '+n+' 기본형으로','날짜·접속일: 연·월·일 숫자 → '+n+'의 순서로','위의 글·앞의 글: 국내용. 해외 투고에서는 쓰지 않는다','마지막으로, 학술지 투고 규정이 언제나 먼저다'];
  S.push({k:'정리',m:'happy',html:'<h4 class="v-h">백일이의 투고 전 점검</h4><ul class="v-check">'+rows.map(function(t,i){return '<li data-r="'+(i+1)+'"><i>✓</i><span>'+esc(t)+'</span></li>'}).join('')+'</ul>',
   b:[{say:'오늘 배운 걸 점검해 보자. 제목과 학술지는 '+n+' 기본형으로 고쳐 써.',bub:'점검해 보자',r:1,dur:0},{say:'날짜와 접속일은 이 양식의 순서로.',bub:'날짜 순서!',r:2,dur:0},{say:'낫표와 위의 글, 앞의 글은 국내용이니까 해외에는 쓰지 않아.',bub:'국내용은 빼기',r:3,dur:0},{say:'마지막으로, 학술지 투고 규정이 언제나 먼저야. 마늘 백 개가 아니라 백 일 동안 연습하면 쉬워져!',bub:'규정이 먼저!',r:4,dur:0}]});
  var nx=EP[k+1];
  S.push({k:'엔딩',m:'happy',html:'<div class="v-title" style="--c:'+e.c+'"><small>'+esc(e.t)+' 끝</small><b>'+(nx?'다음 화 예고':'수고했어요!')+'</b><span>'+esc(nx?nx.t+' · '+nx.topic:'다른 화를 골라 보세요')+'</span></div>',b:[{say:nx?'다음 화는 '+nx.t+'야.':'마지막 화였어. 다른 화도 골라 봐!',bub:nx?'다음 화에서 만나!':'수고했어!',r:9,dur:4200}]});
  return S}
 function build(){scenes=make(EP[ei],ei);beats=[];var a=0;
  scenes.forEach(function(s,si_){s.start=a;s.b.forEach(function(b){b.dur=b.dur||Math.min(14000,Math.max(4200,3000+b.say.length*105));b.start=a;b.si=si_;beats.push(b);a+=b.dur});s.dur=a-s.start});total=a}
 function fmt(ms){var s=Math.round(ms/1000);return Math.floor(s/60)+':'+('0'+s%60).slice(-2)}
 function drawBar(){bar.innerHTML=scenes.map(function(s,i){return '<i style="flex:'+s.dur+'" data-i="'+i+'" title="'+esc(s.k)+'"><u></u></i>'}).join('');bar.querySelectorAll('i').forEach(function(x){x.onclick=function(ev){ev.stopPropagation();seek(scenes[+x.dataset.i].start+1)}})}
 function flip(box,on){var ko=JSON.parse(box.dataset.ko),fv=JSON.parse(box.dataset.fv),ord=JSON.parse(box.dataset.ord),ch={};box.querySelectorAll('.v-chip').forEach(function(c){ch[c.dataset.k]=c});
  var before={};Object.keys(ch).forEach(function(k){before[k]=ch[k].getBoundingClientRect().left});
  (on?ord:['연','월','일']).forEach(function(k){box.appendChild(ch[k]);ch[k].querySelector('b').textContent=on?fv[k]:ko[k]});
  Object.keys(ch).forEach(function(k){var dx=before[k]-ch[k].getBoundingClientRect().left;if(!dx)return;ch[k].style.transition='none';ch[k].style.transform='translateX('+dx+'px)';requestAnimationFrame(function(){requestAnimationFrame(function(){ch[k].style.transition='transform .9s cubic-bezier(.3,1.2,.4,1)';ch[k].style.transform='none'})})})}
 function setBeat(i,fromSeek){var b=beats[i],s=scenes[b.si];
  if(b.si!==si||fromSeek==='scene'){si=b.si;scene.innerHTML='<div class="vp-in">'+s.html+'</div>';scene.className='vp-scene';chip.textContent=EP[ei].t+' · '+s.k+' ('+(si+1)+'/'+scenes.length+')';bar.querySelectorAll('i').forEach(function(x,k){x.classList.toggle('done',k<si)});bearEl.innerHTML=bearSvg(s.m)}
  bi=i;var r=b.r;
  scene.querySelectorAll('[data-r]').forEach(function(x){x.classList.toggle('on',+x.dataset.r<=r)});
  scene.querySelectorAll('[data-cur]').forEach(function(x){x.classList.toggle('cur',+x.dataset.cur===r);x.classList.toggle('past',+x.dataset.cur<r)});
  var fl=scene.querySelector('[data-flip]');if(fl){var want=r>=+fl.dataset.flip;if(fl.dataset.state!==(want?'1':'0')){fl.dataset.state=want?'1':'0';flip(fl,want)}}
  if(s.k==='퀴즈'&&r>=2)scene.querySelectorAll('.v-opt li').forEach(function(x){x.classList.toggle('ok',x.dataset.ans==='1');x.classList.toggle('no',x.dataset.ans!=='1')});
  bubble.textContent=b.bub;bubble.classList.remove('pop');void bubble.offsetWidth;bubble.classList.add('pop');
  typed=b.say;sub.textContent='';if(voice&&playing)say(b.say)}
 var VP={name:'백일이',rate:1.0,pitch:1.55,pref:['Yuna','Sora','SunHi','Heami','Seoyeon','Jimin','Google','유나','선희']},spk=0,talking=false,holdT=0,vcache=null;
function pickVoice(){if(vcache)return vcache;try{var vs=speechSynthesis.getVoices().filter(function(v){return /^ko/i.test(v.lang)});if(!vs.length)return null;function sc(v){var s=0,n=v.name;VP.pref.forEach(function(p,i){if(n.indexOf(p)>-1)s=Math.max(s,40-i*3)});if(/Natural|Neural|Online|Premium|Enhanced|향상/i.test(n))s+=30;if(v.localService===false)s+=5;return s}vs.sort(function(a,b){return sc(b)-sc(a)});vcache=vs[0];return vcache}catch(e){return null}}
try{speechSynthesis.addEventListener('voiceschanged',function(){vcache=null})}catch(e){}
var LN={A:'에이',B:'비',C:'씨',D:'디',E:'이',F:'에프',G:'지',H:'에이치',I:'아이',J:'제이',K:'케이',L:'엘',M:'엠',N:'엔',O:'오',P:'피',Q:'큐',R:'아르',S:'에스',T:'티',U:'유',V:'브이',W:'더블유',X:'엑스',Y:'와이',Z:'지'},ENP=['Samantha','Aria','Jenny','Zira','Google US English','Karen','Moira','Female'],ecache=null;
var TR=[[/\bop\. ?cit\./gi,'옵 싯'],[/\bIbid\./gi,'이비드'],[/\bet al\./gi,'엣 알'],[/\bWorks Cited/g,'웍스 사이티드'],[/\bCited\b/g,'사이티드'],[/\bSeoyun\b/g,'서윤'],[/\bElena\b/g,'엘레나'],[/\bN-?B\b/g,'엔 비'],[/\bChicago\b/g,'시카고'],[/\bVancouver\b/g,'밴쿠버'],[/\bRivera\b/g,'리베라'],[/\bHan\b/g,'핸'],[/\band\b/g,'앤드'],[/\bAuthor-Date\b/g,'오서 데이트']];
function spellKo(s){return s.replace(/[A-Za-z][A-Za-z.\- ]*(?=[가-힣])/g,function(w){TR.forEach(function(r){w=w.replace(r[0],r[1])});return w}).replace(/\b(apa|mla|acs|ieee)\b/gi,function(m){return m.toUpperCase()}).replace(/\b[A-Z]{2,5}\b/g,function(w){return w.split('').map(function(c){return LN[c]}).join(' ')})}
function enVoice(){if(ecache!==null)return ecache;try{var vs=speechSynthesis.getVoices().filter(function(v){return /^en/i.test(v.lang)});if(!vs.length)return null;function sc(v){var s=0,n=v.name;ENP.forEach(function(p,i){if(n.indexOf(p)>-1)s=Math.max(s,40-i*3)});if(/Natural|Neural|Online|Premium|Enhanced/i.test(n))s+=30;if(/en-US/i.test(v.lang))s+=4;return s}vs.sort(function(a,b){return sc(b)-sc(a)});ecache=vs[0];return ecache}catch(e){return null}}
try{speechSynthesis.addEventListener('voiceschanged',function(){ecache=null})}catch(e){}
function seg(s){var out=[],re=/[A-Za-z][A-Za-z0-9'’&\/\-]*(?:[ ,.:;]+[A-Za-z][A-Za-z0-9'’&\/\-]*)*\.?/g,m,last=0,H=/[가-힣]/,en=!!enVoice();while((m=re.exec(s))){var w=m[0],a=s.charAt(m.index-1),b=s.charAt(m.index+w.length),ln=w.replace(/[^A-Za-z]/g,'').length;var sp=w.search(/[ ,]+[^ ,]+$/);if(en&&!H.test(a)&&H.test(b)&&sp>0&&w.slice(0,sp).split(/[ ,]+/).length>=2){out.push(['ko',s.slice(last,m.index)]);out.push(['en',w.slice(0,sp)]);out.push(['ko',' '+w.slice(sp).replace(/^[ ,]+/,'')])}else if(!en||H.test(a)||H.test(b)||/^[A-Z]{2,5}\.?$/.test(w)||ln<3){out.push(['ko',s.slice(last,m.index+w.length)])}else{out.push(['ko',s.slice(last,m.index)]);out.push(['en',w.replace(/\b([A-Z]{2,5})\b/g,function(x){return x.split('').join('. ')+'.'})])}last=m.index+w.length}out.push(['ko',s.slice(last)]);var r=[];out.forEach(function(x){var tx=x[1];if(r.length&&r[r.length-1][0]===x[0])r[r.length-1][1]+=tx;else r.push([x[0],tx])});return r.map(function(x){return [x[0],(x[0]==='ko'?spellKo(x[1]):x[1]).replace(/^[\s,.:;]+/,'').trim()]}).filter(function(x){return /[가-힣A-Za-z0-9]/.test(x[1])})}
function clean(t){return String(t).replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\uFE0F]/gu,'').replace(/[◇◆※★☆✓✔✗✘▶●○■□▲△▼▽]/g,' ').replace(/\s*[→⇒]\s*/g,', ').replace(/·/g,', ').replace(/[“”"『』「」《》〈〉<>]/g,'').replace(/\s*\(([^)]*)\)\s*/g,', $1, ').replace(/\s*…+\s*/g,', ').replace(/\s*[—–]\s*/g,', ').replace(/,\s*,/g,',').replace(/\s+/g,' ').replace(/^[,\s]+|[,\s]+$/g,'').trim()}
function hush(){spk++;talking=false;try{speechSynthesis.cancel()}catch(e){}}
function say(t){try{var S=speechSynthesis;hush();var id=spk,c=clean(t);if(!c)return;var parts,q=[],i=0;try{parts=c.split(new RegExp('(?<=[가-힣)][.~]|[!?])\\s+'))}catch(e){parts=[c]}parts.forEach(function(p,k){seg(p).forEach(function(x,j,arr){q.push([x[0],x[1],j===arr.length-1?110:40])})});var v=pickVoice(),ev=enVoice();talking=true;holdT=0;function next(){if(id!==spk)return;if(i>=q.length){talking=false;return}var it=q[i++],u=new SpeechSynthesisUtterance(it[1]);if(it[0]==='en'&&ev){u.lang=ev.lang||'en-US';u.voice=ev;u.rate=Math.min(1.5,VP.rate*0.95*speed)}else{u.lang='ko-KR';if(v)u.voice=v;u.rate=Math.min(1.6,VP.rate*speed)}u.pitch=VP.pitch;u.volume=1;u.onend=function(){setTimeout(next,it[2])};u.onerror=function(){if(id===spk)talking=false};S.speak(u)}next()}catch(e){talking=false}}
 function frame(ts){if(!playing)return;var dt=Math.min(100,ts-last);last=ts;el+=dt*speed;if(voice&&talking){var hb=beats[bi];if(hb&&el>=hb.start+hb.dur-40){if(!holdT)holdT=ts;if(ts-holdT<12000)el=hb.start+hb.dur-40}}else holdT=0;if(el>=total){end();return}
  var i=0;for(var k=0;k<beats.length;k++){if(el>=beats[k].start)i=k}
  if(i!==bi)setBeat(i);var b=beats[i],p=(el-b.start)/b.dur;
  var n=Math.min(typed.length,Math.floor(typed.length*Math.min(1,p/0.8)));sub.textContent=cc?typed.slice(0,n):'';
  var s=scenes[si],sp=(el-s.start)/s.dur,fills=bar.querySelectorAll('i');if(fills[si])fills[si].firstChild.style.width=Math.min(100,sp*100)+'%';
  $('.vp-time').textContent=fmt(el)+' / '+fmt(total);raf=requestAnimationFrame(frame)}
 function end(){playing=false;sync();if(auto&&ei+1<EP.length){endTimer=setTimeout(function(){load(ei+1,true)},600)}}
 function sync(){stage.classList.toggle('playing',playing);big.hidden=playing;$('[data-a=pp]').textContent=playing?'⏸':'▶';if(!playing){hush()}}
 function play(){clearTimeout(endTimer);if(el>=total-50){el=0;setBeat(0,'scene')}playing=true;last=performance.now();sync();if(voice)say(beats[bi].say);cancelAnimationFrame(raf);raf=requestAnimationFrame(frame)}
 function pause(){playing=false;cancelAnimationFrame(raf);sync()}
 function seek(ms){el=Math.max(0,Math.min(total-10,ms));var i=0;for(var k=0;k<beats.length;k++){if(el>=beats[k].start)i=k}
  var s=beats[i].si;setBeat(i,s!==si?null:'scene');var fills=bar.querySelectorAll('i');fills.forEach(function(x,k){x.firstChild.style.width=k<si?'100%':'0'});var sc=scenes[si];fills[si].firstChild.style.width=((el-sc.start)/sc.dur*100)+'%';$('.vp-time').textContent=fmt(el)+' / '+fmt(total);sub.textContent=cc?typed.slice(0,Math.floor(typed.length*Math.min(1,((el-beats[i].start)/beats[i].dur)/0.8))):''}
 function load(i,gop){clearTimeout(endTimer);ei=i;el=0;si=-1;bi=0;build();drawBar();setBeat(0,'scene');$('.vp-time').textContent='0:00 / '+fmt(total);list.querySelectorAll('.vp-it').forEach(function(x,k){x.classList.toggle('on',k===i)});stage.style.setProperty('--c',EP[i].c);if(gop)play();else pause()}
 list.innerHTML=EP.map(function(e,i){return '<button type="button" class="vp-it" role="listitem" style="--c:'+e.c+'" data-i="'+i+'"><b>'+esc(e.t.replace(/ 편$/,''))+'</b><span>'+esc(e.topic)+'</span><em>▶ 재생 중</em></button>'}).join('');
 list.querySelectorAll('.vp-it').forEach(function(b){b.onclick=function(){load(+b.dataset.i,true);stage.scrollIntoView({block:'nearest',behavior:'smooth'})}});
 big.onclick=function(ev){ev.stopPropagation();play()};
 stage.addEventListener('click',function(ev){if(ev.target.closest('.vp-ctl'))return;playing?pause():play()});
 host.querySelectorAll('[data-a]').forEach(function(b){b.onclick=function(ev){ev.stopPropagation();var a=b.dataset.a;
  if(a==='pp')playing?pause():play();
  else if(a==='prev'){var c=scenes[si];seek(el-c.start>1500?c.start+1:(scenes[si-1]||c).start+1)}
  else if(a==='next'){if(si<scenes.length-1)seek(scenes[si+1].start+1);else if(ei+1<EP.length)load(ei+1,true)}
  else if(a==='cc'){cc=!cc;b.classList.toggle('on',cc);if(!cc)sub.textContent=''}
  else if(a==='voice'){if(!('speechSynthesis' in window)){b.textContent='음성 없음';return}voice=!voice;b.classList.toggle('on',voice);if(voice&&playing)say(beats[bi].say);else hush()}
  else if(a==='spd'){speed=speed===1?1.5:speed===1.5?2:speed===2?.75:1;b.textContent=speed+'×'}
  else if(a==='auto'){auto=!auto;b.classList.toggle('on',auto)}
  else if(a==='fs'){try{if(d.fullscreenElement)d.exitFullscreen();else stage.requestFullscreen()}catch(e){}}}});
 stage.addEventListener('keydown',function(ev){if(ev.key===' '){ev.preventDefault();playing?pause():play()}else if(ev.key==='ArrowRight'){ev.preventDefault();host.querySelector('[data-a=next]').click()}else if(ev.key==='ArrowLeft'){ev.preventDefault();host.querySelector('[data-a=prev]').click()}});
 d.addEventListener('visibilitychange',function(){if(d.hidden&&playing)pause()});
 load(0,false)}
})();
