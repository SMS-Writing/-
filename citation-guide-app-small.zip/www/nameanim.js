(function(){
var d=document,H=d.getElementById('nameanim');if(!H)return;
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
// 연습용 가상 저자: Seoyun Han(성 Han, 이름 Seoyun), Elena Rivera(성 Rivera, 이름 Elena)
var T=function(id,w,r,lab){return{id:id,w:w,r:r,lab:lab}};
var N1=T('a1','Seoyun','','이름'),S=[
{k:'Chicago 참고문헌',sub:'Author-Date·Notes-Bibliography 참고문헌 목록',
 ow:['a1','a2','x','b1','b2','y'],or:['a2','a1','x','b1','b2','y'],
 t:[T('a1','Seoyun','Seoyun,','이름'),T('a2','Han,','Han,','성'),T('x','and','and'),T('b1','Elena','Elena','이름'),T('b2','Rivera.','Rivera.','성'),T('y','Title…','Title…')],
 rule:'<b>첫 번째 저자만</b> 성이 맨 앞으로 옵니다: <b>Han, Seoyun</b>. 두 번째 저자부터는 이름 성 순서 그대로 씁니다: <b>Elena Rivera</b>.'},
{k:'Chicago 외각주',sub:'Notes-Bibliography의 각주(쪽 아래 주석)',
 ow:['a2','a1','x','b1','b2','y'],or:['a1','a2','x','b1','b2','y'],
 t:[T('a2','Han,','Han','성'),T('a1','Seoyun,','Seoyun','이름'),T('x','and','and'),T('b1','Elena','Elena','이름'),T('b2','Rivera,','Rivera,','성'),T('y','Title…','Title…')],
 rule:'외각주(쪽 아래 각주)에서는 <b>이름을 다 쓰고, 이름 성 순서</b>입니다: <b>Seoyun Han</b>. 내각주(본문 괄호)는 성만 씁니다. 옆의 탭에서 비교해 보세요.'},
{k:'Chicago 내각주 · 영어',sub:'Author-Date의 본문 괄호(내각주) · 영어 저자',
 ow:['a1','a2','x','b1','b2','y'],or:['a2','a1','x','b1','b2','y'],
 t:[T('a1','(Seoyun','','이름'),T('a2','Han','(Han','성'),T('x','and','and'),T('b1','Elena','','이름'),T('b2','Rivera','Rivera','성'),T('y','2021)','2021)')],
 rule:'영어 저자는 내각주(본문 괄호)에 <b>성만</b> 씁니다: <b>(Han and Rivera 2021)</b>. 이름은 쓰지 않아요. 외각주에서는 이름을 다 쓰는 것과 다릅니다.'},
{k:'Chicago 내각주 · 한글',sub:'Author-Date의 본문 괄호(내각주) · 한국어 저자',
 ow:['a2','y'],or:['a2','a1','y'],
 t:[T('a2','(한','(한','성'),T('a1','','서윤','이름'),T('y','2021)','2021)')],
 rule:'한국어 저자는 내각주에서도 <b>성과 이름을 모두</b> 씁니다: <b>(한서윤 2021)</b>. 영어 저자는 성만(Han 2021), 한국어 저자는 이름 전체(한서윤 2021) — <b>영어와 한글의 표기가 달라요.</b>'},
{k:'MLA',sub:'Works Cited',
 ow:['a1','a2','x','b1','b2','y'],or:['a2','a1','x','b1','b2','y'],
 t:[T('a1','Seoyun','Seoyun,','이름'),T('a2','Han,','Han,','성'),T('x','and','and'),T('b1','Elena','Elena','이름'),T('b2','Rivera.','Rivera.','성'),T('y','Title…','Title…')],
 rule:'첫 번째 저자만 <b>Han, Seoyun</b>처럼 성을 앞에 둡니다. 둘째 저자는 <b>Elena Rivera</b> 그대로입니다.'},
{k:'APA',sub:'참고문헌 목록',
 ow:['a1','a2','x','b1','b2','y'],or:['a2','a1','x','b2','b1','y'],
 t:[T('a1','Seoyun','S.,','이름'),T('a2','Han,','Han,','성'),T('x','&','&'),T('b1','Elena','E.','이름'),T('b2','Rivera','Rivera,','성'),T('y','(2021).','(2021).')],
 rule:'<b>모든 저자</b>를 성 먼저, 이름은 <b>첫 글자(이니셜)</b>만 씁니다: <b>Han, S., &amp; Rivera, E.</b>'},
{k:'IEEE',sub:'참고문헌 [번호]',
 ow:['a2','a1','x','b2','b1','y'],or:['a1','a2','x','b1','b2','y'],
 t:[T('a2','Han,','Han','성'),T('a1','S.,','S.','이름'),T('x','and','and'),T('b2','Rivera,','Rivera,','성'),T('b1','E.,','E.','이름'),T('y','“Title,”','“Title,”')],
 rule:'IEEE는 <b>이름 이니셜이 먼저, 성이 나중</b>입니다: <b>S. Han and E. Rivera</b>. 성을 앞에 두는 양식과 반대입니다.'},
{k:'Vancouver',sub:'참고문헌 번호 목록',
 ow:['a1','a2','b1','b2','y'],or:['a2','a1','b2','b1','y'],
 t:[T('a1','Seoyun','S,','이름'),T('a2','Han,','Han','성'),T('b1','Elena','E.','이름'),T('b2','Rivera.','Rivera','성'),T('y','Title…','Title…')],
 rule:'성 먼저, 이름 이니셜은 <b>마침표·쉼표 없이 붙여</b> 씁니다: <b>Han S, Rivera E.</b>'},
{k:'ACS',sub:'참고문헌 목록',
 ow:['a1','a2','b1','b2','y'],or:['a2','a1','b2','b1','y'],
 t:[T('a1','S.','S.;','이름'),T('a2','Han,','Han,','성'),T('b1','E.','E.','이름'),T('b2','Rivera','Rivera,','성'),T('y','Title…','Title…')],
 rule:'모든 저자를 <b>성, 이니셜</b> 순서로 쓰고 저자 사이는 <b>세미콜론(;)</b>으로 가릅니다: <b>Han, S.; Rivera, E.</b>'}];
var cur=0,done=false,busy=false,reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
function line(s,right){var ord=right?s.or:s.ow,m={};s.t.forEach(function(t){m[t.id]=t});
 return ord.map(function(id){var t=m[id];var tx=right?t.r:t.w;return '<span class="nmt'+(tx===''?' emp':'')+(s.k.indexOf('한글')>0?' ko':'')+'" data-id="'+id+'"><span class="nml'+(t.lab==='성'?' fam':t.lab==='이름'?' giv':'')+'">'+(t.lab?esc(t.lab):'&nbsp;')+'</span><span class="nmx">'+esc(right?t.r:t.w)+'</span></span>'}).join('')}
function draw(){var s=S[cur];done=false;
 H.innerHTML='<div class="nmtabs" role="tablist">'+S.map(function(x,i){return '<button role="tab" class="nmtab'+(i===cur?' on':'')+'" data-i="'+i+'">'+esc(x.k)+'</button>'}).join('')+'</div>'
 +'<div class="nmcard"><div class="nmsub">'+esc(s.sub)+' · 연습용 가상 저자 Seoyun Han(성 Han, 이름 Seoyun), Elena Rivera(성 Rivera, 이름 Elena)</div>'
 +'<div class="nmstate" id="nmst"><span class="nmbad">✗ 잘못된 순서·모양</span></div>'
 +'<div class="nmline" id="nml">'+line(s,false)+'</div>'
 +'<div class="nmrule" id="nmr" aria-live="polite">영어 이름은 어느 쪽이 성인지 알기 어렵습니다. 위의 <b class="nmfam">성</b>·<b class="nmgiv">이름</b> 표시를 보며 어떻게 옮겨지는지 지켜보세요.</div>'
 +'<div class="nmbtns"><button id="nmgo" class="nmgo">▶ 고쳐 보기</button><button id="nmre">↺ 처음으로</button></div></div>';
 H.querySelectorAll('.nmtab').forEach(function(b){b.onclick=function(){cur=+b.dataset.i;draw();setTimeout(go,350)}});
 $('nmgo').onclick=go;$('nmre').onclick=function(){draw()}}
function $(i){return d.getElementById(i)}
function go(){if(done||busy)return;var s=S[cur],L=$('nml');if(!L)return;busy=true;
 var first={};L.querySelectorAll('.nmt').forEach(function(e){first[e.dataset.id]=e.getBoundingClientRect()});
 L.innerHTML=line(s,true);
 L.querySelectorAll('.nmt').forEach(function(e){var a=first[e.dataset.id],b=e.getBoundingClientRect();if(!a||!a.width){e.classList.add('fin');return}
  if(reduce)return;var dx=a.left-b.left,dy=a.top-b.top;if(!dx&&!dy)return;
  e.style.transition='none';e.style.transform='translate('+dx+'px,'+dy+'px)';e.classList.add('mv');
  requestAnimationFrame(function(){requestAnimationFrame(function(){e.style.transition='transform .9s cubic-bezier(.3,.7,.3,1)';e.style.transform='';})})});
 $('nmst').innerHTML='<span class="nmok">✓ 알맞은 순서·모양</span>';$('nmr').innerHTML=s.rule;
 setTimeout(function(){busy=false;done=true;L.querySelectorAll('.mv').forEach(function(e){e.classList.remove('mv')})},reduce?10:1000)}
draw();
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting&&e.intersectionRatio>=.6&&!H.dataset.auto){H.dataset.auto=1;setTimeout(go,900)}})},{threshold:.6});io.observe(H)}
})();
