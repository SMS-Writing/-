(function(){
function $(s,r){return (r||document).querySelector(s)}
function el(t,c,h){var e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
/* ===== A. 구성 순서와 쪽 번호 ===== */
var F=$('#c2flow');
if(F){
 var items=[
  ['표지','제목(굵게), 부제, 학과·학번·이름, 과목, 담당 교수자, 제출일을 가운데 정렬한다.','no'],
  ['목차','장·절·항 제목과 쪽 번호를 점선으로 이어 쓴다. 쪽 번호는 본문 제목이 놓인 쪽과 같아야 한다.','no'],
  ['요약','연구의 목적, 방법, 결과를 짧게 쓴다. 제출처가 요구할 때만 넣는다.','opt'],
  ['서론','문제 제기, 연구의 배경과 목적, 선행연구 검토, 연구 범위·방법을 쓴다. 여기서부터 쪽 번호를 센다(1쪽).','pg'],
  ['본론','주제를 장·절·항으로 나누어 근거를 들어 논한다. 인용은 여기에서 가장 많이 쓰인다.','pg'],
  ['결론','본론의 결과를 정리하고 한계와 후속 과제를 쓴다.','pg'],
  ['참고문헌','본문에서 인용한 자료를 양식의 규칙대로 정리한다. 새 쪽에서 시작한다.','ref']];
 var box=el('div','c2box'); F.innerHTML='';F.appendChild(box);
 box.innerHTML='<div class="c2h"><b>보고서의 구성 순서와 쪽 번호</b><span class="c2bt"><button type="button" id="c2fp" class="c2b">▶ 순서대로 보기</button></span></div><div class="c2row" id="c2cards"></div><div class="c2bar"><i id="c2nb" style="width:0"></i></div><div class="c2cap" id="c2cap">카드를 누르거나 “순서대로 보기”를 눌러 보세요.</div>';
 var cards=$('#c2cards',box),cap=$('#c2cap',box),nb=$('#c2nb',box),n=0;
 var cs=items.map(function(it,i){
  var c=el('button','c2c '+it[2],'<b>'+it[0]+'</b><small>'+(it[2]==='no'?'쪽 번호 없음':it[2]==='opt'?'요구할 때만':it[2]==='ref'?'새 쪽에서':'쪽 번호 '+(i-2))+'</small>');
  c.type='button';c.addEventListener('click',function(){show(i)});cards.appendChild(c);return c});
 function show(i){cs.forEach(function(c,k){c.classList.toggle('on',k===i);c.classList.toggle('past',k<i)});
  cap.innerHTML='<b>'+items[i][0]+'</b> — '+items[i][1];
  nb.style.width=((i+1)/items.length*100)+'%';nb.className=(i>=3&&i<6)?'pg':''}
 var run=0;
 $('#c2fp',box).addEventListener('click',async function(){var me=++run;for(var i=0;i<items.length;i++){if(me!==run)return;show(i);await sleep(1300)}});
}
/* ===== B. 내어쓰기 ===== */
var H=$('#c2hang');
if(H){
 var L=[['Ⅰ.',0,'서론: 제목이 길어서 두 줄로 넘어갈 경우 둘째 줄은 기호 아래가 아니라 “서” 글자 아래에 맞춥니다.'],
  ['1.',2,'연구의 배경과 목적: 줄이 넘어가면 기호 다음 글자에 맞춥니다. 일부러 길게 적은 예시 문장입니다.'],
  ['가.',4,'국내 연구 동향: 줄이 넘어가는 모습을 확인하기 위해 일부러 길게 적은 예시 문장입니다.'],
  ['1)',6,'표기 요소의 구성: 줄이 넘어가는 모습을 확인하기 위해 일부러 길게 적은 예시 문장입니다.'],
  ['가)',8,'저자와 발행 정보: 줄이 넘어가는 모습을 확인하기 위해 일부러 길게 적은 예시 문장입니다.'],
  ['(1)',10,'개인 저자와 단체 저자: 줄이 넘어가는 모습을 확인하기 위한 예시 문장입니다.'],
  ['(가)',12,'단체 저자의 약칭: 단계가 이렇게 깊어지면 구조를 단순하게 고치는 것이 좋습니다.']];
 H.innerHTML='';
 var w=el('div','c2box c2hang');H.appendChild(w);
 w.innerHTML='<div class="c2h"><b>내어쓰기 직접 보기</b><span class="c2bt"><button type="button" class="c2b" id="hgt" aria-pressed="false">내어쓰기 꺼짐</button><button type="button" class="c2b" id="hgp">▶ 자동 재생</button></span></div>'
  +'<label class="c2lv">보이는 단계 <input type="range" id="hgr" min="1" max="7" value="3"><output id="hgo">3단계</output></label>'
  +'<div class="hgpage" id="hgpage"><div class="hgrul" id="hgrul"></div><div class="hgg" id="hgg"></div><div id="hgrows"></div></div>'
  +'<p class="c2cap" id="hgcap">줄을 눌러 보세요. 점선이 둘째 줄이 맞춰지는 자리입니다. 가로 눈금은 타(한글 1자 = 2타)입니다.</p>';
 var rul=$('#hgrul',w),rows=$('#hgrows',w),g=$('#hgg',w),page=$('#hgpage',w),on=false,sel=null,rs=[];
 for(var t=0;t<=16;t+=2){var tk=el('i','',''),lb=el('span','',String(t));tk.style.left=(t*8)+'px';lb.style.left=(t*8)+'px';rul.appendChild(tk);rul.appendChild(lb)}
 L.forEach(function(l,i){var r=el('div','hgrow','<span class="hgs">'+l[0]+'</span> '+l[2]);r.style.setProperty('--ind',l[1]*.5+'em');
  r.addEventListener('click',function(){sel=i;place()});rows.appendChild(r);rs.push(r)});
 function meas(){rs.forEach(function(r){var s=$('.hgs',r);r.style.setProperty('--sw',(s.getBoundingClientRect().width+ (parseFloat(getComputedStyle(s).fontSize)*.28))+'px')})}
 function place(){setTimeout(function(){if(sel==null||rs[sel].hidden){g.style.opacity=0;return}
   var r=rs[sel],pr=page.getBoundingClientRect(),rr=r.getBoundingClientRect();
   var left=parseFloat(getComputedStyle(r).paddingLeft);
   g.style.left=(rr.left-pr.left+left)+'px';g.style.top=(rr.top-pr.top)+'px';g.style.height=rr.height+'px';g.style.opacity=1;
   rs.forEach(function(x,k){x.classList.toggle('sel',k===sel)});
   $('#hgcap',w).innerHTML=on?'<b>'+L[sel][0]+'</b> 둘째 줄이 점선(기호 다음 글자)에 맞춰집니다.':'<b>'+L[sel][0]+'</b> 내어쓰기가 꺼져 있어 둘째 줄이 기호 아래(점선)로 들어갑니다.'},on?60:40)}
 function setOn(v){on=v;w.classList.toggle('on',on);var b=$('#hgt',w);b.textContent=on?'내어쓰기 켜짐':'내어쓰기 꺼짐';b.setAttribute('aria-pressed',on);
   setTimeout(place,700);place()}
 function setN(n){rs.forEach(function(r,i){r.hidden=i>=n});$('#hgo',w).textContent=n+'단계';$('#hgr',w).value=n;if(sel!=null&&sel>=n)sel=n-1;place()}
 $('#hgt',w).addEventListener('click',function(){setOn(!on)});
 $('#hgr',w).addEventListener('input',function(){setN(+this.value)});
 var run2=0;
 $('#hgp',w).addEventListener('click',async function(){var me=++run2;setOn(false);setN(1);sel=0;place();
   for(var n=2;n<=7;n++){await sleep(700);if(me!==run2)return;setN(n);sel=n-1;place()}
   await sleep(900);if(me!==run2)return;setOn(true);
   for(var k=0;k<7;k++){if(me!==run2)return;sel=k;place();await sleep(650)}});
 window.addEventListener('resize',function(){meas();place()});
 setTimeout(function(){meas();setN(3);sel=1;setOn(false)},50);
 if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){meas();place()});
}
/* ===== C. 언급 → 제시 → 해석 ===== */
var T=$('#c2tf');
if(T){
 T.innerHTML='';var b=el('div','c2box');T.appendChild(b);
 b.innerHTML='<div class="c2h"><b>표·그림을 다루는 세 단계</b><span class="c2bt"><button type="button" class="c2b" id="tfp">▶ 단계별로 보기</button></span></div>'
 +'<div class="c2tf"><div class="tfc" id="tf1"><h5>① 언급</h5><p>본문에서 번호로 먼저 가리킨다.</p><div class="tfx" id="tfx1"></div></div>'
 +'<div class="tfc" id="tf2"><h5>② 제시</h5><p>번호·제목을 붙여 표나 그림을 보인다.</p><div class="tfx" id="tfx2"></div></div>'
 +'<div class="tfc" id="tf3"><h5>③ 해석</h5><p>가장 눈에 띄는 값과 그 뜻을 말한다.</p><div class="tfx" id="tfx3"></div></div></div>'
 +'<p class="c2cap">※ 예시 수치는 연습용 가상 자료입니다.</p>';
 var S1='〈표 1〉은 오류 유형별 사례 수를 보여 준다.',S3='쪽수 누락이 <mark>42건(35.0%)</mark>으로 가장 많았다.';
 var TB='<div class="tft"><b>표 1. 오류 유형별 사례 수</b><table><tr><th>오류 유형</th><th>사례 수(건)</th><th>비율(%)</th></tr><tr class="hot"><td>쪽수 누락</td><td>42</td><td>35.0</td></tr><tr><td>출처–목록 불일치</td><td>30</td><td>25.0</td></tr><tr><td>간접 인용 출처 생략</td><td>24</td><td>20.0</td></tr><tr><td>형식 오류</td><td>24</td><td>20.0</td></tr></table></div>';
 function reset(){['tf1','tf2','tf3'].forEach(function(i){$('#'+i,b).classList.remove('on')});$('#tfx1',b).textContent=S1;$('#tfx2',b).innerHTML=TB;$('#tfx3',b).innerHTML=S3}
 reset();
 async function type(node,html){var plain=html.replace(/<[^>]+>/g,'');node.innerHTML='';for(var i=1;i<=plain.length;i++){node.textContent=plain.slice(0,i);await sleep(28)}node.innerHTML=html}
 var run3=0;
 $('#tfp',b).addEventListener('click',async function(){var me=++run3;reset();
  ['tf1','tf2','tf3'].forEach(function(i){$('#'+i,b).classList.remove('on')});
  $('#tfx1',b).textContent='';$('#tfx2',b).style.visibility='hidden';$('#tfx3',b).textContent='';
  $('#tf1',b).classList.add('on');await type($('#tfx1',b),S1);if(me!==run3)return;await sleep(500);
  $('#tf1',b).classList.remove('on');$('#tf2',b).classList.add('on');$('#tfx2',b).style.visibility='visible';$('#tfx2',b).classList.remove('fade');void $('#tfx2',b).offsetWidth;$('#tfx2',b).classList.add('fade');await sleep(1400);if(me!==run3)return;
  $('#tf2',b).classList.remove('on');$('#tf3',b).classList.add('on');await type($('#tfx3',b),S3)});
 $('#tfx2',b).style.visibility='visible';
}
})();
