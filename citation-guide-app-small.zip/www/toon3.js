(function(){
var d=document,$=function(i){return d.getElementById(i)},K=window.TOONK;
if(!K||!$('webtoon3'))return;
var AN=K.AN,esc=K.esc,INK=K.INK;
var RC={au:'#e57b78',yr:'#e0a100',ti:'#4a8fd0',jn:'#7a62c4',vo:'#4fa08f',pg:'#c47a2c',pl:'#8a6fb0',dt:'#d19a1a',ur:'#6a8f3a',nm:'#9a9088',miss:'#d33'};
function tw(t,fs){var w=0;for(var i=0;i<t.length;i++){var c=t.charCodeAt(i);w+=(c>=0x2E80||c===0x2192)?fs:(c>=65&&c<=90?fs*0.68:fs*0.56)}return w}
// 칩(서지 조각)을 줄바꿈하며 늘어놓는다. seg=[글,역할,틀림?]  '\n'은 줄바꿈
function chips(segs,x0,y0,maxW,fs){var x=x0,y=y0,h=fs+8,out='',gap=4;
 segs.forEach(function(sg){if(sg[0]==='\n'){x=x0;y+=h+gap;return}
  var w=tw(sg[0],fs)+12;if(x>x0&&x+w>x0+maxW){x=x0;y+=h+gap}
  var col=RC[sg[1]]||RC.nm,bad=!!sg[2],miss=sg[1]==='miss';
  out+='<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="5" fill="'+(miss?'#fff':col)+'" fill-opacity="'+(miss?1:0.17)+'" stroke="'+(bad||miss?'#d33':col)+'" stroke-width="'+(bad||miss?2:1.2)+'"'+(bad||miss?' stroke-dasharray="4 2"':'')+'/>'
   +'<text x="'+(x+6)+'" y="'+(y+h-6)+'" font-size="'+fs+'" fill="'+(miss?'#d33':INK)+'" font-weight="'+(/b/.test(sg[3]||'')?900:(sg[1]==='nm'?500:700))+'"'+(((sg[1]==='jn'&&!/n/.test(sg[3]||''))||/i/.test(sg[3]||''))?' font-style="italic"':'')+'>'+esc(sg[0])+'</text>';
  if(bad&&!miss)out+='<text x="'+(x+w-3)+'" y="'+(y-1)+'" font-size="12" fill="#d33" text-anchor="middle" font-weight="900">✘</text>';
  x+=w+gap});
 return {s:out,h:y+h-y0}}
function lines(arr,x,y,fs,col,anchor,maxW){return arr.map(function(t,i){var fit=(maxW&&tw(t,fs)>maxW)?' textLength="'+maxW.toFixed(1)+'" lengthAdjust="spacingAndGlyphs"':'';return '<text x="'+x+'" y="'+(y+i*(fs+4))+'" font-size="'+fs+'" fill="'+(col||INK)+'" font-weight="700"'+(anchor?' text-anchor="'+anchor+'"':'')+fit+'>'+esc(t)+'</text>'}).join('')}
function bubble(x,y,w,arr,fs){var h=arr.length*(fs+4)+10;return '<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="12" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+lines(arr,x+10,y+fs+5,fs,null,null,w-20)}
function band(text,col){return '<rect width="360" height="30" fill="'+col+'"/><text x="12" y="20" font-size="14" font-weight="800" fill="#fff">'+esc(text)+'</text>'}
function tint(c){return c+'22'}
// ---- 컷 종류 ----
function pIntro(k,line){var a=AN[k],h=250;
 return svg(h,'<rect width="360" height="'+h+'" fill="'+tint(a.c)+'"/>'+band(a.st+' 담당 · '+a.n+'('+a.sp+')',a.c)+'<rect y="214" width="360" height="36" fill="'+a.c+'" fill-opacity=".25"/>'+K.animal(k,100,222,'happy',1.25)
  +bubble(168,52,184,line,13)+'<text x="262" y="196" font-size="30" text-anchor="middle">⚠️ ✔️</text>')}
function pCard(k,n,c){var a=AN[k],fs=11,W=312,cw=chips(c.wrong,26,64,W,fs),y2=64+cw.h+30,rw=chips(c.right,26,y2+34-6,W,fs);
 var y1top=44,y1h=cw.h+30,ry=y2,rh=rw.h+36,top2=ry-0,h=ry+rh+96;
 var s='<rect width="360" height="'+h+'" fill="'+tint(a.c)+'"/>'+band('주의 '+n+' · '+c.ttl,a.c)
  +'<rect x="14" y="'+y1top+'" width="332" height="'+y1h+'" rx="10" fill="#fff" stroke="#d33" stroke-width="2.5"/><circle cx="14" cy="'+y1top+'" r="13" fill="#d33"/><text x="14" y="'+(y1top+6)+'" font-size="17" font-weight="900" fill="#fff" text-anchor="middle">✘</text>'+cw.s
  +'<path d="M180 '+(y1top+y1h+3)+'v'+(ry-y1top-y1h-8)+'" stroke="#4a3a30" stroke-width="3" marker-end="url(#ah)"/>'
  +'<rect x="14" y="'+ry+'" width="332" height="'+rh+'" rx="10" fill="#fff" stroke="#2f9e5a" stroke-width="2.5"/><circle cx="14" cy="'+ry+'" r="13" fill="#2f9e5a"/><text x="14" y="'+(ry+6)+'" font-size="17" font-weight="900" fill="#fff" text-anchor="middle">✔</text>'
  +chips(c.right,26,ry+14,W,fs).s
  +'<rect y="'+(h-84)+'" width="360" height="84" fill="'+a.c+'" fill-opacity=".22"/>'+K.animal(k,62,h-8,'ok',0.72)+bubble(110,h-82,238,c.say,11);
 return svg(h,s)}
function pIcons(k,ttl,items,say,mood){var a=AN[k],h=270;
 var s='<rect width="360" height="'+h+'" fill="'+tint(a.c)+'"/>'+band(ttl,a.c);
 items.forEach(function(it,i){var x=20+i*108;s+='<rect x="'+x+'" y="44" width="96" height="116" rx="12" fill="#fff" stroke="'+(it.bad?'#d33':'#2f9e5a')+'" stroke-width="2.5"/><text x="'+(x+48)+'" y="98" font-size="38" text-anchor="middle">'+it.e+'</text>'+lines(it.t,x+48,124,11,INK,'middle')+'<circle cx="'+(x+84)+'" cy="52" r="11" fill="'+(it.bad?'#d33':'#2f9e5a')+'"/><text x="'+(x+84)+'" y="57" font-size="14" font-weight="900" fill="#fff" text-anchor="middle">'+(it.bad?'✘':'✔')+'</text>'});
 s+='<rect y="'+(h-96)+'" width="360" height="96" fill="'+a.c+'" fill-opacity=".22"/>'+K.animal(k,62,h-8,mood||'happy',0.8)+bubble(114,h-92,234,say,11);
 return svg(h,s)}
function svg(h,inner){return '<svg viewBox="0 0 360 '+h+'" class="tnp" role="img" aria-label="그림 컷"><defs><marker id="ah" markerWidth="8" markerHeight="8" refX="4" refY="6" orient="auto"><path d="M0 0L4 8L8 0z" fill="#4a3a30"/></marker></defs>'+inner+'</svg>'}
// ---- 이야기 ----
var A='Han, S.',TT='Reading figures with scientific eyes.',JN='Journal of Imaginary Studies,';
var CH=[
{k:'apa',intro:['나는 아파펭귄! (APA 담당)','연도의 자리와 쪽 표기를','그림으로 알려 줄게.'],src:'이 안내서 제7장. 논문 정보는 연습용 가상 자료입니다.',
 cs:[{ttl:'연도는 저자 바로 뒤',say:['목록에서 연도는','저자 이름 바로 뒤','괄호 안이야.'],
   wrong:[[A,'au'],[TT,'ti'],[JN,'jn'],['29(3), 41–58.','vo'],['(2023).','yr',1]],
   right:[[A,'au'],['(2023).','yr'],[TT,'ti'],[JN,'jn'],['29(3), 41–58.','vo']]},
  {ttl:'직접 인용엔 쪽을 쓴다',say:['따옴표로 그대로','옮기면 쪽 번호도','함께 적어.'],
   wrong:[['“…”','nm'],['(Han, 2023)','au',1]],right:[['“…”','nm'],['(Han, 2023, p. 41)','pg']]},
  {ttl:'국문 논문은 학술지·권을 기울임',web:'apa',say:['학술지 이름과','권 번호는 기울임!','낫표는 쓰지 않아.']}]},
{k:'mla',intro:['나는 엠엘여우! (MLA 담당)','본문엔 연도가 없고,','목록은 쉼표로 이어요.'],src:'이 안내서 제8장. 논문 정보는 연습용 가상 자료입니다.',
 cs:[{ttl:'본문엔 연도를 쓰지 않는다',say:['본문은 저자와','쪽만. 연도는','목록에서 봐.'],
   wrong:[['…라고 했다','nm'],['(Han 2023, 41)','au',1]],right:[['…라고 했다','nm'],['(Han 41)','pg']]},
  {ttl:'목록은 쉼표로 이어 쓴다',say:['제목은 따옴표,','연도는 뒤쪽,','쪽은 pp.로!'],
   wrong:[['Han, Sora.','au'],['(2023).','yr',1],['Reading Figures with Scientific Eyes.','ti',1],[JN,'jn']],
   right:[['Han, Sora.','au'],['“Reading Figures with Scientific Eyes.”','ti'],[JN,'jn'],['vol. 29, no. 3,','vo'],['2023,','yr'],['pp. 41–58.','pg']]},
  {ttl:'국문 논문도 목록은 쉼표로',web:'mla',say:['학술지는 기울임,','vol.·no.·pp.로','쪽까지 써요.']}]},
{k:'cad',intro:['나는 시카곰! (Chicago A-D)','본문 괄호에 쉼표가','없다는 것만 기억해!'],src:'이 안내서 제9장. 논문 정보는 연습용 가상 자료입니다.',
 cs:[{ttl:'저자와 연도 사이엔 쉼표 없음',say:['(Han 2023, 41)','저자와 연도 사이는','띄어쓰기만!'],
   wrong:[['(Han, 2023, 41)','au',1]],right:[['(Han 2023, 41)','au']]},
  {ttl:'연도는 저자 바로 뒤',say:['목록도 저자 뒤에','연도가 바로','나와.'],
   wrong:[['Han, Sora.','au'],['“Reading Figures with Scientific Eyes.”','ti'],['Journal of Imaginary Studies','jn'],['29 (3):','vo'],['41–58.','pg'],['2023.','yr',1]],
   right:[['Han, Sora.','au'],['2023.','yr'],['“Reading Figures with Scientific Eyes.”','ti'],['Journal of Imaginary Studies','jn'],['29 (3):','vo'],['41–58.','pg']]},
  {ttl:'국문 논문도 저자 뒤에 연도',web:'cad',say:['저자 다음에 연도,','제목은 따옴표,','학술지는 기울임!']}]},
{k:'nb',intro:['나는 시카판다! (Chicago N-B)','본문에는 번호만,','내용은 쪽 아래에!'],src:'이 안내서 제10장. 논문 정보는 연습용 가상 자료입니다.',
 cs:[{ttl:'본문엔 번호만 둔다',say:['괄호 대신','위 첨자 번호를','달아 줘.'],
   wrong:[['…라고 했다','nm'],['(Han 2023, 41)','au',1]],right:[['…라고 했다','nm'],['¹','vo'],['\n',''],['1. Sora Han,','au'],['“Reading Figures…,”','ti'],['Journal… 29, no. 3','jn'],['(2023): 41.','yr']]},
  {ttl:'각주는 이름–성, 목록은 성–이름',say:['각주에는 Sora Han,','참고문헌에는','Han, Sora.'],
   wrong:[['1. Han, Sora,','au',1],['“Reading Figures…,”','ti']],right:[['1. Sora Han,','au'],['“Reading Figures…,”','ti'],['\n',''],['Han, Sora.','au'],['“Reading Figures….”','ti']]},
  {ttl:'국문 논문의 각주와 목록',web:'nb',say:['각주는 쉼표로,','목록은 마침표로','이어 써.']}]},
{k:'ieee',intro:['나는 아이트리플냥! (IEEE)','번호는 처음 나온 순서,','이름은 이니셜 먼저!'],src:'이 안내서 제11장. 논문 정보는 연습용 가상 자료입니다.',
 cs:[{ttl:'번호는 처음 인용한 순서',say:['목록 번호는','가나다순이 아니라','본문에 나온 순서!'],
   wrong:[['[2]','vo',1],['먼저 인용한 논문','nm'],['[1]','vo',1],['나중에 인용한 논문','nm']],right:[['[1]','vo'],['먼저 인용한 논문','nm'],['[2]','vo'],['나중에 인용한 논문','nm']]},
  {ttl:'이니셜 먼저, 학술지는 줄여서',say:['S. Han, 제목은','소문자 위주,','학술지는 약어!'],
   wrong:[['Han, Sora.','au',1],['“Reading Figures With Scientific Eyes,”','ti',1],['Journal of Imaginary Studies,','jn',1]],
   right:[['[1]','vo'],['S. Han,','au'],['“Reading figures with scientific eyes,”','ti'],['J. Imaginary Stud.,','jn'],['vol. 29, no. 3,','vo'],['pp. 41–58, 2023.','pg']]},
  {ttl:'국문 논문도 번호와 쉼표',web:'ieee',say:['[1] 번호 다음','저자, 제목,','학술지 순서야.']}]},
{k:'van',intro:['나는 밴쿠개굴! (Vancouver)','번호가 전부예요.','같은 출처는 같은 번호!'],src:'이 안내서 제12장. 논문 정보는 연습용 가상 자료입니다.',
 cs:[{ttl:'같은 출처는 같은 번호',say:['한 논문을 또','인용해도 번호는','새로 안 만들어.'],
   wrong:[['(1)','vo'],['Han S의 논문','au'],['(2)','vo',1],['같은 Han S의 논문','au',1]],right:[['(1)','vo'],['Han S의 논문','au'],['(1)','vo'],['같은 Han S의 논문','au']]},
  {ttl:'따옴표·기울임 없이 연도;권(호):쪽',say:['제목에 따옴표도','기울임도 없어.','세미콜론에 주의!'],
   wrong:[['Han S.','au'],['“Reading figures with scientific eyes.”','ti',1],['2023, 29(3), 41–58.','yr',1]],right:[['Han S.','au'],['Reading figures with scientific eyes.','ti'],['J Imaginary Stud.','jn',0,'n'],['2023;29(3):41-58.','vo']]},
  {ttl:'쪽수는 뒤 숫자를 줄여요',web:'van',say:['123-128은','123-8로 줄여','써요.']}]},
{k:'acs',intro:['나는 애쓰구리! (ACS 담당)','본문 인용은 하나로,','연도는 굵게!'],src:'이 안내서 제13장. 논문 정보는 연습용 가상 자료입니다. 학술지 약어도 가상입니다.',
 cs:[{ttl:'본문 인용 방식은 하나로 통일',say:['위 첨자, (번호),','저자–연도 중','하나만 써.'],
   wrong:[['…¹','vo'],['…(2)','vo',1],['…(Han, 2023)','au',1]],right:[['…¹','vo'],['…²','vo'],['…³','vo']]},
  {ttl:'저자는 세미콜론, 연도는 굵게',say:['Han, S. 모양이고','학술지는 약어,','연도는 굵게!'],
   wrong:[['Han, Sora,','au',1],['Reading Figures with Scientific Eyes','ti'],['Journal of Imaginary Studies','jn',1],['(2023)','yr',1]],right:[['Han, S.','au'],['Reading Figures with Scientific Eyes.','ti'],['J. Imag. Stud.','jn'],['2023,','yr'],['29 (3),','vo'],['41–58.','pg']]},
  {ttl:'학술지와 연도 모양',web:'acs',say:['학술지는 약어에','기울임, 연도는','굵게!']}]}
];
var WEB={
 apa:{w:[['한나래.','au'],['(2024).','yr'],['대학생 글쓰기의 출처 표기 실태.','ti'],['『글쓰기연구』, 29(3), 41–58.','jn',1,'n']],r:[['한나래.','au'],['(2024).','yr'],['대학생 글쓰기의 출처 표기 실태.','ti'],['글쓰기연구, 29','jn',0,'i'],['(3), 41–58.','vo']]},
 mla:{w:[['한나래.','au'],['“대학생 글쓰기의 출처 표기 실태.”','ti'],['『글쓰기연구』,','jn',1,'n'],['29권 3호, 2024, 41–58쪽.','vo',1]],r:[['한나래.','au'],['“대학생 글쓰기의 출처 표기 실태.”','ti'],['글쓰기연구,','jn'],['vol. 29, no. 3,','vo'],['2024,','yr'],['pp. 41–58.','pg']]},
 cad:{w:[['한나래.','au'],['“대학생 글쓰기의 출처 표기 실태.”','ti'],['『글쓰기연구』 29, no. 3: 41–58.','jn',1,'n'],['2024.','yr',1]],r:[['한나래.','au'],['2024.','yr'],['“대학생 글쓰기의 출처 표기 실태.”','ti'],['글쓰기연구','jn'],['29, no. 3: 41–58.','vo']]},
 nb:{w:[['1. 한나래, “대학생 글쓰기의 출처 표기 실태,”','au'],['『글쓰기연구』 29, no. 3 (2024): 41.','jn',1,'n']],r:[['1. 한나래, “대학생 글쓰기의 출처 표기 실태,”','au'],['글쓰기연구','jn'],['29, no. 3 (2024): 41.','vo'],['\n',''],['한나래. “대학생 글쓰기의 출처 표기 실태.”','au'],['글쓰기연구','jn'],['29, no. 3 (2024): 41–58.','vo']]},
 ieee:{w:[['한나래.','au',1],['“대학생 글쓰기의 출처 표기 실태.”','ti',1],['글쓰기연구 29(3):41–58, 2024.','jn',1,'n']],r:[['[1]','vo'],['한나래,','au'],['“대학생 글쓰기의 출처 표기 실태,”','ti'],['글쓰기연구,','jn'],['vol. 29, no. 3,','vo'],['pp. 41–58, 2024.','pg']]},
 van:{w:[['Han S.','au'],['Reading figures with scientific eyes.','ti'],['J Imaginary Stud.','jn',0,'n'],['2023;29(3):123-128.','pg',1]],r:[['Han S.','au'],['Reading figures with scientific eyes.','ti'],['J Imaginary Stud.','jn',0,'n'],['2023;29(3):123-8.','pg']]},
 acs:{w:[['Han, S.','au'],['Reading Figures with Scientific Eyes.','ti'],['J. Imag. Stud.','jn',1,'n'],['2023, 29 (3), 41–58.','yr',1,'n']],r:[['Han, S.','au'],['Reading Figures with Scientific Eyes.','ti'],['J. Imag. Stud.','jn'],['2023,','yr',0,'b'],['29','vo',0,'i'],['(3), 41–58.','pg']]}
};
// 마지막 화: 양식과 관계없는 그림·가사 주의
var ALL=[
 {ttl:'다른 논문의 표·그림은 허락과 출처',items:[{e:'📊',t:['남의 표를','그대로 붙임'],bad:1},{e:'✂️',t:['필요한 부분만','고쳐 그림']},{e:'🏷️',t:['출처와 허락','함께 쓰기']}],say:['표·그림도 저작물이에요.','출처 번호나 저자·연도와','허락 여부를 밝혀요.'],mood:'think'},
 {ttl:'읽지 않은 논문은 인용하지 않기',items:[{e:'🤖',t:['AI가 알려 준','논문을 확인 없이'],bad:1},{e:'🔎',t:['직접 열어','실제로 확인']},{e:'📖',t:['읽은 것만','목록에 올림']}],say:['AI가 알려 준 논문은','열어서 있는지 확인한 뒤','읽은 것만 인용해요.'],mood:'sweat'},
 {ttl:'온라인 논문은 판본을 확인',items:[{e:'🗑️',t:['수정·철회된','논문'],bad:1},{e:'📅',t:['접속한 날을','기록']},{e:'📌',t:['최종본과','수록 정보 확인']}],say:['온라인 논문은 판본이','바뀔 수 있어서','접속일이 중요해요.'],mood:'ok'}];
var CHALL={k:'apa',all:true};
function chapterPanels(i){
 var out=[];
 if(i===CH.length){ALL.forEach(function(x,n){out.push({svg:pIcons(['apa','mla','nb'][n],'함께 · '+x.ttl,x.items,x.say,x.mood),cap:'주의 '+(n+1)})});return out}
 var ch=CH[i];out.push({svg:pIntro(ch.k,ch.intro),cap:'인사'});
 ch.cs.forEach(function(c,n){var cc=c;if(c.web){var w=WEB[c.web];cc={ttl:c.ttl,say:c.say,wrong:w.w,right:w.r}}
  out.push({svg:pCard(ch.k,n+1,cc),cap:(c.web?'국문 논문 (가상 예시)':'주의 '+(n+1))})});
 return out}
function render(host){var cur=0;
 function show(i,noscroll){cur=i;var ch=i<CH.length?CH[i]:null,a=ch?AN[ch.k]:null;
  var tabs=CH.map(function(c,k){var an=AN[c.k];return '<button class="tn-tab'+(k===i?' on':'')+'" data-k="'+k+'" style="--tc:'+an.c+'">'+esc(an.n)+' · '+esc(an.st)+'</button>'}).join('')+'<button class="tn-tab'+(i===CH.length?' on':'')+'" data-k="'+CH.length+'">모두 · 표·그림·확인</button>';
  var ps=chapterPanels(i);
  host.innerHTML='<div class="tn-head"><h2 class="gt">웹툰 시리즈 〈동물 친구들의 주의 한 컷〉</h2><p class="mut">일곱 양식을 맡은 동물 친구가 양식마다 자주 틀리는 곳을 그림으로 보여 줘요. ✘는 틀린 모양, ✔는 맞는 모양, 점선 칸은 빠진 정보입니다. 각 화의 마지막 컷은 논문을 인용할 때의 모양(학술지 이름은 낫표 대신 기울임)이에요.</p></div>'
   +'<div class="tn-tabs" role="tablist">'+tabs+'</div>'
   +'<article class="tn-ep"><h3>'+(ch?esc(a.n)+'의 '+esc(a.st)+' 주의 한 컷':'모두의 주의 한 컷: 표·그림과 확인')+'</h3><div class="tn2 tn2-zig">'+ps.map(function(p){return '<figure class="tn-p tn2p">'+p.svg+'<figcaption class="tn-cap">'+esc(p.cap)+'</figcaption></figure>'}).join('')+'</div>'
   +'<p class="mut tn2-src"><b>이 화의 근거</b> '+esc(ch?ch.src+' 국문 논문의 모양은 이 안내서 각 양식 장의 국문 논문 예시를 따랐고, 양식이 따로 정하지 않아 이 안내서가 맞춘 부분이 있습니다. 저자·논문·학술지는 모두 지어낸 이름입니다.':'표·그림 사용과 출처 확인은 이 안내서 각 양식 장의 안내를 따랐습니다. 저작권과 이용 허락은 학교·학술지·저작권자의 규정이 먼저입니다.')+'</p></article>'
   +'<div class="gbtns"><button class="gbtn" id="tn3p"'+(i===0?' disabled':'')+'>← 이전 화</button><button class="gprimary" id="tn3n"'+(i===CH.length?' disabled':'')+'>다음 화 →</button></div>'
   +'<p class="mut tn-credit">캐릭터는 이 홈페이지를 위해 직접 그린 원본입니다. 예시의 논문·저자·학술지는 모두 연습용으로 지어낸 가상 자료입니다.</p>';
  host.querySelectorAll('.tn-tab').forEach(function(b){b.onclick=function(){show(+b.dataset.k)}});
  var pv=$('tn3p'),nx=$('tn3n');if(pv)pv.onclick=function(){show(cur-1)};if(nx)nx.onclick=function(){show(cur+1)};
  if(!noscroll){var tb=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||110)+8,r=host.getBoundingClientRect();window.scrollTo(0,Math.max(0,r.top+window.pageYOffset-tb))}}
 show(0,true)}
render($('webtoon3'));
})();
