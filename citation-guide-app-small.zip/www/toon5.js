(function(){
var d=document,$=function(i){return d.getElementById(i)},K=window.TOONK;
if(!K)return;
var esc=K.esc,INK=K.INK,C=K.C,E=K.E,P=K.P,RED='#d33',GRN='#2f9e5a';
function svg(h,inner){return '<svg viewBox="0 0 360 '+h+'" class="tnp" role="img" aria-label="웹툰 컷"><defs><marker id="ah5" markerWidth="8" markerHeight="8" refX="4" refY="6" orient="auto"><path d="M0 0L4 8L8 0z" fill="#4a3a30"/></marker></defs>'+inner+'</svg>'}
function tw(t,fs){var w=0;for(var i=0;i<t.length;i++){var c=t.charCodeAt(i);w+=(c>=0x2E80||c===0x2192)?fs:(c>=65&&c<=90?fs*0.7:fs*0.58)}return w}
function lines(arr,x,y,fs,anchor,col,maxW,wt){maxW=maxW||(anchor?0:(346-x));return arr.map(function(t,i){var fit=(maxW&&tw(t,fs)>maxW)?' textLength="'+maxW.toFixed(1)+'" lengthAdjust="spacingAndGlyphs"':'';return '<text x="'+x+'" y="'+(y+i*(fs+4))+'" font-size="'+fs+'" font-weight="'+(wt||700)+'" fill="'+(col||INK)+'"'+(anchor?' text-anchor="'+anchor+'"':'')+fit+'>'+esc(t)+'</text>'}).join('')}
function wrap(t,fs,maxW){var out=[],cur='',ws=t.split(' ');ws.forEach(function(w){var n=cur?cur+' '+w:w;if(tw(n,fs)>maxW&&cur){out.push(cur);cur=w}else cur=n});if(cur)out.push(cur);return out}
function bubble(x,y,w,arr,fs){var h=arr.length*(fs+4)+10;return '<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="12" fill="#fff" stroke="#4a3a30" stroke-width="2"/>'+lines(arr,x+10,y+fs+5,fs,null,null,w-20)}
function band(t,c){return '<rect width="360" height="30" fill="'+c+'"/><text x="12" y="20" font-size="14" font-weight="800" fill="#fff">'+esc(t)+'</text>'}
function tag(x,y,t,c){return '<g><circle cx="'+x+'" cy="'+y+'" r="11" fill="'+c+'"/><text x="'+x+'" y="'+(y+5)+'" font-size="12" font-weight="900" fill="#fff" text-anchor="middle">'+t+'</text></g>'}
/* ---- 주인공 백일이: 단군 이야기의 마늘 먹는 곰을 모티브로 이 홈페이지를 위해 새로 그린 원본 캐릭터 ---- */
function eyes(x,y,m){var ink=INK;if(m==='happy')return '<path d="M'+(x-17)+' '+(y+2)+'q5 -8 10 0M'+(x+7)+' '+(y+2)+'q5 -8 10 0" stroke="'+ink+'" stroke-width="2.4" fill="none" stroke-linecap="round"/>';
 if(m==='shock')return C(x-12,y,5.5,'#fff',ink,2)+C(x+12,y,5.5,'#fff',ink,2)+C(x-12,y,1.8,ink)+C(x+12,y,1.8,ink);
 return C(x-12,y,3.2,ink)+C(x+12,y,3.2,ink)}
function mouth(x,y,m){if(m==='shock')return E(x,y+3,4,5,'#7a3b2e');if(m==='happy')return '<path d="M'+(x-7)+' '+y+'q7 9 14 0" stroke="'+INK+'" stroke-width="2.2" fill="#e88" stroke-linecap="round"/>';return '<path d="M'+(x-6)+' '+y+'q6 6 12 0" stroke="'+INK+'" stroke-width="2.2" fill="none" stroke-linecap="round"/>'}
function garlic(x,y,s){return '<g transform="translate('+x+' '+y+') scale('+(s||1)+')"><path d="M0 -14q-3 -8 0 -12q3 4 0 12z" fill="#e9e1c7" stroke="#8f8668" stroke-width="1"/><path d="M-12 0q0 -14 12 -14q12 0 12 14q0 10 -12 10q-12 0 -12 -10z" fill="#fffdf3" stroke="#8f8668" stroke-width="1.4"/><path d="M0 -13q-6 8 0 22M0 -13q6 8 0 22" stroke="#cfc7a6" stroke-width="1" fill="none"/></g>'}
function bear(x,y,m,s){s=s||1;var h=y-90,g='<g transform="translate('+x+' '+y+') scale('+s+') translate('+(-x)+' '+(-y)+')">';
 g+=E(x,y-36,38,46,'#b5835a')+E(x,y-30,24,34,'#e8cfa9')+E(x-17,y,14,7,'#8a5f3c')+E(x+17,y,14,7,'#8a5f3c');
 g+=E(x-40,y-34,9,22,'#9c6c45',22)+E(x+40,y-34,9,22,'#9c6c45',-22);
 g+=C(x-24,h-18,11,'#b5835a')+C(x+24,h-18,11,'#b5835a')+C(x-24,h-18,5,'#e8cfa9')+C(x+24,h-18,5,'#e8cfa9')+C(x,h,32,'#b5835a');
 g+=E(x,h+10,17,13,'#e8cfa9')+eyes(x,h-3,m)+E(x,h+4,5,3.6,INK)+mouth(x,h+12,m)+C(x-22,h+7,5,'#e79a8a')+C(x+22,h+7,5,'#e79a8a');
 g+=garlic(x,h-36,.9)+garlic(x+36,y-52,.6);
 var bx=x-24;g+='<rect x="'+bx+'" y="'+(y-46)+'" width="48" height="15" rx="7.5" fill="#6a8f3a"/><text x="'+x+'" y="'+(y-35)+'" font-size="9.5" font-weight="800" fill="#fff" text-anchor="middle">백일이</text>';
 return g+'</g>'}
var BG='#faf6ea',BC='#6a8f3a',NM={apa:'APA',cad:'Chicago A-D',mla:'MLA',nb:'Chicago N-B',ieee:'IEEE',van:'Vancouver',acs:'ACS'};
/* ---- 일곱 편의 자료: 국내 관행형(연습용 가상 논문)과 해외 양식형(실제 논문 서지 정보) ---- */
var EP=[
{k:'apa',t:'1화 APA 편',c:'#3a5fb0',topic:'APA: 이름은 이니셜, 제목은 따옴표 없이',
 ko:'한서윤. (2026). 「인용의 기술과 윤리」. 『글쓰기연구』, 31(2), 367–392.',
 en:'Kwon, B. (2026). Milan Kundera’s poetry in North Korea and socialist world literature in the 1950s. Journal of Korean Studies, 31(2), 367–392. https://doi.org/10.1215/07311613-12518309',
 diffs:['이름: 국내는 이름을 다 쓰지만 APA는 이니셜(Kwon, B.)','제목: 낫표 대신 따옴표도 없이, 첫 낱말만 대문자(문장식)','학술지: 『 』 대신 이탤릭(Title Case)으로, 권도 함께 이탤릭','DOI는 https://doi.org/… 주소로 쓴다'],
 kd:['2026. 11. 4. 접속','(검색일: 2026. 11. 4.)'],kdn:'국내는 연·월·일 숫자 순서. 인터넷 자료에 접속일을 적는 학회가 많다(학회마다 다름).',
 ed:'(2026, March 3). Retrieved November 4, 2026, from https://…',edn:['발행일은 (연도, 월 일) 순서로 쓴다','접속일(Retrieved)은 내용이 바뀌는 자료에만 쓴다'],
 order:[['월','March'],['일','3,'],['연','2026']],
 rule:{head:'APA에서 헷갈리는 것: 저자가 둘이면',a:'Kwon, B., & Chi, E. (2012).',b:'권혁용·지은주. (2012).',notes:['이름은 이니셜, 마지막 저자 앞에 & (한국어는 가운뎃점·)','국내 관행의 「」·『』와 위의 글·앞의 글은 쓰지 않는다']}},
{k:'cad',t:'2화 Chicago Author-Date 편',c:'#4fa08f',topic:'Chicago Author-Date: 연도가 저자 바로 뒤',
 ko:'한서윤. 2026. 「인용의 기술과 윤리」. 『글쓰기연구』 31 (2): 367–92.',
 en:'Kwon, Boduerae. 2026. “Milan Kundera’s Poetry in North Korea and Socialist World Literature in the 1950s.” Journal of Korean Studies 31 (2): 367–92. https://doi.org/10.1215/07311613-12518309.',
 diffs:['제목: 「 」 대신 큰따옴표 “ ”, 단어마다 대문자(헤드라인식)','학술지: 『 』 대신 이탤릭. 권·호는 31 (2)처럼 쓴다','쪽수는 367–92처럼 뒤 숫자를 줄이는 것이 기본','연도는 저자 바로 뒤에 쓴다'],
 kd:['2026. 11. 4. 접속','(검색일: 2026. 11. 4.)'],kdn:'국내는 연·월·일 숫자 순서. 접속일을 쓰는 학회가 많다(학회마다 다름).',
 ed:'March 3, 2026. Accessed November 4, 2026. https://…',edn:['월 이름을 줄이지 않고 월 일, 연도 순서','접속일은 Accessed + 월 일, 연도'],
 order:[['월','March'],['일','3,'],['연','2026']],
 rule:{head:'따옴표 안쪽의 마침표',a:'“Title of the Article.” Journal 31 (2).',b:'「논문 제목」. 『학술지』 31 (2).',notes:['영어(미국식)는 마침표·쉼표를 닫는 따옴표 안쪽에 쓴다','국내 낫표는 마침표를 부호 바깥에 쓴다. 이 차이를 꼭 기억!']}},
{k:'mla',t:'3화 MLA 편',c:'#7b66b8',topic:'MLA: 일 월 연도, 쉼표로 이어 쓴다',
 ko:'한서윤. 「인용의 기술과 윤리」. 『글쓰기연구』, vol. 31, no. 2, 2026, pp. 367–92.',
 en:'Kwon, Boduerae. “Milan Kundera’s Poetry in North Korea and Socialist World Literature in the 1950s.” Journal of Korean Studies, vol. 31, no. 2, 2026, pp. 367–92. https://doi.org/10.1215/07311613-12518309.',
 diffs:['제목은 따옴표 “ ”, 학술지는 이탤릭','vol. 31, no. 2, 2026, pp. 367–92처럼 쉼표로 이어 쓴다','연도는 저자 뒤가 아니라 목록 끝쪽에 놓는다','목록 이름은 Works Cited'],
 kd:['2026. 11. 4. 접속','(검색일: 2026. 11. 4.)'],kdn:'국내는 연·월·일 숫자 순서.',
 ed:'3 Mar. 2026. Accessed 4 Nov. 2026.',edn:['MLA는 일 → 월 → 연도 순서(쉼표 없음)','긴 월 이름은 줄여 Mar., Nov.처럼 마침표를 찍는다','접속일은 선택 사항'],
 order:[['일','3'],['월','Mar.'],['연','2026']],
 rule:{head:'본문 인용에는 연도가 없다',a:'(Kwon 370)',b:'(한서윤 370)',notes:['MLA 본문 인용은 저자와 쪽만 쓴다(연도 없음)','APA·Chicago의 (Kwon 2026, 370)과 다르다']}},
{k:'nb',t:'4화 Chicago Notes-Bibliography 편',c:'#c99a3a',topic:'Chicago Notes-Bibliography: 각주와 따옴표 쉼표',
 ko:'1. 한서윤, 「인용의 기술과 윤리」, 『글쓰기연구』 31, no. 2 (2026): 370.',
 en:'1. Boduerae Kwon, “Milan Kundera’s Poetry in North Korea and Socialist World Literature in the 1950s,” Journal of Korean Studies 31, no. 2 (2026): 370, https://doi.org/10.1215/07311613-12518309.',
 diffs:['각주에서는 이름 → 성 순서(Boduerae Kwon). 목록에서는 성 → 이름','제목 뒤 쉼표는 닫는 큰따옴표 안쪽: “…1950s,”','학술지는 이탤릭, 권·호는 31, no. 2 (2026): 370','인용한 쪽(370)만 쓴다. 전체 쪽 범위는 목록에 쓴다'],
 kd:['2026. 11. 4. 접속','(검색일: 2026. 11. 4.)'],kdn:'국내는 연·월·일 숫자 순서.',
 ed:'March 3, 2026, accessed November 4, 2026, https://…',edn:['월 이름을 줄이지 않고 월 일, 연도 순서','접속일은 날짜가 없는 자료에 쓰는 것이 기본'],
 order:[['월','March'],['일','3,'],['연','2026']],
 rule:{head:'같은 문헌을 또 인용할 때: 위의 글 vs 약식 각주',a:'2. Kwon, “Milan Kundera’s Poetry,” 371.',b:'2. 위의 글, 30쪽. / 한서윤, 앞의 글, 45쪽.',notes:['위의 글·앞의 글은 국내 관행. Chicago에는 없다','Chicago 18판은 Ibid.보다 약식 각주(성, 짧은 제목, 쪽)를 권한다']}},
{k:'ieee',t:'5화 IEEE 편',c:'#6f7a8e',topic:'IEEE: 번호 [1], 이름은 이니셜 먼저',
 ko:'[1] 한서윤, 「인용의 기술과 윤리」, 『글쓰기연구』, vol. 31, no. 2, pp. 367–392, 2026.',
 en:'[1] B. Kwon, “Milan Kundera’s poetry in North Korea and socialist world literature in the 1950s,” J. Korean Stud., vol. 31, no. 2, pp. 367–392, 2026, doi: 10.1215/07311613-12518309.',
 diffs:['번호 [1]을 앞에 쓰고 목록은 인용 순서','이름은 이니셜 → 성(B. Kwon). 제목 뒤 쉼표는 따옴표 안쪽','학술지는 약어 이탤릭(J. Korean Stud.)','vol., no., pp.를 쉼표로 이어 쓴다'],
 kd:['2026. 11. 4. 접속','(검색일: 2026. 11. 4.)'],kdn:'국내는 연·월·일 숫자 순서.',
 ed:'Accessed: Nov. 4, 2026. [Online]. Available: https://…',edn:['월을 줄여 Nov.처럼 쓰고 월 일, 연도 순서','Accessed: 뒤에 콜론을 둔다','URL 앞에 [Online]. Available:을 쓴다'],
 order:[['월','Nov.'],['일','4,'],['연','2026']],
 rule:{head:'본문 인용은 번호만',a:'…was shown [1].',b:'…를 보였다(한서윤, 2026).',notes:['본문에는 저자·연도 없이 [1]처럼 번호만 쓴다','같은 문헌은 같은 번호를 다시 쓴다(Ibid. 불필요)']}},
{k:'van',t:'6화 Vancouver 편',c:'#d3777f',topic:'Vancouver: 쉼표·마침표가 거의 없다',
 ko:'1. 한서윤. 「인용의 기술과 윤리」. 『글쓰기연구』. 2026;31(2):367-92.',
 en:'1. Kwon B. Milan Kundera’s poetry in North Korea and socialist world literature in the 1950s. J Korean Stud. 2026;31(2):367-92. doi:10.1215/07311613-12518309',
 diffs:['이름은 성 + 이니셜을 붙여(Kwon B) 쓰고 점이 없다','제목에 따옴표·이탤릭이 없고 첫 낱말만 대문자','학술지 약어에는 마침표가 없다(J Korean Stud)','2026;31(2):367-92처럼 연도;권(호):쪽'],
 kd:['2026. 11. 4. 접속','(검색일: 2026. 11. 4.)'],kdn:'국내는 연·월·일 숫자 순서.',
 ed:'[cited 2026 Nov 4]. Available from: https://…',edn:['연 → 월(약어) → 일 순서이고 쉼표가 없다','접속일은 [cited 2026 Nov 4]처럼 대괄호 안에','주소 앞에 Available from:을 쓴다'],
 order:[['연','2026'],['월','Nov'],['일','4']],
 rule:{head:'한국어 서지의 낫표는?',a:'Kwon B. Milan Kundera’s poetry… J Korean Stud.',b:'한서윤. 인용의 기술과 윤리. 글쓰기연구.',notes:['Vancouver 자체에는 낫표·따옴표·이탤릭이 없다','국내 학회가 낫표를 요구할 때만 「 」 『 』를 쓴다']}},
{k:'acs',t:'7화 ACS 편',c:'#a8764f',topic:'ACS: 연도는 굵게, 권은 기울여서',
 ko:'(1) 한서윤. 「인용의 기술과 윤리」. 『글쓰기연구』 2026, 31 (2), 367–392.',
 en:'(1) Kwon, B. Milan Kundera’s Poetry in North Korea and Socialist World Literature in the 1950s. J. Korean Stud. 2026, 31 (2), 367–392. DOI: 10.1215/07311613-12518309.',
 diffs:['이름은 성, 이니셜(Kwon, B.)','제목에는 따옴표·이탤릭이 없고 단어마다 대문자','학술지 약어에는 마침표(J. Korean Stud.). 연도(굵게)와 권(기울임)을 쓴다','번호는 (1)처럼 괄호 안'],
 kd:['2026. 11. 4. 접속','(검색일: 2026. 11. 4.)'],kdn:'국내는 연·월·일 숫자 순서.',
 ed:'https://… (accessed 2026-11-04).',edn:['접속일은 (accessed 연-월-일) 모양','월·일은 두 자리 숫자로 쓴다'],
 order:[['연','2026'],['월','11'],['일','04']],
 rule:{head:'본문 인용은 세 가지 중 하나로 통일',a:'…shown¹  /  …shown (1)  /  (Kwon, 2026)',b:'한 보고서 안에서 한 가지로',notes:['위 첨자 번호, 괄호 번호, (저자, 연도) 중 하나를 고른다','섞어 쓰지 않는다']}}];
/* ---- 컷 ---- */
function pIntro(e,n){var say=['국내 학회에서는','낫표를 썼는데','해외에 낼 때는','어떻게 달라질까?'];
 return svg(250,'<rect width="360" height="250" fill="'+BC+'22"/>'+band(e.t,e.c)+'<rect y="214" width="360" height="36" fill="'+BC+'" fill-opacity=".25"/>'+bear(96,236,'happy',1.3)+bubble(150,50,196,say,14)
  +lines(wrap(e.topic,13,172),180,150,13,null,e.c,172,800)+lines(['마늘 먹는 곰 백일이가 국내 관행과','해외 관행을 하나씩 비교해 봐요.'],180,170+(wrap(e.topic,13,172).length-1)*16,11.5,null,'#5a4d40',172,600));}
function entryCard(y,label,col,arr,fs,sub){var h=arr.length*(fs+6)+34;return {h:h,s:'<rect x="12" y="'+y+'" width="336" height="'+h+'" rx="10" fill="#fff" stroke="'+col+'" stroke-width="2.5"/><rect x="12" y="'+y+'" width="'+(18+label.length*11)+'" height="18" rx="9" fill="'+col+'"/><text x="21" y="'+(y+13)+'" font-size="11" font-weight="800" fill="#fff">'+esc(label)+'</text>'+lines(arr,22,y+34,fs,null,INK,316,600)}}
function pCompare(e){var fs=10.5,ko=wrap(e.ko,fs,310),en=wrap(e.en,fs,310);var c1=entryCard(40,'🇰🇷 국내 관행(◇ 가상 논문)','#c0392b',ko,fs),c2=entryCard(40+c1.h+14,'🌏 해외 · '+NM[e.k],e.c,en,fs);
 var H=40+c1.h+14+c2.h+34;return svg(H,'<rect width="360" height="'+H+'" fill="'+BG+'"/>'+band('같은 종류의 논문, 두 가지 모양','#6b5a4a')+c1.s+c2.s)}
function pDiff(e){var arr=[];e.diffs.forEach(function(t,i){wrap(t,11.5,262).forEach(function(l,j){arr.push([i,l,j===0])})});var H=60+arr.length*16+90;
 var g='<rect width="360" height="'+H+'" fill="'+BG+'"/>'+band('다른 점을 하나씩',e.c);var y=56,n=0;
 arr.forEach(function(a){if(a[2]){n++;g+=tag(26,y-4,String(n),e.c)}g+='<text x="46" y="'+y+'" font-size="11.5" font-weight="700" fill="'+INK+'">'+esc(a[1])+'</text>';y+=16});
 g+='<rect y="'+(H-80)+'" width="360" height="80" fill="'+BC+'" fill-opacity=".2"/>'+bear(52,H-6,'ok',.72)+bubble(100,H-72,246,['국내 관행(낫표·위의 글)은','해외 투고에서는 쓰지 않아요!'],12);
 return svg(H,g)}
function pDate(e){var ko=['연','월','일'],H=326,g='<rect width="360" height="'+H+'" fill="'+BG+'"/>'+band('날짜와 접속일: 순서가 다르다',e.c);
 g+='<rect x="12" y="40" width="336" height="76" rx="10" fill="#fff" stroke="#c0392b" stroke-width="2.5"/><rect x="12" y="40" width="120" height="18" rx="9" fill="#c0392b"/><text x="21" y="53" font-size="11" font-weight="800" fill="#fff">🇰🇷 국내 관행</text>';
 ko.forEach(function(t,i){g+='<rect x="'+(24+i*66)+'" y="66" width="58" height="26" rx="13" fill="#fdecea" stroke="#c0392b" stroke-width="1.5"/><text x="'+(53+i*66)+'" y="84" font-size="12" font-weight="800" fill="#a03020" text-anchor="middle">'+t+'</text>'});
 g+=lines([e.kd[0]+'  또는  '+e.kd[1]],24,108,10,null,'#7a3b2e',310,600);
 g+='<rect x="12" y="128" width="336" height="'+78+'" rx="10" fill="#fff" stroke="'+e.c+'" stroke-width="2.5"/><rect x="12" y="128" width="150" height="18" rx="9" fill="'+e.c+'"/><text x="21" y="141" font-size="11" font-weight="800" fill="#fff">🌏 해외 · '+esc(NM[e.k])+'</text>';
 e.order.forEach(function(o,i){g+='<rect x="'+(24+i*86)+'" y="154" width="78" height="28" rx="14" fill="#eef3fb" stroke="'+e.c+'" stroke-width="1.8"/><text x="'+(63+i*86)+'" y="173" font-size="12" font-weight="800" fill="#20395e" text-anchor="middle">'+esc(o[1])+'</text><text x="'+(63+i*86)+'" y="197" font-size="10" fill="#6a5a4a" text-anchor="middle">'+o[0]+'</text>'});
 g+=lines(wrap(e.ed,10,324),24,226,10,null,'#20395e',324,600);
 var ln=e.edn.reduce(function(a,t){return a.concat(wrap('· '+t,11,320))},[]);g+=lines(ln,20,262,11,null,'#4a3a30',324,700);
 return svg(H,g)}
function pRule(e){var r=e.rule,nt=r.notes.reduce(function(a,t){return a.concat(wrap(t,11.5,320))},[]);var H=60+70+16+nt.length*16+84;
 var g='<rect width="360" height="'+H+'" fill="'+BG+'"/>'+band(r.head,e.c);
 g+='<rect x="12" y="42" width="336" height="34" rx="8" fill="#fdecea" stroke="#c0392b" stroke-width="2"/>'+tag(28,59,'KR','#c0392b')+lines(wrap(r.b,10.5,280),46,56,10.5,null,'#7a3b2e',290,700);
 g+='<rect x="12" y="84" width="336" height="34" rx="8" fill="#eaf7ee" stroke="'+GRN+'" stroke-width="2"/>'+tag(28,101,'EN',GRN)+lines(wrap(r.a,10.5,280),46,98,10.5,null,'#1c6b3e',290,700);
 g+=lines(nt,18,140,11.5,null,INK,326,700);
 g+='<rect y="'+(H-70)+'" width="360" height="70" fill="'+BC+'" fill-opacity=".2"/>'+bear(50,H-4,'happy',.68)+bubble(98,H-64,248,['다른 점 확인 끝!','투고 전에 학술지 안내를 꼭 보자.'],12);
 return svg(H,g)}
function pSum(e){var rows=['제목·학술지: 낫표(「 」 『 』) → '+NM[e.k]+' 기본형','날짜·접속일: 연·월·일 숫자 → 이 양식의 순서','위의 글·앞의 글·낫표는 국내용. 해외엔 쓰지 않는다','학술지 투고 규정이 먼저다'];
 var arr=rows.reduce(function(a,t,i){wrap(t,12,284).forEach(function(l,j){a.push([i,l,j===0])});return a},[]);var H=60+arr.length*17+140;
 var g='<rect width="360" height="'+H+'" fill="'+BG+'"/>'+band('백일이의 투고 전 점검',e.c);var y=60,n=0;
 arr.forEach(function(a){if(a[2]){n++;g+='<rect x="14" y="'+(y-12)+'" width="16" height="16" rx="3" fill="#fff" stroke="'+BC+'" stroke-width="2"/><path d="M17 '+(y-4)+'l4 4l7 -9" stroke="'+BC+'" stroke-width="2.4" fill="none"/>'}g+='<text x="40" y="'+y+'" font-size="12" font-weight="700" fill="'+INK+'">'+esc(a[1])+'</text>';y+=17});
 g+='<rect y="'+(H-96)+'" width="360" height="96" fill="'+BC+'" fill-opacity=".22"/>'+bear(70,H-8,'happy',.9)+bubble(130,H-86,216,['마늘 백 개…가 아니라','100일 동안 연습하면 쉬워요!'],12);
 return svg(H,g)}
function panels(e){return [pIntro(e),pCompare(e),pDiff(e),pDate(e),pRule(e),pSum(e)]}
function render(host){var cur=0;
 function show(i,noscroll){cur=i;var e=EP[i],ps=panels(e);
  host.innerHTML='<div class="tn-head"><h2 class="gt">웹툰 시리즈 〈백일이의 영어 논문 쓰기〉</h2><p class="mut">마늘을 먹는 곰 백일이가 국내 학회의 관행과 해외 학술지의 양식을 나란히 놓고 비교합니다. 양식마다 한 편씩, 낫표와 따옴표, 날짜 순서, 접속일, 쉼표 자리를 살펴봐요. 서지는 국내 쪽이 연습용 가상 논문, 해외 쪽이 이 홈페이지 대문의 논문 정보입니다.</p></div>'
   +'<div class="tn-tabs" role="tablist">'+EP.map(function(x,k){return '<button class="tn-tab'+(k===i?' on':'')+'" data-k="'+k+'" role="tab" aria-selected="'+(k===i)+'">'+esc(x.t.replace(/ 편$/,''))+'</button>'}).join('')+'</div>'
   +'<article class="tn-ep"><h3>'+esc(e.t)+'</h3><div class="tn2 tn2-zig">'+ps.map(function(p,n){return '<figure class="tn-p tn2p">'+p+'<figcaption class="tn-cap">'+(n+1)+'</figcaption></figure>'}).join('')+'</div>'
   +'<p class="mut tn2-src"><b>이 화의 근거</b> 이 안내서의 제7~13장(“국내 문헌 표기 관행”, 디지털 자료와 접속일), 부록 6. 규정은 학회·학술지마다 다르므로 투고처 안내가 먼저입니다. 날짜 순서와 접속일 표기는 양식별 안내를 따랐습니다.</p></article>'
   +'<div class="gbtns"><button class="gbtn" id="tn5p"'+(i===0?' disabled':'')+'>← 이전 화</button><button class="gprimary" id="tn5n"'+(i===EP.length-1?' disabled':'')+'>다음 화 →</button></div>'
   +'<p class="mut tn-credit">주인공 백일이는 단군 이야기에 나오는 마늘 먹는 곰에서 착안해 이 홈페이지를 위해 새로 그린 원본 캐릭터입니다. 국내 쪽 논문·저자는 연습용 가상 자료(◇)입니다.</p>';
  host.querySelectorAll('.tn-tab').forEach(function(b){b.onclick=function(){show(+b.dataset.k)}});
  var pv=$('tn5p'),nx=$('tn5n');if(pv)pv.onclick=function(){show(cur-1)};if(nx)nx.onclick=function(){show(cur+1)};
  if(!noscroll){var tb=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||110)+8,r=host.getBoundingClientRect();window.scrollTo(0,Math.max(0,r.top+window.pageYOffset-tb))}}
 show(0,true)}
if($('webtoon5'))render($('webtoon5'));
window.TOON5={EP:EP,panels:panels,NM:NM,bear:bear};
})();
