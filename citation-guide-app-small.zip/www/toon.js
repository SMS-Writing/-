(function(){
var d=document,$=function(i){return d.getElementById(i)};
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function lsg(k){try{return localStorage.getItem(k)}catch(e){return null}}function lss(k,v){try{localStorage.setItem(k,v)}catch(e){}}
var INK='#4a3a30';
function face(x,y,m,s){s=s||1;var e='',mo='';
 function dots(dx){return '<circle cx="'+(x-dx)+'" cy="'+y+'" r="'+3.2*s+'" fill="'+INK+'"/><circle cx="'+(x+dx)+'" cy="'+y+'" r="'+3.2*s+'" fill="'+INK+'"/>'}
 if(m==='happy'){e='<path d="M'+(x-13*s)+' '+(y+2)+'q'+5*s+' '+-7*s+' '+10*s+' 0M'+(x+3*s)+' '+(y+2)+'q'+5*s+' '+-7*s+' '+10*s+' 0" stroke="'+INK+'" stroke-width="2.4" fill="none" stroke-linecap="round"/>';mo='<path d="M'+(x-5*s)+' '+(y+9*s)+'q'+5*s+' '+7*s+' '+10*s+' 0z" fill="#e57b78" stroke="'+INK+'" stroke-width="1.6"/>'}
 else if(m==='sleepy'){e='<path d="M'+(x-13*s)+' '+y+'h'+9*s+'M'+(x+4*s)+' '+y+'h'+9*s+'" stroke="'+INK+'" stroke-width="2.4" stroke-linecap="round"/>';mo='<circle cx="'+x+'" cy="'+(y+9*s)+'" r="'+2.4*s+'" fill="none" stroke="'+INK+'" stroke-width="1.6"/>'}
 else if(m==='shock'){e='<circle cx="'+(x-9*s)+'" cy="'+y+'" r="'+5*s+'" fill="#fff" stroke="'+INK+'" stroke-width="2"/><circle cx="'+(x+9*s)+'" cy="'+y+'" r="'+5*s+'" fill="#fff" stroke="'+INK+'" stroke-width="2"/><circle cx="'+(x-9*s)+'" cy="'+y+'" r="'+1.8*s+'" fill="'+INK+'"/><circle cx="'+(x+9*s)+'" cy="'+y+'" r="'+1.8*s+'" fill="'+INK+'"/>';mo='<ellipse cx="'+x+'" cy="'+(y+11*s)+'" rx="'+3.4*s+'" ry="'+4.6*s+'" fill="#7a3a3a"/>'}
 else if(m==='angry'){e=dots(9*s)+'<path d="M'+(x-15*s)+' '+(y-8*s)+'l'+11*s+' '+4*s+'M'+(x+15*s)+' '+(y-8*s)+'l'+-11*s+' '+4*s+'" stroke="'+INK+'" stroke-width="2.4" stroke-linecap="round"/>';mo='<path d="M'+(x-6*s)+' '+(y+11*s)+'q'+6*s+' '+-5*s+' '+12*s+' 0" stroke="'+INK+'" stroke-width="2" fill="none" stroke-linecap="round"/>'}
 else if(m==='sweat'){e=dots(9*s)+'<path d="M'+(x+19*s)+' '+(y-12*s)+'q'+4*s+' '+7*s+' 0 '+10*s+'q'+-4*s+' '+-3*s+' 0 '+-10*s+'z" fill="#8fd0f0" stroke="'+INK+'" stroke-width="1.2"/>';mo='<path d="M'+(x-7*s)+' '+(y+10*s)+'q'+3.5*s+' '+-4*s+' '+7*s+' 0t'+7*s+' 0" stroke="'+INK+'" stroke-width="2" fill="none" stroke-linecap="round"/>'}
 else if(m==='sad'){e=dots(9*s)+'<path d="M'+(x-14*s)+' '+(y-6*s)+'l'+9*s+' '+-2*s+'M'+(x+14*s)+' '+(y-6*s)+'l'+-9*s+' '+-2*s+'" stroke="'+INK+'" stroke-width="2" stroke-linecap="round"/>';mo='<path d="M'+(x-5*s)+' '+(y+12*s)+'q'+5*s+' '+-6*s+' '+10*s+' 0" stroke="'+INK+'" stroke-width="2" fill="none" stroke-linecap="round"/>'}
 else if(m==='think'){e=dots(9*s);mo='<path d="M'+(x-4*s)+' '+(y+10*s)+'h'+8*s+'" stroke="'+INK+'" stroke-width="2" stroke-linecap="round"/><text x="'+(x+16*s)+'" y="'+(y-12*s)+'" font-size="'+16*s+'" font-weight="800" fill="#c46a5e">?</text>'}
 else if(m==='sparkle'){e='<path d="M'+(x-9*s)+' '+(y-5*s)+'l'+2*s+' '+5*s+'l'+5*s+' '+2*s+'l'+-5*s+' '+2*s+'l'+-2*s+' '+5*s+'l'+-2*s+' '+-5*s+'l'+-5*s+' '+-2*s+'l'+5*s+' '+-2*s+'z" fill="#fff" stroke="'+INK+'" stroke-width="1.4"/><path d="M'+(x+9*s)+' '+(y-5*s)+'l'+2*s+' '+5*s+'l'+5*s+' '+2*s+'l'+-5*s+' '+2*s+'l'+-2*s+' '+5*s+'l'+-2*s+' '+-5*s+'l'+-5*s+' '+-2*s+'l'+5*s+' '+-2*s+'z" fill="#fff" stroke="'+INK+'" stroke-width="1.4"/>';mo='<path d="M'+(x-5*s)+' '+(y+10*s)+'q'+5*s+' '+6*s+' '+10*s+' 0" stroke="'+INK+'" stroke-width="2" fill="none" stroke-linecap="round"/>'}
 else{e=dots(9*s);mo='<path d="M'+(x-5*s)+' '+(y+9*s)+'q'+5*s+' '+5*s+' '+10*s+' 0" stroke="'+INK+'" stroke-width="2" fill="none" stroke-linecap="round"/>'}
 return e+mo+'<circle cx="'+(x-17*s)+'" cy="'+(y+7*s)+'" r="'+4*s+'" fill="#f4a39a" opacity=".6"/><circle cx="'+(x+17*s)+'" cy="'+(y+7*s)+'" r="'+4*s+'" fill="#f4a39a" opacity=".6"/>'}
function critter(k,x,y,m,s,flip){s=s||1;var b='';
 if(k==='dot'){b='<path d="M-34 10q-30 -6 -22 -34q6 -20 22 -10" fill="#b9793f" stroke="'+INK+'" stroke-width="2.4"/><ellipse cx="0" cy="8" rx="34" ry="30" fill="#d9a066" stroke="'+INK+'" stroke-width="2.6"/><ellipse cx="0" cy="18" rx="20" ry="16" fill="#f5deb8"/><circle cx="-24" cy="-16" r="9" fill="#d9a066" stroke="'+INK+'" stroke-width="2.4"/><circle cx="24" cy="-16" r="9" fill="#d9a066" stroke="'+INK+'" stroke-width="2.4"/><path d="M-22 -18a22 14 0 0 1 44 0z" fill="#8b5a2b" stroke="'+INK+'" stroke-width="2.4"/><rect x="-3" y="-34" width="6" height="8" rx="2" fill="#6b4220"/>'+face(0,2,m,.9)+'<ellipse cx="-12" cy="38" rx="8" ry="5" fill="#b9793f" stroke="'+INK+'" stroke-width="2"/><ellipse cx="12" cy="38" rx="8" ry="5" fill="#b9793f" stroke="'+INK+'" stroke-width="2"/>'}
 else if(k==='gur'){b='<g fill="#d9d0f6" stroke="'+INK+'" stroke-width="2.4"><circle cx="-26" cy="4" r="17"/><circle cx="26" cy="4" r="17"/><circle cx="-14" cy="-16" r="17"/><circle cx="14" cy="-16" r="17"/><circle cx="0" cy="14" r="22"/></g><ellipse cx="0" cy="2" rx="22" ry="20" fill="#f7efe4" stroke="'+INK+'" stroke-width="2.2"/>'+face(0,0,m,.85)+'<ellipse cx="-12" cy="36" rx="7" ry="5" fill="#8f82c9" stroke="'+INK+'" stroke-width="2"/><ellipse cx="12" cy="36" rx="7" ry="5" fill="#8f82c9" stroke="'+INK+'" stroke-width="2"/>'}
 else if(k==='dub'){b='<path d="M-30 -22l7 -16l8 14l8 -17l8 17l8 -14l7 16" fill="#8f7a5a" stroke="'+INK+'" stroke-width="2.2" stroke-linejoin="round"/><rect x="-34" y="-24" width="68" height="62" rx="20" fill="#f1e6c8" stroke="'+INK+'" stroke-width="2.6"/>'+face(0,-2,m,.95)+'<ellipse cx="-12" cy="40" rx="8" ry="5" fill="#d8c79b" stroke="'+INK+'" stroke-width="2"/><ellipse cx="12" cy="40" rx="8" ry="5" fill="#d8c79b" stroke="'+INK+'" stroke-width="2"/>'}
 else{b='<ellipse cx="0" cy="6" rx="30" ry="34" fill="#a98a6a" stroke="'+INK+'" stroke-width="2.6"/><ellipse cx="0" cy="18" rx="18" ry="20" fill="#e8d8bd"/><path d="M-22 -22l-6 -14l16 8zM22 -22l6 -14l-16 8z" fill="#8c6f50" stroke="'+INK+'" stroke-width="2.2" stroke-linejoin="round"/><circle cx="-11" cy="-4" r="11" fill="#fff" stroke="'+INK+'" stroke-width="2"/><circle cx="11" cy="-4" r="11" fill="#fff" stroke="'+INK+'" stroke-width="2"/><circle cx="-11" cy="-4" r="4" fill="'+INK+'"/><circle cx="11" cy="-4" r="4" fill="'+INK+'"/><path d="M0 2l-5 6h10z" fill="#e8a43a" stroke="'+INK+'" stroke-width="1.6"/>'}
 return '<g transform="translate('+x+' '+y+') scale('+(flip?-s:s)+' '+s+')">'+b+'</g>'}
var BG={lib:['#efe3c9','<rect x="0" y="130" width="360" height="110" fill="#d8c3a0"/><g fill="#a97c50"><rect x="10" y="20" width="90" height="100"/><rect x="130" y="30" width="90" height="90"/><rect x="250" y="20" width="100" height="100"/></g><g stroke="#7c5a36" stroke-width="3"><path d="M10 52H100M10 84H100M130 60H220M130 90H220M250 52H350M250 84H350"/></g>'],
 room:['#e7eaf6','<rect x="0" y="150" width="360" height="90" fill="#cdbfa8"/><rect x="230" y="40" width="100" height="70" fill="#bfe0f3" stroke="#6b7aa8" stroke-width="4"/><path d="M280 40V110M230 75H330" stroke="#6b7aa8" stroke-width="3"/><rect x="20" y="130" width="140" height="22" fill="#a07a50"/>'],
 class:['#eef0e0','<rect x="0" y="160" width="360" height="80" fill="#c9b690"/><rect x="40" y="26" width="200" height="80" fill="#3f6b57" stroke="#8a6a44" stroke-width="5"/><path d="M60 54h90M60 76h130" stroke="#e8f0e0" stroke-width="3" opacity=".7"/>'],
 cafe:['#f6e3d3','<rect x="0" y="160" width="360" height="80" fill="#c99a6e"/><rect x="20" y="30" width="80" height="60" rx="6" fill="#f3c9a0" stroke="#a9683a" stroke-width="3"/><circle cx="300" cy="64" r="26" fill="#ffe08a" opacity=".9"/><rect x="230" y="140" width="110" height="14" fill="#a9683a"/>'],
 night:['#2c3358','<circle cx="300" cy="46" r="20" fill="#f6e7a6"/><g fill="#fff" opacity=".8"><circle cx="40" cy="30" r="2"/><circle cx="110" cy="60" r="2"/><circle cx="200" cy="24" r="2"/><circle cx="160" cy="90" r="2"/></g><rect x="0" y="170" width="360" height="70" fill="#3b3560"/>'],
 out:['#dcefff','<rect x="0" y="170" width="360" height="70" fill="#9fcf8a"/><g fill="#7fb36a"><circle cx="60" cy="150" r="32"/><circle cx="300" cy="140" r="38"/></g><rect x="54" y="170" width="12" height="30" fill="#8a5a36"/><rect x="294" y="170" width="12" height="30" fill="#8a5a36"/>']};
var PROP={lap:'<rect x="-26" y="-6" width="52" height="30" rx="3" fill="#cfd5e6" stroke="'+INK+'" stroke-width="2.4"/><rect x="-22" y="-2" width="44" height="22" fill="#8fa6d8"/><path d="M-32 28h64" stroke="'+INK+'" stroke-width="3"/>',book:'<rect x="-22" y="-14" width="44" height="30" rx="2" fill="#c46a5e" stroke="'+INK+'" stroke-width="2.4"/><path d="M0 -14V16" stroke="'+INK+'" stroke-width="2"/>',paper:'<rect x="-20" y="-24" width="40" height="48" fill="#fff" stroke="'+INK+'" stroke-width="2.4"/><path d="M-12 -12h24M-12 -4h24M-12 4h16" stroke="#8a93a0" stroke-width="2"/>',phone:'<rect x="-12" y="-20" width="24" height="42" rx="5" fill="#2b3558" stroke="'+INK+'" stroke-width="2.4"/><rect x="-9" y="-15" width="18" height="30" fill="#8fd0f0"/>',red:'<rect x="-20" y="-24" width="40" height="48" fill="#fff" stroke="'+INK+'" stroke-width="2.4"/><path d="M-12 -12h24M-12 -4h24M-12 4h16" stroke="#c93a22" stroke-width="3"/><circle cx="14" cy="16" r="9" fill="none" stroke="#c93a22" stroke-width="3"/>'};
function prop(k,x,y,s){return '<g transform="translate('+x+' '+y+') scale('+(s||1)+')">'+PROP[k]+'</g>'}
// ---- 10화 ----
var EP=[
 {t:'1화 · 첫 과제',s:'리포트 과제가 나왔다!',p:[
  {bg:'room',c:[['dot',110,'sweat'],['dub',250,'ok']],pr:[['lap',110,175]],cap:'새내기 도토리의 첫 리포트',b:[['과제가 “자료 3개 이상 인용”이래…',6,6,58],['컴퓨터 앞이 제일 무서워 ㅠㅠ',52,66,44]]},
  {bg:'room',c:[['dot',100,'sparkle'],['dub',250,'think']],pr:[['lap',100,175]],b:[['어! 이 블로그 글, 완전 내 주제다!',6,6,60],['오, 복사해서 붙이면 끝이네?',50,60,46]]},
  {bg:'room',c:[['dot',100,'shock'],['dub',250,'angry']],b:[['잠깐 도토리!!',50,8,44],['그 문장은 남이 쓴 거야. 따옴표도 출처도 없으면 내가 쓴 것처럼 보여.',4,58,60]]},
  {bg:'room',c:[['dot',110,'happy'],['dub',250,'happy']],cap:'오늘의 한 줄',b:[['남의 문장은 내 말로 바꿔 쓰고, 출처를 꼭 밝힌다!',10,8,80]]}]},
 {t:'2화 · 출처가 어딨죠',s:'블로그 글의 근거를 찾아라',p:[
  {bg:'room',c:[['dot',110,'think']],pr:[['phone',110,180]],b:[['블로그에 “연구에 따르면 78%”라고 써 있는데…',6,6,66],['연구 이름이 없어!',48,64,44]]},
  {bg:'lib',c:[['dot',100,'sweat'],['owl',250,'ok']],b:[['사서 선생님, 이 숫자의 원래 출처를 못 찾겠어요.',4,6,64]]},
  {bg:'lib',c:[['dot',100,'sparkle'],['owl',250,'happy']],pr:[['paper',250,185]],b:[['글 속 단서(기관 이름·연도)로 학술DB에서 찾아보렴.',34,6,62],['원자료가 나왔다!',4,64,40]]},
  {bg:'lib',c:[['dot',110,'happy'],['owl',250,'ok']],cap:'오늘의 한 줄',b:[['2차 글(블로그)보다 원자료를 인용하자.',10,8,80]]}]},
 {t:'3화 · 위키는 어디까지',s:'백과사전을 인용해도 될까?',p:[
  {bg:'class',c:[['gur',80,'ok'],['dot',260,'think']],b:[['위키 문서 그대로 인용하면 안 돼?',50,6,46]]},
  {bg:'class',c:[['gur',80,'happy'],['dot',260,'shock']],b:[['처음 개념을 파악하기엔 좋아. 하지만 누구나 고칠 수 있는 글이니까 수업 기준을 먼저 확인해.',4,6,66]]},
  {bg:'lib',c:[['dot',100,'sparkle'],['gur',250,'ok']],pr:[['book',100,185]],b:[['아래 “참고 문헌” 칸에 원자료가 있네!',8,6,56]]},
  {bg:'lib',c:[['dot',110,'happy'],['gur',250,'happy']],cap:'오늘의 한 줄',b:[['백과사전은 길잡이, 인용은 원자료로.',10,8,80]]}]},
 {t:'4화 · 재인용의 늪',s:'이 문장, 누가 쓴 거지?',p:[
  {bg:'lib',c:[['dot',110,'think']],pr:[['book',110,180]],b:[['이 책 속 문장은 “다른 학자의 말”을 가져온 거래.',6,6,66]]},
  {bg:'lib',c:[['dot',100,'sweat'],['owl',250,'ok']],b:[['원 논문은 도서관에 없어요 ㅠㅠ',4,6,50],['그럴 땐 읽은 책을 밝히고 “재인용”임을 표시하렴.',44,58,52]]},
  {bg:'lib',c:[['dot',100,'sparkle'],['owl',250,'happy']],pr:[['paper',100,185]],b:[['양식마다 “~에서 재인용” 쓰는 법이 다르니 내 양식으로 확인!',6,6,70]]},
  {bg:'lib',c:[['dot',110,'happy'],['owl',250,'happy']],cap:'오늘의 한 줄',b:[['내가 읽은 책을 정직하게. 재인용은 부끄러운 게 아니다.',10,8,80]]}]},
 {t:'5화 · AI가 알려 준 논문',s:'그런 논문은 없다고요?',p:[
  {bg:'night',c:[['dot',110,'sleepy']],pr:[['lap',110,185]],cap:'새벽 2시',b:[['AI야, 이 주제 논문 알려줘…',6,6,60]]},
  {bg:'night',c:[['dot',110,'sparkle']],pr:[['lap',110,185]],b:[['우와, 제목·저자·연도까지 딱! 바로 쓰자!',6,6,64]]},
  {bg:'lib',c:[['dot',100,'shock'],['owl',250,'think']],b:[['학술DB에 검색해도 안 나와요…',4,6,52],['AI는 없는 논문을 그럴듯하게 만들기도 해. 꼭 직접 열어 확인하렴.',40,58,56]]},
  {bg:'lib',c:[['dot',110,'happy'],['owl',250,'happy']],cap:'오늘의 한 줄',b:[['AI가 준 출처는 내 눈으로 확인한 것만 쓴다.',10,8,80]]}]},
 {t:'6화 · 교수님마다 달라요',s:'양식이 왜 이렇게 많아?',p:[
  {bg:'class',c:[['dot',100,'sweat'],['dub',250,'sweat']],b:[['A 수업은 APA, B 수업은 MLA래…',4,6,56],['헷갈려 죽겠어!',52,60,42]]},
  {bg:'room',c:[['dot',110,'think'],['gur',250,'ok']],pr:[['paper',110,185]],b:[['수업 안내문이나 교수님 지침이 제일 먼저야.',34,6,62]]},
  {bg:'room',c:[['dot',100,'sparkle'],['gur',250,'happy']],b:[['과목별로 표를 만들어 붙여 둬!',6,6,56],['나는 폰 메모에 정리했어.',50,60,44]]},
  {bg:'room',c:[['dot',110,'happy'],['gur',250,'happy']],cap:'오늘의 한 줄',b:[['어느 양식인지 정하는 건 내가 아니라 수업이다.',10,8,80]]}]},
 {t:'7화 · 쪽번호 실종',s:'전자책엔 쪽수가 없어',p:[
  {bg:'cafe',c:[['dot',100,'think']],pr:[['phone',100,185]],b:[['전자책 문장을 인용하려는데 쪽수가 안 보여…',6,6,70]]},
  {bg:'cafe',c:[['dot',100,'sweat'],['dub',250,'ok']],b:[['종이책이랑 쪽이 달라서 적으면 틀릴 수도 있어.',34,6,62]]},
  {bg:'cafe',c:[['dot',100,'sparkle'],['dub',250,'happy']],pr:[['book',100,185]],b:[['장·절 이름이나 단락 번호로 위치를 밝히면 된대!',6,6,66]]},
  {bg:'cafe',c:[['dot',110,'happy'],['dub',250,'happy']],cap:'오늘의 한 줄',b:[['쪽수가 없으면 장·절로, 양식 안내를 확인.',10,8,80]]}]},
 {t:'8화 · 유사도 검사',s:'노란 형광펜이 잔뜩?',p:[
  {bg:'room',c:[['dot',100,'shock']],pr:[['red',100,185]],b:[['유사도 검사 결과에 표시가 잔뜩 있어요!',6,6,70]]},
  {bg:'lib',c:[['dot',100,'sweat'],['owl',250,'ok']],b:[['인용 표시를 한 부분과 그냥 비슷한 부분을 나눠서 보렴.',34,6,62]]},
  {bg:'lib',c:[['dot',100,'sparkle'],['owl',250,'happy']],pr:[['red',100,185]],b:[['따옴표·출처가 있는 곳은 괜찮고, 없는 곳만 고치면 되네요!',6,6,70]]},
  {bg:'lib',c:[['dot',110,'happy'],['owl',250,'happy']],cap:'오늘의 한 줄',b:[['검사 결과는 점검표. 기준은 우리 학교·수업의 규정.',10,8,80]]}]},
 {t:'9화 · 팀플의 구멍',s:'조원이 쓴 부분의 출처는?',p:[
  {bg:'class',c:[['dot',90,'think'],['gur',180,'ok'],['dub',280,'sleepy']],b:[['합친 보고서에 조원 부분만 출처가 없어요…',6,6,70]]},
  {bg:'class',c:[['dot',90,'sweat'],['dub',280,'sweat']],b:[['…ㅇ…ㅇ 미안, 급해서 복사했어',40,58,56]]},
  {bg:'room',c:[['dot',90,'happy'],['gur',180,'happy'],['dub',280,'ok']],b:[['제출 전에 각자 쓴 부분의 출처를 서로 읽어 주자!',6,6,70]]},
  {bg:'room',c:[['dot',90,'happy'],['gur',180,'happy'],['dub',280,'happy']],cap:'오늘의 한 줄',b:[['공동 과제는 공동 책임. 합치기 전에 출처 확인.',10,8,80]]}]},
 {t:'10화 · 마지막 점검',s:'제출 전 마지막 확인',p:[
  {bg:'night',c:[['dot',110,'sleepy']],pr:[['lap',110,185]],cap:'마감 1시간 전',b:[['다 썼다…!',6,6,40]]},
  {bg:'night',c:[['dot',100,'think'],['gur',250,'ok']],b:[['본문에 나온 출처가 목록에 다 있어? 목록에만 있고 본문에 없는 건?',34,6,62]]},
  {bg:'night',c:[['dot',100,'sparkle'],['gur',250,'happy']],pr:[['paper',100,185]],b:[['순서·구두점·쪽수까지 한 번 더!',6,6,60]]},
  {bg:'out',c:[['dot',100,'happy'],['gur',180,'happy'],['dub',260,'happy'],['owl',330,'happy']],cap:'한 학기, 끝!',b:[['출처를 밝히면 내 글이 더 단단해져요!',10,8,80]]}]}];
var NAMES={dot:'도토리',gur:'구름',dub:'두부',owl:'올빼미 사서'};
function panelSvg(p){var bg=BG[p.bg]||BG.room,s='<svg viewBox="0 0 360 240" class="tnp" role="img" aria-label="웹툰 컷">'+'<rect width="360" height="240" fill="'+bg[0]+'"/>'+bg[1];
 (p.c||[]).forEach(function(c){s+=critter(c[0],c[1],168,c[2],c[0]==='owl'?.95:1,c[1]>200&&(p.c.length===2))});(p.pr||[]).forEach(function(q){s+=prop(q[0],q[1],q[2],1)});return s+'</svg>'}
function toTop(host){var tb=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--tb'))||110)+8,r=host.getBoundingClientRect();scrollTo({top:Math.max(0,scrollY+r.top-tb),behavior:'auto'})}
function render(host){var cur=0,read=[];try{read=JSON.parse(lsg('toon.read')||'[]')}catch(e){}
 var first=true;function show(i){cur=Math.max(0,Math.min(EP.length-1,i));lss('toon.ep',String(cur));if(read.indexOf(cur)<0){read.push(cur);lss('toon.read',JSON.stringify(read))}
  var e=EP[cur];
  host.innerHTML='<div class="tn-head"><h2 class="gt">연재 웹툰 〈도토리의 인용 일기〉</h2><p class="mut">대학생이 인용 때문에 겪는 어려움을 귀여운 동물 친구들의 한 학기로 그렸습니다. 매 화 네 컷입니다.</p></div>'
  +'<div class="tn-tabs" role="tablist">'+EP.map(function(x,k){return '<button class="tn-tab'+(k===cur?' on':'')+(read.indexOf(k)>=0?' read':'')+'" data-k="'+k+'" role="tab" aria-selected="'+(k===cur)+'">'+(k+1)+'화</button>'}).join('')+'</div>'
  +'<article class="tn-ep"><h3>'+esc(e.t)+'</h3><p class="mut">'+esc(e.s)+'</p><div class="tn-panels">'+e.p.map(function(p,k){return '<figure class="tn-p">'+panelSvg(p)+(p.cap?'<figcaption class="tn-cap">'+esc(p.cap)+'</figcaption>':'')+(p.b||[]).map(function(b){return '<div class="tn-b" style="left:'+b[1]+'%;top:'+b[2]+'%;width:'+b[3]+'%">'+esc(b[0])+'</div>'}).join('')+'<span class="tn-n">'+(k+1)+'</span></figure>'}).join('')+'</div>'
  +'<div class="gbtns"><button class="gbtn" id="tnp"'+(cur===0?' disabled':'')+'>← 이전 화</button><button class="gprimary" id="tnn"'+(cur===EP.length-1?' disabled':'')+'>다음 화 →</button></div></article>'
  +'<p class="mut tn-credit">출연: 도토리(다람쥐 학생), 구름(양 선배), 두부(고슴도치 친구), 올빼미 사서 선생님.</p>';
  host.querySelectorAll('.tn-tab').forEach(function(b){b.onclick=function(){show(+b.dataset.k)}});
  var pv=$('tnp'),nx=$('tnn');if(pv)pv.onclick=function(){show(cur-1)};if(nx)nx.onclick=function(){show(cur+1)};if(!first)toTop(host);first=false}
 show(cur)}
var H=$('webtoon');if(H)render(H);
})();
