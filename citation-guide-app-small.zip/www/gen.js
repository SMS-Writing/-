(function(){
var $=function(i){return document.getElementById(i)};
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
var MON=['Jan.','Feb.','Mar.','Apr.','May','June','July','Aug.','Sept.','Oct.','Nov.','Dec.'];
var MONF=['January','February','March','April','May','June','July','August','September','October','November','December'];
function ko(s){return /[가-힣]/.test(s)}
function parseAuthors(t){
  return t.split(/\n/).map(function(l){return l.trim()}).filter(Boolean).map(function(l){
    if(l.charAt(0)==='@'){var on=l.slice(1).trim();return {ko:true,last:on,first:'',full:on,org:true}}
    if(ko(l)&&l.indexOf(',')<0){return {ko:true,last:l,first:'',full:l}}
    var p=l.split(',');
    if(p.length>=2){var last=p[0].trim(),first=p.slice(1).join(',').trim();return {ko:ko(l),last:last,first:first,full:first+' '+last}}
    var w=l.split(/\s+/);var last=w.pop();return {ko:false,last:last,first:w.join(' '),full:l}
  });
}
function ini(first,dot,sp){ // initials
  if(!first)return '';
  return first.split(/[\s]+/).map(function(w){return w.split('-').map(function(x){return x.charAt(0).toUpperCase()+(dot?'.':'')}).join(dot?'-':'')}).join(sp===false?'':(dot?' ':''));
}
function listJoin(a,conj,oxford){
  if(a.length<=1)return a.join('');
  if(a.length==2)return a[0]+(oxford==='apa'?', ':' ')+conj+' '+a[1];
  return a.slice(0,-1).join(', ')+(oxford===false?' ':', ')+conj+' '+a[a.length-1];
}
function v(id){var e=$(id);return e?e.value.trim():''}
function doiUrl(d){ if(!d)return ''; return /^https?:/.test(d)?d:'https://doi.org/'+d.replace(/^doi:\s*/i,'') }
function pagesDash(p){return p.replace(/-/g,'–')}
function shortR(p){var m=p.match(/^(\d+)–(\d+)$/);if(!m||m[1].length!==m[2].length)return p;var a=m[1],b=m[2],i=0;while(i<a.length-2&&a[i]===b[i])i++;return a+'–'+b.slice(i)}
function dateParts(s){ if(!s)return null; var m=s.match(/(\d{4})-(\d{2})-(\d{2})/); return m?{y:+m[1],m:+m[2]-1,d:+m[3]}:null }
function build(f){
  var A=parseAuthors(f.authors), n=A.length, y=f.year||'n.d.', T=f.title, J=f.journal, Ja=f.abbr||f.journal;
  var vol=f.vol,iss=f.issue,pg=pagesDash(f.pages),doi=doiUrl(f.doi),url=f.url,pub=f.pub,pl=f.place,site=f.site||f.journal;
  var ac=dateParts(f.access);var o={};
  var type=f.type;
  // helpers by name format
  function lastOnly(a){return a.last}
  function apaName(a){return a.ko?a.last:a.last+', '+ini(a.first,true)}
  function apaAuth(){ if(!n)return ''; var s=A.map(apaName); if(n>20)s=s.slice(0,19).concat(['… '+s[n-1]]); 
    if(n==1)return s[0]; if(n==2)return s[0]+(A[0].ko?', & ':', & ')+s[1]; return s.slice(0,-1).join(', ')+', & '+s[s.length-1]}
  // APA
  var a=apaAuth(), lead=a?a+' ('+y+'). ':'';
  var degK=f.degree==='phd';
  if(type==='journal') o.apa=lead+T+'. <i>'+J+'</i>'+(vol?', <i>'+vol+'</i>':'')+(iss?'('+iss+')':'')+(pg?', '+pg:'')+'.'+(doi?' '+doi:(url?' '+url:''));
  if(type==='book') o.apa=lead+'<i>'+T+'</i>.'+(pub?' '+pub+'.':'')+(doi?' '+doi:(url?' '+url:''));
  if(type==='web') o.apa=lead+'<i>'+T+'</i>.'+(site?' '+site+'.':'')+(url?' '+url:'');
  if(type==='thesis') o.apa=lead+'<i>'+T+'</i> ['+(ko(T)?(degK?'박사학위논문':'석사학위논문'):(degK?'Doctoral dissertation':'Master’s thesis'))+(pub?', '+pub:'')+']. '+(url||'');
  o.apaT= n==0?'('+shortT(T)+', '+y+')': n==1?'('+A[0].last+', '+y+(f.cite?', '+(ko(f.cite)?'':'p. ')+f.cite:'')+')': n==2?'('+A[0].last+' & '+A[1].last+', '+y+(f.cite?', p. '+f.cite:'')+')':'('+A[0].last+(A[0].ko?' 외':' et al.')+', '+y+(f.cite?', p. '+f.cite:'')+')';
  // Chicago author-date and NB name format
  function chiAuth(){ if(!n)return ''; var s=A.map(function(a,i){return a.ko?a.last:(i==0?a.last+', '+a.first:a.full)});
    if(n>10)s=s.slice(0,7).concat(['et al']); return n<=1?s[0]: s.slice(0,-1).join(', ')+(n==2&&A[0].ko?' and ':', and ')+s[s.length-1]}
  var ca=chiAuth(), cvol=vol?' '+vol+(iss?' ('+iss+')':''):'';
  if(type==='journal') o.cad=ca+'. '+y+'. “'+T+'.” <i>'+J+'</i>'+cvol+(pg?': '+pg:'')+'.'+(doi?' '+doi+'.':'');
  if(type==='book') o.cad=ca+'. '+y+'. <i>'+T+'</i>. '+(pl?pl+': ':'')+(pub||'')+'.';
  if(type==='web') o.cad=ca+'. '+y+'. “'+T+'.” '+(site?site+'. ':'')+(ac?'Accessed '+MONF[ac.m]+' '+ac.d+', '+ac.y+'. ':'')+(url?url+'.':'');
  if(type==='thesis') o.cad=ca+'. '+y+'. “'+T+'.” '+(degK?'PhD diss., ':'Master’s thesis, ')+(pub||'')+'.'+(url?' '+url+'.':'');
  o.cadT= n==0?'(“'+shortT(T)+'” '+y+')': n==1?'('+A[0].last+' '+y+(f.cite?', '+f.cite:'')+')': n==2?'('+A[0].last+' and '+A[1].last+' '+y+(f.cite?', '+f.cite:'')+')': n==3?'('+A[0].last+', '+A[1].last+', and '+A[2].last+' '+y+(f.cite?', '+f.cite:'')+')':'('+A[0].last+(A[0].ko?' 외':' et al.')+' '+y+(f.cite?', '+f.cite:'')+')';
  // MLA
  function mlaAuth(){ if(!n)return ''; if(n>=3)return A[0].ko?A[0].last+' 외':A[0].last+', '+A[0].first+', et al'; var s=A.map(function(a,i){return a.ko?a.last:(i==0?a.last+', '+a.first:a.full)}); return n==1?s[0]:s[0]+', and '+s[1]}
  var ma=mlaAuth(); var mlead=ma?ma+'. ':'';
  var mdate=ac?ac.d+' '+MON[ac.m]+' '+ac.y:'';
  if(type==='journal') o.mla=mlead+'“'+T+'.” <i>'+J+'</i>'+(vol?', vol. '+vol:'')+(iss?', no. '+iss:'')+', '+y+(pg?', pp. '+shortR(pg):'')+'.'+(doi?' '+doi+'.':'');
  if(type==='book') o.mla=mlead+'<i>'+T+'</i>. '+(pub?pub+', ':'')+y+'.';
  if(type==='web') o.mla=mlead+'“'+T+'.” '+(site?'<i>'+site+'</i>, ':'')+y+(url?', '+url.replace(/^https?:\/\//,''):'')+'.'+(mdate?' Accessed '+mdate+'.':'');
  if(type==='thesis') o.mla=mlead+'<i>'+T+'</i>. '+y+'. '+(pub||'')+(degK?', PhD dissertation.':', MA thesis.');
  o.mlaT= n==0?'(“'+shortT(T)+'”'+(f.cite?' '+f.cite:'')+')': n==1?'('+A[0].last+(f.cite?' '+f.cite:'')+')': n==2?'('+A[0].last+' and '+A[1].last+(f.cite?' '+f.cite:'')+')':'('+A[0].last+(A[0].ko?' 외':' et al.')+(f.cite?' '+f.cite:'')+')';
  // Notes-bibliography
  function noteAuth(){ if(!n)return ''; var s=A.map(function(a){return a.full}); if(n>3)return s[0]+(A[0].ko?' 외':' et al.'); return n==1?s[0]: s.slice(0,-1).join(', ')+(n==2?' and ':', and ')+s[s.length-1]}
  var nb='',nn=noteAuth(),ncite=f.cite||(pg?pg.split('–')[0]:'');
  var cvol2=vol?' '+vol+(iss?', no. '+iss:''):'';
  if(type==='journal'){o.nb=ca+'. “'+T+'.” <i>'+J+'</i>'+cvol2+' ('+y+')'+(pg?': '+shortR(pg):'')+'.'+(doi?' '+doi+'.':''); o.nbT='1. '+nn+', “'+T+',” <i>'+J+'</i>'+cvol2+' ('+y+')'+(ncite?': '+ncite:'')+'.'}
  if(type==='book'){o.nb=ca+'. <i>'+T+'</i>. '+(pl?pl+': ':'')+(pub||'')+', '+y+'.'; o.nbT='1. '+nn+', <i>'+T+'</i> ('+(pl?pl+': ':'')+(pub||'')+', '+y+')'+(ncite?', '+ncite:'')+'.'}
  if(type==='web'){o.nb=ca+'. “'+T+'.” '+(site?site+'. ':'')+(url?url+'.':''); o.nbT='1. '+nn+', “'+T+',” '+(site?site+', ':'')+(url||'')+'.'}
  if(type==='thesis'){o.nb=ca+'. “'+T+'.” '+(degK?'PhD diss., ':'Master’s thesis, ')+(pub||'')+', '+y+'.'; o.nbT='1. '+nn+', “'+T+'” ('+(degK?'PhD diss., ':'master’s thesis, ')+(pub||'')+', '+y+')'+(ncite?', '+ncite:'')+'.'}
  // IEEE
  function ieeeAuth(){ if(!n)return ''; var s=A.map(function(a){return a.ko?a.last:ini(a.first,true)+' '+a.last}); if(n>6)return s[0]+' et al.'; return n==1?s[0]: n==2?s[0]+' and '+s[1]: s.slice(0,-1).join(', ')+', and '+s[s.length-1]}
  var ia=ieeeAuth(); var ipg=pg?(pg.indexOf('–')>=0?'pp. ':'p. ')+pg:'';
  var iacc=ac?' (accessed '+MON[ac.m]+' '+ac.d+', '+ac.y+').':'';
  if(type==='journal') o.ieee='[1] '+(ia?ia+', ':'')+'“'+T+',” <i>'+Ja+'</i>'+(vol?', vol. '+vol:'')+(iss?', no. '+iss:'')+(ipg?', '+ipg:'')+', '+y+(doi?', doi: '+doi.replace(/^https?:\/\/(dx\.)?doi\.org\//,'')+'.':'.');
  if(type==='book') o.ieee='[1] '+(ia?ia+', ':'')+'<i>'+T+'</i>. '+(pl?pl+': ':'')+(pub||'')+', '+y+'.';
  if(type==='web') o.ieee='[1] '+(ia?ia+', ':'')+'“'+T+'.” '+(site?site+'. ':'')+(url?'[Online]. Available: '+url:'')+(iacc||'');
  if(type==='thesis') o.ieee='[1] '+(ia?ia+', ':'')+'“'+T+',” '+(degK?'Ph.D. dissertation, ':'M.S. thesis, ')+(pub||'')+(pl?', '+pl:'')+', '+y+'.';
  o.ieeeT='[1]';
  // Vancouver
  function vanAuth(){ if(!n)return ''; var s=A.map(function(a){return a.ko?a.last:a.last+' '+ini(a.first,false)}); if(n>6)s=s.slice(0,6).concat(['et al']); return s.join(', ')}
  var va=vanAuth(); var vpg=pg;
  if(type==='journal') o.van='1. '+(va?va+'. ':'')+T+'. '+Ja.replace(/\./g,'')+'. '+y+(vol?';'+vol:'')+(iss?'('+iss+')':'')+(vpg?':'+shortR(vpg).replace('–','-'):'')+'.'+(doi?' doi:'+doi.replace(/^https?:\/\/(dx\.)?doi\.org\//,''):'');
  if(type==='book') o.van='1. '+(va?va+'. ':'')+T+'. '+(pl?pl+': ':'')+(pub||'')+'; '+y+'.';
  if(type==='web') o.van='1. '+(va?va+'. ':'')+T+' [Internet]. '+(site?site+'; ':'')+y+(ac?' [cited '+ac.y+' '+MON[ac.m].replace('.','')+' '+ac.d+']':'')+'.'+(url?' Available from: '+url:'');
  if(type==='thesis') o.van='1. '+(va?va+'. ':'')+T+' ['+(degK?'dissertation':'master’s thesis')+']. '+(pl?pl+': ':'')+(pub||'')+'; '+y+'.';
  o.vanT='(1)';
  // ACS
  function acsAuth(){ if(!n)return ''; return A.map(function(a){return a.ko?a.last:a.last+', '+ini(a.first,true)}).join('; ')}
  var xa=acsAuth(); var xpg=pg;
  if(type==='journal') o.acs=(xa?xa+' ':'')+T+'. <i>'+Ja+'</i> <b>'+y+'</b>'+(vol?', <i>'+vol+'</i>':'')+(iss?' ('+iss+')':'')+(xpg?', '+xpg:'')+'.'+(doi?' '+doi+'.':'');
  if(type==='book') o.acs=(xa?xa+' ':'')+'<i>'+T+'</i>; '+(pub?pub+': ':'')+(pl?pl+', ':'')+y+'.';
  if(type==='web') o.acs=(xa?xa+' ':'')+T+'. '+(site?site+'. ':'')+(url?url+' ':'')+(ac?'(accessed '+ac.y+'-'+('0'+(ac.m+1)).slice(-2)+'-'+('0'+ac.d).slice(-2)+').':'');
  if(type==='thesis') o.acs=(xa?xa+' ':'')+T+'. '+(degK?'Ph.D. Dissertation, ':'M.S. Thesis, ')+(pub||'')+(pl?', '+pl:'')+', '+y+'.';

  // ===== 추가 자료 유형 =====
  var X=f.extra||'', ED=parseAuthors(f.editors||''), TR=parseAuthors(f.trans||''), gd=dateParts(f.date), nT=T;
  var MORE=['chapter','transbook','conf','news','report','film','app','ai','art'];
  if(MORE.indexOf(type)>=0){
    function edNames(fmt){return ED.map(function(a){return a.ko?a.last:(fmt==='ini'?ini(a.first,true)+' '+a.last:a.full)})}
    function joinE(l,conj){return l.length<2?l.join(''):l.length==2?l[0]+' '+conj+' '+l[1]:l.slice(0,-1).join(', ')+', '+conj+' '+l[l.length-1]}
    var edI=joinE(edNames('ini'),'&'), edF=joinE(edNames('full'),'and'), trF=joinE(TR.map(function(a){return a.full}),'and'), trI=joinE(TR.map(function(a){return a.ko?a.last:ini(a.first,true)+' '+a.last}),'&');
    var dA=gd?(y+', '+MONF[gd.m]+' '+gd.d):y, dC=gd?MONF[gd.m]+' '+gd.d+', '+y:y, dM=gd?gd.d+' '+MON[gd.m]+' '+gd.y:y, dV=gd?(y+' '+MON[gd.m].replace('.','')+' '+gd.d):y;
    var U=url||doi, ORG=pub||'', PL=pl||'', CT=J||'';
    var pgA=pg?(pg.indexOf('–')>=0?'pp. ':'p. ')+pg:'';
    var role=(type==='film'&&A.length)?' (Director)':'';
    var apaL=type==='film'?(a?a+' (Director). ('+y+'). ':''):lead;
    var P=function(x){return x?x+' ':''};
    // APA
    if(type==='chapter')o.apa=lead+T+'. In '+(edI?edI+' (Ed'+(ED.length>1?'s':'')+'.), ':'')+'<i>'+CT+'</i>'+(pgA?' ('+pgA+')':'')+'. '+ORG+'.'+(doi?' '+doi:'');
    if(type==='transbook')o.apa=lead+'<i>'+T+'</i> ('+trI+', Trans.). '+ORG+'.'+(f.orig?' (Original work published '+f.orig+')':'');
    if(type==='conf')o.apa=a+' ('+dA+'). '+T+' [Paper presentation]. '+CT+(PL?', '+PL:'')+'.'+(U?' '+U:'');
    if(type==='news')o.apa=lead.replace('('+y+')','('+dA+')')+T+'. <i>'+CT+'</i>.'+(U?' '+U:'');
    if(type==='report')o.apa=lead+'<i>'+T+'</i>'+(X?' ('+X+')':'')+'. '+(ORG&&ORG!==a?ORG+'.':'')+(U?' '+U:'');
    if(type==='film')o.apa=apaL+'<i>'+T+'</i> [Film]. '+ORG+'.'+(U?' '+U:'');
    if(type==='app')o.apa=lead+'<i>'+T+'</i>'+(f.version?' (Version '+f.version+')':'')+' [Mobile app]. '+(CT?CT+'.':'')+(U?' '+U:'');
    if(type==='ai')o.apa=lead+'<i>'+T+'</i>'+(f.version?' ('+f.version+')':'')+' [Large language model]. '+(U||'');
    if(type==='art')o.apa=lead+'<i>'+T+'</i> ['+(X||'작품 종류')+']. '+(ORG?ORG+(PL?', '+PL:'')+'.':'')+(U?' '+U:'');
    // Chicago author-date
    var cap=ca?ca+'. ':'';
    if(type==='chapter')o.cad=cap+y+'. “'+T+'.” In <i>'+CT+'</i>, '+(edF?'edited by '+edF+', ':'')+(pg?pg+'. ':'')+(PL?PL+': ':'')+ORG+'.';
    if(type==='transbook')o.cad=cap+y+'. <i>'+T+'</i>. Translated by '+trF+'. '+(PL?PL+': ':'')+ORG+'.';
    if(type==='conf')o.cad=cap+y+'. “'+T+'.” Paper presented at '+CT+(PL?', '+PL:'')+(gd?', '+MONF[gd.m]+' '+gd.d:'')+'.';
    if(type==='news')o.cad=cap+dC+'. “'+T+'.” <i>'+CT+'</i>, '+dC+'.'+(U?' '+U+'.':'');
    if(type==='report')o.cad=cap+y+'. <i>'+T+'</i>. '+(PL?PL+': ':'')+ORG+'.'+(U?' '+U+'.':'');
    if(type==='film')o.cad='<i>'+T+'</i>. '+y+'. Directed by '+(a?A.map(function(q){return q.full}).join(' and '):'')+'. '+(PL?PL+': ':'')+ORG+'.';
    if(type==='app')o.cad=cap+y+'. <i>'+T+'</i>. '+(f.version?'Version '+f.version+'. ':'')+(CT?CT+'. ':'')+(U?U+'.':'');
    if(type==='ai')o.cad='(참고문헌 목록에 넣지 않고 각주에만 쓰는 것이 원칙입니다) '+'Text generated by '+T+', '+(ORG||'')+', '+dC+(U?', '+U:'')+'.';
    if(type==='art')o.cad=cap+y+'. <i>'+T+'</i>. '+(X?X+'. ':'')+(ORG?ORG+(PL?', '+PL:'')+'.':'');
    // MLA
    var mp=ma?ma+'. ':'';
    if(type==='chapter')o.mla=mp+'“'+T+'.” <i>'+CT+'</i>, '+(edF?'edited by '+edF+', ':'')+ORG+', '+y+(pg?', '+(pg.indexOf('–')>=0?'pp. ':'p. ')+shortR(pg):'')+'.';
    if(type==='transbook')o.mla=mp+'<i>'+T+'</i>. Translated by '+trF+', '+ORG+', '+y+'.';
    if(type==='conf')o.mla=mp+'“'+T+'.” <i>'+CT+'</i>, '+dM+(PL?', '+PL:'')+'. Presentation.';
    if(type==='news')o.mla=mp+'“'+T+'.” <i>'+CT+'</i>, '+dM+(U?', '+U.replace(/^https?:\/\//,''):'')+'.';
    if(type==='report')o.mla=mp+'<i>'+T+'</i>. '+(ORG&&ORG!==ma?ORG+', ':'')+y+(U?', '+U.replace(/^https?:\/\//,''):'')+'.';
    if(type==='film')o.mla='<i>'+T+'</i>. Directed by '+(a?A.map(function(q){return q.full}).join(' and '):'')+', '+ORG+', '+y+'.';
    if(type==='app')o.mla=mp+'<i>'+T+'</i>. '+(f.version?'Version '+f.version+', ':'')+(CT?CT+', ':'')+y+(U?', '+U.replace(/^https?:\/\//,''):'')+'.';
    if(type==='ai')o.mla='“'+(X||'프롬프트 내용')+'” prompt. <i>'+T+'</i>, '+(f.version?f.version+', ':'')+(ORG?ORG+', ':'')+dM+(U?', '+U.replace(/^https?:\/\//,''):'')+'.';
    if(type==='art')o.mla=mp+'<i>'+T+'</i>. '+y+', '+(ORG||'소장처')+(PL?', '+PL:'')+'.';
    // NB (서지)
    if(type==='chapter')o.nb=cap+'“'+T+'.” In <i>'+CT+'</i>, edited by '+edF+', '+(pg?pg+'. ':'')+(PL?PL+': ':'')+ORG+', '+y+'.';
    if(type==='transbook')o.nb=cap+'<i>'+T+'</i>. Translated by '+trF+'. '+(PL?PL+': ':'')+ORG+', '+y+'.';
    if(type==='conf')o.nb=cap+'“'+T+'.” Paper presented at '+CT+(PL?', '+PL:'')+', '+dC+'.';
    if(type==='news')o.nb=cap+'“'+T+'.” <i>'+CT+'</i>, '+dC+'.'+(U?' '+U+'.':'');
    if(type==='report')o.nb=cap+'<i>'+T+'</i>. '+(PL?PL+': ':'')+ORG+', '+y+'.'+(U?' '+U+'.':'');
    if(type==='film')o.nb='<i>'+T+'</i>. Directed by '+(a?A.map(function(q){return q.full}).join(' and '):'')+'. '+(PL?PL+': ':'')+ORG+', '+y+'.';
    if(type==='app')o.nb=cap+'<i>'+T+'</i>. '+(f.version?'Version '+f.version+'. ':'')+(CT?CT+', ':'')+y+'.'+(U?' '+U+'.':'');
    if(type==='ai')o.nb='(각주에서만 씁니다. 목록은 만들지 않는 것이 원칙입니다)';
    if(type==='art')o.nb=cap+'<i>'+T+'</i>. '+y+'. '+(X?X+'. ':'')+(ORG?ORG+(PL?', '+PL:'')+'.':'');
    if(type==='ai')o.nbT='1. Text generated by '+T+', '+(ORG||'개발사')+', '+dC+(U?', '+U:'')+'.';
    else o.nbT='1. '+(nn?nn+', ':'')+(type==='film'||type==='app'||type==='art'?'<i>'+T+'</i>':'“'+T+',”')+' … ('+(ORG||'출판 정보')+', '+y+'), ○○.';
    // IEEE
    if(type==='chapter')o.ieee='[1] '+(ia?ia+', ':'')+'“'+T+',” in <i>'+CT+'</i>'+(edI?', '+ED.map(function(q){return q.ko?q.last:ini(q.first,true)+' '+q.last}).join(', ')+', Ed'+(ED.length>1?'s':'')+'.':'.')+' '+(PL?PL+': ':'')+ORG+', '+y+(ipg?', '+ipg:'')+'.';
    if(type==='transbook')o.ieee='[1] '+(ia?ia+', ':'')+'<i>'+T+'</i>, '+trI+', Trans. '+(PL?PL+': ':'')+ORG+', '+y+'.';
    if(type==='conf')o.ieee='[1] '+(ia?ia+', ':'')+'“'+T+',” presented at '+CT+(PL?', '+PL:'')+', '+(gd?MONF[gd.m].slice(0,3)+'. '+gd.d+', ':'')+y+'.';
    if(type==='news')o.ieee='[1] '+(ia?ia+', ':'')+'“'+T+',” <i>'+CT+'</i>, '+dC+'.'+(U?' [Online]. Available: '+U:'');
    if(type==='report')o.ieee='[1] '+(ia?ia+', ':'')+'“'+T+',” '+(ORG&&ORG!==a?ORG+', ':'')+(PL?PL+', ':'')+(X?X+', ':'')+y+'.'+(U?' [Online]. Available: '+U:'');
    // Vancouver
    var vP=va?va+'. ':'';
    if(type==='chapter')o.van='1. '+vP+T+'. In: '+(edF?ED.map(function(q){return q.ko?q.last:q.last+' '+ini(q.first,false)}).join(', ')+', editor'+(ED.length>1?'s':'')+'. ':'')+CT+'. '+(PL?PL+': ':'')+ORG+'; '+y+'. '+(pg?'p. '+pg.replace('–','-')+'.':'');
    if(type==='transbook')o.van='1. '+vP+T+'. '+TR.map(function(q){return q.ko?q.last:q.last+' '+ini(q.first,false)}).join(', ')+', translator. '+(PL?PL+': ':'')+ORG+'; '+y+'.';
    if(type==='conf')o.van='1. '+vP+T+'. In: '+CT+'; '+dV+(PL?'; '+PL:'')+'.';
    if(type==='news')o.van='1. '+vP+T+'. '+CT+'. '+dV+(U?'. Available from: '+U:'')+'.';
    if(type==='report')o.van='1. '+(va?va+'. ':'')+T+'. '+(PL?PL+': ':'')+ORG+'; '+y+'.'+(X?' '+X+'.':'');
    // ACS
    var xP=xa?xa+' ':'';
    if(type==='chapter')o.acs=xP+T+'. In <i>'+CT+'</i>; '+(edF?edF+', Ed'+(ED.length>1?'s':'')+'.; ':'')+ORG+': '+(PL?PL+', ':'')+y+(pg?'; pp '+pg.replace('–','–'):'')+'.';
    if(type==='transbook')o.acs=xP+'<i>'+T+'</i>; '+trF+', Trans.; '+ORG+': '+(PL?PL+', ':'')+y+'.';
    if(type==='conf')o.acs=xP+T+'. Presented at '+CT+(PL?', '+PL:'')+', '+dC+'.';
    if(type==='news')o.acs=xP+T+'. <i>'+CT+'</i>, '+dC+(U?', '+U:'')+'.';
    if(type==='report')o.acs=(xa?xa+' ':'')+'<i>'+T+'</i>; '+(X?X+'; ':'')+ORG+': '+(PL?PL+', ':'')+y+'.';
    o.miss={};
    ['ieee','van','acs'].forEach(function(k){if(!o[k])o.miss[k]=1});
    if(type==='ai'||type==='film'||type==='app'||type==='art'){['ieee','van','acs'].forEach(function(k){delete o[k];o.miss[k]=1})}
  }
  o.acsT= n==0?'(“'+shortT(T)+'”, '+y+')': n==1?'('+A[0].last+', '+y+')': n==2?'('+A[0].last+' and '+A[1].last+', '+y+')':'('+A[0].last+(A[0].ko?' 외':' et al.')+', '+y+')';
  o.acsT='위 첨자 ¹ 또는 (1) 또는 '+o.acsT;
  return o;
}
function shortT(t){return t.split(/\s+/).slice(0,4).join(' ')+(t.split(/\s+/).length>4?'…':'')}
var STYLES=[['apa','APA 7판','apa','ch07'],['mla','MLA 9판','mla','ch08'],['cad','Chicago Author-Date','cad','ch09'],['nb','Chicago Notes-Bibliography','nb','ch10'],['ieee','IEEE','ieee','ch11'],['van','Vancouver','van','ch12'],['acs','ACS','acs','ch13']];
var COL={apa:'#3a5fb0',cad:'#6fa89c',mla:'#8272b5',nb:'#cfa04e',ieee:'#8a93a0',van:'#cf7f88',acs:'#a8764f'};
function fields(){return {editors:v('ge'),trans:v('gtr'),date:v('gdt'),orig:v('gor'),version:v('gver'),extra:v('gx'),type:v('gt'),authors:$('ga').value,year:v('gy'),title:v('gtt'),journal:v('gj'),abbr:v('gab'),site:v('gj'),vol:v('gv'),issue:v('gi'),pages:v('gp'),doi:v('gd'),url:v('gu'),pub:v('gpub'),place:v('gpl')||v('gplc'),access:v('gac'),cite:v('gc'),degree:v('gdeg')}}
function showFields(){
  var t=v('gt');
  document.querySelectorAll('[data-for]').forEach(function(e){e.hidden=e.getAttribute('data-for').split(' ').indexOf(t)<0});
  var LJ={journal:'학술지 이름',chapter:'수록된 책 제목',conf:'학술대회 이름',news:'신문·잡지 이름',web:'웹사이트·기관 이름',app:'앱 장터(App Store 등)',art:'소장처 또는 전시 장소'};
  var lab=$('gjl'); if(lab)lab.textContent=LJ[t]||'이름';
  var LP={book:'출판사',transbook:'번역본 출판사',chapter:'출판사',thesis:'수여 대학',report:'발행 기관',film:'제작사',art:'소장 기관',ai:'개발사'};
  var l2=$('gpl2'); if(l2)l2.textContent=LP[t]||'출판사';
  var LX={report:'보고서 번호(선택)',art:'작품 종류(예: 유화, 사진)',ai:'프롬프트 내용(MLA용)'};
  var lx=$('gxl'); if(lx)lx.textContent=LX[t]||'추가 정보';
}
function copyText(txt,btn){
  function ok(){var o=btn.textContent;btn.textContent='복사됨';setTimeout(function(){btn.textContent=o},1200)}
  function fb(){var r=document.createRange();var el=btn._src;r.selectNodeContents(el);var s=getSelection();s.removeAllRanges();s.addRange(r)}
  try{navigator.clipboard.writeText(txt).then(ok,fb)}catch(e){fb()}
}
function render(){
  var f=fields(), out=$('gout'), sel=v('gs');
  if(!f.title&&!f.authors){out.innerHTML='<p class="mut">위 칸에 서지정보를 넣으면 일곱 양식으로 바뀐 모양이 여기에 나옵니다.</p>';return}
  var o=build(f); var h='';
  STYLES.forEach(function(s){
    if(sel!=='all'&&sel!==s[0])return;
    var ent=o[s[0]]; if(!ent){if(o.miss&&o.miss[s[0]]){h+='<article class="gc gm" style="--sc:'+COL[s[0]]+'"><div class="gh"><b>'+s[1]+'</b><a href="'+s[3]+'.html">이 양식 가이드 →</a></div><p class="mut">이 안내서가 확인한 이 자료 유형의 형식이 없어 만들지 않았습니다. 제출처 안내나 양식 발행처 안내를 확인하세요.</p></article>'}return}
    var tx=o[s[0]+'T'];
    h+='<article class="gc" style="--sc:'+COL[s[0]]+'"><div class="gh"><b>'+s[1]+'</b><a href="'+s[3]+'.html">이 양식 가이드 →</a></div>'
     +'<div class="gl">목록</div><div class="gv cp" data-n="e">'+ent+'</div><button class="gb" data-k="e">목록 복사</button>'
     +'<div class="gl">'+(s[0]==='nb'?'각주(처음 인용할 때)':'본문 인용')+'</div><div class="gv cp" data-n="t">'+(s[0]==='nb'?tx:esc(tx))+'</div><button class="gb" data-k="t">본문 표기 복사</button></article>';
  });
  out.innerHTML=h;
  out.querySelectorAll('.gb').forEach(function(b){
    var src=b.previousElementSibling; b._src=src;
    b.addEventListener('click',function(){copyText(src.innerText,b)});
  });
}
function sample(){
  $('gt').value='journal';$('ga').value='Kwon, Hyeok Yong\nChi, Eunju';$('gy').value='2012';$('gtt').value='Unequal New Democracies in East Asia: Rising Inequality and Government Responses in South Korea and Taiwan';
  $('gj').value='Asian Survey';$('gab').value='Asian Surv.';$('gv').value='52';$('gi').value='5';$('gp').value='900-923';$('gd').value='';$('gc').value='';if($('gdt'))$('gdt').value='';
  showFields();render();
}
function clearAll(){document.querySelectorAll('#gform input,#gform textarea').forEach(function(e){e.value=''});render()}
document.addEventListener('DOMContentLoaded',function(){
  if(!$('gform'))return;
  $('gform').addEventListener('input',render);$('gform').addEventListener('change',function(){showFields();render()});
  $('gform').addEventListener('submit',function(e){e.preventDefault()});
  $('gsample').addEventListener('click',sample);$('gclear').addEventListener('click',clearAll);
  showFields();render();
});

// ===== 서지정보 통째로 붙여 넣기 → 자동 분류 =====
function setv(id,val){var e=$(id);if(e&&val!=null)e.value=val}
function fillFrom(o){
  var map={year:'gy',title:'gtt',journal:'gj',abbr:'gab',vol:'gv',issue:'gi',pages:'gp',doi:'gd',url:'gu',pub:'gpub',place:'gpl'};
  document.querySelectorAll('#gform input,#gform textarea').forEach(function(e){e.value=''});
  if(o.type&&$('gt').querySelector('option[value="'+o.type+'"]'))$('gt').value=o.type;
  showFields();
  var au=Array.isArray(o.authors)?o.authors.join('\n'):(o.authors||'');setv('ga',au);
  Object.keys(map).forEach(function(k){if(o[k])setv(map[k],String(o[k]))});
  if(o.type==='conf'&&o.place)setv('gplc',o.place);
  if(o.editors)setv('ge',Array.isArray(o.editors)?o.editors.join('\n'):o.editors);
  if(o.trans)setv('gtr',Array.isArray(o.trans)?o.trans.join('\n'):o.trans);
  if(o.orig)setv('gor',o.orig);
  showFields();render();
}
function flipName(n){n=n.trim().replace(/\.$/,'');if(!n)return '';if(ko(n)||n.indexOf(',')>=0)return n;var w=n.split(/\s+/);if(w.length<2)return n;return w[w.length-1]+', '+w.slice(0,-1).join(' ')}
function parseBib(raw){
  var t=raw.replace(/\r/g,'').replace(/[​]/g,'').replace(/\s*\n\s*/g,' ').replace(/\s{2,}/g,' ').trim();
  var o={},m;
  m=t.match(/(?:https?:\/\/(?:dx\.)?doi\.org\/|doi:\s*)?(10\.\d{4,9}\/[^\s"”<>]+)/i);if(m){o.doi=m[1].replace(/[.,;)\]]+$/,'');t=t.replace(m[0],' ')}
  m=t.match(/https?:\/\/[^\s"”<>]+/);if(m){o.url=m[0].replace(/[.,;)\]]+$/,'');t=t.replace(m[0],' ')}
  t=t.replace(/^\s*(\[\d+\]|\d+\.|\(\d+\))\s+/,'').replace(/\s+/g,' ').trim();
  var ym=t.match(/\((\d{4})[a-z]?(?:,\s*[A-Za-z]+\.?(?:\s+\d{1,2})?)?\)/)||t.match(/[.,;]\s*(\d{4})[a-z]?\s*[.,;:]/)||t.match(/\b((?:19|20)\d{2})\b/);
  if(ym){o.year=ym[1]}
  // 권·호·쪽
  var vm=t.match(/(\d{1,4}),\s*no\.?\s*(\d{1,3})\s*\(\s*(?:[A-Za-z]+\.?\s*)?(?:\d{1,2},?\s*)?\d{4}\s*\)\s*:\s*(\d{1,5}\s*[–—-]\s*\d{1,5})/)||t.match(/vol\.?\s*(\d{1,4}),\s*no\.?\s*(\d{1,3}),\s*(?:\d{4},\s*)?pp?\.\s*(\d{1,5}\s*[–—-]\s*\d{1,5})/i)||t.match(/(?:vol\.?\s*)?(\d{1,4})\s*\(\s*(\d{1,3})\s*\)\s*[:,]?\s*(?:pp?\.\s*)?(\d{1,5}\s*[–—-]\s*\d{1,5})/i)||t.match(/vol\.?\s*(\d{1,4}),?\s*no\.?\s*(\d{1,3}),?\s*(?:pp?\.\s*)?(\d{1,5}\s*[–—-]\s*\d{1,5})/i)||t.match(/;\s*(\d{1,4})\s*\(\s*(\d{1,3})\s*\)\s*:\s*(\d{1,5}\s*[–—-]\s*\d{1,5})/)||t.match(/(\d{1,4})\s*[,:]\s*(?:no\.\s*)?(\d{1,3})\s*[,:]\s*(\d{1,5}\s*[–—-]\s*\d{1,5})/);
  var vm2=null;
  if(vm){o.vol=vm[1];o.issue=vm[2];o.pages=vm[3].replace(/\s/g,'').replace(/[—-]/g,'-')}
  else{vm2=t.match(/(?:vol\.?\s*)?(\d{1,4})\s*[,:]\s*(?:pp?\.\s*)?(\d{1,5}\s*[–—-]\s*\d{1,5})/i)||t.match(/(\d{1,4})\s*\(\s*(\d{1,3})\s*\)/);
   if(vm2){o.vol=vm2[1];if(vm2[2]&&/[–—-]/.test(vm2[2]))o.pages=vm2[2].replace(/\s/g,'').replace(/[—-]/g,'-');else if(vm2[2])o.issue=vm2[2]}
   var pm=t.match(/pp?\.\s*(\d{1,5}\s*[–—-]\s*\d{1,5})/i);if(pm&&!o.pages)o.pages=pm[1].replace(/\s/g,'').replace(/[—-]/g,'-')}
  if(o.pages){var pe=o.pages.match(/^(\d+)-(\d+)$/);if(pe&&pe[2].length<pe[1].length)o.pages=pe[1]+'-'+pe[1].slice(0,pe[1].length-pe[2].length)+pe[2]}
  var VM=t.match(/^(.+?)\.\s+(.+?)\.\s+([^.;]+?)\.?\s*((?:19|20)\d{2})\s*;\s*(\d+)\s*(?:\(([^)]+)\))?\s*:\s*(\d+\s*[–-]\s*\d+)/);
  if(VM&&!/[“"「]/.test(t)){o.type='journal';o.year=VM[4];o.title=VM[2];o.journal=VM[3].trim();o.abbr=VM[3].trim();o.vol=VM[5];if(VM[6])o.issue=VM[6];o.pages=VM[7].replace(/\s/g,'');var pe2=o.pages.match(/^(\d+)-(\d+)$/);if(pe2&&pe2[2].length<pe2[1].length)o.pages=pe2[1]+'-'+pe2[1].slice(0,pe2[1].length-pe2[2].length)+pe2[2];o.authors=VM[1].split(/,\s*/).map(function(x){var mv=x.trim().match(/^([A-Z][A-Za-z'’\-]+)\s+([A-Z]{1,3})$/);return mv?mv[1]+', '+mv[2].split('').join('. ')+'.':flipName(x)}).filter(Boolean);return o}
  // 제목
  var q=t.match(/[“"「『]([^”"」』]+)[”"」』]/);
  var head='',rest='';
  var yi=ym?t.indexOf(ym[0]):-1;
  if(q){o.title=q[1].replace(/[.,]$/,'').trim();var qi=t.indexOf(q[0]);head=t.slice(0,(yi>=0&&yi<qi)?yi:qi);rest=t.slice(qi+q[0].length)}
  else if(yi>=0){var after=t.slice(yi+ym[0].length).replace(/^[\s.,;:)]+/,'');head=t.slice(0,yi);
    var sp=after.split(/(?<=[^A-Z])\.\s+(?=[A-Z가-힣(])/);o.title=(sp[0]||'').replace(/\.$/,'').trim();rest=sp.slice(1).join('. ')}
  else{var sp2=t.split(/\.\s+/);head=sp2[0];o.title=(sp2[1]||'').trim();rest=sp2.slice(2).join('. ')}
  // 저자
  head=head.replace(/\(\s*$/,'').replace(/[\s,;]+$/,'').replace(/(?<![A-Z])\.+$/,'').trim();
  var A=[];
  if(ko(head)){A=head.split(/\s*[·,&]\s*|\s+그리고\s+|\s+and\s+/).map(function(x){return x.replace(/(?:지음|저|엮음|편)$/,'').trim()}).filter(Boolean)}
  else if(head){
    var pairs=[],h=head.replace(/\bet al\.?/,'');
    var re=/([A-Z][A-Za-z'’\-]+),\s*((?:[A-Z][a-z]*\.?\s?)+?)(?=,|\s+and\b|\s+&|\.?$|\.\s)/g,mm;
    while((mm=re.exec(h))){pairs.push(mm[1]+', '+mm[2].trim().replace(/\.$/,'.'))}
    if(pairs.length){A=pairs;var ms=h.split(/,?\s+(?:and|&)\s+/);if(ms.length>1){var lastp=ms[ms.length-1];if(!/,/.test(lastp)&&/^[A-Z]/.test(lastp)&&pairs.length<ms.length+1&&!ms[ms.length-1].match(/^[A-Z][a-z'’\-]+,/)){A.push(flipName(lastp))}}}
    else{var vv=h.split(/,\s*|\s+and\s+|\s+&\s+|;\s*/).map(function(x){return x.trim()}).filter(Boolean);
      A=vv.map(function(x){var mv=x.match(/^([A-Z][A-Za-z'’\-]+)\s+([A-Z]{1,3})$/);if(mv)return mv[1]+', '+mv[2].split('').join('. ')+'.';var mi=x.match(/^((?:[A-Z]\.\s?)+)([A-Z][A-Za-z'’\-]+)$/);if(mi)return mi[2]+', '+mi[1].trim();return flipName(x)})}
  }
  o.authors=A.filter(function(x){return x&&x.length<60});
  // 학술지·출판사
  var low=raw.toLowerCase();
  if(/학위논문|dissertation|thesis|doctoral|master['’]s/.test(low))o.type='thesis';
  else if(/trans(?:lated)?\.? by|\(.*trans\.\)|번역|옮김/i.test(raw)&&!o.vol)o.type='transbook';
  else if(/proceedings|conference|학술대회|symposium|workshop/.test(low))o.type='conf';
  else if(o.vol||o.pages&&/[–-]/.test(o.pages)&&!/\bpress\b|publishers?|books\b/i.test(raw))o.type='journal';
  else if(/\bpress\b|publishers?|books\b|출판|문학동네|\buniversity\b/i.test(raw)&&!o.url)o.type='book';
  else if(o.url&&!o.doi)o.type='web';
  else o.type=o.vol?'journal':'book';
  var r2=rest.replace(/^[\s.,;:)”"]+/,'').trim();
  if(o.type==='journal'||o.type==='conf'){var jm=r2.match(/^([^0-9()]+?)(?:[,.:;]?\s*(?:vol\.?\s*)?\d|\s*$)/i);if(jm)o.journal=jm[1].replace(/[,.:;\s]+$/,'').trim()}
  else if(o.type==='book'||o.type==='transbook'||o.type==='thesis'){
    var pm2=r2.match(/(?:([A-Z][A-Za-z.\s]+),\s*)?([^,.:]+(?:Press|Books|Publishers?|University|출판사|문학동네)[^,.]*)/i)||r2.match(/([A-Za-z가-힣\s]+?):\s*([^,.]+)/);
    if(pm2){if(pm2.length>2&&pm2[1])o.place=pm2[1].trim();o.pub=(pm2[2]||pm2[1]||'').replace(/[,.\s]+$/,'').trim()}
    if(!o.pub){var seg=r2.split(/[.,]\s*/).filter(Boolean);if(seg.length)o.pub=seg[seg.length-1]}}
  var tm=(o.title||'').match(/\s*\(([^()]*?),?\s*Trans\.\)\s*$/i);if(tm){o.trans=[flipName(tm[1])];o.title=o.title.replace(tm[0],'')}
  var om=raw.match(/Original work published\s*(\d{4})/i);if(om)o.orig=om[1];
  if(o.title)o.title=o.title.replace(/^[“"「『]|[”"」』]$/g,'').replace(/[,]+$/,'').trim();
  return o;
}
function pasteNote(o){var miss=[];if(!o.authors||!o.authors.length)miss.push('저자');if(!o.year)miss.push('연도');if(!o.title)miss.push('제목');if(o.type==='journal'&&!o.journal)miss.push('학술지 이름');if(o.type==='journal'&&!o.pages)miss.push('쪽 범위');
  var tn={journal:'학술지 논문',book:'단행본',transbook:'번역서',thesis:'학위논문',conf:'학술대회',web:'웹 자료'}[o.type]||o.type;
  return '자료 유형을 “'+tn+'”(으)로 분류하고 칸을 채웠습니다.'+(miss.length?' <b>찾지 못한 칸: '+miss.join(', ')+'</b>. 아래 칸에서 직접 채워 주세요.':'')+' 칸에 들어간 값이 맞는지 꼭 확인하세요.'}
async function parseAI(raw){
  var smp=null;try{smp=await window.claude.use('sample')}catch(e){}
  if(!smp)throw {code:'none'};
  var pr='아래는 학생이 붙여 넣은 참고문헌(서지) 한 건이다. 어느 인용 양식으로 쓴 것이든 정보를 읽어 JSON 하나로만 답하라. 키: type(journal|book|transbook|chapter|thesis|conf|web|news 중 하나), authors(문자열 배열: 영문은 “성, 이름”, 국문은 이름 그대로, 기관은 @를 앞에 붙임), year, title(원문 그대로, 대소문자 바꾸지 말 것), journal(학술지·웹사이트 이름), abbr(학술지 약어, 모르면 빈 문자열), vol, issue, pages(하이픈으로), doi, url, pub(출판사), place(도시), editors(배열), trans(번역자 배열), orig(원서 출판 연도). 글에 없는 정보는 지어내지 말고 빈 문자열로 둬라.\n\n'+raw;
  return await smp.json(pr,{modelTier:'quick'});
}
document.addEventListener('DOMContentLoaded',function(){
  var pb=$('gparse'),pa=$('gparseai'),ta=$('gpt'),mm=$('gpm');if(!pb||!ta)return;
  pb.addEventListener('click',function(){var raw=ta.value.trim();if(!raw){mm.textContent='위 칸에 서지정보를 붙여 넣어 주세요.';return}var o=parseBib(raw);fillFrom(o);mm.innerHTML=pasteNote(o)});
  pa.addEventListener('click',async function(){var raw=ta.value.trim();if(!raw){mm.textContent='위 칸에 서지정보를 붙여 넣어 주세요.';return}
    pa.disabled=true;mm.textContent='AI가 읽는 중…';
    try{var o=await parseAI(raw);if(!o||typeof o!=='object')throw {code:'bad'};fillFrom(o);mm.innerHTML='AI가 분류해 칸을 채웠습니다. '+pasteNote(o).replace(/^자료 유형을 [^.]*\. ?/,'')}
    catch(e){var o2=parseBib(raw);fillFrom(o2);mm.innerHTML=(e&&e.code==='not_granted'?'AI 사용을 허락하지 않아 ':'AI를 쓸 수 없어 ')+'기본 방식으로 분류했습니다. '+pasteNote(o2)}
    pa.disabled=false});
});
})();
