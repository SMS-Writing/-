(function(){
var d=document;
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
var FN='김서연, 『글쓰기와 인용』(가상출판사, 2021), 45.';
var CM=26;                       // 눈금자 1cm = 26px (쪽 글 폭 460px ≈ 17.7cm 중 420px 사용)
// ---------- 리본 조각 ----------
function rb(id,ic,t){return '<button type="button" class="rb" data-id="'+id+'" tabindex="-1"><i>'+ic+'</i><span>'+t+'</span></button>'}
function rg(name,items,lnc){return '<div class="rg"><div class="rbs">'+items+'</div><em>'+name+(lnc?'<b class="lnc" data-id="'+lnc+'">⌟</b>':'')+'</em></div>'}
var faint=rg('',rb('','▫','')+rb('','▫','')+rb('','▫',''));
var RIB={
 word:{
  '홈':rg('클립보드',rb('','📋','붙여넣기'))+rg('글꼴',rb('','가','굵게')+rb('','가','기울임')+rb('','가','밑줄'))
   +rg('단락',rb('al','☰','왼쪽 맞춤')+rb('','☰','가운데')+rb('jf','▤','양쪽 맞춤')+rb('indm','⇤','내어쓰기')+rb('indp','⇥','들여쓰기'),'pl')+rg('스타일',rb('','Aa','본문')+rb('','Aa','제목 1')),
  '참조':rg('목차',rb('','☷','목차'))+rg('각주',rb('fn','¹','각주 삽입')+rb('','²','미주 삽입')+rb('','AB','다음 각주'))+rg('인용 및 참고 문헌',rb('','❝','인용 삽입')+rb('','☰','참고 문헌')),
  '보기':rg('보기',rb('','▭','읽기 모드')+rb('','▭','인쇄 모양'))+rg('표시',rb('rul','📏','눈금자')+rb('','▦','격자선')),
  '삽입':rg('삽입',rb('','▦','표')+rb('','🖼','그림')+rb('','◇','도형'))},
 hwp:{
  '입력':rg('개체',rb('','▦','표')+rb('','🖼','그림')+rb('','◇','도형')+rb('','▭','글상자'))+rg('주석',rb('fn','¹','각주')+rb('','²','미주')+rb('','✎','메모')+rb('','↔','상호 참조'))+rg('문자',rb('','Ω','문자표')+rb('','∑','수식')),
  '서식':rg('글자',rb('','가','글자 모양'))+rg('문단',rb('pm','☰','문단 모양')+rb('al','☰','왼쪽 정렬')+rb('jf','▤','양쪽 정렬')),
  '보기':rg('화면',rb('','▭','쪽 윤곽'))+rg('표시',rb('rul','📏','눈금자')+rb('','▦','문단 부호')),
  '편집':rg('편집',rb('','⎘','복사')+rb('','📋','붙이기')+rb('','⌕','찾기'))}};
var TABS={word:['파일','홈','삽입','디자인','레이아웃','참조','검토','보기'],hwp:['파일','편집','보기','입력','서식','쪽','보안','검토','도구']};
function tabsHtml(app){return TABS[app].map(function(t){return '<button type="button" class="tb" data-tab="'+t+'" tabindex="-1">'+t+'</button>'}).join('')}
function ribHtml(app){var o='';Object.keys(RIB[app]).forEach(function(k){o+='<div class="rp" data-rp="'+k+'">'+RIB[app][k]+'</div>'});return o+'<div class="rp" data-rp="*">'+faint+faint+faint+'</div>'}
function rulerHtml(){var t='';for(var i=0;i<=17;i++)t+='<s style="left:'+(20+i*CM)+'px"><u>'+i+'</u></s>';
 return '<div class="ud-ruler" hidden><div class="rtk">'+t+'</div><b class="mk f" data-id="mkf" title="첫 줄 들여쓰기">▽</b><b class="mk h" data-id="mkh" title="왼쪽 들여쓰기·내어쓰기">△</b><span class="rl" data-id="rlab"></span></div>'}
function dlgHtml(app,title,rows){return '<div class="ud-dlg" hidden><div class="dh">'+title+'</div>'+rows.map(function(r){return '<div class="dr"><label>'+r[1]+'</label><span class="di" data-k="'+r[0]+'">'+esc(r[2])+'</span></div>'}).join('')+'<div class="db"><button type="button" class="ok" data-id="dok" tabindex="-1">'+(app==='word'?'확인':'설정')+'</button><button type="button" tabindex="-1">취소</button></div></div>'}
// ---------- 쪽 내용 ----------
function P(txt,id,cls){return '<p class="ud-p'+(cls?' '+cls:'')+'"'+(id?' data-id="'+id+'"':'')+'>'+txt+'</p>'}
var FNPAGE=P('<b>1. 서론</b>')+P('김 교수는 “글쓰기는 생각을 정리하는 일이다”<span class="car" data-id="anchor"></span><sup class="fnn" data-id="fnn" hidden>1</sup>라고 말했다. 이 보고서는 인용 표기의 기본 규칙과 출처를 밝히는 방법을 차근차근 살펴본다.','p1')+P('다음으로 한글과 워드에서 각주와 참고문헌을 설정하는 방법을 확인한다. 쓰는 도구가 달라도 보고서의 모양은 같아야 한다.')
 +'<div class="fnarea" data-id="fna" hidden><hr><p><sup>1</sup> <span data-id="fnt"></span><span class="car on"></span></p></div>';
var BIB=['김서연. (2021). 대학 글쓰기에서 출처 표기의 효과와 학생들이 자주 하는 실수에 관한 연구. 글쓰기연구, 14(2), 45–68.','박도윤, 이하늘. (2019). 보고서의 형식과 읽기 경험에 관한 사례 분석. 대학교육논총, 8(1), 101–120.','최나래. (2020). 인용 표기 방식에 따른 독자의 신뢰도 비교. 학술문화연구, 5(3), 77–96.'];
var HANGPAGE=P('<b>참고문헌</b>')+BIB.map(function(b,i){return P(esc(b),'bib'+i,'bib')}).join('');
var BODY1='인용은 출처를 밝혀 독자가 근거를 직접 확인하게 하는 일이다. 또한 인용 방식을 일관되게 쓴 보고서는 그만큼 믿음직하게 읽힌다. 따라서 이 보고서는 인용 표기의 기본 규칙을 정리한다.';
var BODY2='문단은 새 생각이 시작될 때 바뀐다. 문단이 시작하는 곳이 한눈에 보이도록 첫 줄을 안쪽으로 들이고, 나머지 줄은 왼쪽 끝에 맞춘다. 이 규칙은 한글과 워드에서 모두 같다.';
var FIRSTPAGE=P('<b>2. 본론</b>')+P(BODY1,'b1')+P(BODY2,'b2');
var QUOTEPAGE=P('이 연구는 출처를 밝히는 일의 의미를 다음과 같이 설명한다.','q0')+P('출처를 밝히면 독자가 근거를 직접 확인할 수 있고, 글쓴이는 다른 사람의 생각과 자기 생각을 나누어 보여 줄 수 있다. 인용 표기를 일관되게 쓴 보고서는 그만큼 믿음직하게 읽힌다. 따라서 긴 인용은 따옴표 없이 따로 떼어 쓴다.','qq','q')+P('이 설명에 따라 아래에서는 인용 표기의 기본 규칙을 차례대로 살펴본다.','q2');
var JPAGE=P('<b>1. 서론</b>')+P('MS워드로 보고서를 쓸 때에 양쪽 맞춤을 해야 합니다. 양쪽 맞춤은 홈 메뉴에 있습니다. 단축키는 Ctrl+J입니다. 양쪽 맞춤을 하지 않으면 쪽 모양이 삐뚤빼뚤해집니다. 보고서를 작성할 때에는 반드시 양쪽 맞춤을 합시다.','jp','left');
// ---------- 데모 정의 ----------
var DEMOS={};
function fnScript(app){return async function(u){
 u.step(0);await u.move('[data-id=anchor]',0,6);await u.click('[data-id=anchor]',function(){u.q('[data-id=anchor]').classList.add('on')});
 u.step(1);await u.move('[data-tab="'+(app==='word'?'참조':'입력')+'"]');await u.click('[data-tab="'+(app==='word'?'참조':'입력')+'"]',function(){u.tab(app==='word'?'참조':'입력')});
 u.step(2);await u.move('[data-id=fn]');await u.click('[data-id=fn]',function(){u.q('[data-id=anchor]').classList.remove('on');u.q('[data-id=fnn]').hidden=false;u.q('[data-id=fnn]').classList.add('pop');u.q('[data-id=fna]').hidden=false;u.key(app==='word'?'Ctrl + Alt + F':'Ctrl + N, N')});
 u.step(3);await u.move('[data-id=fnt]',40,0);await u.type('[data-id=fnt]',FN,22);await u.wait(500);
 u.step(4);u.q('.car.on')&&u.q('.car.on').classList.remove('on');u.done('<b>번호는 직접 쓰지 않았어요.</b> 단축키(<kbd>'+(app==='word'?'Ctrl+Alt+F':'Ctrl+N, N')+'</kbd>)나 메뉴로 넣으면 본문의 위 첨자 번호와 쪽 아래 각주가 저절로 이어져요. 직접 인용이라 <b>닫는 큰따옴표(”) 바로 다음</b>에 넣었어요.');
}}
DEMOS['word-fn']={app:'word',title:'워드: 참조 > 각주 삽입',tab:'홈',page:FNPAGE,
 steps:['각주 번호를 붙일 곳(닫는 큰따옴표 다음)을 눌러 커서를 둔다','위쪽 <b>참조</b> 탭을 누른다','<b>각주 삽입</b>을 누른다 (단축키 Ctrl+Alt+F)','쪽 아래 각주 칸에 출처를 쓴다','번호는 직접 치지 않는다!'],script:fnScript('word')};
DEMOS['hwp-fn']={app:'hwp',title:'한글: 입력 > 주석 > 각주',tab:'편집',page:FNPAGE,
 steps:['각주 번호를 붙일 곳(닫는 큰따옴표 다음)을 눌러 커서를 둔다','위쪽 <b>입력</b> 탭을 누른다','<b>주석 &gt; 각주</b>를 누른다 (단축키 Ctrl+N, N)','쪽 아래 각주 칸에 출처를 쓴다','번호는 직접 치지 않는다!'],script:fnScript('hwp')};
function setP(els,l,f){els.forEach(function(e){e.style.paddingLeft=l+'px';e.style.textIndent=f+'px'})}
function ruler(u,l,f,lab){var r=u.q('.ud-ruler');u.q('[data-id=mkf]').style.left=(20+l+f-6)+'px';u.q('[data-id=mkh]').style.left=(20+l-6)+'px';if(lab!=null)u.q('[data-id=rlab]').textContent=lab}
DEMOS['word-hang']={app:'word',title:'워드: 눈금자의 내어쓰기 삼각형 끌기',tab:'홈',page:HANGPAGE,
 steps:['참고문헌 항목만 블록으로 지정한다 (Ctrl+A는 쓰지 않는다)','<b>보기</b> 탭에서 <b>눈금자</b>를 켠다','눈금자 왼쪽 아래의 <b>△(내어쓰기)</b>를 오른쪽으로 끌어 0.5인치(1.27cm)에 맞춘다','둘째 줄부터 안쪽으로 들어갔다!'],
 script:async function(u){var ps=u.qa('.bib');
  u.step(0);await u.move('[data-id=bib0]',-150,-8);await u.drag(function(t){var n=Math.ceil(t*3);ps.forEach(function(p,i){p.classList.toggle('sel',i<n)})},'[data-id=bib2]',60,10,1100);
  u.step(1);await u.move('[data-tab=보기]');await u.click('[data-tab=보기]',function(){u.tab('보기')});await u.move('[data-id=rul]');await u.click('[data-id=rul]',function(){u.q('.ud-ruler').hidden=false;ruler(u,0,0,'0.0cm')});
  u.step(2);await u.move('[data-id=mkh]',0,0);var L=1.27*CM;await u.drag(function(t){var l=L*t;setP(ps,l,-l);ruler(u,l,-l,'내어쓰기 '+(1.27*t).toFixed(2)+'cm')},'[data-id=mkh]',L,0,1300,true);
  u.step(3);ps.forEach(function(p){p.classList.remove('sel')});u.done('<b>참고문헌 내어쓰기</b>: 첫 줄은 왼쪽 끝, 둘째 줄부터 0.5인치(1.27cm) 안쪽이에요. APA·MLA·Chicago 기준이고, IEEE·Vancouver·ACS는 번호 폭에 맞춰요. 양식과 제출처 규정이 먼저예요.')}};
DEMOS['hwp-hang']={app:'hwp',title:'한글: 서식 > 문단 모양 > 내어쓰기',tab:'편집',page:HANGPAGE,
 dlg:['문단 모양',[['l','왼쪽 여백','0 pt'],['f','첫 줄','보통'],['v','값','0 pt']]],
 steps:['참고문헌 항목만 블록으로 지정한다','<b>서식</b> 탭의 <b>문단 모양</b>을 누른다 (단축키 Alt+T)','첫 줄을 <b>내어 쓰기</b>로 고르고 값을 36pt(0.5인치)로 쓴다','<b>설정</b>을 누르면 둘째 줄부터 들어간다'],
 script:async function(u){var ps=u.qa('.bib');
  u.step(0);await u.move('[data-id=bib0]',-150,-8);await u.drag(function(t){var n=Math.ceil(t*3);ps.forEach(function(p,i){p.classList.toggle('sel',i<n)})},'[data-id=bib2]',60,10,1100);
  u.step(1);await u.move('[data-tab=서식]');await u.click('[data-tab=서식]',function(){u.tab('서식')});await u.move('[data-id=pm]');await u.click('[data-id=pm]',function(){u.dlg(true)});
  u.step(2);await u.move('[data-k=f]');await u.click('[data-k=f]',function(){u.val('f','내어 쓰기')});await u.move('[data-k=v]');await u.click('[data-k=v]',function(){u.val('v','36 pt')});
  u.step(3);await u.move('[data-id=dok]');await u.click('[data-id=dok]',function(){u.dlg(false)});var L=36*1.333;await u.tween(function(t){var l=L*t;setP(ps,l,-l);u.q('.ud-ruler').hidden=false;ruler(u,l,-l,'내어쓰기 '+Math.round(36*t)+'pt')},900);
  ps.forEach(function(p){p.classList.remove('sel')});u.done('<b>참고문헌 내어쓰기</b>: 한글은 문단 모양에서 첫 줄을 “내어 쓰기”로 고르고 값을 넣어요. APA·MLA·Chicago는 36pt(0.5인치)가 기본값이에요. 항목마다 따로 하지 말고 참고문헌만 한 번에 블록으로 지정해요.')}};
function firstScript(app){return async function(u){var ps=u.qa('[data-id=b1],[data-id=b2]'),L=10*1.333;
 u.step(0);await u.move('[data-id=b1]',-120,-14);await u.drag(function(t){ps.forEach(function(p,i){p.classList.toggle('sel',t>(i?.5:.05))})},'[data-id=b2]',160,10,1100);
 if(app==='word'){u.step(1);await u.move('[data-id=pl]');await u.click('[data-id=pl]',function(){u.dlg(true)});u.step(2);await u.move('[data-k=s]');await u.click('[data-k=s]',function(){u.val('s','첫 줄')});await u.move('[data-k=v]');await u.click('[data-k=v]',function(){u.val('v','10 pt')});u.step(3)}
 else{u.step(1);await u.move('[data-tab=서식]');await u.click('[data-tab=서식]',function(){u.tab('서식')});await u.move('[data-id=pm]');await u.click('[data-id=pm]',function(){u.dlg(true)});u.step(2);await u.move('[data-k=f]');await u.click('[data-k=f]',function(){u.val('f','들여 쓰기')});await u.move('[data-k=v]');await u.click('[data-k=v]',function(){u.val('v','10 pt')});u.step(3)}
 await u.move('[data-id=dok]');await u.click('[data-id=dok]',function(){u.dlg(false);u.q('.ud-ruler').hidden=false});
 await u.tween(function(t){setP(ps,0,L*t);ruler(u,0,L*t,'첫 줄 '+Math.round(10*t)+'pt')},900);
 ps.forEach(function(p){p.classList.remove('sel')});
 u.done('<b>첫 줄 들여쓰기 10pt</b>: 본문이 10pt이면 첫 줄만 10pt(글자 한 개 폭), 왼쪽 값은 <b>0</b>이에요. 스페이스나 Tab으로 밀지 않아요. 소제목은 제외해요.')}}
DEMOS['word-first']={app:'word',title:'워드: 단락 > 특수 > 첫 줄',tab:'홈',page:FIRSTPAGE,ruler:1,dlg:['단락',[['l','들여쓰기 왼쪽','0 pt'],['s','특수','(없음)'],['v','값','']]],
 steps:['소제목을 뺀 본문 단락을 블록으로 지정한다','<b>단락</b> 그룹 오른쪽 아래 작은 화살표를 누른다','<b>특수</b>를 “첫 줄”로, 값을 10pt로 쓴다','확인을 누르면 첫 줄만 들어간다'],script:firstScript('word')};
DEMOS['hwp-first']={app:'hwp',title:'한글: 문단 모양 > 첫 줄 들여 쓰기',tab:'편집',page:FIRSTPAGE,ruler:1,dlg:['문단 모양',[['l','왼쪽 여백','0 pt'],['f','첫 줄','보통'],['v','값','0 pt']]],
 steps:['소제목을 뺀 본문 단락을 블록으로 지정한다','<b>서식</b> 탭 &gt; <b>문단 모양</b> (단축키 Alt+T)','첫 줄을 “들여 쓰기”, 값을 10pt로 쓴다','설정을 누르면 첫 줄만 들어간다'],script:firstScript('hwp')};

function hangTo(u,ps,n,lab){var l=n*1.27*CM;setP(ps,l,-l);ruler(u,l,-l,lab||('내어쓰기 '+(n*1.27).toFixed(2)+'cm'))}
DEMOS['word-ctrlt']={app:'word',title:'워드: 단축키 Ctrl+T로 내어쓰기, Ctrl+Shift+T로 해제',tab:'홈',page:HANGPAGE,ruler:1,
 steps:['참고문헌 항목만 블록으로 지정한다','<b>Ctrl+T</b>를 한 번 누른다 → 둘째 줄부터 한 칸(1.27cm) 들어간다','한 번 더 누르면 한 칸 더 들어간다 (참고문헌에는 한 번이면 충분)','<b>Ctrl+Shift+T</b>를 누르면 한 칸씩 되돌아온다','한 번 더 누르면 내어쓰기가 완전히 없어진다'],
 tryit:[{l:'Ctrl+T 누르기 (내어쓰기 한 칸 더)',k:'Ctrl + T',d:1},{l:'Ctrl+Shift+T 누르기 (한 칸 덜)',k:'Ctrl + Shift + T',d:-1}],
 script:async function(u){var ps=u.qa('.bib');
  u.step(0);await u.move('[data-id=bib0]',-150,-8);await u.drag(function(t){var n=Math.ceil(t*3);ps.forEach(function(p,i){p.classList.toggle('sel',i<n)})},'[data-id=bib2]',60,10,1100);
  u.step(1);await u.wait(300);u.key('Ctrl + T');await u.tween(function(t){hangTo(u,ps,t)},700);await u.wait(500);
  u.step(2);await u.wait(300);u.key('Ctrl + T');await u.tween(function(t){hangTo(u,ps,1+t)},700);await u.wait(600);
  u.step(3);await u.wait(300);u.key('Ctrl + Shift + T');await u.tween(function(t){hangTo(u,ps,2-t)},700);await u.wait(600);
  u.step(4);await u.wait(300);u.key('Ctrl + Shift + T');await u.tween(function(t){hangTo(u,ps,1-t)},700);await u.wait(400);
  ps.forEach(function(p){p.classList.remove('sel')});
  u.done('<b>내어쓰기 단축키</b>: <kbd>Ctrl+T</kbd>는 눌릴 때마다 둘째 줄부터의 들여쓰기가 한 칸(기본 1.27cm)씩 늘고, <kbd>Ctrl+Shift+T</kbd>는 한 칸씩 줄어요. 참고문헌은 한 번만 눌러 1.27cm(0.5인치)로 맞추면 돼요. 단락 서식을 모두 지우려면 <kbd>Ctrl+Q</kbd>를 눌러도 되지만 줄 간격 같은 다른 서식도 같이 지워지니 조심하세요. 아래 단추로 직접 눌러 볼 수 있어요.')}};
function quoteScript(app){return async function(u){var q=u.q('[data-id=qq]'),L=app==='word'?CM:28*1.333;
 u.step(0);await u.move('[data-id=qq]',-175,-24);await u.drag(function(t){q.classList.toggle('sel',t>.1)},'[data-id=qq]',150,26,1100);
 if(app==='word'){u.step(1);await u.move('[data-id=pl]');await u.click('[data-id=pl]',function(){u.dlg(true)});u.step(2);await u.move('[data-k=l]');await u.click('[data-k=l]',function(){u.val('l','1 cm')});await u.move('[data-k=a]');await u.click('[data-k=a]',function(){u.val('a','6 pt / 6 pt');u.val('g','배수 1.2')})}
 else{u.step(1);await u.move('[data-tab=서식]');await u.click('[data-tab=서식]',function(){u.tab('서식')});await u.move('[data-id=pm]');await u.click('[data-id=pm]',function(){u.dlg(true)});u.step(2);await u.move('[data-k=l]');await u.click('[data-k=l]',function(){u.val('l','28 pt')});await u.move('[data-k=a]');await u.click('[data-k=a]',function(){u.val('a','6 pt / 6 pt');u.val('g','120 %')})}
 u.step(3);await u.move('[data-id=dok]');await u.click('[data-id=dok]',function(){u.dlg(false);u.q('.ud-ruler').hidden=false});
 await u.tween(function(t){setP([q],L*t,0);q.style.fontSize=(11-t)+'px';q.style.margin=(6*t)+'px 0';ruler(u,L*t,0,'왼쪽 '+(app==='word'?(t).toFixed(1)+'cm':Math.round(28*t)+'pt'))},1100);
 u.step(4);await u.wait(500);await u.tween(function(t){var l=L*(1-t);setP([q],l,0);ruler(u,l,0,'왼쪽 '+(app==='word'?(l/CM).toFixed(1)+'cm':Math.round(l/1.333)+'pt'))},700);
 u.q('.ud-ruler').classList.add('glow');await u.move('[data-id=mkh]',0,0);await u.drag(function(t){var l=L*t;setP([q],l,0);ruler(u,l,0,'왼쪽 '+(app==='word'?(l/CM).toFixed(1)+'cm':Math.round(l/1.333)+'pt'))},'[data-id=mkh]',L,0,1300,true);u.q('.ud-ruler').classList.remove('glow');
 q.classList.remove('sel');
 u.done('<b>눈금자로도 같아요</b>: 문단 모양에 값을 넣은 뒤에는 눈금자의 △(왼쪽 여백)가 그 값에 있어요. △를 직접 끌어도 같은 효과가 나지만, 값을 정확히 맞출 때는 대화상자가 편해요. <b>단락(블록) 인용</b>: 모든 줄이 함께 안쪽으로 들어가요(눈금자의 △와 ▽가 같이 움직여요). 값은 '+(app==='word'?'왼쪽 1cm, 간격 앞·뒤 6pt, 줄 간격 1.2배':'왼쪽 여백 28pt(약 1cm), 문단 위·아래 6pt, 줄 간격 120%')+'이고, 글자는 본문보다 1pt 작게 해요. 제출처 규정이 있으면 따라요.')}}
DEMOS['hwp-quote']={app:'hwp',title:'한글: 블록 지정 후 문단 모양과 눈금자',tab:'편집',page:QUOTEPAGE,ruler:1,dlg:['문단 모양',[['l','왼쪽 여백','0 pt'],['a','문단 위·아래','0 pt / 0 pt'],['g','줄 간격','160 %']]],
 steps:['인용문 단락만 블록으로 지정한다 (앞뒤 본문은 빼기)','<b>서식</b> 탭 &gt; <b>문단 모양</b> (단축키 Alt+T)','왼쪽 여백 28pt, 문단 위·아래 6pt, 줄 간격 120%','설정을 누르면 눈금자 표시가 함께 움직인다','눈금자의 △를 직접 끌어도 같은 효과가 난다'],script:quoteScript('hwp')};
DEMOS['word-quote']={app:'word',title:'워드: 단락 대화상자와 눈금자',tab:'홈',page:QUOTEPAGE,ruler:1,dlg:['단락',[['l','들여쓰기 왼쪽','0 cm'],['a','간격 앞·뒤','0 pt / 0 pt'],['g','줄 간격','배수 1.5']]],
 steps:['인용문 단락만 블록으로 지정한다 (단락 안을 세 번 누르면 전체 선택)','<b>단락</b> 그룹 오른쪽 아래 작은 화살표','왼쪽 1cm, 간격 앞·뒤 6pt, 줄 간격 1.2배','확인을 누르면 눈금자의 △▽가 함께 움직인다','눈금자의 △를 직접 끌어도 같은 효과가 난다'],script:quoteScript('word')};
function justScript(app){return async function(u){var p=u.q('[data-id=jp]');
 u.step(0);await u.move('[data-id=jp]',-170,-20);await u.drag(function(t){p.classList.toggle('sel',t>.1)},'[data-id=jp]',160,24,1000);
 u.step(1);if(app==='word'){await u.move('[data-id=jf]');await u.click('[data-id=jf]',function(){p.classList.remove('left');p.classList.add('just')})}
 else{await u.move('[data-tab=서식]');await u.click('[data-tab=서식]',function(){u.tab('서식')});await u.move('[data-id=jf]');await u.click('[data-id=jf]',function(){p.classList.remove('left');p.classList.add('just')})}
 u.step(2);await u.wait(500);p.classList.remove('sel');u.done('<b>양쪽 정렬</b>: 줄 끝이 한 줄로 맞아요. 단축키는 '+(app==='word'?'Ctrl+J':'Ctrl+Shift+M')+'. 국문 보고서·논문은 본문을 양쪽 정렬로 쓰는 것이 일반적이에요. 영문은 양식에 따라 왼쪽 정렬일 수 있으니 제출 양식을 먼저 확인해요.')}}
DEMOS['word-justify']={app:'word',title:'워드: 홈 > 양쪽 맞춤',tab:'홈',page:JPAGE,steps:['본문을 블록으로 지정한다','<b>홈</b> 탭 단락 그룹의 <b>양쪽 맞춤</b>을 누른다 (Ctrl+J)','줄 끝이 한 줄로 맞아요'],script:justScript('word')};
DEMOS['hwp-justify']={app:'hwp',title:'한글: 서식 > 양쪽 정렬',tab:'편집',page:JPAGE,steps:['본문을 블록으로 지정한다','<b>서식</b> 탭의 <b>양쪽 정렬</b>을 누른다 (Ctrl+Shift+M)','줄 끝이 한 줄로 맞아요'],script:justScript('hwp')};

var LSPAGE=P('<b>2. 본론</b>')+P('출처를 밝히면 독자가 근거를 직접 확인할 수 있고, 글쓴이는 다른 사람의 생각과 자기 생각을 나누어 보여 줄 수 있다. 인용 표기를 일관되게 쓴 보고서는 그만큼 믿음직하게 읽힌다. 따라서 이 보고서는 인용 표기의 기본 규칙을 정리한다.','ls1')+P('문단은 새 생각이 시작될 때 바뀐다. 문단이 시작하는 곳이 한눈에 보이도록 첫 줄을 안쪽으로 들이고, 나머지 줄은 왼쪽 끝에 맞춘다. 이 규칙은 한글과 워드에서 모두 같다.','ls2');
function lsScript(app){return async function(u){var ps=u.qa('[data-id=ls1],[data-id=ls2]'),H=function(v){ps.forEach(function(p){p.style.lineHeight=v})};H(2.0);
 u.step(0);await u.move('[data-id=ls1]',-170,-20);await u.drag(function(t){ps.forEach(function(p){p.classList.toggle('sel',t>.1)})},'[data-id=ls2]',150,30,1100);
 if(app==='hwp'){u.step(1);await u.move('[data-tab=서식]');await u.click('[data-tab=서식]',function(){u.tab('서식')});await u.move('[data-id=pm]');await u.click('[data-id=pm]',function(){u.dlg(true);u.key('Alt + T')});
  u.step(2);await u.move('[data-k=g]');await u.click('[data-k=g]',function(){u.val('g','글자에 따라 160 %')})}
 else{u.step(1);await u.move('[data-id=pl]');await u.click('[data-id=pl]',function(){u.dlg(true)});
  u.step(2);await u.move('[data-k=g]');await u.click('[data-k=g]',function(){u.val('g','고정')});await u.move('[data-k=v]');await u.click('[data-k=v]',function(){u.val('v','16 pt')})}
 u.step(3);await u.move('[data-id=dok]');await u.click('[data-id=dok]',function(){u.dlg(false)});
 await u.tween(function(t){H((2.0-0.4*t).toFixed(3))},1300);ps.forEach(function(p){p.classList.remove('sel')});
 u.done('<b>줄 간격 줄이기</b>: 줄 사이가 넓었던 글이 촘촘해졌어요. '+(app==='hwp'?'한글은 “글자에 따라 160%”(글자 10pt이면 16pt). 블록 지정 후 <kbd>Alt+Shift+A</kbd>(줄 간격 줄이기)를 눌러도 줄어요. 정확한 값은 문단 모양에서 확인하세요.':'워드는 “고정 16pt”가 한글 160%(글자 10pt)와 비슷해요. 줄 간격 단추(홈 탭)에서 1.5 → 1.0처럼 배수를 고를 수도 있어요. 그림이 든 줄은 “한 줄”로 바꾸세요.')+' 양식이 정한 값이 있으면 그것이 먼저예요.')}}
DEMOS['hwp-ls']={app:'hwp',title:'한글: 문단 모양에서 줄 간격 줄이기',tab:'편집',page:LSPAGE,dlg:['문단 모양',[['l','왼쪽 여백','0 pt'],['g','줄 간격','글자에 따라 200 %']]],
 steps:['줄 간격을 줄일 본문을 블록으로 지정한다','<b>서식</b> 탭 &gt; <b>문단 모양</b> (Alt+T)','줄 간격을 <b>글자에 따라 160%</b>로 바꾼다','설정을 누르면 줄 사이가 좁아진다'],script:lsScript('hwp')};
DEMOS['word-ls']={app:'word',title:'워드: 단락에서 줄 간격 줄이기',tab:'홈',page:LSPAGE,dlg:['단락',[['l','들여쓰기 왼쪽','0 cm'],['g','줄 간격','배수'],['v','값','2.0']]],
 steps:['줄 간격을 줄일 본문을 블록으로 지정한다','<b>홈</b> 탭 단락 그룹 오른쪽 아래 작은 화살표','줄 간격을 <b>고정</b>, 값 <b>16pt</b>로 바꾼다','확인을 누르면 줄 사이가 좁아진다'],script:lsScript('word')};
// ---------- 엔진 ----------
function build(host,id){var C=DEMOS[id];if(!C)return;
 host.classList.add('ud');
 host.innerHTML='<div class="ud-top"><span class="ud-app '+C.app+'">'+(C.app==='word'?'워드(PC)':'한글(PC)')+'</span><b>'+C.title+'</b><span class="ud-sp"></span><button type="button" class="ud-play">▶ 재생</button></div>'
  +'<div class="ud-wrap"><div class="ud-win"><div class="ud-tt"><i></i><i></i><i></i><span>'+(C.app==='word'?'문서1 - 워드':'제목 없음 - 한글')+'</span></div><div class="ud-tabs"></div><div class="ud-rib"></div><div class="ud-doc"></div><div class="ud-ptr" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22"><path d="M4 2l15 9-7 1.6L9 19z" fill="#fff" stroke="#1f2a44" stroke-width="1.6" stroke-linejoin="round"/></svg><b class="rip"></b></div><div class="ud-key" hidden></div></div></div>'
  +'<ol class="ud-steps">'+C.steps.map(function(s){return '<li>'+s+'</li>'}).join('')+'</ol><div class="ud-done" hidden></div>';
 var win=host.querySelector('.ud-win'),wrap=host.querySelector('.ud-wrap'),ptr=host.querySelector('.ud-ptr'),play=host.querySelector('.ud-play'),steps=host.querySelectorAll('.ud-steps li'),doneEl=host.querySelector('.ud-done'),keyEl=host.querySelector('.ud-key');
 var hl=0;var token=0,scale=1,reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 function fit(){if(!wrap.clientWidth)return;scale=Math.min(1,wrap.clientWidth/720);win.style.transform='scale('+scale+')';wrap.style.height=Math.ceil(win.offsetHeight*scale)+'px'}
 function reset(){win.querySelector('.ud-tabs').innerHTML=tabsHtml(C.app);win.querySelector('.ud-rib').innerHTML=ribHtml(C.app);
  win.querySelector('.ud-doc').innerHTML=rulerHtml()+'<div class="ud-paper">'+C.page+'</div>'+(C.dlg?dlgHtml(C.app,C.dlg[0],C.dlg[1]):'');
  if(C.ruler){win.querySelector('.ud-ruler').hidden=false;ruler({q:function(s){return win.querySelector(s)}},0,0,'0')}
  hl=0;  setTab(C.tab);ptr.style.transform='translate(560px,400px)';doneEl.hidden=true;keyEl.hidden=true;steps.forEach(function(s){s.className=''});fit()}
 function setTab(n){var has=!!RIB[C.app][n];win.querySelectorAll('.tb').forEach(function(b){b.classList.toggle('on',b.dataset.tab===n)});win.querySelectorAll('.rp').forEach(function(r){r.classList.toggle('on',r.dataset.rp===(has?n:'*'))})}
 function q(s){return win.querySelector(s)}function qa(s){return [].slice.call(win.querySelectorAll(s))}
 function U(my){function chk(){if(token!==my)throw 'stop'}
  var u={q:q,qa:qa,
   wait:function(ms){return new Promise(function(r,j){setTimeout(function(){token!==my?j('stop'):r()},ms*(reduce?.4:1))})},
   step:function(i){chk();steps.forEach(function(s,k){s.className=k<i?'done':k===i?'now':''});steps[i]&&steps[i].scrollIntoView&&0},
   tab:function(n){setTab(n)},dlg:function(on){var e=q('.ud-dlg');if(e)e.hidden=!on},
   val:function(k,t){var e=q('.di[data-k='+k+']');if(e){e.textContent=t;e.classList.add('chg')}},
   key:function(t){keyEl.textContent=t;keyEl.hidden=false;setTimeout(function(){keyEl.hidden=true},2200)},
   done:function(h){steps.forEach(function(s){s.className='done'});doneEl.innerHTML='✅ '+h;doneEl.hidden=false},
   move:function(sel,dx,dy){chk();var e=q(sel);if(!e)return u.wait(10);var wr=win.getBoundingClientRect(),r=e.getBoundingClientRect();var x=(r.left+r.width/2-wr.left)/scale+(dx||0)-3,y=(r.top+r.height/2-wr.top)/scale+(dy||0)-2;ptr.style.transform='translate('+x+'px,'+y+'px)';return u.wait(reduce?300:850)},
   click:async function(sel,fn){chk();ptr.classList.add('press');var e=q(sel);e&&e.classList.add('hit');await u.wait(220);if(fn)fn();ptr.classList.remove('press');await u.wait(380);e&&e.classList.remove('hit')},
   tween:function(fn,ms){return new Promise(function(res,rej){var t0=performance.now();(function f(now){if(token!==my)return rej('stop');var t=Math.min(1,(now-t0)/(ms*(reduce?.4:1)));var e=t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;fn(e);t<1?requestAnimationFrame(f):res()})(t0)})},
   drag:function(fn,sel,dx,dy,ms,withPtr){chk();var e=q(sel),wr=win.getBoundingClientRect(),r=e.getBoundingClientRect();var x0=(r.left+r.width/2-wr.left)/scale-3,y0=(r.top+r.height/2-wr.top)/scale-2;ptr.classList.add('press');
    return u.tween(function(t){if(withPtr!==true||true){ptr.style.transition='none';ptr.style.transform='translate('+(x0+(withPtr===true?dx:dx)*t)+'px,'+(y0+dy*t)+'px)'}fn(t)},ms).then(function(){ptr.style.transition='';ptr.classList.remove('press')})},
   type:function(sel,txt,cps){return new Promise(function(res,rej){var e=q(sel),i=0;(function f(){if(token!==my)return rej('stop');e.textContent=txt.slice(0,++i);if(i<txt.length)setTimeout(f,1000/(cps||20)*(reduce?.4:1));else res()})()})}};
  return u}
 async function run(){var my=++token;reset();play.textContent='■ 멈춤';try{await U(my).wait(500);await C.script(U(my));play.textContent='↺ 다시 보기'}catch(e){if(e!=='stop')console.error(e)}}
 play.onclick=function(){if(play.textContent.indexOf('멈춤')>-1){token++;play.textContent='▶ 재생'}else run()};
 if(C.tryit){var tb=d.createElement('div');tb.className='ud-try';tb.innerHTML='<b>직접 눌러 보기</b> '+C.tryit.map(function(b,i){return '<button type="button" data-i="'+i+'">'+b.l+'</button>'}).join('')+'<span class="ud-try-n">(브라우저가 Ctrl+T를 쓰고 있어서 키보드 대신 단추를 눌러요)</span>';host.insertBefore(tb,host.querySelector('.ud-steps'));
  tb.querySelectorAll('button').forEach(function(bt){bt.onclick=function(){token++;play.textContent='▶ 재생';var b=C.tryit[+bt.dataset.i],u=U(token),ps=u.qa('.bib');ps.forEach(function(p){p.classList.add('sel')});hl=Math.max(0,Math.min(4,hl+b.d));hangTo(u,ps,hl);u.key(b.k);doneEl.hidden=true;steps.forEach(function(s){s.className=''})}})}
 reset();addEventListener('resize',fit);try{new ResizeObserver(fit).observe(wrap)}catch(e){}
 try{if('IntersectionObserver' in window){var seen=false,io=new IntersectionObserver(function(es){es.forEach(function(en){if(en.isIntersecting&&!seen){seen=true;io.disconnect();if(!reduce)run()}})},{threshold:.6});io.observe(wrap)}}catch(e){}
}
function init(){d.querySelectorAll('[data-udemo]').forEach(function(h){if(!h.__ud){h.__ud=1;build(h,h.dataset.udemo)}})}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',init);else init();
})();
