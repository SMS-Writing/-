
(function(){
var KO=['시발','씨발','시팔','씨팔','씨빨','시빨','쉬발','씹새','씹할','씹년','병신','븅신','지랄','좆','개새끼','개색기','개세끼','개쉐','염병','엠창','앰창','니미','느금','닥쳐라','썅','쌍년','쌍놈','창녀','갈보','화냥','한남충','김치녀','된장녀','맘충','틀딱','급식충','짱깨','쪽발이','똥남아','죽어라','뒤져라','뒈져','자살해'];
var CH=['ㅅㅂ','ㅆㅂ','ㅂㅅ','ㅄ','ㅈㄹ','ㅅㅂㄴ','ㅆㅂㄴ','ㄲㅈ','ㅈㄴ','ㅈㅅ'];
var EN=['fuck','fuk','fck','shit','bitch','bastard','asshole','cunt','nigger','nigga','faggot','whore','slut','retard','dickhead','motherfucker','bullshit'];
var EXC=['병신년','병신자','병신박해'];
function norm(t){t=String(t||'').toLowerCase();EXC.forEach(function(e){t=t.split(e).join('')});return t}
function kor(t){return t.replace(/[^가-힣ㄱ-ㅎㅏ-ㅣ]/g,'')}
function en(t){var m={'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s','!':'i'};return t.replace(/[0134-57@$!]/g,function(c){return m[c]||c}).replace(/[^a-z\s]/g,' ').replace(/(.)\1{2,}/g,'$1$1')}
window.RN='이 홈페이지에 남긴 건의·평가·한마디는 글쓰기 교과를 고치는 데 쓰는 연구 자료로 쓰일 수 있습니다. 쓸 때에는 이름 등 개인을 알아볼 수 있는 내용을 빼고 정리하는 것을 원칙으로 합니다. 원하지 않으면 남기지 않아도 되고, 건의와 한마디는 내가 지울 수 있습니다.';
window.PF={bad:function(text){var t=norm(text),k=kor(t),e=en(t),toks=e.split(/\s+/),sq=e.replace(/\s+/g,'');
 for(var i=0;i<KO.length;i++)if(k.indexOf(KO[i])>=0)return true;
 for(i=0;i<CH.length;i++)if(k.indexOf(CH[i])>=0)return true;
 for(i=0;i<EN.length;i++){var w=EN[i];if(toks.indexOf(w)>=0||toks.indexOf(w+'s')>=0||toks.indexOf(w+'ing')>=0||toks.indexOf(w+'ed')>=0)return true;if(w.length>=5&&sq.indexOf(w)>=0&&/[a-z]{1}/.test(w))return true}
 return false},
 msg:'비속어·욕설이 있는 것 같아요. 표현을 바꿔 다시 써 주세요. (자동 검사라 놓치거나 잘못 걸릴 수 있습니다.)'};
})();
window.__g2boot=function(){
var d=document,$=function(i){return d.getElementById(i)};
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function mk(s){return esc(s).replace(/__(.+?)__/g,'<i>$1</i>').replace(/\*\*(.+?)\*\*/g,'<b>$1</b>')}
function plain(s){return String(s).replace(/__|\*\*/g,'')}
function sh(a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),t=a[i];a[i]=a[j];a[j]=t}return a}
function pick(a){return a[Math.floor(Math.random()*a.length)]}
function ri(a,b){return a+Math.floor(Math.random()*(b-a+1))}
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){}return null}
var STY=[{id:'apa',n:'APA',c:'#3a5fb0'},{id:'mla',n:'MLA',c:'#8272b5'},{id:'cad',n:'Chicago Author-Date',c:'#6fa89c'},{id:'nb',n:'Chicago Notes-Bibliography',c:'#cfa04e'},{id:'ieee',n:'IEEE',c:'#8a93a0'},{id:'van',n:'Vancouver',c:'#cf7f88'},{id:'acs',n:'ACS',c:'#a8764f'}];
function sty(id){return STY.filter(function(s){return s.id===id})[0]||STY[0]}
var MIXC=null;
function myId(){if(MIXC&&ls('gmix')==='1')return MIXC;var m=ls('mystyle');return sty(m||'apa').id}
// ===== 효과 =====
function confetti(host){var c=d.createElement('div');c.className='confetti';var cols=['#8b0029','#d6b36a','#3a5fb0','#6fa89c','#cf7f88'];
 for(var i=0;i<46;i++){var s=d.createElement('i');s.style.left=Math.random()*100+'%';s.style.background=cols[i%5];s.style.animationDelay=Math.random()*.5+'s';s.style.setProperty('--dx',(Math.random()*160-80)+'px');s.style.setProperty('--rot',(Math.random()*720-360)+'deg');c.appendChild(s)}
 host.appendChild(c);setTimeout(function(){c.remove()},2600)}
// ===== 아이디·점수판(공유 db가 되면 순위 공유, 아니면 이 기기에서만) =====
var GN={abbr:'논문 약어 주관식 · 약어를 직접 써 보기',names:'이름 표기 연습 · 영문 성·이름 쓰는 법',docfind:'문서 속 인용 찾기 · 본문과 참고문헌 짝 맞추기',match:'짝 맞추기 카드 · 약어와 양식 익히기',assemble:'서지 조립 라인 · 서지 순서 익히기',traffic:'인용 신호등 · 출처 밝힐 때 판단하기',sorter:'서지 검수 라인 · 불량 서지 가려내기',explore:'논문 첫 쪽 탐험 · 서지정보 찾기',sports:'인용 올림픽 · 오류 유형 26종목 훈련',lab:'학과 실험실 · 전공 속 서지 불량 찾기',nob:'노벨상 도전 · Nature식 참고문헌',shoot:'사격 훈련 · 틀린 표기 조준하기',sec:'보안 방화벽 · 위조 서지 차단하기',plc:'위치 맞추기 퍼즐 · 표·그림·수식 자리',yut:'윷놀이 · 참고문헌 판정',sabang:'사방치기 · 본문 인용 표기',squid:'오징어 놀이 · 서지 검사 통과',mole:'두더지 잡기 · 틀린 표기 잡아내기',race:'카레이싱 · 맞고 틀린 표기 구분',claw:'인형 뽑기 · 맞는 표기 고르기',lit:'문학 인용 연습 · 시·소설 인용하기',bingo:'약어 뽑기 빙고 · 논문 약어 익히기'};
var RANKED={abbr:1,names:1,docfind:1,match:1,assemble:1,traffic:1,sorter:1,explore:1,sports:1,bingo:1,lab:1,nob:1,shoot:1,sec:1,plc:1,yut:1,sabang:1,squid:1,mole:1,race:1,claw:1,lit:1};
var SB={db:null,uid:null,can:false,p:null};
function sbInit(){if(SB.p)return SB.p;SB.p=(async function(){try{if(!window.claude||!window.claude.use)return;var db=await window.claude.use('db');if(!db)return;SB.db=db;var u=await window.claude.use('user');if(u){try{SB.uid=await u.id()}catch(e){}try{SB.can=!!(u.can&&u.can('data.write')!==false)}catch(e){SB.can=true}}}catch(e){}})();return SB.p}
function prof(){try{var p=JSON.parse(ls('gprof.v1')||'null');return p&&p.id?p:null}catch(e){return null}}
function cleanId(v){v=String(v||'').replace(/[<>]/g,'').trim().slice(0,12);return (window.PF&&PF.bad(v))?'':v}
function localBest(){try{return JSON.parse(ls('gbest.v1')||'{}')}catch(e){return {}}}
function rankTable(rows){return '<table class="rk"><thead><tr><th>순위</th><th>아이디</th><th>점수</th><th>기록</th></tr></thead><tbody>'+(rows.length?rows.map(function(r,i){return '<tr'+(r.me?' class="me"':'')+'><td>'+(i+1)+'</td><td>'+esc(r.id||'익명')+'</td><td><b>'+r.s+'</b></td><td>'+esc(r.l||'')+'</td></tr>'}).join(''):'<tr><td colspan="4">아직 기록이 없습니다. 첫 기록을 남겨 보세요.</td></tr>')+'</tbody></table>'}
async function fetchRows(g){await sbInit();var rows=[],shared=false;
 if(SB.db){try{var q=await SB.db.collection('scores').get();q.docs.forEach(function(x){var v=x.data()||{};var b=g==='total'?{s:v.total||0,l:'전체 합계'}:(v.best&&v.best[g]);if(b&&b.s>0)rows.push({id:v.id,s:b.s,l:b.l,me:x.id===SB.uid})});shared=true}catch(e){}}
 if(!shared){var p=prof(),b=localBest(),mine=g==='total'?{s:Object.keys(b).reduce(function(t,k){return t+(b[k].s||0)},0),l:'전체 합계'}:b[g];if(mine&&mine.s>0)rows.push({id:p?p.id:'나',s:mine.s,l:mine.l,me:true})}
 rows.sort(function(a,b){return b.s-a.s});return {rows:rows,shared:shared}}
async function showRank(host,g){host.innerHTML='<p class="mut">순위를 불러오는 중…</p>';var r=await fetchRows(g),top=r.rows.slice(0,10),mi=r.rows.findIndex(function(x){return x.me});
 host.innerHTML=rankTable(top)+(mi>=10?'<p class="mut">내 순위: '+(mi+1)+'위 / '+r.rows.length+'명</p>':'')+(r.shared?'':'<p class="mut">이 환경에서는 다른 사람과 순위를 함께 볼 수 없어 이 기기의 기록만 보입니다. (공유 순위는 사이트가 “참여 가능” 권한으로 공유되어 있고 로그인했을 때 보입니다.)</p>')}
async function save(g,s,label){var b=localBest();if(!b[g]||b[g].s<s){b[g]={s:s,l:label};ls('gbest.v1',JSON.stringify(b))}
 var p=prof();await sbInit();if(!p||!SB.db||!SB.uid||!SB.can)return 'local';
 try{var ref=SB.db.doc('scores/'+SB.uid),snap=await ref.get(),old=snap.exists?(snap.data().best||{}):{},nb={};Object.keys(old).forEach(function(k){nb[k]=old[k]});
  if(!nb[g]||nb[g].s<s)nb[g]={s:s,l:label};var tot=Object.keys(nb).reduce(function(t,k){return t+(nb[k].s||0)},0);
  await ref.set({id:p.id,best:nb,total:tot,upd:Date.now()});return 'shared'}catch(e){return 'local'}}
async function renameId(nid){var p=prof()||{};p.id=nid;ls('gprof.v1',JSON.stringify(p));await sbInit();
 if(SB.db&&SB.uid&&SB.can){try{var ref=SB.db.doc('scores/'+SB.uid),sn=await ref.get();if(sn.exists){var v=sn.data();v.id=nid;v.upd=Date.now();await ref.set(v)}}catch(e){}}}
async function wipeMine(){ls('gprof.v1','null');ls('gbest.v1','{}');await sbInit();
 if(SB.db&&SB.uid&&SB.can){try{await SB.db.doc('scores/'+SB.uid).delete()}catch(e){}}}
// 아이디 막대: 정하기·수정·기록 지우기
function idBar(host,onChange){if(!host)return;
 function r(){var p=prof();
  if(!p){host.innerHTML='<form class="idf"><label>아이디 <small>(2~12자, 원하는 대로)</small><input name="nid" maxlength="12" required autocomplete="off" placeholder="예: 인용왕, cite_master"></label><button class="gprimary">이 아이디로 시작</button><p class="mut">실명·학번을 쓰지 않아도 됩니다. 순위에는 이 아이디와 점수만 보입니다.</p></form>';
   host.querySelector('form').onsubmit=async function(ev){ev.preventDefault();var v=cleanId(ev.target.nid.value);if(v.length<2){var raw=ev.target.nid.value;if(PF.bad(raw)&&!host.querySelector('.pfw'))host.insertAdjacentHTML('beforeend','<p class="mut warn pfw">'+PF.msg+'</p>');return}await renameId(v);r();if(onChange)onChange()};return}
  host.innerHTML='<div class="idbar"><span>내 아이디 <b>'+esc(p.id)+'</b></span><button class="gbtn2" data-a="e">아이디 수정</button><button class="gbtn2" data-a="w">내 기록 지우기</button><span class="mut idm" aria-live="polite"></span></div>';
  host.querySelector('[data-a=e]').onclick=function(){host.innerHTML='<form class="idf in"><input name="nid" maxlength="12" required value="'+esc(p.id)+'" aria-label="새 아이디"><button class="gprimary">저장</button><button type="button" class="gbtn2" data-a="c">취소</button></form>';
   host.querySelector('[data-a=c]').onclick=r;host.querySelector('form').onsubmit=async function(ev){ev.preventDefault();var v=cleanId(ev.target.nid.value);if(v.length<2){var raw=ev.target.nid.value;if(PF.bad(raw)&&!host.querySelector('.pfw'))host.insertAdjacentHTML('beforeend','<p class="mut warn pfw">'+PF.msg+'</p>');return}await renameId(v);r();if(onChange)onChange()}};
  var wb=host.querySelector('[data-a=w]');wb.onclick=async function(){if(wb.dataset.s!=='1'){wb.dataset.s='1';wb.textContent='정말 지울까요? 한 번 더';return}await wipeMine();r();if(onChange)onChange()}}
 r()}
function scorePanel(host,g,score,label){if(!RANKED[g])return null;var w=d.createElement('div');w.className='sbp';var p=prof();
 w.innerHTML='<h3>점수 '+score+'점 <small>'+esc(label)+'</small></h3><p class="mut pn2">'+(p?esc(p.id)+' (으)로 순위에 올리는 중…':'아이디가 없어 순위에 올리지 못했습니다. 위에서 아이디를 정해 주세요.')+'</p><div class="rkh"></div>';
 host.appendChild(w);if(p)save(g,score,label).then(function(r){w.querySelector('.pn2').textContent=(r==='shared'?'순위에 올렸습니다. (아이디: '+p.id+')':'이 기기에 기록했습니다. 공유 순위에는 올라가지 않았습니다(로그인과 참여 권한이 필요합니다).');showRank(w.querySelector('.rkh'),g)});return w}
window.GSB={after:function(host,g,score,label){scorePanel(host,g,score,label)}};
// 순위 게임 쪽: 아이디를 정해야 시작
var IG=$('idgate');
if(IG){var GB=$('gbody');function lock(){if(GB)GB.classList.toggle('locked',!prof())}idBar(IG,lock);lock()}

function stars(n){return '★'.repeat(n)+'☆'.repeat(3-n)}
var GKEY='games.stars.v1';function gs(g,n){try{var a=JSON.parse(ls(GKEY)||'{}');if(!a[g]||a[g]<n){a[g]=n;ls(GKEY,JSON.stringify(a))}}catch(e){}}
function win(host,st,title,msg,btn,fn,gid,score,label){gs(gid,st);var w=d.createElement('div');w.className='gwin pop';w.innerHTML='<div class="stars">'+stars(st)+'</div><h2>'+title+'</h2><p>'+msg+'</p><div class="gbtns"><button class="gprimary">'+btn+'</button><a class="gbtn" href="games.html">게임 모음</a></div>';
 host.appendChild(w);confetti(w);w.querySelector('button').onclick=fn;if(score!=null)scorePanel(host,gid,score,label||'');w.scrollIntoView({behavior:'smooth',block:'center'})}
// ===== 내 양식 고르기 =====
var DS=null;try{DS=JSON.parse($('d-sty').textContent).sty}catch(e){}
function picker(host,cb){if(!host)return;var mixok=host.dataset.mix==='1';function r(){var m=ls('mystyle')||'apa',mx=mixok&&ls('gmix')==='1';host.innerHTML='<span class="mylab">내 인용 스타일</span>'+(mixok?'<button class="mys mixb'+(mx?' on':'')+'" style="--sc:#555" data-i="mix">양식 정하지 않고 섞어서</button>':'')+STY.map(function(s){return '<button class="mys'+(!mx&&s.id===m?' on':'')+'" style="--sc:'+s.c+'" data-i="'+s.id+'">'+esc(s.n)+'</button>'}).join('');
 host.querySelectorAll('.mys').forEach(function(b){b.onclick=function(){if(b.dataset.i==='mix'){ls('gmix','1')}else{ls('gmix','0');ls('mystyle',b.dataset.i)}r();if(cb)cb()}})}r()}
// ===== 가상 서지 만들기(연습용) =====
var AU=[['Rivera','Elena'],['Han','Sora'],['Okafor','Tunde'],['Moreno','Lucia'],['Lindqvist','Maja'],['Park','Jisoo'],['Choi','Yuna'],['Seo','Minjun'],['Cho','Hana'],['Baek','Doyun'],['Nam','Eunseo'],['Reyes','Marco']];
var TI=['crystal growth kinetics of hydrated salts in aqueous solution','reading habits of first-year university students','citation practices in undergraduate writing','sleep patterns and academic performance in adolescents','urban green space and neighborhood well-being','machine translation quality for academic abstracts','peer feedback and revision in collaborative writing','water use efficiency in small-scale rice farming','network latency in campus wireless systems','public library services during the pandemic','visual attention in scientific figure reading','noise exposure and concentration in open study rooms','dietary fiber intake and gut microbiota diversity','memory retention after spaced online quizzes','heat transfer in porous ceramic membranes','early literacy and picture book reading','bedside handover routines and patient safety on medical wards','lightweight anomaly detection for campus network traffic','minimum wage adjustments and part-time hours in small retail firms','daylight distribution in narrow urban courtyards','summit diplomacy and public attention in regional politics','seasonal variation of soil microbial diversity in alpine meadows','short video platforms and news habits of young adults','breakfast composition and mid-morning attention in university students','vibration damping in lightweight robotic arms','neighbourhood ties and civic participation in new towns','microplastic retention in small urban wetlands','moral luck and responsibility in everyday judgement','ensemble tempo coordination without a conductor','memory and narrative structure in short fiction reading','fatigue crack growth in recycled aluminium alloys','tax compliance and trust in local government','language attitudes among bilingual primary school pupils','photovoltaic output under partial shading in rooftop arrays','pain assessment tools in paediatric emergency care','interpretation of historical maps in secondary school classrooms'];
var JR=[['Lakeside Journal of Chemistry','Lakeside J. Chem.'],['Journal of Writing Studies','J. Writ. Stud.'],['International Review of Education Research','Int. Rev. Educ. Res.'],['Review of Applied Sciences','Rev. Appl. Sci.'],['Journal of Public Health Research','J. Public Health Res.'],['Proceedings of the Campus Network Society','Proc. Campus Netw. Soc.'],['Harborview Journal of Nursing Practice','Harborview J. Nurs. Pract.'],['Review of Applied Labour Economics','Rev. Appl. Labour Econ.'],['Journal of Building Form and Climate','J. Build. Form Clim.'],['Annals of Mountain Ecology','Ann. Mt. Ecol.'],['Review of Digital Media Studies','Rev. Digit. Media Stud.'],['Journal of Urban Society Studies','J. Urban Soc. Stud.'],['Journal of Music Performance Studies','J. Music Perform. Stud.'],['Journal of Practical Philosophy Review','J. Pract. Philos. Rev.']];
function cap(s){return s.charAt(0).toUpperCase()+s.slice(1)}
var SM={a:1,an:1,and:1,of:1,in:1,on:1,the:1,for:1,to:1,at:1,by:1,after:1,during:1};
function tcase(s){return s.split(' ').map(function(w,i){return (i&&SM[w])?w:cap(w)}).join(' ')}
function rec(){var n=Math.random()<.45?1:2,a=sh(AU).slice(0,n),j=pick(JR),p1=ri(10,980),pl=p1+ri(8,24);return {au:a,y:ri(2004,2025),t:cap(pick(TI)),j:j[0],ja:j[1],v:ri(3,60),i:ri(1,6),p1:p1,p2:pl}}
function shortP(a,b){a=String(a);b=String(b);if(a.length!==b.length)return b;var i=0;while(i<a.length-2&&a[i]===b[i])i++;return b.slice(i)}
function nm(sid,au){var o=[];if(sid==='apa'){o=au.map(function(x){return x[0]+', '+x[1][0]+'.'});return o.length>1?o[0]+', & '+o[1]:o[0]}
 if(sid==='mla'||sid==='cad'||sid==='nb'){return au.length>1?au[0][0]+', '+au[0][1]+', and '+au[1][1]+' '+au[1][0]:au[0][0]+', '+au[0][1]}
 if(sid==='ieee'){o=au.map(function(x){return x[1][0]+'. '+x[0]});return o.join(' and ')}
 if(sid==='van'){o=au.map(function(x){return x[0]+' '+x[1][0]});return o.join(', ')}
 return au.map(function(x){return x[0]+', '+x[1][0]+'.'}).join('; ')}
function fmt(sid,r,k){var N=nm(sid,r.au),T=r.t,Tt=tcase(r.t),P=r.p1+'–'+r.p2,e;k=k||1;
 if(sid==='apa')return [N,'('+r.y+').',T+'.','__'+r.j+'__,','__'+r.v+'__('+r.i+'),',P+'.'];
 if(sid==='mla')return [N+'.','“'+Tt+'.”','__'+r.j+'__,','vol. '+r.v+', no. '+r.i+',',r.y+',','pp. '+r.p1+'–'+shortP(r.p1,r.p2)+'.'];
 if(sid==='cad')return [N+'.',r.y+'.','“'+Tt+'.”','__'+r.j+'__',r.v+' ('+r.i+'):',r.p1+'–'+shortP(r.p1,r.p2)+'.'];
 if(sid==='nb')return [N+'.','“'+Tt+'.”','__'+r.j+'__',r.v+', no. '+r.i,'('+r.y+'):',P+'.'];
 if(sid==='ieee')return ['['+k+']',N+',','“'+T+',”','__'+r.ja+'__,','vol. '+r.v+', no. '+r.i+',','pp. '+r.p1+'–'+r.p2+',',r.y+'.'];
 if(sid==='van')return [k+'.',N+'.',T+'.',r.ja+'.',r.y+';',r.v+'('+r.i+'):',r.p1+'-'+shortP(r.p1,r.p2)+'.'];
 return [N,Tt+'.','__'+r.ja+'__','**'+r.y+'**,','__'+r.v+'__ ('+r.i+'),',P+'.']}
var PNS={apa:['저자','연도','논문 제목','학술지','권(호)','쪽'],mla:['저자','논문 제목','학술지','권·호','연도','쪽'],cad:['저자','연도','논문 제목','학술지','권(호)','쪽'],nb:['저자','논문 제목','학술지','권·호','연도','쪽'],ieee:['번호','저자','논문 제목','학술지(약어)','권·호','쪽','연도'],van:['번호','저자','논문 제목','학술지(약어)','연도','권(호)','쪽'],acs:['저자','논문 제목','학술지(약어)','연도','권(호)','쪽']};
function pidx(sid,nm){var pn=PNS[sid];for(var i=0;i<pn.length;i++)if(pn[i].indexOf(nm)===0)return i;return -1}
var ORD={apa:'저자. (연도). 제목. 학술지, 권(호), 쪽.',mla:'저자. “제목.” 학술지, vol. 권, no. 호, 연도, pp. 쪽.',cad:'저자. 연도. “제목.” 학술지 권 (호): 쪽.',nb:'저자. “제목.” 학술지 권, no. 호 (연도): 쪽.',ieee:'[번호] 저자, “제목,” 학술지(약어), vol. 권, no. 호, pp. 쪽, 연도.',van:'번호. 저자. 제목. 학술지(약어). 연도;권(호):쪽.',acs:'저자. 제목. 학술지(약어) 연도, 권(호), 쪽.'};
function scase(s){return s.replace(/ ([A-Z])/g,function(m,a){return ' '+a.toLowerCase()})}
var SENT={apa:1,ieee:1,van:1,acs:1};
var lastK='';
// 틀리는 방식 목록: 각 항목은 (양식, 조각배열, 한국어 자료인지) → {i:[바뀐 조각 번호], why, rule, tip} 또는 null
var MUTS={
 dash:function(sid,c){var i=pidx(sid,'쪽'),s=c[i];if(sid==='van'){if(!/\d-\d/.test(s))return null;c[i]=s.replace('-','–');return {i:[i],why:'쪽 범위를 엔 대시(–)로 이었습니다.',rule:'Vancouver는 쪽 범위를 하이픈(-)으로 잇습니다(예: 583-9). 다른 양식은 엔 대시(–)를 씁니다.',tip:'양식마다 “범위 기호”가 다릅니다. Vancouver만 하이픈!'}}
  if(!/\d–\d/.test(s))return null;c[i]=s.replace('–','-');return {i:[i],why:'쪽 범위를 짧은 하이픈(-)으로 이었습니다.',rule:'쪽·연도 같은 숫자 범위는 하이픈(-)이 아니라 엔 대시(–)로 잇습니다(Vancouver 제외).',tip:'하이픈은 낱말을 잇는 기호, 엔 대시는 “~부터 ~까지”를 뜻하는 기호입니다.'}},
 ital:function(sid,c){var i=pidx(sid,'학술지');if(i<0||c[i].indexOf('__')<0)return null;c[i]=c[i].replace(/__/g,'');return {i:[i],why:'학술지 이름이 기울임(이탤릭) 없이 곧게 쓰였습니다.',rule:'이 양식에서는 학술지 이름을 이탤릭(기울임)으로 씁니다.',tip:'책·학술지처럼 “큰 덩어리” 이름은 기울이고, 논문 제목은 따옴표(또는 그냥 보통체)로 씁니다.'}},
 tcase:function(sid,c,ko){if(ko)return null;var i=pidx(sid,'논문 제목'),s=c[i],n;if(SENT[sid]){n=tcase(s);if(n===s)return null;c[i]=n;return {i:[i],why:'논문 제목의 단어마다 첫 글자가 대문자입니다(Title Case).',rule:'이 양식은 영문 논문 제목을 “문장식 대문자”로 씁니다. 첫 단어와 고유명사만 대문자입니다.',tip:'APA·IEEE·Vancouver·ACS는 문장식, MLA·Chicago는 제목식(단어마다 대문자)입니다.'}}
  n=scase(s);if(n===s)return null;c[i]=n;return {i:[i],why:'논문 제목이 문장식 대문자(첫 단어만 대문자)입니다.',rule:'이 양식은 영문 제목을 “제목식 대문자”로 씁니다. 관사·전치사·접속사 말고는 단어마다 첫 글자를 대문자로 씁니다.',tip:'MLA·Chicago는 제목식, 나머지는 문장식입니다.'}},
 quote:function(sid,c){var i=pidx(sid,'논문 제목'),s=c[i];if(/[“”]/.test(s)){c[i]=s.replace(/[“”]/g,'');if(sid==='ieee')c[i]=c[i].replace(/,$/,'.');return {i:[i],why:'논문 제목에 따옴표가 없습니다.',rule:'이 양식은 논문 제목을 큰따옴표(“ ”)로 묶습니다.',tip:'따옴표를 쓰는 양식: MLA · Chicago · IEEE. 안 쓰는 양식: APA · Vancouver · ACS.'}}
  if(/[“”]/.test(s))return null;c[i]='“'+s.replace(/\.$/,'')+'.”';return {i:[i],why:'논문 제목에 따옴표를 붙였습니다.',rule:'이 양식은 논문 제목에 따옴표를 쓰지 않습니다.',tip:'따옴표를 쓰는 양식: MLA · Chicago · IEEE. 안 쓰는 양식: APA · Vancouver · ACS.'}},
 amp:function(sid,c,ko){var i=pidx(sid,'저자'),s=c[i];if(ko){if(sid==='apa'&&/, & /.test(s)){c[i]=s.replace(', & ','·');return {i:[i],why:'한국어 저자를 “·”로 이었습니다.',rule:'APA는 저자를 쉼표로 잇고 마지막 저자 앞에 &를 씁니다(한국어 저자도 이 안내서 예시에서는 같은 방식).',tip:'APA는 저자 사이 “, &”, 나머지 양식은 이 안내서의 국문 예시에서 “·”.'}}
  if(sid!=='apa'&&sid!=='ieee'&&sid!=='van'&&s.indexOf('·')>0){c[i]=s.replace('·',', & ');return {i:[i],why:'한국어 저자를 “, &”로 이었습니다.',rule:'이 안내서의 국문 예시에서 이 양식은 저자 사이를 가운뎃점(·)으로 잇습니다.',tip:'“&”는 APA의 표기입니다.'}}return null}
  if(sid==='apa'&&/, & /.test(s)){c[i]=s.replace(', & ',', and ');return {i:[i],why:'마지막 저자 앞에 “and”를 썼습니다.',rule:'APA는 마지막 저자 앞에 &를 씁니다(, & ).',tip:'and를 쓰는 양식: MLA·Chicago·IEEE. &를 쓰는 양식: APA.'}}
  if((sid==='mla'||sid==='cad'||sid==='nb'||sid==='ieee')&&/ and /.test(s)){c[i]=s.replace(' and ',' & ');return {i:[i],why:'저자 사이에 “&”를 썼습니다.',rule:'이 양식은 저자 사이에 “and”를 씁니다.',tip:'&는 APA에서만 씁니다.'}}return null},
 pp:function(sid,c){var i=pidx(sid,'쪽'),s=c[i];if(sid==='apa'&&!/^pp\./.test(s)){c[i]='pp. '+s;return {i:[i],why:'쪽수 앞에 “pp.”가 붙었습니다.',rule:'APA 참고문헌의 학술지 논문은 쪽수 앞에 pp.를 쓰지 않고 숫자만 씁니다.',tip:'pp.를 쓰는 양식: MLA·IEEE. 쓰지 않는 양식: APA·Chicago AD·Vancouver·ACS.'}}
  if((sid==='mla'||sid==='ieee')&&/^pp\./.test(s)){c[i]=s.replace(/^pp\. /,'');return {i:[i],why:'쪽수 앞의 “pp.”가 빠졌습니다.',rule:'이 양식은 쪽수 앞에 pp.를 씁니다.',tip:'pp.를 쓰는 양식: MLA·IEEE.'}}return null},
 volno:function(sid,c){var i=pidx(sid,'권'),s=c[i];if(!/vol\. /.test(s))return null;if(Math.random()<.5){c[i]=s.replace('vol. ','Vol. ').replace('no. ','No. ');return {i:[i],why:'“vol.”와 “no.”를 대문자로 썼습니다(Vol., No.).',rule:'이 양식에서는 vol.과 no.를 소문자로 씁니다.',tip:'약어는 소문자 + 마침표(vol., no., pp.)로 외우세요.'}}c[i]=s.replace('vol. ','vol ').replace('no. ','no ');return {i:[i],why:'“vol”과 “no” 뒤의 마침표가 빠졌습니다.',rule:'vol.와 no.는 줄임말이므로 마침표를 찍습니다.',tip:'줄임말은 마침표가 한 쌍!'}},
 issue:function(sid,c){var i=pidx(sid,'권'),s=c[i];if(sid==='apa'||sid==='cad'||sid==='van'||sid==='acs'){var m=s.match(/\((\d+)\)/);if(!m)return null;c[i]=s.replace(/ ?\((\d+)\)/,', no. $1');return {i:[i],why:'호를 “, no. 3” 방식으로 썼습니다.',rule:'이 양식은 권 뒤에 호를 괄호로 붙여 씁니다(예: 12(3)).',tip:'호를 “no.”로 쓰는 양식은 MLA·Chicago NB·IEEE입니다.'}}
  var m2=s.match(/, no\. (\d+)/);if(!m2)return null;c[i]=s.replace(/, no\. (\d+)/,'($1)');return {i:[i],why:'호를 괄호로 붙여 썼습니다.',rule:'이 양식은 호를 “no.”로 밝혀 씁니다.',tip:'호를 괄호로 쓰는 양식: APA·Chicago AD·Vancouver·ACS.'}},
 yparen:function(sid,c){if(sid!=='apa')return null;var i=pidx(sid,'연도');if(!/^\(/.test(c[i]))return null;c[i]=c[i].replace(/^\((\d+)\)/,'$1');return {i:[i],why:'연도에 괄호가 없습니다.',rule:'APA 참고문헌에서는 연도를 괄호에 넣고 마침표를 붙입니다. (2019).',tip:'APA: 저자 다음에 곧바로 (연도).'}},
 init:function(sid,c,ko){if(ko||!window._lastRec||(sid!=='apa'&&sid!=='ieee'&&sid!=='van'&&sid!=='acs'))return null;var i=pidx(sid,'저자'),f=window._lastRec.au[0][1],r=c[i].replace(/(^|, |; | and )([A-Z])\.(?= |,|;|$)/,function(m,a,b){return a+f}) ;if(r===c[i]&&sid==='van'){r=c[i].replace(/ ([A-Z])(,|\.|$)/,function(m,b,e){return ' '+f+e})}if(r===c[i]&&sid==='ieee'){r=c[i].replace(/(^| and )([A-Z])\. /,function(m,a,b){return a+f+' '})}if(r===c[i])return null;c[i]=r;return {i:[i],why:'이름을 이니셜이 아니라 풀어 썼습니다.',rule:'이 양식은 저자의 이름(first name)을 첫 글자 이니셜로 줄여 씁니다.',tip:'이니셜 규칙은 양식마다 달라요: APA “E.”, Vancouver “E”(점 없음), IEEE “E. Rivera”.'}},
 swap:function(sid,c){var pn=PNS[sid],lo=(sid==='ieee'||sid==='van')?1:0,n=c.length,i=ri(lo,n-2),t=c[i];c[i]=c[i+1];c[i+1]=t;return {i:[i,i+1],why:'‘'+pn[i]+'’와 ‘'+pn[i+1]+'’의 순서가 바뀌었습니다.',rule:'이 양식의 순서: '+ORD[sid],tip:'순서를 소리 내어 읽어 보세요. “'+ORD[sid].split(' ').slice(0,4).join(' ')+' …”'}},
 miss:function(sid,c){var pn=PNS[sid],lo=(sid==='ieee'||sid==='van')?1:0,n=c.length,i=ri(lo+1,n-1),nmn=pn[i];c.splice(i,1);return {i:[],gone:nmn,why:'‘'+nmn+'’이(가) 통째로 빠졌습니다.',rule:'이 양식의 필수 요소 순서: '+ORD[sid],tip:'다 쓴 뒤 “저자·연도·제목·학술지·권호·쪽”을 손가락으로 하나씩 짚어 보세요.'}},
 abbr:function(sid,c,ko){if(ko||!window._lastRec)return null;var ji=pidx(sid,'학술지');if(ji<0)return null;var ab=PNS[sid][ji].indexOf('약어')>0,r2=window._lastRec;c[ji]=ab?'__'+r2.j+'__':'__'+r2.ja+'__';if(sid==='ieee')c[ji]+=',';return {i:[ji],why:ab?'학술지 이름을 약어가 아니라 전체 이름으로 썼습니다.':'학술지 이름을 줄여 약어로 썼습니다.',rule:ab?'이 양식은 학술지 이름을 약어로 씁니다(예: Lakeside J. Chem.).':'이 양식은 학술지 이름을 줄이지 않고 전체 이름으로 씁니다.',tip:'약어를 쓰는 양식: IEEE·Vancouver·ACS. 전체 이름: APA·MLA·Chicago.'}},
 name:function(sid,c,ko){var r3=window._lastRec;if(ko||!r3)return null;var oth=pick(STY.filter(function(s){return s.id!==sid&&s.id!=='cad'&&s.id!=='nb'&&sid!=='cad'&&sid!=='nb'&&!(sid==='mla'&&(s.id==='cad'||s.id==='nb'))})),lo=(sid==='ieee'||sid==='van')?1:0;if(!oth)return null;var alt=fmt(oth.id,r3)[(oth.id==='ieee'||oth.id==='van')?1:0];if(alt===c[lo])return null;c[lo]=alt;return {i:[lo],why:'저자 이름 모양이 다른 양식('+oth.n+')의 것입니다.',rule:'저자 이름은 양식마다 모양이 다릅니다. 이 양식: '+nm(sid,r3.au),tip:'APA “성, 이니셜.” / MLA·Chicago “성, 이름” / IEEE “이니셜. 성” / Vancouver “성 이니셜”.'}},
 dot:function(sid,c){var l=c.length-1,s=c[l];if(/[.,]$/.test(s)){c[l]=s.slice(0,-1);return {i:[l],why:'맨 끝의 마침표(또는 쉼표)가 빠졌습니다.',rule:'이 양식의 서지 끝에는 마침표를 찍습니다.',tip:'항목 하나는 마침표로 끝난다고 외우세요.'}}c[l]=s+',';return {i:[l],why:'끝에 쉼표가 붙었습니다.',rule:'서지 항목은 마침표로 끝납니다.',tip:'쉼표는 항목 안에서 요소를 나눌 때만 씁니다.'}}
};
var MUT_ALL=['dash','ital','tcase','quote','amp','pp','volno','issue','yparen','init','swap','miss','abbr','name','dot'];
function defect(sid,pc,ko){var ks=sh(MUT_ALL.filter(function(k){return k!==lastK}));for(var q=0;q<ks.length;q++){var c=pc.slice(),r=MUTS[ks[q]](sid,c,ko);if(r&&c.join('|')!==pc.join('|')){lastK=ks[q];return {c:c,why:r.why,hi:r.i,gone:r.gone,rule:r.rule,tip:r.tip,kind:ks[q]}}}
 var c2=pc.slice(),r2=MUTS.dot(sid,c2);return {c:c2,why:r2.why,hi:r2.i,rule:r2.rule,tip:r2.tip,kind:'dot'}}
// 서지 7명 이상 (Vancouver) 문제
function manyItem(){var au=sh(AU).slice(0,7),r=rec();r.au=au;var A6=au.slice(0,6).map(function(x){return x[0]+' '+x[1][0]}).join(', ');var pc=fmt('van',r,ri(1,9));pc[1]=A6+', et al.';var kind=pick(['all','no','three']),c=pc.slice(),why,hi=[1];
 if(kind==='all'){c[1]=au.map(function(x){return x[0]+' '+x[1][0]}).join(', ')+'.';why='저자 7명을 모두 썼습니다. 6명 뒤에는 et al.로 줄여야 합니다.'}
 else if(kind==='no'){c[1]=A6+'.';why='7번째 이후 저자를 “et al.” 없이 그냥 잘라 버렸습니다.'}
 else{c[1]=au.slice(0,3).map(function(x){return x[0]+' '+x[1][0]}).join(', ')+', et al.';why='3명만 쓰고 et al.로 줄였습니다. 이 안내서의 Vancouver는 6명까지 씁니다.'}
 return {pc:pc,c:c,why:why,hi:hi,rule:'Vancouver: 저자가 6명까지면 모두 쓰고, 7명 이상이면 앞 6명 뒤에 et al.을 씁니다(이 안내서 12장).',tip:'“7명부터 줄인다 — 6명 + et al.” 숫자 6과 7을 같이 기억하세요.'}}
// ===== 공통 막대 =====
function modeBar(modes,cur,cb){return '<div class="gtabs">'+modes.map(function(m){return '<button class="gtab'+(m[0]===cur?' on':'')+'" data-m="'+m[0]+'">'+m[1]+'</button>'}).join('')+'</div>'}
function lives(n,max){var o='';for(var i=0;i<max;i++)o+='<i class="lf'+(i<n?'':' off')+'">♥</i>';return '<span class="lives" aria-label="목숨 '+n+'개">'+o+'</span>'}
function endGame(host,gid,score,label,again){host.innerHTML='';win(host,score>=1500?3:score>=600?2:1,'게임 종료','최종 점수는 <b>'+score+'점</b>입니다. '+esc(label),'다시 하기',again,gid,score,label)}
// ===== 짝 맞추기 =====
var M=$('mg');
if(M){var D=JSON.parse($('d-mg').textContent),mode=ls('mg.mode')||'name';
 function pool(){if(mode==='name')return D.name;var s=DS&&DS.filter(function(x){return x.id===myId()})[0],pc=[];if(s)s.p.forEach(function(p,k){var t=plain(p);if(s.pn[k]!=='논문 제목'&&t.length<=34)pc.push([s.pn[k]+' (내 양식)',t])});return pc.length>=4?pc:D.name}
 function start(){ls('mg.mode',mode);var endless=mode==='endless',rounds=0,score=0,t0=Date.now(),moves=0,miss=0;
  function round(){var pl=(endless?(Math.random()<.5?D.name:pool()):pool()),pp=sh(pl).slice(0,6),cards=sh(pp.map(function(p,i){return{k:i,t:p[0],a:1}}).concat(pp.map(function(p,i){return{k:i,t:p[1],a:0}}))),first=null,lock=false,found=0,mv=0;
   M.innerHTML=modeBar([['name','이름의 뜻(공통)'],['mine','내 양식 요소 짝'],['endless','무한 모드']],mode)+'<div class="gbar"><span>점수 <b id="msc">'+score+'</b></span><span>넘긴 횟수 <b id="mm">0</b></span><span>찾은 짝 <b id="mf">0</b> / '+pp.length+'</span>'+(endless?'<span>라운드 <b>'+(rounds+1)+'</b></span>':'')+'</div>'
   +'<div class="mgrid">'+cards.map(function(c,i){return '<button class="mcard" data-i="'+i+'" aria-label="카드 뒤집기"><span class="mi"><span class="mb"><svg viewBox="0 0 60 60" aria-hidden="true"><rect width="60" height="60" fill="#3a5fb0"/><circle cx="30" cy="30" r="14" fill="#d6b36a"/><rect x="0" y="40" width="60" height="6" fill="#8b0029"/></svg></span><span class="mfr'+(c.a?' ab':'')+'">'+esc(c.t)+'</span></span></button>'}).join('')+'</div>'+(endless?'<div class="gbtns"><button id="mstop" class="gprimary">그만하고 점수 등록</button></div>':'');
   M.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){mode=b.dataset.m;start()}});
   if(endless)$('mstop').onclick=function(){endGame(M,'match',score,'무한 모드 '+rounds+'라운드 완료',start)};
   M.querySelectorAll('.mcard').forEach(function(b){b.onclick=function(){var c=cards[+b.dataset.i];if(lock||b.classList.contains('flip')||b.classList.contains('ok'))return;b.classList.add('flip');
    if(!first){first=b;return}mv++;moves++;$('mm').textContent=mv;var c0=cards[+first.dataset.i];
    if(c0.k===c.k){var f=first;first=null;setTimeout(function(){f.classList.add('ok');b.classList.add('ok');found++;score+=100;$('msc').textContent=score;$('mf').textContent=found;
      if(found===pp.length){rounds++;if(endless){score+=Math.max(0,120-mv*8);setTimeout(round,700)}else{var sc=Math.max(50,pp.length*100+300-mv*20-Math.round((Date.now()-t0)/1000)*2),st=mv<=pp.length+3?3:mv<=pp.length*2?2:1;win(M,st,'모두 찾았습니다!',mv+'번 넘겨 '+pp.length+'쌍을 맞췄습니다.','한 판 더',start,'match',sc,(mode==='name'?'이름의 뜻':'내 양식 요소')+' · '+mv+'번')}}},350)}
    else{lock=true;var f=first;first=null;miss++;if(endless){score=Math.max(0,score-10);$('msc').textContent=score}setTimeout(function(){f.classList.remove('flip');b.classList.remove('flip');lock=false},850)}}})}
  round()}
 picker($('mys'),start);start()}
// ===== 서지 조립 라인 =====
var AS=$('asm');
if(AS&&DS){var amode=ls('asm.mode')||'one',showAll=false;
 function asm(){ls('asm.mode',amode);var sid=myId(),s0=DS.filter(function(x){return x.id===sid})[0],endless=amode==='endless',score=0,lv=5,done=0,streak=0;
  function one(sidx){var st=sty(sidx),r=endless?rec():null,base=r?fmt(sidx,r):DS.filter(function(x){return x.id===sidx})[0].p,pn=r?PNS[sidx]:DS.filter(function(x){return x.id===sidx})[0].pn,i=0,miss=0,order=sh(base.map(function(p,k){return k}));
   AS.style.setProperty('--sc',st.c);
   AS.innerHTML=modeBar([['one','예시 논문 한 판'],['endless','무한 조립']],amode)+(showAll?'<div class="gtabs">'+STY.map(function(x){return '<button class="gtab alt'+(x.id===sidx?' on':'')+'" data-k="'+x.id+'" style="--sc:'+x.c+'">'+esc(x.n)+'</button>'}).join('')+'</div>':'')
   +'<div class="gbar"><span>양식 <b>'+esc(st.n)+'</b></span><span>조각 <b id="ai">0</b> / '+base.length+'</span>'+(endless?'<span>점수 <b id="asc">'+score+'</b></span><span>목숨 '+lives(lv,5)+'</span>':'<span>실수 <b id="am">0</b></span>')+'</div>'
   +'<div class="belt"><div class="line" id="aline" aria-live="polite"><span class="ph">조각을 순서대로 눌러 여기에 놓으세요</span></div></div><div class="chips2" id="achips">'+order.map(function(k){return '<button class="chip2" data-k="'+k+'">'+mk(base[k])+'</button>'}).join('')+'</div><div class="gfb" id="afb" aria-live="polite"></div>'
   +'<div class="gbtns"><button id="aall">'+(showAll?'다른 양식 숨기기':'다른 양식도 해 보기')+'</button>'+(endless?'<button id="astop" class="gprimary">그만하고 점수 등록</button>':'')+'</div>';
   AS.querySelectorAll('.gtab[data-m]').forEach(function(b){b.onclick=function(){amode=b.dataset.m;asm()}});
   AS.querySelectorAll('.gtab.alt').forEach(function(b){b.onclick=function(){one(b.dataset.k)}});
   $('aall').onclick=function(){showAll=!showAll;one(sidx)};if(endless)$('astop').onclick=function(){endGame(AS,'assemble',score,esc(st.n)+' 무한 조립 · '+done+'건 완성',asm)};
   AS.querySelectorAll('.chip2').forEach(function(b){b.onclick=function(){var k=+b.dataset.k;
    if(k===i){var ln=$('aline');if(i===0)ln.innerHTML='';var sp=d.createElement('span');sp.className='put';sp.innerHTML=mk(base[k])+' ';ln.appendChild(sp);b.classList.add('gone');b.disabled=true;i++;$('ai').textContent=i;$('afb').textContent='';streak++;if(endless){score+=10+Math.min(20,streak);$('asc').textContent=score}
     if(i===base.length){if(endless){done++;score+=50;if(done%2===0&&lv<5)lv++;setTimeout(function(){one(sidx)},600)}else{var sc=Math.max(50,600-miss*60),stt=miss<=1?3:miss<=4?2:1;win(AS,stt,esc(st.n)+' 서지를 완성했습니다!','실수 '+miss+'회. 다른 양식으로도 조립해 보세요.','다시 하기',function(){one(sidx)},'assemble',sc,st.n+' · 예시 논문')}}}
    else{miss++;streak=0;b.classList.remove('shk');void b.offsetWidth;b.classList.add('shk');$('afb').textContent=i===0?'첫 조각이 아닙니다. 이 양식에서 맨 앞에 오는 것을 생각해 보세요.':'아직 이 조각 차례가 아닙니다.';
     if(endless){lv--;AS.querySelector('.lives').outerHTML=lives(lv,5);if(lv<=0)endGame(AS,'assemble',score,esc(st.n)+' 무한 조립 · '+done+'건 완성',asm)}else $('am').textContent=miss}}})}
  one(sid)}
 picker($('mys'),asm);asm()}
// ===== 인용 신호등 =====
var TR=$('trf');
if(TR){var TD=JSON.parse($('d-trf').textContent),tmode=ls('trf.mode')||'ten';
 function tr(){ls('trf.mode',tmode);var endless=tmode==='endless',q=sh(TD),qi=0,ok=0,streak=0,best=0,score=0,lv=3,timer=null;
  function next(){if(qi>=q.length){q=sh(TD);qi=0}return q[qi++]}
  var total=endless?1e9:10,i=0;
  function show(){var it=next(),sec=endless?Math.max(6,12-Math.floor(i/4)):12;
   TR.innerHTML=modeBar([['ten','10문제 한 판'],['endless','무한 모드(목숨 3)']],tmode)+'<div class="gbar"><span>문제 <b>'+(i+1)+(endless?'':' / 10')+'</b></span><span>점수 <b>'+score+'</b></span><span>연속 <b>'+streak+'</b></span>'+(endless?'<span>목숨 '+lives(lv,3)+'</span>':'')+'</div><div class="trow"><div class="tlight" id="tl"><i class="r"></i><i class="y"></i><i class="g"></i></div><div class="tmain"><div class="tbar"><i id="tb"></i></div><div class="tq">'+esc(it.t)+'</div><div class="tbtn"><button class="tb r" data-v="1">밝혀야 한다</button><button class="tb g" data-v="0">밝히지 않아도 된다</button></div><div class="gfb" id="tfb" aria-live="polite"></div>'+(endless?'<div class="gbtns"><button id="tstop">그만하고 점수 등록</button></div>':'')+'</div></div>';
   TR.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){tmode=b.dataset.m;tr()}});
   var tb=$('tb');tb.style.animation='none';void tb.offsetWidth;tb.style.animation='tbar '+sec+'s linear forwards';
   if(endless)$('tstop').onclick=function(){clearTimeout(timer);endGame(TR,'traffic',score,'무한 모드 '+ok+'문제 정답',tr)};
   function done(v){clearTimeout(timer);var right=(v===(it.n?1:0));TR.querySelectorAll('.tb').forEach(function(b){b.disabled=true});tb.style.animationPlayState='paused';
    if(right){ok++;streak++;best=Math.max(best,streak);score+=10+Math.min(30,streak*2)}else{streak=0;if(endless)lv--}
    $('tl').className='tlight '+(it.n?'r':'g');$('tl').classList.add('lit');
    var over=endless&&lv<=0;
    $('tfb').innerHTML=(v===-1?'<b>시간 초과.</b> ':right?'<b class="okt">정답!</b> ':'<b class="not">아쉬워요.</b> ')+'정답은 “'+(it.n?'밝혀야 한다':'밝히지 않아도 된다')+'”. '+esc(it.w)+' <button class="gprimary" id="tn">'+(over?'결과 보기':!endless&&i+1>=10?'결과 보기':'다음 →')+'</button>';
    $('tn').onclick=function(){i++;if(over)endGame(TR,'traffic',score,'무한 모드 '+ok+'문제 정답',tr);else if(!endless&&i>=10){var st=ok>=9?3:ok>=7?2:1;TR.innerHTML='';win(TR,st,ok+' / 10 정답','가장 긴 연속 정답은 '+best+'문제입니다.','한 판 더',tr,'traffic',score,'10문제 한 판 · '+ok+'/10')}else show()}}
   TR.querySelectorAll('.tb').forEach(function(b){b.onclick=function(){done(+b.dataset.v)}});
   timer=setTimeout(function(){done(-1)},sec*1000)}
  show()}
 tr()}
// ===== 서지 검수 라인(양식 택배 대체) =====
var SR=$('srt');
if(SR){var smode=ls('srt.mode')||'ten';
 function sr(){ls('srt.mode',smode);var sid=myId(),st=sty(sid),endless=smode==='endless',i=0,score=0,lv=3,streak=0,miss=0,ok=0,timer=null,total=endless?1e9:10;
  function show(){clearTimeout(timer);var r=rec();window._lastRec=r;var pc=fmt(sid,r,ri(1,9)),bad=Math.random()<.55,df=bad?defect(sid,pc):null,shown=bad?df.c:pc,sec=endless?Math.max(7,16-Math.floor(i/3)):0;
   SR.style.setProperty('--sc',st.c);
   SR.innerHTML=modeBar([['ten','10상자 한 판'],['endless','무한 검수(목숨 3)']],smode)+'<div class="gbar"><span>양식 <b>'+esc(st.n)+'</b></span><span>상자 <b>'+(i+1)+(endless?'':' / 10')+'</b></span><span>점수 <b>'+score+'</b></span>'+(endless?'<span>목숨 '+lives(lv,3)+'</span>':'')+'</div>'
   +(endless?'<div class="tbar"><i id="sbar"></i></div>':'')+'<div class="conv"><div class="pkg" id="pkg">'+shown.map(mk).join(' ')+'</div><div class="rail2"></div></div><div class="gfb" id="sfb" aria-live="polite">이 서지는 <b>'+esc(st.n)+'</b> 규칙에 맞게 쓰였을까요? 틀린 곳이 있으면 “불량”입니다.</div>'
   +'<div class="tbtn"><button class="tb g" data-v="0">합격</button><button class="tb r" data-v="1">불량</button></div><div class="gbtns"><button id="shn">힌트(내 양식 규칙)</button>'+(endless?'<button id="sstop">그만하고 점수 등록</button>':'')+'</div>';
   SR.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){smode=b.dataset.m;sr()}});
   $('shn').onclick=function(){var s=DS&&DS.filter(function(x){return x.id===sid})[0];$('sfb').innerHTML='<b>올바른 모양(예시 논문)</b> '+(s?s.p.map(mk).join(' '):'')};
   if(endless){var sb=$('sbar');sb.style.animation='tbar '+sec+'s linear forwards';$('sstop').onclick=function(){clearTimeout(timer);endGame(SR,'sorter',score,st.n+' 무한 검수 · '+ok+'건 정답',sr)};timer=setTimeout(function(){ans(-1)},sec*1000)}
   function ans(v){clearTimeout(timer);SR.querySelectorAll('.tb').forEach(function(b){b.disabled=true});var right=(v===(bad?1:0));
    if(right){ok++;streak++;score+=10+Math.min(30,streak*2)}else{streak=0;miss++;if(endless)lv--}
    $('pkg').classList.add(right?'drop':'shk');
    $('sfb').innerHTML=(v===-1?'<b>시간 초과.</b> ':right?'<b class="okt">정답!</b> ':'<b class="not">아쉬워요.</b> ')+(bad?'불량이었습니다. '+esc(df.why):'규칙에 맞는 서지였습니다.')+' <button class="gprimary" id="sn">다음 상자 →</button>';
    var over=(endless&&lv<=0);if(over||(!endless&&i+1>=10))$('sn').textContent='결과 보기';
    $('sn').onclick=function(){i++;if(over)endGame(SR,'sorter',score,st.n+' 무한 검수 · '+ok+'건 정답',sr);else if(!endless&&i>=10){var stt=miss<=1?3:miss<=3?2:1;SR.innerHTML='';win(SR,stt,'검수 완료!','10상자 중 '+ok+'개를 맞혔습니다.','한 판 더',sr,'sorter',score,st.n+' · 10상자 '+ok+'/10')}else show()}}
   SR.querySelectorAll('.tb').forEach(function(b){b.onclick=function(){ans(+b.dataset.v)}})}
  show()}
 picker($('mys'),sr);sr()}
// ===== 논문 첫 쪽 탐험 =====
var XP=$('exp');
if(XP&&DS){var xmode=ls('exp.mode')||'one';
 function xp(){ls('exp.mode',xmode);var sid=myId(),st=sty(sid),endless=xmode==='endless',score=0,lv=3,rounds=0;
  function round(){var r=endless?rec():{au:[['Kwon','Hyeok Yong'],['Chi','Eunju']],y:2012,t:'Unequal new democracies in East Asia: Rising inequality and government responses in South Korea and Taiwan',j:'Asian Survey',ja:'Asian Surv.',v:52,i:5,p1:900,p2:923};
   var F=[['author','저자'],['year','발행 연도'],['title','논문 제목'],['journal','학술지 이름'],['vol','권(Vol.)'],['no','호(No.)'],['pages','쪽 범위']],q=sh(F.map(function(f){return f[0]})),i=0,miss=0,names=r.au.map(function(x){return x[1]+' '+x[0]}).join(' and '),
   fl=Object.fromEntries?Object.fromEntries(F):{};
   XP.innerHTML=modeBar([['one','예시 논문 한 판'],['endless','무한 탐험(목숨 3)']],xmode)+'<div class="gbar"><span>찾을 것 <b id="xq"></b></span><span>찾은 정보 <b id="xn">0</b> / 7</span>'+(endless?'<span>점수 <b id="xs">'+score+'</b></span><span>목숨 '+lives(lv,3)+'</span>':'<span>실수 <b id="xm">0</b></span>')+'</div>'
   +'<div class="paper"><div class="ptop"><span class="x" data-f="journal">'+esc(r.j)+'</span><span>Vol. <span class="x" data-f="vol">'+r.v+'</span>, No. <span class="x" data-f="no">'+r.i+'</span> · <span class="x" data-f="year">'+r.y+'</span> · pp. <span class="x" data-f="pages">'+r.p1+'–'+r.p2+'</span></span></div>'
   +'<h2 class="ptitle x" data-f="title">'+esc(tcase(r.t))+'</h2><p class="pauth x" data-f="author">'+esc(names)+'</p><div class="pabs"><i></i><i></i><i></i><i></i></div><div class="pfoot"><span class="x" data-f="decoy">Page 1 of '+(r.p2-r.p1+1)+'</span><span>(PDF 파일 안의 쪽 표시)</span></div></div><div class="gfb" id="xfb" aria-live="polite"></div><div id="xref"></div>'+(endless?'<div class="gbtns"><button id="xstop">그만하고 점수 등록</button></div>':'');
   XP.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){xmode=b.dataset.m;xp()}});
   if(endless)$('xstop').onclick=function(){endGame(XP,'explore',score,st.n+' 무한 탐험 · '+rounds+'편',xp)};
   $('xq').textContent=fl[q[0]]||F.filter(function(f){return f[0]===q[0]})[0][1];
   function lab(k){return F.filter(function(f){return f[0]===k})[0][1]}
   XP.querySelectorAll('.x').forEach(function(el){el.onclick=function(ev){ev.stopPropagation();if(i>=7)return;var k=el.dataset.f,want=q[i];
    if(k===want){el.classList.add('hit');var tag=d.createElement('em');tag.className='tag2';tag.textContent=lab(k);el.appendChild(tag);i++;$('xn').textContent=i;$('xfb').innerHTML='<b class="okt">찾았습니다.</b> '+esc(lab(k));if(endless){score+=10;$('xs').textContent=score}
     if(i<7)$('xq').textContent=lab(q[i]);else{$('xq').textContent='모두 찾았습니다';rounds++;$('xref').innerHTML='<div class="ufmt"><div class="ulab">완성된 서지 ('+esc(st.n)+')</div><div class="ub cp">'+fmt(sid,r,1).map(mk).join(' ')+'</div></div>';
      if(endless){score+=40;$('xs').textContent=score;var b=d.createElement('button');b.className='gprimary';b.textContent='다음 논문 →';b.onclick=round;$('xref').appendChild(b)}
      else{var sc=Math.max(50,500-miss*50),stt=miss<=1?3:miss<=4?2:1;win(XP,stt,'정보를 모두 찾았습니다!','실수 '+miss+'회. 논문 첫 쪽에는 서지에 필요한 정보가 대부분 모여 있습니다.','한 번 더',xp,'explore',sc,st.n+' · 예시 논문')}}}
    else{miss++;el.classList.remove('shk');void el.offsetWidth;el.classList.add('shk');$('xfb').innerHTML=k==='decoy'?'“Page 1 of N”은 내려받은 파일의 쪽 번호입니다. 서지에는 논문이 학술지에서 차지하는 쪽(pp.)을 씁니다.':'그것은 <b>'+esc(k==='decoy'?'쪽 표시':lab(k))+'</b>입니다. 지금 찾을 것은 <b>'+esc(lab(want))+'</b>입니다.';
     if(endless){lv--;score=Math.max(0,score-5);XP.querySelector('.lives').outerHTML=lives(lv,3);$('xs').textContent=score;if(lv<=0)endGame(XP,'explore',score,st.n+' 무한 탐험 · '+rounds+'편',xp)}else $('xm').textContent=miss}}})}
  round()}
 picker($('mys'),xp);xp()}
// ===== 판정 게임 공통 틀(스포츠·법정·의학) =====
function hiRow(arr,hi){return arr.map(function(p,j){return '<span class="'+((hi&&hi.indexOf(j)>=0)?'hl':'')+'">'+mk(p)+'</span>'}).join(' ')}
function fixRow(it){var sh0=it.shown,f=it.fix,same=sh0.length===f.length;return f.map(function(p,j){var d=same?(sh0[j]!==p):(sh0.indexOf(p)<0);return '<span class="'+(d?'hl2':'')+'">'+mk(p)+'</span>'}).join(' ')}
function whyPanel(it,right,v){if(it.panel)return it.panel(right,v);if(!it.bad){return right?'':'<details class="why" open><summary>왜 맞는 표기일까요?</summary><div class="wr"><b>이 표기</b><div class="wrow">'+it.shown.map(mk).join(' ')+'</div></div><div class="wr"><b>이 양식의 순서</b><p>'+esc(ORD[it.sid||myId()]||'')+'</p></div><div class="wr tp"><b>기억 팁</b><p>틀렸다고 느껴질 때는 “구두점·대문자·기울임·쪽 범위 기호”를 하나씩 규칙과 맞춰 보고, 어긋난 곳이 없으면 맞는 표기입니다.</p></div></details>'}
 return '<details class="why"'+(right?'':' open')+'><summary>'+(right?'틀린 이유 자세히 보기':'왜 틀렸을까요? (눌러서 접기)')+'</summary>'
 +'<div class="wr"><b>보인 표기</b><div class="wrow">'+hiRow(it.shown,it.hi)+'</div>'+(it.gone?'<div class="wgone">빠진 곳: <b>'+esc(it.gone)+'</b></div>':'')+'</div>'
 +'<div class="wr"><b>무엇이 틀렸나</b><p>'+esc(it.why)+'</p></div>'+(it.rule?'<div class="wr"><b>규칙</b><p>'+esc(it.rule)+'</p></div>':'')
 +(it.fix?'<div class="wr"><b>바른 표기</b><div class="wrow">'+fixRow(it)+'</div></div>':'')+(it.tip?'<div class="wr tp"><b>기억 팁</b><p>'+esc(it.tip)+'</p></div>':'')+'</details>'}
function btnHTML(cfg){var sk=cfg.skin||'card',ic=cfg.icons||['',''],o='<button class="tb g sk-'+sk+'" data-v="0"><i class="ic">'+ic[0]+'</i><span>'+cfg.okL+'</span></button>',b='<button class="tb r sk-'+sk+'" data-v="1"><i class="ic">'+ic[1]+'</i><span>'+cfg.badL+'</span></button>';return '<div class="tbtn skn-'+sk+(cfg.pos?' pos-'+cfg.pos:'')+'">'+(cfg.flip?b+o:o+b)+'</div>'}
// ----- 캐릭터(이 홈페이지 웹툰의 동물 친구들, 직접 그린 그림) -----
var CHK=['dot','gur','dub','owl'],CHN={dot:'도토리',gur:'구름',dub:'두부',owl:'올빼미'};
function avatar(k,mood){var ink='#4a3a30',m=mood||'idle',eye=m==='sad'?'<path d="M21 31l5 2M39 31l-5 2" stroke="'+ink+'" stroke-width="2" stroke-linecap="round"/>':(m==='happy'?'<path d="M20 33q3-5 6 0M34 33q3-5 6 0" stroke="'+ink+'" stroke-width="2.4" fill="none" stroke-linecap="round"/>':'<circle cx="23" cy="33" r="2.6" fill="'+ink+'"/><circle cx="37" cy="33" r="2.6" fill="'+ink+'"/>'),mo=m==='sad'?'<path d="M26 44q4-4 8 0" stroke="'+ink+'" stroke-width="2" fill="none" stroke-linecap="round"/>':'<path d="M26 41q4 5 8 0" stroke="'+ink+'" stroke-width="2" fill="none" stroke-linecap="round"/>',b='';
 if(k==='dot')b='<path d="M44 44q18-4 10-30q-16 8-10 30z" fill="#a8693c" stroke="'+ink+'" stroke-width="1.6"/><circle cx="18" cy="20" r="6" fill="#c98b57" stroke="'+ink+'" stroke-width="1.6"/><circle cx="42" cy="20" r="6" fill="#c98b57" stroke="'+ink+'" stroke-width="1.6"/><ellipse cx="30" cy="36" rx="19" ry="17" fill="#c98b57" stroke="'+ink+'" stroke-width="1.8"/><ellipse cx="30" cy="42" rx="10" ry="7" fill="#f3dcbf"/>'+eye+'<ellipse cx="30" cy="39" rx="2.4" ry="1.8" fill="'+ink+'"/>'+mo+'<path d="M17 24q13-14 26 0z" fill="#7a5233" stroke="'+ink+'" stroke-width="1.6"/>';
 else if(k==='gur')b='<g fill="#fff" stroke="#8fa0c4" stroke-width="1.8"><circle cx="16" cy="32" r="11"/><circle cx="26" cy="20" r="12"/><circle cx="40" cy="21" r="12"/><circle cx="46" cy="34" r="11"/><circle cx="30" cy="44" r="11"/></g><ellipse cx="30" cy="35" rx="14" ry="12" fill="#5b5f78" stroke="'+ink+'" stroke-width="1.6"/><g transform="translate(0 -1)"><circle cx="24" cy="33" r="2.4" fill="#fff"/><circle cx="36" cy="33" r="2.4" fill="#fff"/><path d="M27 40q3 4 6 0" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round"/></g>';
 else if(k==='dub')b='<path d="M10 30l5-12 6 8 6-12 5 11 6-11 5 12 6-8 4 12z" fill="#8b7355" stroke="'+ink+'" stroke-width="1.6" stroke-linejoin="round"/><rect x="10" y="26" width="40" height="30" rx="10" fill="#f6efd8" stroke="'+ink+'" stroke-width="1.8"/>'+eye+'<ellipse cx="30" cy="39" rx="2.4" ry="1.8" fill="#b9826a"/>'+mo;
 else b='<path d="M14 18l6 8M46 18l-6 8" stroke="'+ink+'" stroke-width="3" stroke-linecap="round"/><ellipse cx="30" cy="34" rx="19" ry="21" fill="#9a785a" stroke="'+ink+'" stroke-width="1.8"/><circle cx="22" cy="30" r="8" fill="#fff" stroke="'+ink+'" stroke-width="1.6"/><circle cx="38" cy="30" r="8" fill="#fff" stroke="'+ink+'" stroke-width="1.6"/><circle cx="22" cy="31" r="3.2" fill="'+ink+'"/><circle cx="38" cy="31" r="3.2" fill="'+ink+'"/><path d="M27 37l3 6 3-6z" fill="#e6a23c" stroke="'+ink+'" stroke-width="1.2"/><path d="M13 29h5M42 29h5" stroke="'+ink+'" stroke-width="1.6"/>';
 return '<svg class="chav" viewBox="0 0 60 60" aria-hidden="true">'+b+'</svg>'}
function charFor(gid){var h=0;gid=gid||'x';for(var i=0;i<gid.length;i++)h+=gid.charCodeAt(i);return CHK[h%4]}
// ----- 양식 섞기 -----
function mixOn(){return ls('gmix')==='1'}
function mixAllow(){var g=document.getElementById('stygate');return (g&&g.dataset.mode==='lit')?['apa','mla','cad','nb']:STY.map(function(s){return s.id})}
function dragAv(trk,av,cb){var drag=false;function pos(cl){var r=trk.getBoundingClientRect(),p=Math.max(0,Math.min(1,(cl-r.left)/r.width));av.style.left=(p*100)+'%';return p}
 av.addEventListener('pointerdown',function(e){drag=true;try{av.setPointerCapture(e.pointerId)}catch(x){}av.classList.add('drag');e.preventDefault()});
 av.addEventListener('pointermove',function(e){if(drag)pos(e.clientX)});
 av.addEventListener('pointerup',function(e){if(!drag)return;drag=false;av.classList.remove('drag');var p=pos(e.clientX);if(p<.2)cb(-1);else if(p>.8)cb(1);else av.style.left='50%'});
 av.addEventListener('pointercancel',function(){drag=false;av.style.left='50%'})}
var CIRC=['①','②','③','④'];
function judgeGame(host,cfg){var mode=ls(cfg.gid+'.mode')||'ten';
 function run(){ls(cfg.gid+'.mode',mode);var endless=mode==='endless',i=0,score=0,lv=3,streak=0,ok=0,miss=0,timer=null,total=cfg.rounds||10,ck=cfg.char||charFor(cfg.gid);
  function prog(){return endless?(ok%10)/10:Math.min(1,ok/total)}
  function qtype(it){if(cfg.tfOnly||it.panel)return 'tf';var can=!!(it.opts||(it.sid&&it.fix&&it.fix.length>=3)),r=Math.random();
   if(it.bad&&it.hi&&it.hi.length&&it.shown.length>=3)return r<.34?'tf':r<.67?'where':(can?'pick':'tf');
   return can&&r<.5?'pick':'tf'}
  function mkOpts(it){var o=[];if(it.opts){var bads=sh(it.opts.filter(function(x){return !x.good})).slice(0,2),g=it.opts.filter(function(x){return x.good})[0];if(!g||bads.length<2)return null;return sh([g].concat(bads))}
   var ko=/[가-힣]/.test(it.fix.join('')),seen={},df,t;o=[{pc:it.fix,good:1}];seen[it.fix.join('|')]=1;
   for(t=0;t<10&&o.length<3;t++){df=defect(it.sid,it.fix.slice(),ko);var key=df.c.join('|');if(!seen[key]){seen[key]=1;o.push({pc:df.c,hi:df.hi,why:df.why})}}
   return o.length>=3?sh(o):null}
  function show(){clearTimeout(timer);if(host.__kb){d.removeEventListener('keydown',host.__kb);host.__kb=null}
   MIXC=mixOn()?pick(mixAllow()):null;
   var it=cfg.item(i),sec=endless?Math.max(9,20-Math.floor(i/3)):0,qt=qtype(it),os=qt==='pick'?mkOpts(it):null;if(qt==='pick'&&!os)qt='tf';
   var sn=it.sid?sty(it.sid):null,pill=(mixOn()&&sn)?'<span class="spill" style="--sc:'+sn.c+'">'+esc(sn.n)+'</span> ':'',ask=cfg.ask;
   if(mixOn()&&sn)ask=ask.replace(/내 인용 스타일/g,esc(sn.n));
   if(qt==='pick')ask='<b>세 가지 표기</b> 가운데 <b>규칙에 맞는 것</b> 하나를 고르세요.';else if(qt==='where')ask='이 표기에는 <b>틀린 곳</b>이 있습니다. 틀린 부분을 <b>직접 눌러</b> 찾으세요.';
   var area;
   if(qt==='pick')area='<div class="opts">'+os.map(function(op,k){return '<button type="button" class="opt" data-k="'+k+'"><b>'+CIRC[k]+'</b><span>'+op.pc.map(mk).join(' ')+'</span></button>'}).join('')+'</div>';
   else if(qt==='where')area='<div class="jcard whr" id="jc">'+it.shown.map(function(p,j){return '<button type="button" class="seg" data-j="'+j+'">'+mk(p)+'</button>'}).join(' ')+'</div>';
   else area='<div class="jcard" id="jc">'+it.shown.map(mk).join(' ')+'</div>';
   var dz=qt==='tf'?'<div class="dzrow"><span class="dzl">'+esc(cfg.flip?cfg.badL:cfg.okL)+'</span><div class="dzt" id="dzt"><span class="dzc" id="dzc" title="끌어서 좌우 끝으로 옮기세요">'+avatar(ck)+'</span></div><span class="dzr">'+esc(cfg.flip?cfg.okL:cfg.badL)+'</span></div><p class="dzh mut">'+esc(CHN[ck])+'를 좌우 끝으로 끌어다 놓거나, 키보드 ← → 로도 답할 수 있어요.</p>':'';
   host.innerHTML=modeBar([['ten',total+(cfg.unit||'문제')+' 한 판'],['endless','무한(목숨 3)']],mode)+(cfg.top?cfg.top(prog()):'')
    +'<div class="gbar"><span>'+(cfg.unit||'문제')+' <b>'+(i+1)+(endless?'':' / '+total)+'</b></span><span>점수 <b>'+score+'</b></span><span>연속 <b>'+streak+'</b></span>'+(endless?'<span>목숨 '+lives(lv,3)+'</span>':'')+'</div>'+(endless?'<div class="tbar"><i id="jbar"></i></div>':'')
    +(pill?'<div class="qpill">'+pill+'<small>이 문제의 양식</small></div>':'')+(qt==='tf'?area:'')+(qt!=='tf'?'<div class="gfb ask" id="jfb0">'+ask+'</div>'+area:'')
    +'<div class="gfb" id="jfb" aria-live="polite">'+(qt==='tf'?ask:'')+'</div>'+dz+(qt==='tf'?btnHTML(cfg):'')+'<div class="gbtns"><button id="jhn">힌트</button>'+(endless?'<button id="jstop">그만하고 마치기</button>':'')+'</div>';
   host.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){mode=b.dataset.m;run()}});
   $('jhn').onclick=function(){$('jfb').innerHTML='<b>힌트</b> '+(cfg.hint?cfg.hint(it):'올바른 모양: '+it.fix.map(mk).join(' '))};
   function fin(){clearTimeout(timer);var lab=cfg.label(ok,endless,i);if(endless||!(cfg.rounds||10))endGame(host,cfg.gid,score,lab,run);else{host.innerHTML='';win(host,miss<=1?3:miss<=3?2:1,cfg.doneT||'경기 종료!',total+'문제 중 '+ok+'개를 맞혔습니다.','한 번 더',run,cfg.gid,score,lab)}}
   var done=false;
   if(endless){var sb=$('jbar');sb.style.animation='tbar '+sec+'s linear forwards';$('jstop').onclick=function(){clearTimeout(timer);endGame(host,cfg.gid,score,cfg.label(ok,true,i),run)};timer=setTimeout(function(){fb(false,-1)},sec*1000)}
   function fb(right,v){if(done)return;done=true;clearTimeout(timer);if(host.__kb){d.removeEventListener('keydown',host.__kb);host.__kb=null}
    host.querySelectorAll('.tb,.opt,.seg').forEach(function(b){b.disabled=true});
    if(right){ok++;streak++;score+=10+Math.min(30,streak*2)}else{streak=0;miss++;if(endless)lv--}
    var jc=$('jc'),av=$('dzc');if(jc)jc.classList.add(right?'drop':'shk');if(av){av.classList.add(right?'cheer':'oops');av.innerHTML=avatar(ck,right?'happy':'sad')}
    if(cfg.onMove)cfg.onMove(host,prog(),right,ok,i);
    var head=(v===-1?'<b>시간 초과.</b> ':right?'<b class="okt">'+cfg.goodW+'</b> ':'<b class="not">'+cfg.badW+'</b> '),body='';
    if(qt==='tf'){head+=(it.bad?(right?'틀린 표기를 잡아냈습니다.':'틀린 표기였습니다.'):(right?'규칙에 맞는 표기였습니다.':'규칙에 맞는 표기였는데 틀렸다고 보았습니다.'));
     if(jc&&!it.panel){if(it.bad){jc.innerHTML=it.hi&&it.hi.length?hiRow(it.shown,it.hi):'<span class="hl">'+it.shown.map(mk).join(' ')+'</span>';jc.classList.add('hlk')}else jc.classList.add('okc')}
     body=whyPanel(it,right,v)}
    else if(qt==='where'){head+=(right?'맞습니다, 바로 그 부분이 틀렸습니다.':'그 부분이 아니었습니다. <mark class="hlm">노란 형광펜</mark> 부분이 틀린 곳입니다.');
     jc.querySelectorAll('.seg').forEach(function(s,j){if(it.hi.indexOf(j)>=0)s.classList.add('hl','blink');else if(v===j)s.classList.add('pickbad')});jc.classList.add('hlk');body=whyPanel(it,right,v)}
    else{var gi=0;os.forEach(function(o,k){if(o.good)gi=k});head+=(right?'규칙에 맞는 표기를 골랐습니다.':'맞는 표기는 <b>'+CIRC[gi]+'</b>번이었습니다.');
     host.querySelectorAll('.opt').forEach(function(b,k){var op=os[k];b.classList.add(op.good?'good':(v===k?'pickbad':'dim'));var sp=b.querySelector('span');if(!op.good){if(op.hi&&op.hi.length)sp.innerHTML=hiRow(op.pc,op.hi);sp.classList.add('hlk');b.insertAdjacentHTML('beforeend','<em class="owhy">✖ '+esc(op.why||'규칙에 맞지 않습니다.')+'</em>')}else b.insertAdjacentHTML('beforeend','<em class="owhy ok">✔ 규칙에 맞는 표기</em>')});
     body='<details class="why"><summary>이 양식의 순서 다시 보기</summary><div class="wr"><b>순서</b><p>'+esc(ORD[it.sid||myId()]||'')+'</p></div></details>'}
    $('jfb').innerHTML=head+body+' <button class="gprimary spkl" id="jn">다음 →</button>';
    var over=(endless&&lv<=0),last=!endless&&i+1>=total;if(over||last)$('jn').textContent='결과 보기';
    $('jn').onclick=function(){i++;if(over||last)fin();else show()}}
   if(qt==='tf'){host.querySelectorAll('.tb').forEach(function(b){b.onclick=function(){var v=+b.dataset.v;fb(v===(it.bad?1:0),v)}});
    var trk=$('dzt'),avx=$('dzc');if(trk&&avx)dragAv(trk,avx,function(side){var bs=host.querySelectorAll('.tb'),b=side<0?bs[0]:bs[1];if(b)b.click()});
    host.__kb=function(e){if(!d.body.contains(host)||done)return;if(/INPUT|TEXTAREA|SELECT/.test((e.target||{}).tagName||''))return;if(e.key==='ArrowLeft'||e.key==='ArrowRight'){var bs=host.querySelectorAll('.tb'),b=e.key==='ArrowLeft'?bs[0]:bs[1];if(b){e.preventDefault();b.click()}}};d.addEventListener('keydown',host.__kb)}
   else if(qt==='where'){host.querySelectorAll('.seg').forEach(function(b){b.onclick=function(){var j=+b.dataset.j;fb(it.hi.indexOf(j)>=0,j)}})}
   else{host.querySelectorAll('.opt').forEach(function(b){b.onclick=function(){var k=+b.dataset.k;fb(!!os[k].good,k)}});
    host.__kb=function(e){if(!d.body.contains(host)||done)return;var n=parseInt(e.key,10);if(n>=1&&n<=3){var b=host.querySelectorAll('.opt')[n-1];if(b){e.preventDefault();b.click()}}};d.addEventListener('keydown',host.__kb)}}
  show()}
 run()}
// ===== 한국어 논문(KCI 목록) 서지 틀 =====
function auK(sid,au){if(sid==='apa')return au.length>1?au.slice(0,-1).join(', ')+', & '+au[au.length-1]:au[0];if(sid==='ieee'||sid==='van')return au.join(', ');if(sid==='acs')return au.join('; ');return au.join('·')}
function fmtK(sid,r,k){var A=auK(sid,r.au),P=r.p1+'–'+r.p2,PS=r.p1+'–'+shortP(r.p1,r.p2),vi=r.v+(r.i?'('+r.i+')':''),vn=r.v+(r.i?', no. '+r.i:'');
 if(sid==='apa')return [A+'.','('+r.y+').',r.t+'.',r.j+',',vi+',',P+'.'];
 if(sid==='mla')return [A+'.','“'+r.t+'.”',r.j+',','vol. '+r.v+(r.i?', no. '+r.i:'')+',',r.y+',','pp. '+PS+'.'];
 if(sid==='cad')return [A+'.',r.y+'.','“'+r.t+'.”',r.j,vn+':',PS+'.'];
 if(sid==='nb')return [A+'.','“'+r.t+'.”',r.j,vn,'('+r.y+'):',PS+'.'];
 if(sid==='ieee')return ['['+k+']',A+',','“'+r.t+',”',r.j+',','vol. '+r.v+(r.i?', no. '+r.i:'')+',','pp. '+P+',',r.y+'.'];
 if(sid==='van')return [k+'.',A+'.',r.t+'.',r.j+'.',r.y+';',vi+':',r.p1+'-'+shortP(r.p1,r.p2)+'.'];
 return [A+'.',r.t+'.',r.j+',',r.y+',',vi+',',P+'.']}
// ===== 인용 올림픽 =====
var SP=$('spt');
if(SP){var KC=[];try{KC=JSON.parse($('d-kci').textContent)}catch(e){}
 var K='#2b3558';
 function T(x,y,r,s){return 'translate('+x+'px,'+y+'px) rotate('+(r||0)+'deg) scale('+(s||1)+')'}
 function A(id,body){return '<g class="mv" id="sa-'+id+'">'+body+'</g>'}
 function P(c,s){c=c||K;return '<circle cx="0" cy="-30" r="8" fill="'+c+'"/><path d="M0 -22V6M0 -14L-12 -4M0 -14L12 -4M0 6L-9 28M0 6L9 28" stroke="'+c+'" stroke-width="3.4" stroke-linecap="round" fill="none"/>'}
 function R(x,y,w,h,f,x2){return '<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" fill="'+f+'"'+(x2||'')+'/>'}
 function pp(n,a,b){return n%2?b:a}
 function tri(t){t=t%2;return t<=1?t:2-t}
 var OV=function(cx,cy,rx,ry,a){return [cx+rx*Math.cos(a),cy+ry*Math.sin(a)]};
 var C=function(a,b,t){return a+(b-a)*t};
 var SPORTS=[
 // ---- 구기 (필드)
 {c:'구기',id:'baseball',n:'야구',g:'세이프!',b:'아웃!',H:240,tag:'1루·2루·3루를 돌아 홈으로',
  bg:function(){var s='<rect width="800" height="240" fill="#8fc27a"/><path d="M60 240 Q400 -90 740 240Z" fill="#a6d38e"/><path d="M60 240 Q400 -90 740 240" fill="none" stroke="#5f8f55" stroke-width="8"/><circle cx="400" cy="150" r="98" fill="#d9b382"/><path d="M400 222L494 150L400 78L306 150Z" fill="#8fc27a" stroke="#fff" stroke-width="3"/><circle cx="400" cy="150" r="9" fill="#d9b382" stroke="#fff"/>';
   [[400,218,'홈'],[494,150,'1루'],[400,82,'2루'],[306,150,'3루']].forEach(function(b){s+='<rect x="'+(b[0]-8)+'" y="'+(b[1]-8)+'" width="16" height="16" fill="#fff" stroke="'+K+'" stroke-width="2" transform="rotate(45 '+b[0]+' '+b[1]+')"/><text x="'+(b[0]+(b[2]==='1루'?20:b[2]==='3루'?-34:b[2]==='홈'?14:14))+'" y="'+(b[1]+(b[2]==='2루'?-14:b[2]==='홈'?10:5))+'" font-size="13" font-weight="700" fill="'+K+'">'+b[2]+'</text>'});
   s+='<text x="400" y="36" text-anchor="middle" font-size="15" font-weight="700" fill="#3d6b34">외야</text><text x="640" y="150" font-size="13" fill="#3d6b34">우익</text><text x="130" y="150" font-size="13" fill="#3d6b34">좌익</text><text x="400" y="116" text-anchor="middle" font-size="13" font-weight="700" fill="#7a5a30">내야</text>';
   [[210,100],[400,56],[590,100],[500,166],[440,98],[360,98],[300,166],[400,236]].forEach(function(f){s+='<circle cx="'+f[0]+'" cy="'+f[1]+'" r="6" fill="#3a5fb0" stroke="#fff" stroke-width="2"/>'});return s},
  act:function(){return A('a','<circle r="8" fill="#c46a5e" stroke="#fff" stroke-width="2.5"/>')+A('b','<circle r="5.5" fill="#fff" stroke="'+K+'" stroke-width="1.8"/>')},
  pos:function(ok,t,r){var B=[[400,218],[494,150],[400,82],[306,150]],k=ok%4,b=B[k],nx=B[(k+1)%4];return {a:T(b[0],b[1]-14),b:r?T(400,150):T(nx[0],nx[1])}}},
 {c:'구기',id:'soccer',n:'축구',g:'패스 성공!',b:'오프사이드!',H:240,tag:'패스를 이어 골문으로',
  bg:function(){var s='<rect width="800" height="240" fill="#7fb56a"/>';for(var i=0;i<8;i++)s+='<rect x="'+i*100+'" width="50" height="240" fill="#8cc476"/>';return s+'<path d="M400 0V240" stroke="#fff" stroke-width="3"/><circle cx="400" cy="120" r="38" fill="none" stroke="#fff" stroke-width="3"/><rect x="696" y="70" width="62" height="100" fill="none" stroke="#fff" stroke-width="4"/><path d="M712 70V170M728 70V170M744 70V170M696 95H758M696 120H758M696 145H758" stroke="#fff" stroke-width="1.5" opacity=".7"/><rect x="740" y="86" width="22" height="68" fill="none" stroke="#fff" stroke-width="3"/>'},
  act:function(){return A('a',P('#3a5fb0'))+A('b','<circle r="9" fill="#fff" stroke="'+K+'" stroke-width="2"/><path d="M0 -6l5 4-2 6h-6l-2-6z" fill="'+K+'"/>')},
  pos:function(ok,t,r){var x=80+ok*58,y=pp(ok,70,170);return {a:T(x-24,y+22),b:r?T(x,y+40):T(x-60,y+40)}}},
 {c:'구기',id:'basketball',n:'농구',g:'골인!',b:'에어볼!',H:240,tag:'슛을 쏘아 림을 통과',
  bg:function(){return R(0,0,800,240,'#d9a066')+'<path d="M0 214H800" stroke="#fff" stroke-width="3" opacity=".8"/><rect x="722" y="40" width="8" height="90" fill="#fff" stroke="'+K+'" stroke-width="2"/><ellipse cx="700" cy="96" rx="22" ry="5" fill="none" stroke="#c46a5e" stroke-width="4"/><path d="M682 100l7 26M700 102v28M718 100l-7 26" stroke="#fff" stroke-width="1.5"/>'},
  act:function(){return A('a',P('#c46a5e'))+A('b','<circle r="12" fill="#e8873a" stroke="'+K+'" stroke-width="2"/><path d="M-12 0H12M0 -12V12" stroke="'+K+'" stroke-width="1.4"/>')},
  pos:function(ok,t,r){return {a:T(120+t*60,186),b:r?T(700,110):T(560+(ok%3)*10,60)}}},
 {c:'구기',id:'golf',n:'골프',g:'홀인!',b:'OB!',H:240,tag:'공을 그린 위 깃발로',
  bg:function(){return R(0,0,800,240,'#9bd08a')+'<path d="M0 150 Q400 90 800 140V240H0Z" fill="#b6e2a1"/><ellipse cx="700" cy="168" rx="46" ry="14" fill="#c8eab4"/><ellipse cx="700" cy="168" rx="9" ry="4" fill="'+K+'"/><path d="M700 168V90" stroke="'+K+'" stroke-width="3"/><path d="M700 90l28 10-28 10z" fill="#c46a5e"/>'},
  act:function(){return A('a','<circle r="7" fill="#fff" stroke="'+K+'" stroke-width="2"/>')},
  pos:function(ok,t,r){return {a:T(C(70,690,t),C(190,166,t)-(r?Math.sin(t*3.14)*50:0))}}},
 // ---- 라켓·네트 (왔다 갔다)
 {c:'라켓·네트',id:'tabletennis',n:'탁구',g:'득점!',b:'네트!',H:200,tag:'랠리: 공이 양쪽을 오갑니다',
  bg:function(){return R(0,0,800,200,'#e9dfc9')+R(40,124,720,14,'#2a5db0')+'<path d="M70 138V190M730 138V190" stroke="'+K+'" stroke-width="6"/><rect x="396" y="98" width="8" height="26" fill="#fff" stroke="'+K+'" stroke-width="1.6"/>'},
  act:function(){return A('a','<rect x="-6" y="-22" width="12" height="30" rx="6" fill="#c46a5e" stroke="'+K+'" stroke-width="2"/>')+A('b','<rect x="-6" y="-22" width="12" height="30" rx="6" fill="#222" stroke="'+K+'" stroke-width="2"/>')+A('c','<circle class="bnc" r="8" fill="#f2a43a" stroke="'+K+'" stroke-width="2"/>')},
  pos:function(ok,t,r){var x=pp(ok,90,710);return {a:T(60,100),b:T(740,100),c:T(r?x:(ok%2?90:710),r?100:150)}}},
 {c:'라켓·네트',id:'tennis',n:'테니스',g:'에이스!',b:'폴트!',H:200,tag:'베이스라인에서 베이스라인으로',
  bg:function(){return R(0,0,800,200,'#5a8fd0')+'<rect x="30" y="24" width="740" height="150" fill="none" stroke="#fff" stroke-width="3"/><path d="M30 64H770M30 134H770M400 64V134" stroke="#fff" stroke-width="2"/><rect x="397" y="16" width="6" height="166" fill="#fff"/>'},
  act:function(){return A('a',P('#fff'))+A('b',P('#f3ede0'))+A('c','<circle r="9" fill="#d8e84a" stroke="'+K+'" stroke-width="2"/>')},
  pos:function(ok,t,r){return {a:T(60,pp(ok,120,90)+30),b:T(740,pp(ok+1,120,90)+30),c:T(pp(ok,120,680),pp(ok,70,130))}}},
 {c:'라켓·네트',id:'badminton',n:'배드민턴',g:'스매시!',b:'아웃!',H:200,tag:'셔틀콕이 높이 넘어갑니다',
  bg:function(){return R(0,0,800,200,'#7fa79c')+'<rect x="30" y="40" width="740" height="130" fill="none" stroke="#fff" stroke-width="3"/><path d="M30 80H770M30 130H770M200 40V170M600 40V170" stroke="#fff" stroke-width="2" opacity=".8"/><path d="M400 20V176" stroke="#f3ede0" stroke-width="5"/>'},
  act:function(){return A('a','<path d="M-8 0L10 -9V9Z" fill="#fff" stroke="'+K+'" stroke-width="2"/><circle cx="-10" cy="0" r="6" fill="#f3ede0" stroke="'+K+'" stroke-width="2"/>')},
  pos:function(ok,t,r){return {a:T(pp(ok,110,690),r?(ok%2?30:30):60,ok%2?180:0)}}},
 {c:'라켓·네트',id:'volleyball',n:'배구',g:'스파이크!',b:'네트 터치!',H:220,tag:'네트 위로 공을 넘겨요',
  bg:function(){return R(0,0,800,220,'#f0d9a8')+R(0,190,800,30,'#d9b382')+'<rect x="394" y="70" width="12" height="130" fill="'+K+'"/><path d="M406 78H430M406 100H430M406 122H430" stroke="'+K+'" opacity="0"/><rect x="394" y="70" width="12" height="40" fill="#fff"/>'},
  act:function(){return A('a',P('#3a5fb0'))+A('b',P('#c46a5e'))+A('c','<circle r="12" fill="#fff" stroke="'+K+'" stroke-width="2"/><path d="M-12 0q12 -8 24 0M0 -12q-8 12 0 24" stroke="#d6b36a" stroke-width="2" fill="none"/>')},
  pos:function(ok,t,r){return {a:T(140,168),b:T(660,168),c:T(pp(ok,160,640),pp(ok,40,40))}}},
 // ---- 겨루기
 {c:'겨루기',id:'fencing',n:'펜싱',g:'찌르기 성공!',b:'파라드!',H:200,tag:'앞으로 찌르고 뒤로 물러서기',
  bg:function(){return R(0,0,800,200,'#e8e0d0')+R(40,176,720,10,'#8c8c96')+'<path d="M400 176V186" stroke="'+K+'" stroke-width="4"/>'},
  act:function(){return A('a',P('#3a5fb0')+'<path d="M12 -8L70 -14" stroke="'+K+'" stroke-width="3"/>')+A('b','<g transform="scale(-1,1)">'+P('#c46a5e')+'<path d="M12 -8L70 -14" stroke="'+K+'" stroke-width="3"/></g>')},
  pos:function(ok,t,r){var f=r?1:0,a=pp(ok,120,230),w=r?40:0;return {a:T(a+w,150),b:T(680-(a-120)-w,150)}}},
 {c:'겨루기',id:'taekwondo',n:'태권도',g:'발차기 적중!',b:'막혔다!',H:200,tag:'발차기가 들어가면 상대가 밀립니다',
  bg:function(){return R(0,0,800,200,'#f3e3c0')+R(0,176,800,24,'#c46a5e')+'<path d="M0 176H800" stroke="#fff" stroke-width="4"/>'},
  act:function(){return A('a',P('#3a5fb0')+'<path d="M0 6L38 -8" class="kick" stroke="#3a5fb0" stroke-width="4" stroke-linecap="round"/>')+A('b','<g transform="scale(-1,1)">'+P('#c46a5e')+'</g>')},
  pos:function(ok,t,r){return {a:T(220+(r?60:0),148,0,1),b:T(560+Math.min(ok,10)*10+(r?0:-30),148)}}},
 {c:'겨루기',id:'judo',n:'유도',g:'한판!',b:'버텼다!',H:200,tag:'메치면 상대가 뒤집힙니다',
  bg:function(){return R(0,0,800,200,'#d8e8c8')+R(80,150,640,40,'#7fa79c')+'<path d="M80 150H720" stroke="#fff" stroke-width="3"/>'},
  act:function(){return A('a',P('#3a5fb0'))+A('b',P('#c46a5e'))},
  pos:function(ok,t,r){return {a:T(330+(r?0:0),138),b:T(400+(r?10:0),138-(r?10:0),r?-90*Math.min(1,(ok%4+1)/2):0)}}},
 {c:'겨루기',id:'boxing',n:'복싱',g:'잽 적중!',b:'가드!',H:200,tag:'주먹이 오갑니다',
  bg:function(){return R(0,0,800,200,'#e4dcc8')+R(60,170,680,20,'#c46a5e')+'<path d="M60 90H740M60 130H740" stroke="#fff" stroke-width="5"/><path d="M60 50H740" stroke="#3a5fb0" stroke-width="5"/>'},
  act:function(){return A('a',P('#3a5fb0')+'<circle cx="16" cy="-10" r="7" fill="#c46a5e"/>')+A('b','<g transform="scale(-1,1)">'+P('#c46a5e')+'<circle cx="16" cy="-10" r="7" fill="#3a5fb0"/></g>')},
  pos:function(ok,t,r){var m=ok%2;return {a:T(260+(m&&r?50:0),148),b:T(540-(!m&&r?50:0),148)}}},
 // ---- 기록 종목
 {c:'기록',id:'weightlifting',n:'역도',g:'성공!',b:'실패!',H:240,tag:'정답마다 바벨이 위로 올라갑니다',
  bg:function(){return R(0,0,800,240,'#e6e0d4')+R(150,206,500,24,'#8c6a4a')+'<path d="M150 206H650" stroke="#fff" stroke-width="3"/><path d="M120 14V206" stroke="#c9c2b4" stroke-width="2" stroke-dasharray="4 6"/><text x="128" y="26" font-size="12" fill="'+K+'">머리 위</text>'},
  act:function(){return A('a',P('#3a5fb0'))+A('b','<path d="M-70 0H70" stroke="'+K+'" stroke-width="5"/><rect x="-62" y="-26" width="12" height="52" fill="#c46a5e" stroke="'+K+'" stroke-width="2"/><rect x="50" y="-26" width="12" height="52" fill="#c46a5e" stroke="'+K+'" stroke-width="2"/><rect x="-76" y="-18" width="8" height="36" fill="'+K+'"/><rect x="68" y="-18" width="8" height="36" fill="'+K+'"/>')},
  pos:function(ok,t,r){var h=Math.min(1,ok/10);return {a:T(400,176+(r?0:0)-h*18),b:T(400,190-h*130+(r?0:12))}}},
 {c:'기록',id:'archery',n:'양궁',g:'10점!',b:'빗나감!',H:200,tag:'과녁 한가운데로',
  bg:function(){return R(0,0,800,200,'#cfe3c4')+'<rect x="0" y="170" width="800" height="30" fill="#8fc27a"/><path d="M730 170V90" stroke="'+K+'" stroke-width="5"/><circle cx="730" cy="82" r="42" fill="#fff" stroke="'+K+'" stroke-width="2"/><circle cx="730" cy="82" r="32" fill="#222"/><circle cx="730" cy="82" r="24" fill="#3a5fb0"/><circle cx="730" cy="82" r="16" fill="#c46a5e"/><circle cx="730" cy="82" r="8" fill="#d6b36a"/>'},
  act:function(){return A('a','<path d="M-30 0H20" stroke="'+K+'" stroke-width="3"/><path d="M20 0l-8-5v10z" fill="'+K+'"/><path d="M-30 0l-8-6M-30 0l-8 6" stroke="#c46a5e" stroke-width="3"/>')},
  pos:function(ok,t,r){return {a:T(r?694:C(90,560,t),r?82+((ok*17)%30-15):94)}}},
 {c:'기록',id:'gymnastics',n:'기계체조',g:'착지 성공!',b:'감점!',H:200,tag:'도약해 공중 회전',
  bg:function(){return R(0,0,800,200,'#e8e4f0')+R(40,168,720,18,'#3a5fb0')+'<path d="M40 168H760" stroke="#fff" stroke-width="3"/>'},
  act:function(){return A('a','<circle cx="0" cy="-26" r="8" fill="#c46a5e"/><path d="M0 -18V6M-12 -10L12 -10M0 6L-9 24M0 6L9 24" stroke="#c46a5e" stroke-width="3.4" stroke-linecap="round" fill="none"/>')},
  pos:function(ok,t,r){return {a:T(C(90,700,Math.min(1,ok/10)),r?96:150,r?360*ok:0)}}},
 {c:'기록',id:'athletics',n:'육상 400m',g:'스퍼트!',b:'부정 출발!',H:240,tag:'타원 트랙을 돕니다(코너를 돌며)',
  bg:function(){return R(0,0,800,240,'#8fc27a')+'<rect x="60" y="30" width="680" height="180" rx="90" fill="#d97a5a"/><rect x="110" y="64" width="580" height="112" rx="56" fill="#8fc27a"/><path d="M400 30V64" stroke="#fff" stroke-width="4"/><text x="400" y="124" text-anchor="middle" font-size="13" fill="#3d6b34">출발·결승선은 위쪽 가운데</text>'},
  act:function(){return A('a','<circle r="8" fill="#3a5fb0" stroke="#fff" stroke-width="2.5"/>')},
  pos:function(ok){var o=OV(400,120,305,76,-Math.PI/2+ok/10*2*Math.PI);return {a:T(o[0],o[1])}}},
 {c:'기록',id:'cycling',n:'트랙 사이클',g:'추월!',b:'라인 침범!',H:240,tag:'경사진 타원 경륜장 돌기',
  bg:function(){return R(0,0,800,240,'#e8dcc4')+'<rect x="50" y="24" width="700" height="192" rx="96" fill="#d6b36a" stroke="'+K+'" stroke-width="3"/><rect x="108" y="64" width="584" height="112" rx="56" fill="#e8dcc4" stroke="'+K+'" stroke-width="2"/><path d="M80 120H120M680 120H720" stroke="#c46a5e" stroke-width="3"/>'},
  act:function(){return A('a','<circle cx="-10" cy="4" r="7" fill="none" stroke="'+K+'" stroke-width="2.5"/><circle cx="10" cy="4" r="7" fill="none" stroke="'+K+'" stroke-width="2.5"/><circle cx="0" cy="-8" r="5" fill="#c46a5e"/><path d="M-10 4L0 -4L10 4" stroke="'+K+'" stroke-width="2.5" fill="none"/>')},
  pos:function(ok){var o=OV(400,120,326,84,Math.PI/2-ok/10*2*Math.PI);return {a:T(o[0],o[1],0)}}},
 {c:'기록',id:'swimming',n:'수영',g:'터치!',b:'레인 이탈!',H:200,tag:'50m 레인을 왕복(턴)합니다',
  bg:function(){var s=R(0,0,800,200,'#9fd3ec');for(var i=0;i<5;i++)s+='<path d="M40 '+(30+i*34)+'H760" stroke="'+(i%2?'#e8873a':'#3a5fb0')+'" stroke-width="3" stroke-dasharray="6 6"/>';return s+'<path d="M40 14V186M760 14V186" stroke="'+K+'" stroke-width="4"/><text x="46" y="196" font-size="12" fill="'+K+'">벽</text><text x="734" y="196" font-size="12" fill="'+K+'">벽</text>'},
  act:function(){return A('a','<circle r="8" fill="#c46a5e" stroke="#fff" stroke-width="2"/><path d="M-18 0q8 -6 16 0" stroke="#fff" stroke-width="3" fill="none"/>')},
  pos:function(ok){var x=C(70,730,tri(ok/5));return {a:T(x,100)}}},
 // ---- 위에서 아래로
 {c:'설원·빙상',id:'alpine',n:'알파인스키',g:'게이트 통과!',b:'실격!',H:260,tag:'위에서 아래로 활강하며 깃발 통과',
  bg:function(){var s=R(0,0,800,260,'#e8f0fa')+'<path d="M300 0H500L560 260H240Z" fill="#fff"/><path d="M300 0L240 260M500 0L560 260" stroke="#cfe0f2" stroke-width="4"/>';for(var k=0;k<6;k++){var y=30+k*42,x=k%2?470+k*10:330-k*10;s+='<path d="M'+x+' '+(y-22)+'V'+y+'" stroke="'+(k%2?'#3a5fb0':'#c46a5e')+'" stroke-width="4"/><path d="M'+x+' '+(y-22)+'l16 5-16 5z" fill="'+(k%2?'#3a5fb0':'#c46a5e')+'"/>'}return s+'<text x="20" y="24" font-size="13" fill="'+K+'">출발 ▲</text><text x="20" y="250" font-size="13" fill="'+K+'">결승 ▼</text>'},
  act:function(){return A('a',P('#2b3558')+'<path d="M-12 30L12 38" stroke="#c46a5e" stroke-width="4"/>')},
  pos:function(ok){var k=Math.min(ok,10),y=36+k*20;return {a:T(400+(k%2?-34:34)*(1-k/14),y,0,0.7)}}},
 {c:'설원·빙상',id:'skijump',n:'스키점프',g:'비거리 확보!',b:'착지 불안!',H:260,tag:'스타트 슬로프를 내려와 공중으로',
  bg:function(){return R(0,0,800,260,'#dfeaf5')+'<path d="M60 20L420 160L520 170L760 244V260H60Z" fill="#fff" stroke="#9bb8d6" stroke-width="3"/><path d="M420 160L520 170" stroke="#c46a5e" stroke-width="4"/>'},
  act:function(){return A('a',P(K)+'<path d="M-14 30H16" stroke="#c46a5e" stroke-width="4"/>')},
  pos:function(ok){var t=Math.min(1,ok/10);var x=t<.5?C(90,420,t*2):C(420,700,(t-.5)*2),y=t<.5?C(24,128,t*2):C(128,206,(t-.5)*2)-Math.sin((t-.5)*2*3.14)*24;return {a:T(x,y,t<.5?24:10,.75)}}},
 {c:'설원·빙상',id:'figure',n:'피겨스케이팅',g:'점프 성공!',b:'감점!',H:240,tag:'링크를 돌며 점프·스핀',
  bg:function(){return R(0,0,800,240,'#e6f2fb')+'<ellipse cx="400" cy="120" rx="360" ry="100" fill="#f7fbff" stroke="#8fb4d8" stroke-width="4"/><path d="M160 120q80 -50 160 0t160 0t160 0" stroke="#cfe0f2" stroke-width="3" fill="none"/>'},
  act:function(){return A('a','<g class="spin"><circle cx="0" cy="-24" r="8" fill="'+K+'"/><path d="M0 -16L-16 20H16Z" fill="#c46a5e" stroke="'+K+'" stroke-width="2"/><path d="M-6 -4L-24 -12M6 -4L24 -12" stroke="'+K+'" stroke-width="3" stroke-linecap="round"/></g>')},
  pos:function(ok,t,r){var o=OV(400,120,260,64,ok/10*2*Math.PI+Math.PI);return {a:T(o[0],o[1])}}},
 {c:'설원·빙상',id:'curling',n:'컬링',g:'하우스 안착!',b:'핫 스톤!',H:260,tag:'아래에서 위의 하우스(원)로 스톤을 밀기',
  bg:function(){return R(0,0,800,260,'#e8f4fb')+'<rect x="300" y="0" width="200" height="260" fill="#fff" stroke="#9bb8d6" stroke-width="3"/><circle cx="400" cy="52" r="46" fill="#3a5fb0"/><circle cx="400" cy="52" r="32" fill="#fff"/><circle cx="400" cy="52" r="18" fill="#c46a5e"/><circle cx="400" cy="52" r="6" fill="#fff"/><path d="M300 100H500M300 230H500" stroke="#9bb8d6" stroke-width="2"/><text x="506" y="56" font-size="13" fill="'+K+'">하우스</text><text x="506" y="246" font-size="13" fill="'+K+'">핵(출발)</text>'},
  act:function(){return A('a','<ellipse rx="22" ry="16" fill="#8c8c96" stroke="'+K+'" stroke-width="2"/><rect x="-6" y="-24" width="12" height="10" fill="#c46a5e"/>')},
  pos:function(ok){var t=Math.min(1,ok/10);return {a:T(400+(ok%2?10:-10)*(1-t),C(236,64,t))}}},
 {c:'설원·빙상',id:'speed',n:'스피드스케이팅',g:'스퍼트!',b:'인코스 반칙!',H:240,tag:'빙판 타원을 돕니다',
  bg:function(){return R(0,0,800,240,'#dfeaf5')+'<rect x="60" y="30" width="680" height="180" rx="90" fill="#f4f9fd" stroke="#9bb8d6" stroke-width="4"/><rect x="120" y="70" width="560" height="100" rx="50" fill="#dfeaf5" stroke="#9bb8d6" stroke-width="3"/><path d="M400 30V70" stroke="#c46a5e" stroke-width="3" stroke-dasharray="8 6"/>'},
  act:function(){return A('a','<circle cx="0" cy="-10" r="7" fill="'+K+'"/><path d="M0 -3L10 10L-10 14M10 10L22 12" stroke="'+K+'" stroke-width="4" stroke-linecap="round" fill="none"/><path d="M-14 22H26" stroke="#c46a5e" stroke-width="4"/>')},
  pos:function(ok){var o=OV(400,120,320,78,-Math.PI/2-ok/10*2*Math.PI);return {a:T(o[0],o[1],0,.85)}}},
 // ---- 물·바다
 {c:'물·바다',id:'diving',n:'다이빙',g:'입수 성공!',b:'물이 튀었다!',H:260,tag:'10m 플랫폼에서 물속까지 아래로',
  bg:function(){return R(0,0,800,260,'#e8f4fb')+R(0,150,800,110,'#6fb5de')+'<rect x="80" y="60" width="150" height="10" fill="#c46a5e"/><rect x="150" y="70" width="14" height="190" fill="#9a9aa4"/><path d="M0 150H800" stroke="#fff" stroke-width="3"/><text x="244" y="68" font-size="13" fill="'+K+'">10m 플랫폼</text><text x="20" y="250" font-size="13" fill="#fff">풀 바닥</text>'},
  act:function(){return A('a','<g class="spin"><circle cx="0" cy="-12" r="7" fill="'+K+'"/><path d="M0 -4V16M0 16L-7 28M0 16L7 28M-10 4L10 4" stroke="'+K+'" stroke-width="3.2" stroke-linecap="round" fill="none"/></g>')},
  pos:function(ok){var t=Math.min(1,ok/10);return {a:T(C(130,430,t)+Math.sin(t*6)*8,C(30,230,t),t*540,.9)}}},
 {c:'물·바다',id:'surfing',n:'서핑',g:'파도 타기 성공!',b:'와이프아웃!',H:240,tag:'파도 위를 오른쪽에서 왼쪽 아래로 미끄러짐',
  bg:function(){return R(0,0,800,240,'#bfe4f4')+'<path d="M0 240V150Q200 60 420 120T800 70V240Z" fill="#4a9ccf"/><path d="M0 200Q200 130 420 180T800 140" stroke="#fff" stroke-width="3" fill="none" opacity=".8"/>'},
  act:function(){return A('a',P('#2b3558')+'<path d="M-24 32H24" stroke="#d6b36a" stroke-width="5" stroke-linecap="round"/>')},
  pos:function(ok){var t=Math.min(1,ok/10);return {a:T(C(700,100,t),C(86,176,t),C(-16,16,t),.8)}}},
 {c:'물·바다',id:'rowing',n:'조정',g:'호흡 일치!',b:'엇박!',H:260,tag:'위쪽 결승선까지 노를 저어 올라가기',
  bg:function(){var s=R(0,0,800,260,'#86bde0');for(var i=0;i<5;i++)s+='<path d="M'+(200+i*100)+' 0V260" stroke="#fff" stroke-width="2" stroke-dasharray="6 8" opacity=".8"/>';return s+'<path d="M180 22H620" stroke="#c46a5e" stroke-width="5"/><text x="634" y="26" font-size="13" fill="'+K+'">결승선</text><text x="634" y="252" font-size="13" fill="'+K+'">출발</text>'},
  act:function(){return A('a','<path d="M0 -42Q10 0 0 42Q-10 0 0 -42Z" fill="#d6b36a" stroke="'+K+'" stroke-width="2"/><path d="M-24 -10H24M-24 12H24" stroke="'+K+'" stroke-width="3"/>')},
  pos:function(ok){var t=Math.min(1,ok/10);return {a:T(400,C(226,56,t))}}}
 ];
 var cur=ls('oly.cur')||'baseball';
 function spo(){return SPORTS.filter(function(x){return x.id===cur})[0]||SPORTS[0]}
 function applyPos(svg,s,ok,t,r){var m=s.pos(ok,t,r);for(var k in m){var e=svg.querySelector('#sa-'+k);if(e)e.style.transform=m[k]}}
 function scene(p){var s=spo(),H=s.H||200,act=s.act(),m=s.pos(okNow,p,lastR);for(var k in m)act=act.replace('id="sa-'+k+'"','id="sa-'+k+'" style="transform:'+m[k]+'"');var h='<div class="sport"><svg viewBox="0 0 800 '+H+'" role="img" aria-label="'+esc(s.n)+' 경기장" id="spsvg">'+s.bg()+act+'</svg><div class="sptag">'+esc(s.n)+' · '+esc(s.tag)+'</div></div>';return h}
 var okNow=0,lastR=true;
 function setScene(h,p,r,ok){var sv=h.querySelector('#spsvg');if(sv)applyPos(sv,spo(),ok||0,p,r!==false)}
 function chips(){var cats=[],by={};SPORTS.forEach(function(s){if(!by[s.c]){by[s.c]=[];cats.push(s.c)}by[s.c].push(s)});$('spchips').innerHTML=cats.map(function(c){return '<div class="olyrow"><span class="olyc">'+c+'</span>'+by[c].map(function(s){return '<button class="gtab'+(s.id===cur?' on':'')+'" data-s="'+s.id+'">'+s.n+'</button>'}).join('')+'</div>'}).join('');$('spchips').querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){cur=b.dataset.s;ls('oly.cur',cur);chips();start()}})}
 var OFLAG=['⚑','✖'];
 function start(){var s=spo();okNow=0;lastR=true;judgeGame(SP,{gid:'sports',skin:'flag',icons:OFLAG,flip:(SPORTS.indexOf(s)%2===1),ask:'이 참고문헌은 <b>내 인용 스타일</b> 규칙에 맞을까요? 심판 깃발을 들어 주세요.',okL:'통과 · '+s.g.replace('!',''),badL:'반칙 · '+s.b.replace('!',''),goodW:s.g,badW:s.b,unit:'경기',rounds:10,doneT:s.n+' 경기 종료!',
  top:function(p){return scene(p)},
  onMove:function(h,p,r,ok){okNow=ok;lastR=r;setScene(h,p,r,ok);var w=h.querySelector('.sport');if(w){w.classList.remove('good','bad');void w.offsetWidth;w.classList.add(r?'good':'bad')}},
  item:function(){var sid=myId(),ko=KC.length&&Math.random()<.65,r=ko?pick(KC):rec();window._lastRec=ko?null:r;var bad=Math.random()<.5;
   if(sid==='van'&&!ko&&Math.random()<.14){var m=manyItem();return {shown:bad?m.c:m.pc,bad:bad,why:bad?m.why:'',fix:m.pc,hi:bad?m.hi:null,rule:bad?m.rule:'',tip:bad?m.tip:'',sid:sid}}
   var pc=ko?fmtK(sid,r,ri(1,9)):fmt(sid,r,ri(1,9)),df=bad?defect(sid,pc,!!ko):null;return {shown:bad?df.c:pc,bad:bad,why:bad?df.why:'',fix:pc,hi:bad?df.hi:null,gone:bad?df.gone:null,rule:bad?df.rule:'',tip:bad?df.tip:'',sid:sid}},
  label:function(ok,en){return spo().n+(en?' 무한 연전 · ':' · ')+ok+'건 정답'}});
  var sv=SP.querySelector('#spsvg');if(sv)applyPos(sv,s,0,0,true)}
 chips();picker($('mys'),start);start()}
// ===== 법정 게임(법률 문헌) =====
var CT=$('court');
if(CT){var CL=JSON.parse($('d-court').textContent);
 judgeGame(CT,{gid:'court',skin:'stamp',icons:['✔','✖'],ask:'이 인용 표기는 <b>법률문헌 인용방법 표준안</b>에 맞을까요? 맞으면 “채택”, 틀리면 “기각”입니다.',okL:'채택',badL:'기각',goodW:'탕탕! 판단이 옳습니다.',badW:'판단이 달랐습니다.',unit:'사건',rounds:10,doneT:'폐정!',
  top:function(){return '<div class="bench"><b>재판장</b> 증거로 제출된 인용 표기를 심사합니다.</div>'},
  item:function(){var c=pick(CL),bad=Math.random()<.55,b=bad?pick(c.bad):null;return {shown:[bad?b[0]:c.c],bad:bad,why:bad?b[1]:'',fix:[c.c],k:c.k}},
  hint:function(it){return '자료 유형: <b>'+esc(it.k)+'</b>. 틀 — '+esc((CL.filter(function(x){return x.k===it.k})[0]||{}).t||'')},
  label:function(ok,en){return '법정 게임'+(en?' 무한 · ':' · ')+ok+'건 정답'}})}
// ===== 의학 연구 게임(Vancouver) =====
var MD=$('medg');
if(MD){var AUM=['Kim HJ','Lee SY','Park JW','Choi MK','Jung EH','Han SW','Yoon JH','Kang DH','Seo YM','Lim BR','Shin HS','Oh TG'],AUF={'Kim HJ':'Kim Hyunjung','Lee SY':'Lee Seoyeon','Park JW':'Park Jinwoo','Choi MK':'Choi Minkyung','Jung EH':'Jung Eunhee','Han SW':'Han Sangwoo','Yoon JH':'Yoon Jihoon','Kang DH':'Kang Daehan','Seo YM':'Seo Yumi','Lim BR':'Lim Bora','Shin HS':'Shin Hyunseok','Oh TG':'Oh Taegun'};
 var TM=['Effect of spaced exercise on postoperative recovery in older adults','Sleep duration and blood pressure control in shift workers','Vitamin D supplementation and fracture risk in a community cohort','Nurse-led telephone follow-up after hospital discharge','Continuous glucose monitoring and glycemic variability in adolescents','Hand hygiene adherence in intensive care units','Dietary sodium intake and kidney function decline','Mindfulness training for chronic low back pain'];
 var JM=[['Lakeside Journal of Clinical Medicine','Lakeside J Clin Med'],['Annals of Campus Health','Ann Campus Health'],['Journal of Sleep and Nutrition Research','J Sleep Nutr Res'],['Review of Applied Nursing','Rev Appl Nurs']];
 function recMed(){var n=pick([1,2,3,4,6,6,7,8,9]),a=sh(AUM).slice(0,n),j=pick(JM),p1=ri(100,990);return {a:a,t:pick(TM),j:j,y:ri(2008,2025),v:ri(3,60),i:ri(1,12),p1:p1,p2:p1+ri(3,14)}}
 function au(a){return a.length>6?a.slice(0,6).join(', ')+', et al':a.join(', ')}
 function medItem(k){var r=recMed(),pg=r.p1+'-'+shortP(r.p1,r.p2),tail=r.y+';'+r.v+'('+r.i+'):'+pg+'.',pc=[k+'.',au(r.a)+'.',r.t+'.',r.j[1]+'.',tail],bad=Math.random()<.55,c=pc.slice(),why='';
  if(bad){var kinds=[];if(r.a.length>6)kinds.push('all');if(r.a.length<=6)kinds.push('etal');kinds=kinds.concat(['full','semi','pp','title','fname','dots']);var kd=pick(kinds);
   if(kd==='all'){c[1]=r.a.join(', ')+'.';why='저자가 7명 이상이면 앞 6명만 쓰고 et al을 붙입니다(NLM 방식).'}
   else if(kd==='etal'){c[1]=r.a[0]+', et al.';why='저자가 6명 이하이면 모두 씁니다. et al은 7명 이상일 때 씁니다.'}
   else if(kd==='full'){c[3]=r.j[0]+'.';why='학술지 이름은 표준 약어로 씁니다(마침표 없는 약어).'}
   else if(kd==='semi'){c[4]=r.y+' '+r.v+'('+r.i+'):'+pg+'.';why='연도 뒤에 세미콜론(;)을 씁니다: 연;권(호):쪽.'}
   else if(kd==='pp'){c[4]=r.y+';'+r.v+'('+r.i+'):pp. '+pg+'.';why='Vancouver는 쪽을 “pp.” 없이 숫자만 씁니다.'}
   else if(kd==='title'){c[2]=tcase(r.t)+'.';why='논문 제목은 첫 낱말만 대문자로 씁니다.'}
   else if(kd==='fname'){c[1]=au([AUF[r.a[0]]].concat(r.a.slice(1)))+'.';why='저자는 “성 이름 첫 글자들”(예: Kim HJ)로 씁니다. 이름을 풀어 쓰지 않습니다.'}
   else{var p=r.a[0].split(' ');c[1]=au([p[0]+' '+p[1].split('').join('.')+'.'].concat(r.a.slice(1)))+'.';why='이니셜 사이에 마침표를 찍지 않습니다(Kim HJ).'}}
  return {shown:bad?c:pc,bad:bad,why:why,fix:pc}}
 judgeGame(MD,{gid:'medical',skin:'pill',icons:['℞','✖'],ask:'이 참고문헌은 <b>Vancouver(NLM 방식)</b>에 맞을까요? 서지는 모두 연습용으로 만든 가상 자료입니다.',okL:'적합',badL:'수정 필요',goodW:'정확한 판독입니다.',badW:'놓쳤습니다.',unit:'차트',rounds:10,doneT:'검토 완료!',
  top:function(p){var n=Math.min(6,Math.round(p*6)),bd='';for(var i=0;i<6;i++){var x=24+i*126,ok=i<n;bd+='<g transform="translate('+x+' 92)"><rect x="0" y="22" width="108" height="38" rx="6" fill="#f4f1ea" stroke="#2b3558" stroke-width="2.4"/><rect x="0" y="14" width="22" height="46" rx="5" fill="#cfd8ea" stroke="#2b3558" stroke-width="2.4"/><ellipse cx="54" cy="32" rx="32" ry="12" fill="'+(ok?'#bfe8cf':'#f6c9c0')+'" stroke="#2b3558" stroke-width="2"/><circle cx="38" cy="24" r="12" fill="#e8c4a0" stroke="#2b3558" stroke-width="2"/><circle cx="34" cy="23" r="1.6" fill="#2b3558"/><circle cx="42" cy="23" r="1.6" fill="#2b3558"/><path d="M34 29q4 '+(ok?'4':'-3')+' 8 0" stroke="#2b3558" stroke-width="1.6" fill="none"/>'+(ok?'<text x="82" y="14" font-size="16" fill="#2b8a56">✔</text>':'<text x="82" y="14" font-size="14" fill="#c93a22">차트 대기</text>')+'<rect x="8" y="62" width="6" height="14" fill="#2b3558"/><rect x="94" y="62" width="6" height="14" fill="#2b3558"/></g>'}
 return '<div class="ward"><svg viewBox="0 0 780 180" role="img" aria-label="병동에서 환자 침대 여섯 개"><rect width="780" height="180" fill="#e8f4f2"/><rect x="0" y="150" width="780" height="30" fill="#cfe2dd"/><path d="M0 40H780" stroke="#bcd6cf" stroke-width="3"/><rect x="330" y="8" width="120" height="26" rx="5" fill="#fff" stroke="#2b3558" stroke-width="2"/><path d="M382 12v18M372 21h20" stroke="#c93a22" stroke-width="5"/>'+bd+'</svg><p class="mut"><b>병동 회진</b> 차트(참고문헌)가 Vancouver 규칙에 맞으면 처방을 승인하고, 틀리면 반려하세요. 승인이 맞으면 환자가 회복합니다. <span class="wd">회복 '+n+' / 6</span></p></div>'},
  item:function(i){return medItem(i+1)},hint:function(it){return 'Vancouver 모양: <b>번호. 저자(앞 6명). 제목. 학술지약어. 연;권(호):쪽.</b>'},
  label:function(ok,en){return '의학 연구 게임'+(en?' 무한 · ':' · ')+ok+'건 정답'}})}
// ===== 허브: 내 양식 + 순위 =====
if($('hubmys'))picker($('hubmys'));
if($('hubid'))idBar($('hubid'),function(){var b=d.querySelector('#rtabs .gtab.on');if(b)showRank($('rkt'),b.dataset.g)});
var A=(function(){try{return JSON.parse(ls(GKEY)||'{}')}catch(e){return {}}})();d.querySelectorAll('.gst').forEach(function(x){x.textContent=stars(A[x.dataset.g]||0)});
var RB=$('rankbox');
if(RB){var tabs=[['total','전체 합계']].concat(Object.keys(GN).map(function(k){return [k,GN[k]]}));
 RB.innerHTML='<div class="gtabs" id="rtabs">'+tabs.map(function(t,i){return '<button class="gtab'+(i?'':' on')+'" data-g="'+t[0]+'">'+esc(t[1])+'</button>'}).join('')+'</div><div id="rkt"></div>';
 function rk(g){showRank($('rkt'),g)}rk('total');
 RB.querySelectorAll('.gtab').forEach(function(b){b.onclick=function(){RB.querySelectorAll('.gtab').forEach(function(x){x.classList.toggle('on',x===b)});rk(b.dataset.g)}})}
// ===== 건의함 =====
var SG=$('sgf');
if(SG){var admin=$('sgadmin');
 window.sgMineDraw=function(){var box=$('sgmine');if(!box)return;var ml=[];try{ml=JSON.parse(ls('sg.mine.v1')||'[]')}catch(e){}
  box.innerHTML=ml.length?'<h3 class="gh3">내가 보낸 건의 <small>이 기기에서 보낸 것만 보입니다</small></h3>'+ml.slice().reverse().map(function(v){return '<div class="sgm1"><span>'+esc(v.kind||'')+' · '+esc(v.text||'')+'…</span><button class="gbtn2" data-k="'+v.k+'">지우기</button></div>'}).join(''):'';
  box.querySelectorAll('button').forEach(function(b){b.onclick=async function(){if(b.dataset.s!=='1'){b.dataset.s='1';b.textContent='정말 지울까요?';return}var k=b.dataset.k;
   try{await sbInit();if(SB.db&&SB.uid){var rf=SB.db.doc('suggest/'+SB.uid),sn=await rf.get();if(sn.exists){var its=(sn.data().items||[]).filter(function(x){return x.k!==k});await rf.set({items:its,upd:Date.now()})}}}catch(e){}
   try{var l2=JSON.parse(ls('sg.mine.v1')||'[]').filter(function(x){return x.k!==k});ls('sg.mine.v1',JSON.stringify(l2))}catch(e){}window.sgMineDraw()}})};
 window.sgMineDraw();
 SG.onsubmit=async function(ev){ev.preventDefault();var t=SG.text.value.trim();if(!t)return;var msg=$('sgm');if(PF.bad(t+' '+SG.who.value+' '+SG.page.value)){msg.textContent=PF.msg;return}await sbInit();var item={k:Date.now().toString(36)+Math.random().toString(36).slice(2,6),kind:SG.kind.value,text:t,name:SG.who.value.trim(),page:SG.page.value.trim(),at:Date.now()};try{var ml=JSON.parse(ls('sg.mine.v1')||'[]');ml.push({k:item.k,kind:item.kind,text:t.slice(0,50),at:item.at});ls('sg.mine.v1',JSON.stringify(ml.slice(-30)))}catch(e){}if(window.sgMineDraw)setTimeout(window.sgMineDraw,50);
  if(SB.db&&SB.can&&SB.uid){try{var rf=SB.db.doc('suggest/'+SB.uid),sn=await rf.get(),its=sn.exists?(sn.data().items||[]):[];its.push(item);await rf.set({items:its.slice(-50),upd:Date.now()});SG.reset();msg.textContent='건의가 접수되었습니다. 감사합니다.';return}catch(e){}}
  msg.innerHTML='이 환경에서는 건의를 바로 보낼 수 없습니다(로그인과 참여 권한이 필요합니다). 아래 내용을 복사해 담당 교수자에게 전달해 주세요.<textarea readonly rows="4" class="sgcopy">['+esc(item.kind)+'] '+esc(item.text)+(item.page?' (쪽: '+esc(item.page)+')':'')+'</textarea>'};
 (async function(){await sbInit();if(!SB.db)return;var u=null;try{u=await window.claude.use('user')}catch(e){}if(!(u&&u.canEdit&&u.canEdit()))return;admin.hidden=false;var box=$('sglist');
  try{SB.db.collection('suggest').onSnapshot(function(sn){var all=[];sn.docs.forEach(function(x){((x.data()||{}).items||[]).forEach(function(v){all.push(v)})});all.sort(function(a,b){return (b.at||0)-(a.at||0)});box.innerHTML=all.length?all.map(function(v){return '<article class="sgi"><b>'+esc(v.kind||'')+'</b> <span class="mut">'+new Date(v.at||0).toLocaleString('ko-KR')+(v.name?' · '+esc(v.name):'')+(v.page?' · '+esc(v.page):'')+'</span><p>'+esc(v.text||'')+'</p></article>'}).join(''):'<p class="mut">아직 건의가 없습니다.</p>'},function(){})}catch(e){}
  })()}

// ===== 익명 한마디(무한 모드가 있는 게임에만) =====
var GC=$('gcom');
if(GC){var gcg=GC.dataset.g,GLK='gcom.local.v1',GMK='gcom.mine.v1',gcLast=0;
 function lget(k){try{return JSON.parse(ls(k)||'[]')}catch(e){return []}}
 function rid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
 function ago(t){var s=Math.max(0,(Date.now()-t)/1000);if(s<60)return '방금';if(s<3600)return Math.floor(s/60)+'분 전';if(s<86400)return Math.floor(s/3600)+'시간 전';return Math.floor(s/86400)+'일 전'}
 GC.innerHTML='<section class="gc"><h2 class="gt">익명 한마디</h2><p class="mut">이 게임을 해 본 느낌, 어려웠던 점, 고치면 좋을 점을 이름 없이 남길 수 있습니다. 화면에는 글과 시각만 보이고 이름·학번은 보이지 않습니다. 서로 존중하는 말만 써 주세요.</p><p class="rnote"><b>알림</b> '+window.RN+'</p>'
  +'<form class="gcf"><textarea maxlength="200" rows="2" required placeholder="예: 무한 모드 3단계부터 너무 빨라요 / 힌트가 있으면 좋겠어요"></textarea><div class="gcb"><small class="cnt">0/200</small><button class="gprimary">익명으로 남기기</button></div><p class="gcm" aria-live="polite"></p></form><div class="gcl"></div></section>';
 var fm=GC.querySelector('form'),ta=fm.querySelector('textarea'),cnt=fm.querySelector('.cnt'),msg=fm.querySelector('.gcm'),list=GC.querySelector('.gcl'),shared=[],isOwner=false;
 ta.oninput=function(){cnt.textContent=ta.value.length+'/200'};
 function draw(){var mine=lget(GMK),loc=lget(GLK).filter(function(v){return v.g===gcg}),all=shared.filter(function(v){return v.g===gcg});
  loc.forEach(function(v){if(!all.some(function(x){return x.k===v.k}))all.push(v)});all.sort(function(a,b){return (b.at||0)-(a.at||0)});all=all.slice(0,30);
  list.innerHTML=all.length?all.map(function(v){var own=mine.indexOf(v.k)>=0;return '<article class="gci"><p>'+esc(v.text)+'</p><span class="mut">익명 · '+ago(v.at||0)+(v.loc?' · 이 기기에서만 보임':'')+'</span>'+((own||isOwner)?' <button class="gdel2" data-k="'+esc(v.k)+'" data-d="'+(v.doc||'')+'">삭제</button>':'')+'</article>'}).join(''):'<p class="mut">아직 남은 글이 없습니다. 첫 한마디를 남겨 보세요.</p>';
  list.querySelectorAll('.gdel2').forEach(function(b){b.onclick=async function(){var k=b.dataset.k;
   var l=lget(GLK).filter(function(v){return v.k!==k});ls(GLK,JSON.stringify(l));
   try{var docid=b.dataset.d||(SB.uid||'');if(SB.db&&docid){var rf=SB.db.doc('gcomments/'+docid),sn=await rf.get();if(sn.exists){var its=(sn.data().items||[]).filter(function(v){return v.k!==k});await rf.set({items:its,upd:Date.now()})}}}catch(e){}
   shared=shared.filter(function(v){return v.k!==k});draw()}})}
 fm.onsubmit=async function(ev){ev.preventDefault();var t=ta.value.trim();if(!t)return;if(PF.bad(t)){msg.textContent=PF.msg;return}if(Date.now()-gcLast<20000){msg.textContent='잠시 뒤에 다시 남겨 주세요(20초 간격).';return}
  await sbInit();var item={g:gcg,text:t,at:Date.now(),k:rid()};gcLast=Date.now();var mine=lget(GMK);mine.push(item.k);ls(GMK,JSON.stringify(mine.slice(-100)));
  if(SB.db&&SB.can&&SB.uid){try{var rf=SB.db.doc('gcomments/'+SB.uid),sn=await rf.get(),its=sn.exists?(sn.data().items||[]):[];its.push(item);await rf.set({items:its.slice(-50),upd:Date.now()});shared.push({g:item.g,text:item.text,at:item.at,k:item.k,doc:SB.uid});ta.value='';cnt.textContent='0/200';msg.textContent='남겼습니다. 이름은 화면에 나오지 않습니다.';draw();return}catch(e){}}
  item.loc=1;var l=lget(GLK);l.push(item);ls(GLK,JSON.stringify(l.slice(-50)));ta.value='';cnt.textContent='0/200';msg.textContent='이 환경에서는 모두에게 공유할 수 없어 이 기기에만 저장했습니다(공유하려면 로그인과 참여 권한이 필요합니다).';draw()};
 draw();
 (async function(){await sbInit();if(!SB.db)return;try{var u=await window.claude.use('user');isOwner=!!(u&&u.isOwner&&u.isOwner())}catch(e){}
  try{SB.db.collection('gcomments').onSnapshot(function(sn){var a=[];sn.docs.forEach(function(x){((x.data()||{}).items||[]).forEach(function(v){a.push({g:v.g,text:v.text,at:v.at,k:v.k,doc:x.id})})});shared=a;draw()},function(){})}catch(e){}})()}
function qitem(){var KCs=[];try{KCs=JSON.parse($('d-kci').textContent)}catch(e){}var sid=(mixOn()&&!MIXC)?pick(mixAllow()):myId(),ko=KCs.length&&Math.random()<.65,r=ko?pick(KCs):rec();window._lastRec=ko?null:r;var pc=ko?fmtK(sid,r,ri(1,9)):fmt(sid,r,ri(1,9)),bad=Math.random()<.5,df=bad?defect(sid,pc,!!ko):null;return {shown:bad?df.c:pc,bad:bad,why:bad?df.why:'',fix:pc,hi:bad?df.hi:null,gone:bad?df.gone:null,rule:bad?df.rule:'',tip:bad?df.tip:'',sid:sid}}
function spill(it){return (mixOn()&&it&&it.sid)?'<span class="spill sm" style="--sc:'+sty(it.sid).c+'">'+esc(sty(it.sid).n)+'</span> ':''}
window.GX={spill:spill,avatar:avatar,charFor:charFor,CHN:CHN,CHK:CHK,mixOn:mixOn,mixAllow:mixAllow,dragAv:dragAv,whyPanel:whyPanel,hiRow:hiRow,ls:ls,AU:AU,esc:esc,mk:mk,plain:plain,sh:sh,pick:pick,ri:ri,ls:ls,STY:STY,sty:sty,myId:myId,fmt:fmt,fmtK:fmtK,defect:defect,manyItem:manyItem,ORD:ORD,rec:rec,tcase:tcase,shortP:shortP,qitem:qitem,judgeGame:judgeGame,endGame:endGame,win:win,lives:lives,modeBar:modeBar,confetti:confetti,sbInit:sbInit,SB:SB,prof:prof,idBar:idBar,picker:picker,PNS:PNS,AU:AU};
};
if(!document.getElementById("stygate"))window.__g2boot();
